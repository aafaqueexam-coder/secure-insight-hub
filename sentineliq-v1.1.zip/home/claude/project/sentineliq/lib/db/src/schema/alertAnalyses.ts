import { pgTable, text, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const alertAnalysesTable = pgTable("alert_analyses", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  alertId: text("alert_id").notNull().unique(),
  organizationId: text("organization_id").notNull(),
  summary: text("summary").notNull(),
  threatDescription: text("threat_description").notNull(),
  businessImpact: text("business_impact").notNull(),
  investigationSteps: text("investigation_steps").array().notNull().default([]),
  remediationPlan: text("remediation_plan").array().notNull().default([]),
  recommendedActions: text("recommended_actions").array().notNull().default([]),
  containmentActions: text("containment_actions").array().notNull().default([]),
  affectedAssets: text("affected_assets").array().notNull().default([]),
  analystNotes: text("analyst_notes").notNull().default(""),
  executiveSummary: text("executive_summary").notNull().default(""),
  confidenceScore: real("confidence_score").notNull().default(0),
  severity: text("severity").notNull().default("medium"),
  generatedAt: timestamp("generated_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAlertAnalysisSchema = createInsertSchema(alertAnalysesTable).omit({ id: true, createdAt: true });
export type InsertAlertAnalysis = z.infer<typeof insertAlertAnalysisSchema>;
export type AlertAnalysis = typeof alertAnalysesTable.$inferSelect;
