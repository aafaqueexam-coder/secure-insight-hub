import { pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const wazuhConnectionsTable = pgTable("wazuh_connections", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  name: text("name").notNull(),
  apiUrl: text("api_url").notNull(),
  username: text("username").notNull(),
  passwordHash: text("password_hash").notNull(),
  status: text("status").notNull().default("pending"),
  syncInterval: integer("sync_interval").notNull().default(300),
  lastSyncAt: timestamp("last_sync_at", { withTimezone: true }),
  lastSyncStatus: text("last_sync_status"),
  agentCount: integer("agent_count"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertWazuhConnectionSchema = createInsertSchema(wazuhConnectionsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertWazuhConnection = z.infer<typeof insertWazuhConnectionSchema>;
export type WazuhConnection = typeof wazuhConnectionsTable.$inferSelect;
