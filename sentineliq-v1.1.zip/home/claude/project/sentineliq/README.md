# SentinelIQ — MDR Platform

A full-stack Managed Detection and Response (MDR) platform built with:

- **Backend**: Node.js · Express · Drizzle ORM · PostgreSQL · OpenAI
- **Frontend**: React · Vite · Tailwind CSS · shadcn/ui
- **Integrations**: Wazuh SIEM · Clerk Auth · Web Push · SMTP

## Features

| Domain | Capabilities |
|--------|-------------|
| Alert Management | Advanced filtering, bulk actions, AI investigation pipeline, pagination |
| AI Pipeline | Prompt versioning, token tracking, response caching, retry logic |
| Incident Management | Full workflow (Open → Assigned → Investigating → Resolved), timeline, evidence |
| Threat Intelligence | IP/domain/hash enrichment, GeoIP, ASN, threat feeds, IOC database |
| Compliance | PCI DSS · ISO 27001 · CIS Controls · NIST CSF · HIPAA — live scoring |
| Rule Optimization | AI-driven tuning suggestions, risk scoring, approve/reject workflow |
| Wazuh Integration | Agents, live alerts, rules, MITRE mapping, FIM, vulnerabilities, active response |
| Notifications | Slack · Teams · Email · Browser Push · Daily Digest |
| RBAC | 6 roles (L1–L3 Analyst, SOC Manager, Admin, Auditor), 24 permissions |
| Audit Logs | Immutable event log across all platform actions |
| Reports | 7 report types, PDF / CSV / Excel export |
| Dashboards | Executive KPI + Analyst queue views |

## Quick Start

```bash
# Install dependencies
pnpm install

# Set environment variables
cp .env.example .env
# Edit .env with DATABASE_URL, CLERK_SECRET_KEY, OPENAI_API_KEY, etc.

# Push DB schema
pnpm --filter @workspace/db run push

# Apply performance indexes
psql $DATABASE_URL -f lib/db/migrations/001_performance_indexes.sql

# Start development servers
pnpm --filter @workspace/api-server dev   # API on :3000
pnpm --filter @workspace/soc-platform dev # UI  on :5173
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | ✓ | PostgreSQL connection string |
| `CLERK_SECRET_KEY` | ✓ | Clerk backend secret |
| `VITE_CLERK_PUBLISHABLE_KEY` | ✓ | Clerk frontend key |
| `OPENAI_API_KEY` | — | GPT-4o-mini for AI pipeline (falls back to rule-based) |
| `REDIS_URL` | — | Redis for caching + queue dedup (optional) |
| `VAPID_PUBLIC_KEY` | — | Web Push public key |
| `VAPID_PRIVATE_KEY` | — | Web Push private key |
| `VAPID_SUBJECT` | — | Web Push contact (mailto:) |

## Architecture

```
artifacts/
├── api-server/     Express REST API + AI pipeline + background jobs
└── soc-platform/   React SPA (Vite + Tailwind + shadcn/ui)

lib/
├── db/             Drizzle ORM schema + migrations
├── api-zod/        OpenAPI-generated Zod schemas
└── api-client-react/  Orval-generated React Query hooks
```

## License

Proprietary — All rights reserved.
