import { Router } from "express";
import { db } from "@workspace/db";
import { wazuhConnectionsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }
function fmt(c: any) { return { ...c, passwordHash: undefined, lastSyncAt: c.lastSyncAt?.toISOString() ?? null, createdAt: c.createdAt.toISOString() }; }

router.get("/wazuh-connections", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const conns = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.organizationId, orgId));
    res.json(conns.map(fmt));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list connections" });
  }
});

router.post("/wazuh-connections", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { name, apiUrl, username, password, syncInterval } = req.body;
    const [conn] = await db.insert(wazuhConnectionsTable).values({ organizationId: orgId, name, apiUrl, username, passwordHash: password, syncInterval: syncInterval ?? 300, status: "pending" }).returning();
    res.status(201).json(fmt(conn));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create connection" });
  }
});

router.get("/wazuh-connections/:id", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    res.json(fmt(conn));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get connection" });
  }
});

router.patch("/wazuh-connections/:id", async (req, res) => {
  try {
    const { name, apiUrl, username, password, syncInterval } = req.body;
    const updates: any = {};
    if (name) updates.name = name;
    if (apiUrl) updates.apiUrl = apiUrl;
    if (username) updates.username = username;
    if (password) updates.passwordHash = password;
    if (syncInterval) updates.syncInterval = syncInterval;
    const [updated] = await db.update(wazuhConnectionsTable).set(updates).where(eq(wazuhConnectionsTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "Connection not found" }); return; }
    res.json(fmt(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update connection" });
  }
});

router.delete("/wazuh-connections/:id", async (req, res) => {
  try {
    await db.delete(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete connection" });
  }
});

router.post("/wazuh-connections/:id/test", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    const start = Date.now();
    try {
      await fetch(`${conn.apiUrl}/`, { signal: AbortSignal.timeout(5000) });
      const latencyMs = Date.now() - start;
      await db.update(wazuhConnectionsTable).set({ status: "connected" }).where(eq(wazuhConnectionsTable.id, req.params.id));
      res.json({ success: true, message: "Connection successful", latencyMs });
    } catch {
      await db.update(wazuhConnectionsTable).set({ status: "error" }).where(eq(wazuhConnectionsTable.id, req.params.id));
      res.json({ success: false, message: "Could not connect to Wazuh API. Verify the URL and credentials.", latencyMs: null });
    }
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to test connection" });
  }
});

router.post("/wazuh-connections/:id/sync", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    await db.update(wazuhConnectionsTable).set({ lastSyncAt: new Date(), lastSyncStatus: "success" }).where(eq(wazuhConnectionsTable.id, req.params.id));
    res.json({ success: true, alertsSynced: 0, agentsSynced: 0, vulnerabilitiesSynced: 0, message: "Sync initiated. Connect a live Wazuh instance to synchronize data." });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to sync" });
  }
});

export default router;
