import { Router } from "express";
import { db } from "@workspace/db";
import { alertsTable, incidentsTable, wazuhAgentsTable, vulnerabilitiesTable, alertAnalysesTable } from "@workspace/db";
import { sql, eq, and, gte, desc } from "drizzle-orm";

const router = Router();

function getOrgId(req: any): string {
  return req.query.orgId as string || "demo-org";
}

router.get("/dashboard", async (req, res) => {
  try {
    const orgId = getOrgId(req);

    const [alertCounts, incidentCount, agentCounts, vulnCount] = await Promise.all([
      db.select({
        total: sql<number>`count(*)::int`,
        critical: sql<number>`count(*) filter (where severity = 'critical')::int`,
        high: sql<number>`count(*) filter (where severity = 'high')::int`,
        medium: sql<number>`count(*) filter (where severity = 'medium')::int`,
        low: sql<number>`count(*) filter (where severity = 'low')::int`,
      }).from(alertsTable).where(eq(alertsTable.organizationId, orgId)),
      db.select({ count: sql<number>`count(*)::int` }).from(incidentsTable)
        .where(and(eq(incidentsTable.organizationId, orgId), eq(incidentsTable.status, "open"))),
      db.select({
        total: sql<number>`count(*)::int`,
        offline: sql<number>`count(*) filter (where status = 'disconnected')::int`,
      }).from(wazuhAgentsTable).where(eq(wazuhAgentsTable.organizationId, orgId)),
      db.select({ count: sql<number>`count(distinct agent_id)::int` }).from(vulnerabilitiesTable)
        .where(and(eq(vulnerabilitiesTable.organizationId, orgId), eq(vulnerabilitiesTable.status, "open"))),
    ]);

    const ac = alertCounts[0] ?? { total: 0, critical: 0, high: 0, medium: 0, low: 0 };
    res.json({
      totalAlerts: ac.total,
      criticalAlerts: ac.critical,
      highAlerts: ac.high,
      mediumAlerts: ac.medium,
      lowAlerts: ac.low,
      activeIncidents: incidentCount[0]?.count ?? 0,
      vulnerableAssets: vulnCount[0]?.count ?? 0,
      offlineAgents: agentCounts[0]?.offline ?? 0,
      totalAgents: agentCounts[0]?.total ?? 0,
      securityScore: 72,
      alertsChangePercent: 12.5,
      incidentsChangePercent: -8.3,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load dashboard" });
  }
});

router.get("/dashboard/threat-trends", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const days = parseInt(req.query.days as string) || 7;
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const rows = await db.select({
      date: sql<string>`date_trunc('day', timestamp)::date::text`,
      critical: sql<number>`count(*) filter (where severity = 'critical')::int`,
      high: sql<number>`count(*) filter (where severity = 'high')::int`,
      medium: sql<number>`count(*) filter (where severity = 'medium')::int`,
      low: sql<number>`count(*) filter (where severity = 'low')::int`,
    })
      .from(alertsTable)
      .where(and(eq(alertsTable.organizationId, orgId), gte(alertsTable.timestamp, since)))
      .groupBy(sql`date_trunc('day', timestamp)`)
      .orderBy(sql`date_trunc('day', timestamp)`);

    res.json(rows);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load threat trends" });
  }
});

router.get("/dashboard/top-threats", async (req, res) => {
  try {
    const orgId = getOrgId(req);

    const [topSystems, topSourceIps, topRules] = await Promise.all([
      db.select({
        name: alertsTable.agentName,
        count: sql<number>`count(*)::int`,
      }).from(alertsTable).where(eq(alertsTable.organizationId, orgId))
        .groupBy(alertsTable.agentName).orderBy(desc(sql`count(*)`)).limit(10),
      db.select({
        name: alertsTable.sourceIp,
        count: sql<number>`count(*)::int`,
      }).from(alertsTable).where(and(eq(alertsTable.organizationId, orgId), sql`source_ip is not null`))
        .groupBy(alertsTable.sourceIp).orderBy(desc(sql`count(*)`)).limit(10),
      db.select({
        name: alertsTable.ruleName,
        count: sql<number>`count(*)::int`,
      }).from(alertsTable).where(eq(alertsTable.organizationId, orgId))
        .groupBy(alertsTable.ruleName).orderBy(desc(sql`count(*)`)).limit(10),
    ]);

    res.json({
      topSystems,
      topSourceIps: topSourceIps.map(r => ({ name: r.name ?? "unknown", count: r.count })),
      topRules,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load top threats" });
  }
});

router.get("/dashboard/recent-activity", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const rows = await db.select().from(alertsTable)
      .where(eq(alertsTable.organizationId, orgId))
      .orderBy(desc(alertsTable.timestamp))
      .limit(20);

    res.json(rows.map(a => ({
      id: a.id,
      type: "alert",
      message: `${a.ruleName} on ${a.agentName}`,
      timestamp: a.timestamp.toISOString(),
      severity: a.severity,
      agentName: a.agentName,
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load recent activity" });
  }
});

export default router;
