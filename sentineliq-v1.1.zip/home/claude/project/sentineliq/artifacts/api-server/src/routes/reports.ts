import { Router } from "express";
import { db } from "@workspace/db";
import { reportsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }
function fmt(r: any) { return { ...r, createdAt: r.createdAt.toISOString(), generatedAt: r.generatedAt?.toISOString() ?? null }; }

router.get("/reports", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const reports = await db.select().from(reportsTable).where(eq(reportsTable.organizationId, orgId)).orderBy(desc(reportsTable.createdAt));
    res.json(reports.map(fmt));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list reports" });
  }
});

router.post("/reports", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { type, period } = req.body;
    const [report] = await db.insert(reportsTable).values({
      organizationId: orgId, type: type ?? "daily", period: period ?? new Date().toISOString().split("T")[0], status: "generating",
    }).returning();
    setTimeout(async () => {
      await db.update(reportsTable).set({ status: "ready", generatedAt: new Date() }).where(eq(reportsTable.id, report.id));
    }, 3000);
    res.status(201).json(fmt(report));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to generate report" });
  }
});

router.get("/reports/:id", async (req, res) => {
  try {
    const [report] = await db.select().from(reportsTable).where(eq(reportsTable.id, req.params.id));
    if (!report) { res.status(404).json({ error: "Report not found" }); return; }
    res.json(fmt(report));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get report" });
  }
});

router.delete("/reports/:id", async (req, res) => {
  try {
    await db.delete(reportsTable).where(eq(reportsTable.id, req.params.id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete report" });
  }
});

export default router;
