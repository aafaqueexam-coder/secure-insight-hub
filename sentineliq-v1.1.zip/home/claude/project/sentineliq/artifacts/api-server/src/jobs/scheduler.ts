import cron from "node-cron";
import { runRuleTuningJob } from "./ruleTuningJob";
import { logger } from "../lib/logger";

const ORGS = ["demo-org"];

export function startScheduler(): void {
  cron.schedule("0 2 * * *", async () => {
    logger.info("Scheduled rule tuning job triggered (daily 2 AM)");
    for (const orgId of ORGS) {
      try {
        await runRuleTuningJob(orgId, "scheduler");
      } catch (err) {
        logger.error({ err, orgId }, "Scheduled rule tuning job failed");
      }
    }
  });

  logger.info("Scheduler started — rule tuning runs daily at 02:00");
}
