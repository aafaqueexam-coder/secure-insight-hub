import { Router } from "express";

const router = Router();

const FRAMEWORKS = [
  { id: "iso27001", name: "ISO 27001", score: 74, status: "partial", controlsTotal: 114, controlsPassed: 84, controlsFailed: 30 },
  { id: "pci-dss", name: "PCI DSS", score: 68, status: "partial", controlsTotal: 78, controlsPassed: 53, controlsFailed: 25 },
  { id: "soc2", name: "SOC 2", score: 81, status: "compliant", controlsTotal: 60, controlsPassed: 49, controlsFailed: 11 },
  { id: "nist", name: "NIST CSF", score: 71, status: "partial", controlsTotal: 98, controlsPassed: 70, controlsFailed: 28 },
  { id: "cis", name: "CIS Controls", score: 65, status: "partial", controlsTotal: 153, controlsPassed: 99, controlsFailed: 54 },
];

router.get("/compliance", async (_req, res) => {
  res.json(FRAMEWORKS.map(f => ({ ...f, lastAssessedAt: new Date().toISOString() })));
});

router.get("/compliance/:framework", async (req, res) => {
  const fw = FRAMEWORKS.find(f => f.id === req.params.framework);
  if (!fw) { res.status(404).json({ error: "Framework not found" }); return; }
  const controls = [
    { id: "C1", name: "Access Control", status: "passed", category: "Security", evidence: "Implemented" },
    { id: "C2", name: "Audit Logging", status: "partial", category: "Monitoring", evidence: "Partial coverage" },
    { id: "C3", name: "Vulnerability Management", status: "failed", category: "Risk Management", evidence: null },
    { id: "C4", name: "Incident Response", status: "passed", category: "Operations", evidence: "Playbook documented" },
    { id: "C5", name: "Data Encryption", status: "partial", category: "Data Protection", evidence: "In-transit only" },
    { id: "C6", name: "MFA Enforcement", status: "failed", category: "Access Control", evidence: null },
  ];
  res.json({ ...fw, controls, lastAssessedAt: new Date().toISOString() });
});

router.get("/compliance/:framework/gaps", async (req, res) => {
  const fw = FRAMEWORKS.find(f => f.id === req.params.framework);
  if (!fw) { res.status(404).json({ error: "Framework not found" }); return; }
  res.json([
    { controlId: "GAP-01", controlName: "Patch Management", category: "Vulnerability Management", recommendation: "Implement automated patch management with SLA enforcement", priority: "high" },
    { controlId: "GAP-02", controlName: "Security Awareness Training", category: "People Controls", recommendation: "Deploy quarterly security awareness training for all staff", priority: "medium" },
    { controlId: "GAP-03", controlName: "Incident Response Plan", category: "Incident Management", recommendation: "Formalize and test the incident response playbook", priority: "high" },
    { controlId: "GAP-04", controlName: "Data Encryption at Rest", category: "Data Protection", recommendation: "Enable full-disk encryption on all endpoints", priority: "critical" },
    { controlId: "GAP-05", controlName: "MFA Enforcement", category: "Access Control", recommendation: "Enforce multi-factor authentication for all privileged accounts", priority: "critical" },
  ]);
});

export default router;
