import { Router } from "express";
import { db } from "@workspace/db";
import { ruleTuningRecommendationsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { runRuleTuningJob } from "../jobs/ruleTuningJob";

const router = Router();
function getOrgId(req: any): string {
  return (req.query.orgId as string) || "demo-org";
}

router.get("/rule-tuning", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const limit = parseInt(req.query.limit as string) || 10;

    const rows = await db
      .select()
      .from(ruleTuningRecommendationsTable)
      .where(eq(ruleTuningRecommendationsTable.organizationId, orgId))
      .orderBy(desc(ruleTuningRecommendationsTable.jobRunAt))
      .limit(limit);

    const results = rows.map((r) => ({
      ...r,
      recommendations: JSON.parse(r.recommendations),
      rawMetrics: JSON.parse(r.rawMetrics),
    }));

    res.json({ items: results, total: results.length });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list rule tuning jobs" });
  }
});

router.get("/rule-tuning/latest", async (req, res) => {
  try {
    const orgId = getOrgId(req);

    const [row] = await db
      .select()
      .from(ruleTuningRecommendationsTable)
      .where(eq(ruleTuningRecommendationsTable.organizationId, orgId))
      .orderBy(desc(ruleTuningRecommendationsTable.jobRunAt))
      .limit(1);

    if (!row) {
      res.status(404).json({ error: "No rule tuning results found. Trigger a run first." });
      return;
    }

    res.json({
      ...row,
      recommendations: JSON.parse(row.recommendations),
      rawMetrics: JSON.parse(row.rawMetrics),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get latest rule tuning result" });
  }
});

router.post("/rule-tuning/run", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    req.log.info({ orgId }, "Manual rule tuning job triggered");

    const result = await runRuleTuningJob(orgId, "manual");

    res.json({
      ...result,
      recommendations: JSON.parse(result.recommendations),
      rawMetrics: JSON.parse(result.rawMetrics),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to run rule tuning job" });
  }
});

export default router;
