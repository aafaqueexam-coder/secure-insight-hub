import { Router } from "express";
import { db } from "@workspace/db";
import { incidentsTable, incidentNotesTable, alertsTable } from "@workspace/db";
import { eq, and, sql, desc } from "drizzle-orm";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }

router.get("/incidents", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { status, priority } = req.query as Record<string, string>;
    const limit = parseInt(req.query.limit as string) || 20;
    const offset = parseInt(req.query.offset as string) || 0;
    const conditions = [eq(incidentsTable.organizationId, orgId)];
    if (status) conditions.push(eq(incidentsTable.status, status));
    if (priority) conditions.push(eq(incidentsTable.priority, priority));
    const [items, [{ total }]] = await Promise.all([
      db.select().from(incidentsTable).where(and(...conditions)).orderBy(desc(incidentsTable.createdAt)).limit(limit).offset(offset),
      db.select({ total: sql<number>`count(*)::int` }).from(incidentsTable).where(and(...conditions)),
    ]);
    res.json({ items: items.map(i => ({ ...i, createdAt: i.createdAt.toISOString(), updatedAt: i.updatedAt.toISOString(), resolvedAt: i.resolvedAt?.toISOString() ?? null })), total, offset, limit });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list incidents" });
  }
});

router.get("/incidents/stats", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [row] = await db.select({
      open: sql<number>`count(*) filter (where status='open')::int`,
      investigating: sql<number>`count(*) filter (where status='investigating')::int`,
      resolved: sql<number>`count(*) filter (where status='resolved')::int`,
      total: sql<number>`count(*)::int`,
    }).from(incidentsTable).where(eq(incidentsTable.organizationId, orgId));
    res.json({ open: row?.open ?? 0, investigating: row?.investigating ?? 0, resolved: row?.resolved ?? 0, total: row?.total ?? 0, avgResolutionHours: null });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get incident stats" });
  }
});

router.post("/incidents", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { title, description, priority, assigneeId, alertIds } = req.body;
    const [incident] = await db.insert(incidentsTable).values({
      organizationId: orgId, title, description, priority: priority ?? "medium", assigneeId, alertCount: alertIds?.length ?? 0,
    }).returning();
    if (alertIds?.length) {
      await db.update(alertsTable).set({ incidentId: incident.id })
        .where(and(eq(alertsTable.organizationId, orgId), sql`id = any(${alertIds})`));
    }
    res.status(201).json({ ...incident, createdAt: incident.createdAt.toISOString(), updatedAt: incident.updatedAt.toISOString(), resolvedAt: null });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create incident" });
  }
});

router.get("/incidents/:id", async (req, res) => {
  try {
    const [incident] = await db.select().from(incidentsTable).where(eq(incidentsTable.id, req.params.id));
    if (!incident) { res.status(404).json({ error: "Incident not found" }); return; }
    res.json({ ...incident, createdAt: incident.createdAt.toISOString(), updatedAt: incident.updatedAt.toISOString(), resolvedAt: incident.resolvedAt?.toISOString() ?? null });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get incident" });
  }
});

router.patch("/incidents/:id", async (req, res) => {
  try {
    const { title, description, status, priority, assigneeId } = req.body;
    const updates: any = {};
    if (title) updates.title = title;
    if (description) updates.description = description;
    if (status) { updates.status = status; if (status === "resolved") updates.resolvedAt = new Date(); }
    if (priority) updates.priority = priority;
    if (assigneeId !== undefined) updates.assigneeId = assigneeId;
    const [updated] = await db.update(incidentsTable).set(updates).where(eq(incidentsTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "Incident not found" }); return; }
    res.json({ ...updated, createdAt: updated.createdAt.toISOString(), updatedAt: updated.updatedAt.toISOString(), resolvedAt: updated.resolvedAt?.toISOString() ?? null });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update incident" });
  }
});

router.post("/incidents/:id/notes", async (req, res) => {
  try {
    const { content } = req.body;
    const auth = (req as any).auth?.userId ?? "system";
    const [note] = await db.insert(incidentNotesTable).values({
      incidentId: req.params.id, organizationId: getOrgId(req), content, authorId: auth, authorName: "Analyst",
    }).returning();
    res.status(201).json({ ...note, createdAt: note.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to add note" });
  }
});

router.get("/incidents/:id/timeline", async (req, res) => {
  try {
    const notes = await db.select().from(incidentNotesTable).where(eq(incidentNotesTable.incidentId, req.params.id)).orderBy(incidentNotesTable.createdAt);
    res.json(notes.map(n => ({ id: n.id, type: "note", message: n.content, timestamp: n.createdAt.toISOString(), authorName: n.authorName })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get timeline" });
  }
});

export default router;
