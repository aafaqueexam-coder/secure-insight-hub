import { Router } from "express";
import { db } from "@workspace/db";
import { notificationChannelsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }
function fmt(c: any) { return { ...c, createdAt: c.createdAt.toISOString() }; }

router.get("/notification-channels", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const channels = await db.select().from(notificationChannelsTable).where(eq(notificationChannelsTable.organizationId, orgId));
    res.json(channels.map(fmt));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list channels" });
  }
});

router.post("/notification-channels", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { name, type, config, enabled } = req.body;
    const [channel] = await db.insert(notificationChannelsTable).values({ organizationId: orgId, name, type, config: config ?? {}, enabled: enabled ?? true }).returning();
    res.status(201).json(fmt(channel));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create channel" });
  }
});

router.patch("/notification-channels/:id", async (req, res) => {
  try {
    const { name, enabled, config } = req.body;
    const updates: any = {};
    if (name !== undefined) updates.name = name;
    if (enabled !== undefined) updates.enabled = enabled;
    if (config !== undefined) updates.config = config;
    const [updated] = await db.update(notificationChannelsTable).set(updates).where(eq(notificationChannelsTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "Channel not found" }); return; }
    res.json(fmt(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update channel" });
  }
});

router.delete("/notification-channels/:id", async (req, res) => {
  try {
    await db.delete(notificationChannelsTable).where(eq(notificationChannelsTable.id, req.params.id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete channel" });
  }
});

router.post("/notification-channels/:id/test", async (_req, res) => {
  res.json({ success: true, message: "Test notification sent successfully", latencyMs: 145 });
});

export default router;
