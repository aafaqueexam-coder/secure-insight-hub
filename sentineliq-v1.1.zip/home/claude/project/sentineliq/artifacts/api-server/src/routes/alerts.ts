import { Router } from "express";
import { db } from "@workspace/db";
import { alertsTable, alertAnalysesTable } from "@workspace/db";
import { eq, and, desc, sql } from "drizzle-orm";
import OpenAI from "openai";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }
function getOpenAI() {
  return process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
}

router.get("/alerts", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { severity, status, agentId } = req.query as Record<string, string>;
    const limit = parseInt(req.query.limit as string) || 50;
    const offset = parseInt(req.query.offset as string) || 0;
    const conditions = [eq(alertsTable.organizationId, orgId)];
    if (severity) conditions.push(eq(alertsTable.severity, severity));
    if (status) conditions.push(eq(alertsTable.status, status));
    if (agentId) conditions.push(eq(alertsTable.agentId, agentId));
    const [items, [{ total }]] = await Promise.all([
      db.select().from(alertsTable).where(and(...conditions)).orderBy(desc(alertsTable.timestamp)).limit(limit).offset(offset),
      db.select({ total: sql<number>`count(*)::int` }).from(alertsTable).where(and(...conditions)),
    ]);
    res.json({ items, total, offset, limit });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list alerts" });
  }
});

router.get("/alerts/stats", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [row] = await db.select({
      total: sql<number>`count(*)::int`,
      critical: sql<number>`count(*) filter (where severity='critical')::int`,
      high: sql<number>`count(*) filter (where severity='high')::int`,
      medium: sql<number>`count(*) filter (where severity='medium')::int`,
      low: sql<number>`count(*) filter (where severity='low')::int`,
      newAlerts: sql<number>`count(*) filter (where status='new')::int`,
      acknowledged: sql<number>`count(*) filter (where status='acknowledged')::int`,
      resolved: sql<number>`count(*) filter (where status='resolved')::int`,
    }).from(alertsTable).where(eq(alertsTable.organizationId, orgId));
    res.json({ total: row?.total ?? 0, critical: row?.critical ?? 0, high: row?.high ?? 0, medium: row?.medium ?? 0, low: row?.low ?? 0, new: row?.newAlerts ?? 0, acknowledged: row?.acknowledged ?? 0, resolved: row?.resolved ?? 0 });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load alert stats" });
  }
});

router.get("/alerts/:id", async (req, res) => {
  try {
    const [alert] = await db.select().from(alertsTable).where(eq(alertsTable.id, req.params.id));
    if (!alert) { res.status(404).json({ error: "Alert not found" }); return; }
    res.json(alert);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get alert" });
  }
});

router.patch("/alerts/:id", async (req, res) => {
  try {
    const { status, incidentId, falsePositive } = req.body;
    const patch: Record<string, unknown> = {};
    if (status !== undefined) patch.status = status;
    if (incidentId !== undefined) patch.incidentId = incidentId;
    if (falsePositive !== undefined) patch.falsePositive = falsePositive;
    const [updated] = await db.update(alertsTable)
      .set(patch)
      .where(eq(alertsTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "Alert not found" }); return; }
    res.json(updated);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update alert" });
  }
});

router.get("/alerts/:id/analysis", async (req, res) => {
  try {
    const [analysis] = await db.select().from(alertAnalysesTable).where(eq(alertAnalysesTable.alertId, req.params.id));
    if (!analysis) { res.status(404).json({ error: "No analysis found. POST to generate one." }); return; }
    res.json({ ...analysis, generatedAt: analysis.generatedAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get analysis" });
  }
});

router.post("/alerts/:id/analysis", async (req, res) => {
  try {
    const [alert] = await db.select().from(alertsTable).where(eq(alertsTable.id, req.params.id));
    if (!alert) { res.status(404).json({ error: "Alert not found" }); return; }

    let analysis: any;
    const openai = getOpenAI();

    if (openai) {
      const prompt = `You are a cybersecurity analyst. Analyze this Wazuh security alert and provide a structured analysis.

Alert Details:
- Rule: ${alert.ruleName} (Level ${alert.ruleLevel})
- Severity: ${alert.severity}
- Description: ${alert.description}
- Agent: ${alert.agentName} (${alert.agentIp ?? "unknown IP"})
- Source IP: ${alert.sourceIp ?? "N/A"}
- MITRE Tactic: ${alert.mitreTactic ?? "N/A"}
- MITRE Technique: ${alert.mitreTechniqueId ?? "N/A"} - ${alert.mitreTechnique ?? "N/A"}
- Timestamp: ${alert.timestamp.toISOString()}

Respond with a JSON object containing: summary, threatDescription, businessImpact, investigationSteps (array), remediationPlan (array), recommendedActions (array), containmentActions (array), affectedAssets (array), analystNotes, executiveSummary, confidenceScore (0-1), severity.`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });
      analysis = JSON.parse(completion.choices[0].message.content ?? "{}");
    } else {
      analysis = {
        summary: `${alert.ruleName} detected on ${alert.agentName}`,
        threatDescription: `A ${alert.severity} severity security event: ${alert.description}`,
        businessImpact: "Potential unauthorized access or system compromise if not addressed promptly.",
        investigationSteps: [`Review logs on ${alert.agentName}`, "Check for related events from the same source IP", "Verify system integrity"],
        remediationPlan: ["Isolate affected system if compromise confirmed", "Reset credentials for affected accounts", "Apply relevant security patches"],
        recommendedActions: ["Escalate to Tier 2 analyst", "Enable enhanced monitoring on affected host"],
        containmentActions: ["Block source IP at firewall", "Disable compromised account"],
        affectedAssets: [alert.agentName],
        analystNotes: `Rule level ${alert.ruleLevel}. MITRE: ${alert.mitreTechniqueId ?? "N/A"}`,
        executiveSummary: `A ${alert.severity} security alert on ${alert.agentName} requires investigation.`,
        confidenceScore: 0.75,
        severity: alert.severity,
      };
    }

    await db.delete(alertAnalysesTable).where(eq(alertAnalysesTable.alertId, req.params.id));
    const [saved] = await db.insert(alertAnalysesTable).values({
      alertId: req.params.id,
      organizationId: alert.organizationId,
      summary: analysis.summary ?? "",
      threatDescription: analysis.threatDescription ?? "",
      businessImpact: analysis.businessImpact ?? "",
      investigationSteps: analysis.investigationSteps ?? [],
      remediationPlan: analysis.remediationPlan ?? [],
      recommendedActions: analysis.recommendedActions ?? [],
      containmentActions: analysis.containmentActions ?? [],
      affectedAssets: analysis.affectedAssets ?? [],
      analystNotes: analysis.analystNotes ?? "",
      executiveSummary: analysis.executiveSummary ?? "",
      confidenceScore: analysis.confidenceScore ?? 0.75,
      severity: analysis.severity ?? alert.severity,
      generatedAt: new Date(),
    }).returning();
    res.json({ ...saved, generatedAt: saved.generatedAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to generate analysis" });
  }
});

export default router;
