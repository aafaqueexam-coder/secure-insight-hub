import { useListAlerts, getListAlertsQueryKey, useUpdateAlert } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ShieldAlert, AlertTriangle, AlertCircle, Info } from "lucide-react";

const getSeverityBadge = (severity: string) => {
  switch (severity.toUpperCase()) {
    case 'CRITICAL': return <Badge variant="destructive" className="bg-red-600 hover:bg-red-700"><ShieldAlert className="w-3 h-3 mr-1" /> CRITICAL</Badge>;
    case 'HIGH': return <Badge className="bg-orange-500 hover:bg-orange-600 text-white border-transparent"><AlertTriangle className="w-3 h-3 mr-1" /> HIGH</Badge>;
    case 'MEDIUM': return <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-500 hover:bg-yellow-500/30"><AlertCircle className="w-3 h-3 mr-1" /> MEDIUM</Badge>;
    case 'LOW': return <Badge variant="outline" className="text-blue-400 border-blue-400/30"><Info className="w-3 h-3 mr-1" /> LOW</Badge>;
    default: return <Badge variant="outline">{severity}</Badge>;
  }
};

const getStatusBadge = (status: string) => {
  switch (status.toLowerCase()) {
    case 'new': return <Badge variant="outline" className="border-blue-500/30 text-blue-400">New</Badge>;
    case 'acknowledged': return <Badge variant="outline" className="border-yellow-500/30 text-yellow-500">Acknowledged</Badge>;
    case 'resolved': return <Badge variant="outline" className="border-green-500/30 text-green-500">Resolved</Badge>;
    default: return <Badge variant="outline">{status}</Badge>;
  }
};

export default function Alerts() {
  const [severityFilter, setSeverityFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const queryParams: any = {};
  if (severityFilter !== "all") queryParams.severity = severityFilter;
  if (statusFilter !== "all") queryParams.status = statusFilter;

  const { data: alertList, isLoading } = useListAlerts(queryParams, { query: { queryKey: getListAlertsQueryKey(queryParams) } });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Alert Management</h1>
        <div className="flex gap-2">
          <Select value={severityFilter} onValueChange={setSeverityFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Severity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Severities</SelectItem>
              <SelectItem value="CRITICAL">Critical</SelectItem>
              <SelectItem value="HIGH">High</SelectItem>
              <SelectItem value="MEDIUM">Medium</SelectItem>
              <SelectItem value="LOW">Low</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="new">New</SelectItem>
              <SelectItem value="acknowledged">Acknowledged</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card className="border-border bg-card">
        <CardHeader className="border-b border-border py-4">
          <CardTitle className="text-lg">Recent Alerts</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead>Time</TableHead>
                <TableHead>Severity</TableHead>
                <TableHead>Rule</TableHead>
                <TableHead>Agent</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i} className="border-border">
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-64" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                  </TableRow>
                ))
              ) : alertList?.items?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                    No alerts found.
                  </TableCell>
                </TableRow>
              ) : (
                alertList?.items?.map((alert) => (
                  <TableRow key={alert.id} className="border-border hover:bg-accent/50 cursor-pointer">
                    <TableCell className="text-muted-foreground whitespace-nowrap">
                      {format(new Date(alert.timestamp), "MMM d, HH:mm:ss")}
                    </TableCell>
                    <TableCell>{getSeverityBadge(alert.severity)}</TableCell>
                    <TableCell className="font-medium max-w-[400px] truncate" title={alert.ruleName}>
                      {alert.ruleName}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="text-sm">{alert.agentName}</span>
                        {alert.agentIp && <span className="text-xs text-muted-foreground">{alert.agentIp}</span>}
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(alert.status)}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
