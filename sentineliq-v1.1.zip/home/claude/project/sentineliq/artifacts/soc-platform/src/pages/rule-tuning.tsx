import { useState } from "react";
import {
  useGetLatestRuleTuningJob,
  useTriggerRuleTuningJob,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  AlertTriangle,
  Bot,
  CheckCircle2,
  Clock,
  Play,
  RefreshCw,
  Shield,
  TrendingDown,
  TrendingUp,
  VolumeX,
  Wrench,
  XCircle,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ACTION_META: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  suppress:        { label: "Suppress",          color: "bg-red-500/10 text-red-400 border-red-500/20",     icon: VolumeX },
  raise_threshold: { label: "Raise Threshold",   color: "bg-orange-500/10 text-orange-400 border-orange-500/20", icon: TrendingDown },
  tune_frequency:  { label: "Tune Frequency",    color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20", icon: Wrench },
  investigate_fp:  { label: "Investigate FP",    color: "bg-purple-500/10 text-purple-400 border-purple-500/20", icon: AlertTriangle },
  keep:            { label: "Well Calibrated",   color: "bg-green-500/10 text-green-400 border-green-500/20",   icon: CheckCircle2 },
};

const PRIORITY_COLOR: Record<string, string> = {
  high:   "bg-red-500/15 text-red-400 border-red-500/30",
  medium: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30",
  low:    "bg-slate-500/15 text-slate-400 border-slate-500/30",
};

function MetricPill({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex flex-col gap-0.5 min-w-[80px]">
      <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</span>
      <span className="text-sm font-semibold text-foreground">{value}</span>
    </div>
  );
}

function RecommendationCard({ rec }: { rec: any }) {
  const meta = ACTION_META[rec.action] ?? ACTION_META.keep;
  const Icon = meta.icon;
  const fpPct = ((rec.metrics?.falsePositiveRatio ?? 0) * 100).toFixed(0);
  const avgHrs = rec.metrics?.avgResolutionHours != null
    ? `${rec.metrics.avgResolutionHours}h`
    : "—";

  return (
    <Card className="bg-card/50 border-border">
      <CardContent className="p-5 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            <div className={`mt-0.5 p-1.5 rounded-md border ${meta.color}`}>
              <Icon className="h-4 w-4" />
            </div>
            <div className="min-w-0">
              <p className="font-semibold text-foreground truncate">{rec.ruleName}</p>
              <p className="text-xs text-muted-foreground font-mono">Rule {rec.ruleId}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Badge variant="outline" className={`text-xs ${PRIORITY_COLOR[rec.priority]}`}>
              {rec.priority}
            </Badge>
            <Badge variant="outline" className={`text-xs ${meta.color}`}>
              {meta.label}
            </Badge>
          </div>
        </div>

        <div className="flex flex-wrap gap-4 py-3 px-4 rounded-lg bg-background/60 border border-border/50">
          <MetricPill label="Total Alerts" value={rec.metrics?.totalAlerts ?? 0} />
          <MetricPill label="Alerts/Day" value={rec.metrics?.alertsPerDay?.toFixed(1) ?? "—"} />
          <MetricPill label="False Positive %" value={`${fpPct}%`} />
          <MetricPill label="Avg Resolution" value={avgHrs} />
          <MetricPill label="Unique IPs" value={rec.metrics?.uniqueSourceIps ?? 0} />
          <MetricPill label="Agents Hit" value={rec.metrics?.uniqueAgents ?? 0} />
        </div>

        <div className="space-y-2">
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-1">Finding</p>
            <p className="text-sm text-foreground/90 leading-relaxed">{rec.reason}</p>
          </div>
          <Separator className="bg-border/50" />
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-1 flex items-center gap-1">
              <Wrench className="h-3 w-3" /> Suggested Change
            </p>
            <p className="text-sm text-primary/90 leading-relaxed">{rec.suggestedChange}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function RuleTuning() {
  const { toast } = useToast();
  const [isRunning, setIsRunning] = useState(false);

  const { data: job, isLoading, error, refetch } = useGetLatestRuleTuningJob();
  const { mutateAsync: triggerJob } = useTriggerRuleTuningJob();

  const handleRun = async () => {
    setIsRunning(true);
    try {
      await triggerJob();
      await refetch();
      toast({ title: "Analysis complete", description: "Rule tuning recommendations updated." });
    } catch {
      toast({ title: "Job failed", description: "Could not run analysis. Check server logs.", variant: "destructive" });
    } finally {
      setIsRunning(false);
    }
  };

  const recs: any[] = job?.recommendations ?? [];
  const actionSummary = recs.reduce<Record<string, number>>((acc, r) => {
    acc[r.action] = (acc[r.action] ?? 0) + 1;
    return acc;
  }, {});

  const highPriority = recs.filter((r) => r.priority === "high").length;
  const needsAction = recs.filter((r) => r.action !== "keep").length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Rule Tuning</h1>
          <p className="text-muted-foreground mt-1">
            AI-powered analysis of alert rules — reduce noise, surface real threats
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isLoading}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button size="sm" onClick={handleRun} disabled={isRunning}>
            {isRunning ? (
              <><RefreshCw className="h-4 w-4 mr-2 animate-spin" />Analyzing…</>
            ) : (
              <><Play className="h-4 w-4 mr-2" />Run Analysis</>
            )}
          </Button>
        </div>
      </div>

      {isLoading && (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="bg-card/50 border-border">
              <CardContent className="p-5">
                <Skeleton className="h-24 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {!isLoading && error && (
        <Card className="bg-card/50 border-border">
          <CardContent className="p-12 flex flex-col items-center gap-4 text-center">
            <div className="p-4 rounded-full bg-muted/40">
              <Bot className="h-10 w-10 text-muted-foreground" />
            </div>
            <div>
              <p className="font-semibold text-lg">No analysis yet</p>
              <p className="text-muted-foreground text-sm mt-1">
                Click <strong>Run Analysis</strong> to analyze the past 30 days of alerts and generate tuning recommendations.
              </p>
              <p className="text-muted-foreground text-xs mt-2">
                The scheduler also runs this automatically every day at 2 AM.
              </p>
            </div>
            <Button onClick={handleRun} disabled={isRunning} className="mt-2">
              {isRunning ? (
                <><RefreshCw className="h-4 w-4 mr-2 animate-spin" />Analyzing…</>
              ) : (
                <><Play className="h-4 w-4 mr-2" />Run Analysis Now</>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {!isLoading && job && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-card/50 border-border">
              <CardHeader className="pb-2 flex flex-row items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">Alerts Analyzed</CardTitle>
                <Shield className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{job.totalAlertsAnalyzed}</div>
                <p className="text-xs text-muted-foreground mt-1">past {job.aggregationWindowDays} days</p>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-border">
              <CardHeader className="pb-2 flex flex-row items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">Rules Evaluated</CardTitle>
                <TrendingUp className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{recs.length}</div>
                <p className="text-xs text-muted-foreground mt-1">{needsAction} need attention</p>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-border">
              <CardHeader className="pb-2 flex flex-row items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">High Priority</CardTitle>
                <AlertTriangle className="h-4 w-4 text-red-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-400">{highPriority}</div>
                <p className="text-xs text-muted-foreground mt-1">immediate action needed</p>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-border">
              <CardHeader className="pb-2 flex flex-row items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">AI Model</CardTitle>
                <Bot className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-sm font-bold">{job.aiModelUsed ?? "Rule-based"}</div>
                <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {new Date(job.jobRunAt).toLocaleString()}
                </p>
              </CardContent>
            </Card>
          </div>

          {Object.keys(actionSummary).length > 0 && (
            <Card className="bg-card/50 border-border">
              <CardHeader>
                <CardTitle className="text-sm font-medium">Action Summary</CardTitle>
                <CardDescription>Distribution of recommendations across all rules</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-3">
                  {Object.entries(actionSummary).map(([action, count]) => {
                    const meta = ACTION_META[action] ?? ACTION_META.keep;
                    const Icon = meta.icon;
                    return (
                      <div key={action} className={`flex items-center gap-2 px-3 py-2 rounded-lg border ${meta.color}`}>
                        <Icon className="h-4 w-4" />
                        <span className="text-sm font-medium">{count}× {meta.label}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">
                Recommendations
                {job.triggeredBy === "manual" && (
                  <Badge variant="outline" className="ml-2 text-xs text-primary border-primary/30">manual run</Badge>
                )}
              </h2>
              <span className="text-sm text-muted-foreground">{recs.length} rules</span>
            </div>

            {recs.length === 0 ? (
              <Card className="bg-card/50 border-border">
                <CardContent className="p-8 text-center">
                  <XCircle className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No recommendations generated — not enough alert data yet.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {[...recs]
                  .sort((a, b) => {
                    const pOrder = { high: 0, medium: 1, low: 2 };
                    return (pOrder[a.priority as keyof typeof pOrder] ?? 2) - (pOrder[b.priority as keyof typeof pOrder] ?? 2);
                  })
                  .map((rec, i) => (
                    <RecommendationCard key={`${rec.ruleId}-${i}`} rec={rec} />
                  ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
