import { useState } from "react";
import {
  useListComplianceFrameworks,
  useGetComplianceGaps,
  useGetComplianceGapAnalysis,
  useGenerateComplianceGapAnalysis,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { AiAnalysisPanel, AiList, AiBadge } from "@/components/ai-analysis-panel";
import { CheckSquare, X, AlertTriangle, ChevronRight, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const SCORE_COLOR = (score: number) =>
  score >= 80 ? "text-green-400" : score >= 60 ? "text-yellow-400" : "text-red-400";

const PRIORITY_STYLES: Record<string, string> = {
  critical: "border-red-500/50 text-red-400 bg-red-500/10",
  high:     "border-orange-500/50 text-orange-400 bg-orange-500/10",
  medium:   "border-yellow-500/50 text-yellow-400 bg-yellow-500/10",
  low:      "border-blue-500/50 text-blue-400 bg-blue-500/10",
};

const RISK_COLORS: Record<string, string> = {
  high:   "bg-red-500/10 text-red-400 border-red-500/30",
  medium: "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
  low:    "bg-blue-500/10 text-blue-400 border-blue-500/30",
};

const EFFORT_COLORS: Record<string, string> = {
  hours:  "bg-green-500/10 text-green-400 border-green-500/30",
  days:   "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
  weeks:  "bg-orange-500/10 text-orange-400 border-orange-500/30",
  months: "bg-red-500/10 text-red-400 border-red-500/30",
};

function GapAnalysisPanel({ framework, gap, onClose }: { framework: string; gap: any; onClose: () => void }) {
  const { toast } = useToast();
  const { data: analysis, isLoading, refetch } = useGetComplianceGapAnalysis(framework, gap.controlId);
  const { mutateAsync: generate, isPending: isGenerating } = useGenerateComplianceGapAnalysis();

  const handleGenerate = async () => {
    try {
      await generate({ framework, controlId: gap.controlId });
      await refetch();
    } catch {
      toast({ title: "Analysis failed", variant: "destructive" });
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="flex items-center justify-between px-6 py-3 border-b border-border bg-card/20">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <CheckSquare className="h-4 w-4" />
          <span>{framework.toUpperCase()} · {gap.controlId}</span>
        </div>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-5">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={`text-xs ${PRIORITY_STYLES[gap.priority] ?? ""}`}>{gap.priority}</Badge>
            <span className="text-xs font-mono text-muted-foreground">{gap.controlId}</span>
          </div>
          <h2 className="text-lg font-semibold">{gap.controlName}</h2>
          <p className="text-xs text-muted-foreground">{gap.category}</p>
          {gap.recommendation && (
            <div className="p-3 rounded-lg bg-muted/30 border border-border/50">
              <p className="text-xs text-foreground/80 leading-relaxed">{gap.recommendation}</p>
            </div>
          )}
        </div>

        <Separator className="bg-border/50" />

        <AiAnalysisPanel
          analysis={analysis}
          isLoading={isLoading}
          error={false}
          onGenerate={handleGenerate}
          isGenerating={isGenerating}
          label="Compliance AI Analysis"
        >
          {(d) => (
            <div className="space-y-4">
              {d.gapAnalysis && (
                <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                  <p className="text-xs text-foreground/90 leading-relaxed">{d.gapAnalysis}</p>
                </div>
              )}

              <div className="flex flex-wrap gap-3">
                {d.regulatoryRisk && <AiBadge label="Regulatory Risk" value={d.regulatoryRisk} colorMap={RISK_COLORS} />}
                {d.effort && <AiBadge label="Effort" value={d.effort} colorMap={EFFORT_COLORS} />}
                {d.costEstimate && <AiBadge label="Cost" value={d.costEstimate} colorMap={{}} />}
              </div>

              {d.quickWin && (
                <div className="p-3 rounded-lg bg-green-500/5 border border-green-500/20">
                  <p className="text-xs font-medium text-green-400 mb-1 flex items-center gap-1">
                    <Clock className="h-3 w-3" /> Quick Win
                  </p>
                  <p className="text-xs text-foreground/90 leading-relaxed">{d.quickWin}</p>
                </div>
              )}

              <Separator className="bg-border/40" />

              <AiList label="Implementation Steps" items={d.implementationSteps} />
              <AiList label="Tooling Recommendations" items={d.toolingRecommendations} />

              {d.auditEvidence && (
                <div>
                  <p className="text-xs font-medium text-muted-foreground mb-1">Audit Evidence to Collect</p>
                  <p className="text-xs text-foreground/90 leading-relaxed">{d.auditEvidence}</p>
                </div>
              )}
            </div>
          )}
        </AiAnalysisPanel>
      </div>
    </div>
  );
}

function FrameworkGaps({ frameworkId, onSelectGap }: { frameworkId: string; onSelectGap: (gap: any) => void }) {
  const { data: gaps, isLoading } = useGetComplianceGaps(frameworkId);

  if (isLoading) return (
    <div className="space-y-2 p-4">
      {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
    </div>
  );

  return (
    <div className="divide-y divide-border">
      {(gaps ?? []).map((gap: any) => (
        <button
          key={gap.controlId}
          onClick={() => onSelectGap(gap)}
          className="w-full text-left px-5 py-3 hover:bg-accent/50 transition-colors flex items-center gap-3"
        >
          <AlertTriangle className={`h-4 w-4 flex-shrink-0 ${
            gap.priority === "critical" ? "text-red-400" :
            gap.priority === "high" ? "text-orange-400" :
            gap.priority === "medium" ? "text-yellow-400" : "text-blue-400"
          }`} />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium">{gap.controlName}</p>
            <p className="text-xs text-muted-foreground">{gap.category}</p>
          </div>
          <Badge variant="outline" className={`text-[10px] flex-shrink-0 ${PRIORITY_STYLES[gap.priority] ?? ""}`}>
            {gap.priority}
          </Badge>
          <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
        </button>
      ))}
    </div>
  );
}

export default function Compliance() {
  const [selectedFramework, setSelectedFramework] = useState<string | null>(null);
  const [selectedGap, setSelectedGap] = useState<any | null>(null);
  const { data: frameworks, isLoading } = useListComplianceFrameworks();

  const handleSelectGap = (gap: any) => {
    setSelectedGap(gap);
  };

  return (
    <div className="flex h-full gap-0 -m-6">
      <div className={`flex flex-col border-r border-border transition-all ${selectedGap ? "w-[440px] flex-shrink-0" : "flex-1"}`}>
        <div className="px-6 py-4 border-b border-border">
          <h1 className="text-2xl font-bold tracking-tight">Compliance</h1>
          <p className="text-sm text-muted-foreground mt-1">Framework posture and AI-powered gap remediation</p>
        </div>

        <div className="flex-1 overflow-y-auto">
          {isLoading ? (
            <div className="p-4 grid grid-cols-1 gap-3">
              {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}
            </div>
          ) : (
            <div className="p-4 space-y-3">
              {(frameworks ?? []).map((fw: any) => (
                <Card
                  key={fw.id}
                  className={`cursor-pointer border-border bg-card/50 transition-all hover:border-primary/40 ${selectedFramework === fw.id ? "border-primary/60 bg-primary/5" : ""}`}
                  onClick={() => setSelectedFramework(selectedFramework === fw.id ? null : fw.id)}
                >
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold">{fw.name}</h3>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {fw.controlsPassed}/{fw.controlsTotal} controls passed · {fw.controlsFailed} gaps
                        </p>
                      </div>
                      <div className="text-right">
                        <div className={`text-2xl font-bold ${SCORE_COLOR(fw.score)}`}>{fw.score}%</div>
                        <Badge variant="outline" className={`text-[10px] mt-1 ${
                          fw.status === "compliant" ? "text-green-400 border-green-500/40" :
                          fw.status === "partial" ? "text-yellow-400 border-yellow-500/40" :
                          "text-red-400 border-red-500/40"
                        }`}>{fw.status}</Badge>
                      </div>
                    </div>
                    <Progress value={fw.score} className="h-1.5" />

                    {selectedFramework === fw.id && (
                      <div className="mt-3 border-t border-border/50 pt-3">
                        <p className="text-xs font-medium text-muted-foreground mb-2">Control Gaps — click for AI remediation</p>
                        <FrameworkGaps frameworkId={fw.id} onSelectGap={(gap) => {
                          setSelectedGap({ ...gap, frameworkId: fw.id });
                        }} />
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {selectedGap && (
        <GapAnalysisPanel
          framework={selectedGap.frameworkId ?? selectedFramework ?? "iso27001"}
          gap={selectedGap}
          onClose={() => setSelectedGap(null)}
        />
      )}

      {!selectedGap && (
        <div className="flex-1 flex items-center justify-center text-muted-foreground">
          <div className="text-center space-y-2">
            <CheckSquare className="h-10 w-10 mx-auto opacity-30" />
            <p className="text-sm">Expand a framework and select a control gap for AI remediation guidance</p>
          </div>
        </div>
      )}
    </div>
  );
}
