import { useState } from "react";
import {
  useListIncidents,
  useGetIncident,
  useGetIncidentAnalysis,
  useGenerateIncidentAnalysis,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { AiAnalysisPanel, AiList, AiBadge } from "@/components/ai-analysis-panel";
import { format } from "date-fns";
import {
  AlertTriangle, Clock, ShieldAlert, X, Plus,
  CheckCircle2, Search
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const PRIORITY_STYLES: Record<string, string> = {
  critical: "border-red-500/50 text-red-400 bg-red-500/10",
  high:     "border-orange-500/50 text-orange-400 bg-orange-500/10",
  medium:   "border-yellow-500/50 text-yellow-400 bg-yellow-500/10",
  low:      "border-blue-500/50 text-blue-400 bg-blue-500/10",
};
const STATUS_STYLES: Record<string, string> = {
  open:          "bg-red-500/10 text-red-400",
  investigating: "bg-yellow-500/10 text-yellow-400",
  resolved:      "bg-green-500/10 text-green-400",
};
const RISK_COLORS: Record<string, string> = {
  critical: "bg-red-500/10 text-red-400 border-red-500/30",
  high:     "bg-orange-500/10 text-orange-400 border-orange-500/30",
  medium:   "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
  low:      "bg-blue-500/10 text-blue-400 border-blue-500/30",
};

function IncidentDetail({ incidentId }: { incidentId: string }) {
  const { toast } = useToast();
  const { data: incident, isLoading } = useGetIncident(incidentId);
  const { data: analysis, isLoading: analysisLoading, refetch } = useGetIncidentAnalysis(incidentId);
  const { mutateAsync: generate, isPending: isGenerating } = useGenerateIncidentAnalysis();

  const handleGenerate = async () => {
    try {
      await generate({ id: incidentId });
      await refetch();
    } catch {
      toast({ title: "Analysis failed", variant: "destructive" });
    }
  };

  if (isLoading) return (
    <div className="p-6 space-y-3">
      <Skeleton className="h-6 w-2/3" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-5/6" />
    </div>
  );

  if (!incident) return null;

  return (
    <div className="p-6 space-y-5 overflow-y-auto h-full">
      <div className="space-y-2">
        <div className="flex items-start gap-2 flex-wrap">
          <Badge variant="outline" className={`text-xs ${PRIORITY_STYLES[incident.priority?.toLowerCase()] ?? PRIORITY_STYLES.medium}`}>
            {incident.priority}
          </Badge>
          <Badge className={`text-xs ${STATUS_STYLES[incident.status] ?? "bg-muted"}`}>
            {incident.status}
          </Badge>
          <span className="text-xs text-muted-foreground flex items-center gap-1 ml-auto">
            <Clock className="h-3 w-3" />
            {format(new Date(incident.createdAt), "MMM d, yyyy HH:mm")}
          </span>
        </div>
        <h2 className="text-lg font-semibold leading-tight">{incident.title}</h2>
        {incident.description && (
          <p className="text-sm text-muted-foreground leading-relaxed">{incident.description}</p>
        )}
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><AlertTriangle className="h-3 w-3" />{incident.alertCount ?? 0} alerts</span>
          {incident.resolvedAt && (
            <span className="flex items-center gap-1 text-green-400">
              <CheckCircle2 className="h-3 w-3" />Resolved {format(new Date(incident.resolvedAt), "MMM d")}
            </span>
          )}
        </div>
      </div>

      <Separator className="bg-border/50" />

      <AiAnalysisPanel
        analysis={analysis}
        isLoading={analysisLoading}
        error={false}
        onGenerate={handleGenerate}
        isGenerating={isGenerating}
        label="Incident AI Analysis"
      >
        {(d) => (
          <div className="space-y-4">
            {d.attackChain && (
              <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                <p className="text-xs font-medium text-primary mb-1">Attack Chain</p>
                <p className="text-xs text-foreground/90 leading-relaxed">{d.attackChain}</p>
              </div>
            )}

            <div className="flex flex-wrap gap-3">
              {d.riskLevel && <AiBadge label="Risk" value={d.riskLevel} colorMap={RISK_COLORS} />}
            </div>

            {d.threatActorProfile && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">Threat Actor Profile</p>
                <p className="text-xs text-foreground/90">{d.threatActorProfile}</p>
              </div>
            )}

            {d.businessImpact && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">Business Impact</p>
                <p className="text-xs text-foreground/90">{d.businessImpact}</p>
              </div>
            )}

            <Separator className="bg-border/40" />

            <AiList label="Immediate Actions" items={d.immediateActions} />
            <AiList label="Investigation Steps" items={d.investigationSteps} />
            <AiList label="Remediation Steps" items={d.remediationSteps} />
            {d.similarPatterns?.length > 0 && <AiList label="Similar Patterns" items={d.similarPatterns} />}

            <div className="text-[10px] text-muted-foreground pt-1">
              Generated {analysis?.generatedAt ? format(new Date(analysis.generatedAt), "MMM d, HH:mm") : "—"}
            </div>
          </div>
        )}
      </AiAnalysisPanel>
    </div>
  );
}

export default function Incidents() {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const { data: incidentList, isLoading } = useListIncidents({}, { query: { queryKey: ["incidents"] } });
  const incidents = incidentList?.items ?? [];

  return (
    <div className="flex h-full gap-0 -m-6">
      <div className={`flex flex-col border-r border-border bg-card/30 transition-all ${selectedId ? "w-[420px] flex-shrink-0" : "flex-1"}`}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h1 className="text-2xl font-bold tracking-tight">Incidents</h1>
          <Button size="sm"><Plus className="h-4 w-4 mr-2" />Create</Button>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-border">
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="px-6 py-4 space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            ))
          ) : incidents.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 gap-2 text-muted-foreground">
              <Search className="h-8 w-8" />
              <p className="text-sm">No incidents found</p>
            </div>
          ) : (
            incidents.map((incident) => (
              <button
                key={incident.id}
                onClick={() => setSelectedId(selectedId === incident.id ? null : incident.id)}
                className={`w-full text-left px-6 py-4 hover:bg-accent/50 transition-colors ${selectedId === incident.id ? "bg-primary/5 border-l-2 border-l-primary" : ""}`}
              >
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <span className="font-medium text-sm leading-tight flex-1">{incident.title}</span>
                  <Badge variant="outline" className={`text-[10px] flex-shrink-0 ${PRIORITY_STYLES[incident.priority?.toLowerCase()] ?? ""}`}>
                    {incident.priority}
                  </Badge>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <Badge className={`text-[10px] ${STATUS_STYLES[incident.status] ?? "bg-muted"}`}>{incident.status}</Badge>
                  <span>{incident.alertCount ?? 0} alerts</span>
                  <span className="ml-auto">{format(new Date(incident.createdAt), "MMM d")}</span>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {selectedId && (
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-6 py-3 border-b border-border bg-card/20">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <ShieldAlert className="h-4 w-4" />
              <span>Incident Detail</span>
            </div>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setSelectedId(null)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex-1 overflow-hidden">
            <IncidentDetail incidentId={selectedId} />
          </div>
        </div>
      )}

      {!selectedId && !isLoading && incidents.length > 0 && (
        <div className="flex-1 flex items-center justify-center text-muted-foreground">
          <div className="text-center space-y-2">
            <ShieldAlert className="h-10 w-10 mx-auto opacity-30" />
            <p className="text-sm">Select an incident to view details and AI analysis</p>
          </div>
        </div>
      )}
    </div>
  );
}
