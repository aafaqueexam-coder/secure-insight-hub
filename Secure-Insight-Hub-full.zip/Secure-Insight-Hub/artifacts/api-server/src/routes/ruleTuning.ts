import { Router } from "express";
import { db } from "@workspace/db";
import { ruleTuningRecommendationsTable, ruleTuningDecisionsTable } from "@workspace/db";
import { eq, desc, and } from "drizzle-orm";
import { runRuleTuningJob } from "../jobs/ruleTuningJob";
import { requirePermission } from "../lib/rbac";
import { audit, fromRequest } from "../lib/auditWriter";

const router = Router();
function getOrgId(req: any): string { return (req.query.orgId as string) || "demo-org"; }
function getActor(req: any): { id: string; name: string } {
  return { id: (req as any).auth?.userId ?? "demo-user", name: (req as any).auth?.userName ?? "Analyst" };
}

router.get("/rule-tuning", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const limit = parseInt(req.query.limit as string) || 10;
    const rows = await db.select().from(ruleTuningRecommendationsTable)
      .where(eq(ruleTuningRecommendationsTable.organizationId, orgId))
      .orderBy(desc(ruleTuningRecommendationsTable.jobRunAt)).limit(limit);
    const results = rows.map((r) => ({ ...r, recommendations: JSON.parse(r.recommendations), rawMetrics: JSON.parse(r.rawMetrics) }));
    res.json({ items: results, total: results.length });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list rule tuning jobs" });
  }
});

router.get("/rule-tuning/latest", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [row] = await db.select().from(ruleTuningRecommendationsTable)
      .where(eq(ruleTuningRecommendationsTable.organizationId, orgId))
      .orderBy(desc(ruleTuningRecommendationsTable.jobRunAt)).limit(1);
    if (!row) { res.status(404).json({ error: "No rule tuning results found. Trigger a run first." }); return; }

    // Attach the latest decision for each rule
    const recs = JSON.parse(row.recommendations) as any[];
    const ruleIds = recs.map((r: any) => r.ruleId);
    const allDecisions = ruleIds.length
      ? await db.select().from(ruleTuningDecisionsTable)
          .where(and(eq(ruleTuningDecisionsTable.organizationId, orgId), eq(ruleTuningDecisionsTable.jobId, row.id)))
          .orderBy(desc(ruleTuningDecisionsTable.decidedAt))
      : [];
    const latestByRule = new Map<string, typeof allDecisions[number]>();
    for (const d of allDecisions) {
      if (!latestByRule.has(d.ruleId)) latestByRule.set(d.ruleId, d);
    }

    const enrichedRecs = recs.map((r: any) => ({
      ...r,
      latestDecision: latestByRule.get(r.ruleId)
        ? { ...latestByRule.get(r.ruleId), decidedAt: latestByRule.get(r.ruleId)!.decidedAt.toISOString() }
        : null,
    }));

    res.json({ ...row, recommendations: enrichedRecs, rawMetrics: JSON.parse(row.rawMetrics) });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get latest rule tuning result" });
  }
});

// Approve or reject a specific recommendation from the latest job.
router.post("/rule-tuning/:jobId/rules/:ruleId/decision", requirePermission("rules:modify"), async (req, res) => {
  try {
    const { decision, analystNote } = req.body as { decision: "approved" | "rejected"; analystNote?: string };
    if (decision !== "approved" && decision !== "rejected") {
      res.status(400).json({ error: "decision must be 'approved' or 'rejected'" });
      return;
    }

    const [job] = await db.select().from(ruleTuningRecommendationsTable).where(eq(ruleTuningRecommendationsTable.id, req.params.jobId));
    if (!job) { res.status(404).json({ error: "Job not found" }); return; }

    const recs = JSON.parse(job.recommendations) as any[];
    const rec = recs.find((r: any) => r.ruleId === req.params.ruleId);
    if (!rec) { res.status(404).json({ error: "Rule not found in this job" }); return; }

    const actor = getActor(req);
    const orgId = job.organizationId;

    const [saved] = await db.insert(ruleTuningDecisionsTable).values({
      organizationId: orgId,
      jobId: job.id,
      ruleId: rec.ruleId,
      ruleName: rec.ruleName,
      action: rec.action,
      suggestedChange: rec.suggestedChange,
      riskScore: rec.riskScore ?? null,
      expectedImprovement: rec.expectedImprovement ?? null,
      decision,
      analystNote: analystNote ?? null,
      decidedBy: actor.id,
      decidedByName: actor.name,
      snapshot: rec,
    }).returning();

    await audit({
      ...fromRequest(req), organizationId: orgId,
      eventType: decision === "approved" ? "rule.change.approved" : "rule.change.rejected",
      summary: `Rule "${rec.ruleName}" change ${decision}: ${rec.suggestedChange}`,
      resourceType: "rule", resourceId: rec.ruleId, resourceName: rec.ruleName,
      details: { decision, action: rec.action, riskScore: rec.riskScore, suggestedChange: rec.suggestedChange, analystNote: analystNote ?? null, jobId: job.id },
    });

    res.status(201).json({ ...saved, decidedAt: saved.decidedAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to record decision" });
  }
});

// Full version history for a single rule across all jobs.
router.get("/rule-tuning/rules/:ruleId/history", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const decisions = await db.select().from(ruleTuningDecisionsTable)
      .where(and(eq(ruleTuningDecisionsTable.organizationId, orgId), eq(ruleTuningDecisionsTable.ruleId, req.params.ruleId)))
      .orderBy(desc(ruleTuningDecisionsTable.decidedAt));
    res.json(decisions.map((d) => ({ ...d, decidedAt: d.decidedAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load rule history" });
  }
});

router.post("/rule-tuning/run", requirePermission("rules:run_tuning"), async (req, res) => {
  try {
    const orgId = getOrgId(req);
    req.log.info({ orgId }, "Manual rule tuning job triggered");
    const result = await runRuleTuningJob(orgId, "manual");
    await audit({
      ...fromRequest(req), organizationId: orgId,
      eventType: "rule.tuning.run",
      summary: `Rule optimization analysis triggered manually`,
      resourceType: "rule",
      details: { rulesAnalyzed: result.totalRulesAnalyzed, triggeredBy: "manual" },
    });
    res.json({ ...result, recommendations: JSON.parse(result.recommendations), rawMetrics: JSON.parse(result.rawMetrics) });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to run rule tuning job" });
  }
});

export default router;
