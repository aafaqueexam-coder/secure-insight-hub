import { Router } from "express";
import { db } from "@workspace/db";
import { wazuhConnectionsTable, alertsTable, wazuhAgentsTable, fimEventsTable, vulnerabilitiesTable } from "@workspace/db";
import { eq, and, desc, sql } from "drizzle-orm";
import { syncWazuhConnection } from "../lib/wazuhSync";
import {
  authenticate, fetchAgents, fetchRules, fetchMitreTechniques,
  fetchFimEvents, fetchVulnerabilities, fetchManagerInfo,
  triggerActiveResponse, fetchActiveResponseCommands,
  clearTokenCache, WazuhApiError,
} from "../lib/wazuhClient";
import { audit, fromRequest } from "../lib/auditWriter";

const router = Router();
function getOrgId(req: any): string { return (req.query.orgId as string) || "demo-org"; }
function fmt(c: any) {
  return {
    ...c, passwordHash: undefined,
    lastSyncAt: c.lastSyncAt?.toISOString() ?? null,
    lastErrorAt: c.lastErrorAt?.toISOString() ?? null,
    createdAt: c.createdAt.toISOString(),
    updatedAt: c.updatedAt?.toISOString() ?? null,
  };
}

/* ─── Connection CRUD ──────────────────────────────────────────────────── */
router.get("/wazuh-connections", async (req, res) => {
  try {
    const conns = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.organizationId, getOrgId(req)));
    res.json(conns.map(fmt));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to list connections" }); }
});

router.post("/wazuh-connections", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { name, apiUrl, username, password, syncInterval, syncAlerts, syncAgents, syncVulnerabilities, syncFim } = req.body;
    if (!name || !apiUrl || !username || !password) { res.status(400).json({ error: "name, apiUrl, username, password are required" }); return; }
    const [conn] = await db.insert(wazuhConnectionsTable).values({
      organizationId: orgId, name, apiUrl, username, passwordHash: password,
      syncInterval: syncInterval ?? 300, status: "pending",
      syncAlerts: syncAlerts ?? true, syncAgents: syncAgents ?? true,
      syncVulnerabilities: syncVulnerabilities ?? true, syncFim: syncFim ?? true,
    }).returning();
    await audit({ ...fromRequest(req), organizationId: orgId, eventType: "wazuh.connection.created", summary: `Wazuh connection "${name}" created`, resourceType: "wazuh", resourceId: conn.id, resourceName: name });
    res.status(201).json(fmt(conn));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to create connection" }); }
});

router.patch("/wazuh-connections/:id", async (req, res) => {
  try {
    const { name, apiUrl, username, password, syncInterval, syncAlerts, syncAgents, syncVulnerabilities, syncFim } = req.body;
    const updates: any = { updatedAt: new Date() };
    if (name) updates.name = name;
    if (apiUrl) updates.apiUrl = apiUrl;
    if (username) updates.username = username;
    if (password) { updates.passwordHash = password; clearTokenCache(apiUrl ?? "", username ?? ""); }
    if (syncInterval !== undefined) updates.syncInterval = syncInterval;
    if (syncAlerts !== undefined) updates.syncAlerts = syncAlerts;
    if (syncAgents !== undefined) updates.syncAgents = syncAgents;
    if (syncVulnerabilities !== undefined) updates.syncVulnerabilities = syncVulnerabilities;
    if (syncFim !== undefined) updates.syncFim = syncFim;
    const [updated] = await db.update(wazuhConnectionsTable).set(updates).where(eq(wazuhConnectionsTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "Connection not found" }); return; }
    res.json(fmt(updated));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to update connection" }); }
});

router.delete("/wazuh-connections/:id", async (req, res) => {
  try {
    await db.delete(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    res.status(204).send();
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to delete connection" }); }
});

/* ─── Wazuh API Auth Test ────────────────────────────────────────────── */
router.post("/wazuh-connections/:id/test", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    const t0 = Date.now();
    try {
      clearTokenCache(conn.apiUrl, conn.username);
      const token = await authenticate(conn.apiUrl, conn.username, conn.passwordHash);
      const info = await fetchManagerInfo(conn.apiUrl, token);
      const latencyMs = Date.now() - t0;
      await db.update(wazuhConnectionsTable).set({ status: "connected" }).where(eq(wazuhConnectionsTable.id, conn.id));
      res.json({ success: true, latencyMs, managerVersion: (info as any).version, managerType: (info as any).type, message: "Connected and authenticated successfully" });
    } catch (err: any) {
      const msg = err instanceof WazuhApiError ? err.message : `Connection failed: ${err.message}`;
      await db.update(wazuhConnectionsTable).set({ status: "error", lastErrorAt: new Date(), lastErrorMessage: msg }).where(eq(wazuhConnectionsTable.id, conn.id));
      res.json({ success: false, latencyMs: Date.now() - t0, message: msg });
    }
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to test connection" }); }
});

/* ─── Full Sync ─────────────────────────────────────────────────────── */
router.post("/wazuh-connections/:id/sync", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    // Respond immediately — sync runs in background
    res.json({ success: true, message: "Sync started", connectionId: conn.id });
    setImmediate(async () => {
      try {
        const result = await syncWazuhConnection(conn.id);
        await audit({
          ...fromRequest(req), organizationId: conn.organizationId,
          eventType: "wazuh.sync.completed",
          summary: `Wazuh sync: ${result.alertsSynced} alerts, ${result.agentsSynced} agents, ${result.vulnerabilitiesSynced} vulns, ${result.fimEventsSynced} FIM events`,
          resourceType: "wazuh", resourceId: conn.id, resourceName: conn.name,
          details: { ...result },
        });
      } catch (err: any) {
        req.log.error(err, "Background sync failed");
      }
    });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to start sync" }); }
});

// Synchronous sync for smaller requests (used by the "Sync Now" button — awaits result)
router.post("/wazuh-connections/:id/sync-now", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    const result = await syncWazuhConnection(conn.id);
    res.json(result);
  } catch (err: any) {
    req.log.error(err);
    res.status(500).json({ error: err instanceof WazuhApiError ? err.message : "Sync failed" });
  }
});

/* ─── Agent Status (live from Wazuh) ──────────────────────────────────── */
router.get("/wazuh-connections/:id/agents", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    const token = await authenticate(conn.apiUrl, conn.username, conn.passwordHash);
    const agents = await fetchAgents(conn.apiUrl, token);
    res.json(agents);
  } catch (err: any) {
    // Fallback to DB cache
    const orgId = getOrgId(req);
    const cached = await db.select().from(wazuhAgentsTable).where(and(eq(wazuhAgentsTable.connectionId, req.params.id), eq(wazuhAgentsTable.organizationId, orgId)));
    res.json(cached.map((a) => ({ ...a, lastKeepAlive: a.lastKeepAlive.toISOString() })));
  }
});

/* ─── Rule Metadata ────────────────────────────────────────────────────── */
router.get("/wazuh-connections/:id/rules", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    const token = await authenticate(conn.apiUrl, conn.username, conn.passwordHash);
    const rules = await fetchRules(conn.apiUrl, token, parseInt(req.query.limit as string) || 500);
    res.json(rules);
  } catch (err: any) { res.status(502).json({ error: err.message }); }
});

/* ─── MITRE Techniques ──────────────────────────────────────────────────── */
router.get("/wazuh-connections/:id/mitre", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    const token = await authenticate(conn.apiUrl, conn.username, conn.passwordHash);
    const techniques = await fetchMitreTechniques(conn.apiUrl, token);
    res.json(techniques);
  } catch (err: any) { res.status(502).json({ error: err.message }); }
});

/* ─── Vulnerabilities ──────────────────────────────────────────────────── */
router.get("/wazuh-connections/:id/vulnerabilities/:agentId", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    const token = await authenticate(conn.apiUrl, conn.username, conn.passwordHash);
    const vulns = await fetchVulnerabilities(conn.apiUrl, token, req.params.agentId);
    res.json(vulns);
  } catch (err: any) { res.status(502).json({ error: err.message }); }
});

/* ─── FIM Events ──────────────────────────────────────────────────────── */
router.get("/wazuh-connections/:id/fim/:agentId", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    const token = await authenticate(conn.apiUrl, conn.username, conn.passwordHash);
    const events = await fetchFimEvents(conn.apiUrl, token, req.params.agentId);
    res.json(events);
  } catch (err: any) {
    // Fallback to DB cache
    const cached = await db.select().from(fimEventsTable)
      .where(and(eq(fimEventsTable.connectionId, req.params.id), eq(fimEventsTable.agentId, req.params.agentId)))
      .orderBy(desc(fimEventsTable.eventTimestamp)).limit(100);
    res.json(cached.map((e) => ({ ...e, eventTimestamp: e.eventTimestamp.toISOString(), createdAt: e.createdAt.toISOString() })));
  }
});

// All FIM events for the org (from DB cache)
router.get("/wazuh-connections/:id/fim", async (req, res) => {
  try {
    const limit = parseInt(req.query.limit as string) || 100;
    const events = await db.select().from(fimEventsTable)
      .where(eq(fimEventsTable.connectionId, req.params.id))
      .orderBy(desc(fimEventsTable.eventTimestamp)).limit(limit);
    res.json(events.map((e) => ({ ...e, eventTimestamp: e.eventTimestamp.toISOString(), createdAt: e.createdAt.toISOString() })));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to list FIM events" }); }
});

/* ─── Active Response ──────────────────────────────────────────────────── */
router.get("/wazuh-connections/:id/active-response/commands", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    const token = await authenticate(conn.apiUrl, conn.username, conn.passwordHash);
    const commands = await fetchActiveResponseCommands(conn.apiUrl, token);
    // Always include the standard built-in active responses
    const builtins = ["restart-wazuh", "netsh", "route-null", "host-deny", "firewall-drop", "disable-account"];
    res.json([...new Set([...builtins, ...commands])]);
  } catch (err: any) {
    // Return builtins even if API call fails
    res.json(["restart-wazuh", "netsh", "route-null", "host-deny", "firewall-drop", "disable-account"]);
  }
});

router.post("/wazuh-connections/:id/active-response", async (req, res) => {
  try {
    const { agentId, command, arguments: args = [] } = req.body as { agentId: string; command: string; arguments?: string[] };
    if (!agentId || !command) { res.status(400).json({ error: "agentId and command are required" }); return; }
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    const token = await authenticate(conn.apiUrl, conn.username, conn.passwordHash);
    const result = await triggerActiveResponse(conn.apiUrl, token, agentId, command, args);
    await audit({
      ...fromRequest(req), organizationId: conn.organizationId,
      eventType: "wazuh.active_response.triggered",
      summary: `Active response "${command}" triggered on agent ${agentId}`,
      resourceType: "wazuh", resourceId: conn.id, resourceName: conn.name,
      details: { agentId, command, arguments: args, result },
    });
    res.json(result);
  } catch (err: any) { res.status(502).json({ error: err.message }); }
});

/* ─── Ingest webhook (Wazuh → platform push) ─────────────────────────── */
router.post("/wazuh-connections/:id/ingest", async (req, res) => {
  try {
    const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, req.params.id));
    if (!conn) { res.status(404).json({ error: "Connection not found" }); return; }
    const rawAlerts = Array.isArray(req.body) ? req.body : Array.isArray(req.body?.alerts) ? req.body.alerts : [req.body];
    if (!rawAlerts.length) { res.status(400).json({ error: "No alerts provided" }); return; }
    const toInsert = rawAlerts.map((raw: any) => ({
      organizationId: conn.organizationId, connectionId: conn.id,
      ruleId: String(raw.rule?.id ?? raw.ruleId ?? "unknown"),
      ruleName: raw.rule?.description ?? raw.ruleName ?? "Unnamed rule",
      ruleLevel: Number(raw.rule?.level ?? raw.ruleLevel ?? 0),
      severity: mapLevelToSeverity(Number(raw.rule?.level ?? raw.ruleLevel ?? 0)),
      description: raw.full_log ?? raw.description ?? raw.rule?.description ?? "No description",
      agentId: String(raw.agent?.id ?? raw.agentId ?? "unknown"),
      agentName: raw.agent?.name ?? raw.agentName ?? "unknown-agent",
      agentIp: raw.agent?.ip ?? raw.agentIp ?? null,
      sourceIp: raw.data?.srcip ?? raw.sourceIp ?? null,
      status: "new" as const,
      mitreTactic: raw.rule?.mitre?.tactic?.[0] ?? raw.mitreTactic ?? null,
      mitreTechnique: raw.rule?.mitre?.technique?.[0] ?? raw.mitreTechnique ?? null,
      mitreTechniqueId: raw.rule?.mitre?.id?.[0] ?? raw.mitreTechniqueId ?? null,
      rawLog: typeof raw === "string" ? raw : JSON.stringify(raw),
      timestamp: raw.timestamp ? new Date(raw.timestamp) : new Date(),
    }));
    const inserted = await db.insert(alertsTable).values(toInsert).onConflictDoNothing().returning({ id: alertsTable.id });
    await db.update(wazuhConnectionsTable).set({ lastSyncAt: new Date(), lastSyncStatus: "success" }).where(eq(wazuhConnectionsTable.id, conn.id));
    res.status(201).json({ received: rawAlerts.length, ingested: inserted.length, alertIds: inserted.map((a) => a.id) });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to ingest alerts" }); }
});

function mapLevelToSeverity(level: number): "low" | "medium" | "high" | "critical" {
  if (level >= 12) return "critical";
  if (level >= 8) return "high";
  if (level >= 4) return "medium";
  return "low";
}

export default router;
