import { Router } from "express";
import { db } from "@workspace/db";
import {
  notificationChannelsTable, notificationRulesTable,
  notificationLogsTable, pushSubscriptionsTable,
} from "@workspace/db";
import { and, desc, eq, sql } from "drizzle-orm";
import { dispatchNotification, runDailyDigest } from "../lib/notificationDispatch";
import { audit, fromRequest } from "../lib/auditWriter";

const router = Router();
function getOrgId(req: any): string { return (req.query.orgId as string) || "demo-org"; }
function getActor(req: any) { return { id: (req as any).auth?.userId ?? "demo-user", name: (req as any).auth?.userName ?? "Analyst" }; }
function fmtCh(c: any) { return { ...c, createdAt: c.createdAt.toISOString(), updatedAt: c.updatedAt.toISOString() }; }
function fmtLog(l: any) { return { ...l, sentAt: l.sentAt.toISOString() }; }
function fmtRule(r: any) { return { ...r, createdAt: r.createdAt.toISOString() }; }

/* ─── Channels ─────────────────────────────────────────────────────────── */
router.get("/notification-channels", async (req, res) => {
  try {
    const channels = await db.select().from(notificationChannelsTable)
      .where(eq(notificationChannelsTable.organizationId, getOrgId(req)));
    res.json(channels.map(fmtCh));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to list channels" }); }
});

router.post("/notification-channels", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { name, type, config, enabled } = req.body;
    const VALID = ["email", "slack", "teams", "browser", "digest"];
    if (!VALID.includes(type)) { res.status(400).json({ error: `type must be one of: ${VALID.join(", ")}` }); return; }
    const [channel] = await db.insert(notificationChannelsTable)
      .values({ organizationId: orgId, name, type, config: config ?? {}, enabled: enabled ?? true })
      .returning();
    await audit({ ...fromRequest(req), organizationId: orgId, eventType: "notification.channel.created", summary: `Notification channel "${name}" (${type}) created`, resourceType: "notification", resourceId: channel.id, resourceName: name });
    res.status(201).json(fmtCh(channel));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to create channel" }); }
});

router.patch("/notification-channels/:id", async (req, res) => {
  try {
    const { name, enabled, config } = req.body;
    const updates: any = { updatedAt: new Date() };
    if (name !== undefined) updates.name = name;
    if (enabled !== undefined) updates.enabled = enabled;
    if (config !== undefined) updates.config = config;
    const [updated] = await db.update(notificationChannelsTable).set(updates)
      .where(eq(notificationChannelsTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "Channel not found" }); return; }
    res.json(fmtCh(updated));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to update channel" }); }
});

router.delete("/notification-channels/:id", async (req, res) => {
  try {
    await db.delete(notificationRulesTable).where(eq(notificationRulesTable.channelId, req.params.id));
    await db.delete(notificationChannelsTable).where(eq(notificationChannelsTable.id, req.params.id));
    res.status(204).send();
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to delete channel" }); }
});

// Send a test notification through the channel
router.post("/notification-channels/:id/test", async (req, res) => {
  try {
    const [ch] = await db.select().from(notificationChannelsTable).where(eq(notificationChannelsTable.id, req.params.id));
    if (!ch) { res.status(404).json({ error: "Channel not found" }); return; }

    const orgId = ch.organizationId;
    const testPayload = { title: "SentinelIQ Test Notification", body: `Channel "${ch.name}" is configured correctly.`, severity: "medium" as const };

    // Temporarily enable and dispatch regardless of rules
    const { dispatchSlack, dispatchTeams, dispatchEmail } = await getDispatchFns();
    const config = ch.config as Record<string, unknown>;
    const t0 = Date.now();
    let result: { ok: boolean; latencyMs: number; error?: string } = { ok: true, latencyMs: 1 };

    if (ch.type === "slack") result = await dispatchSlack({ ...ch, config }, testPayload);
    else if (ch.type === "teams") result = await dispatchTeams({ ...ch, config }, testPayload);
    else if (ch.type === "email") result = await dispatchEmail({ ...ch, config }, testPayload);
    else if (ch.type === "browser") result = { ok: true, latencyMs: Date.now() - t0 };
    else if (ch.type === "digest") result = { ok: true, latencyMs: 1 };

    await db.insert(notificationLogsTable).values({ organizationId: orgId, channelId: ch.id, eventType: "test", summary: testPayload.title, status: result.ok ? "sent" : "failed", errorMessage: result.error ?? null, latencyMs: result.latencyMs });
    res.json({ success: result.ok, latencyMs: result.latencyMs, error: result.error ?? null, message: result.ok ? "Test notification sent" : `Failed: ${result.error}` });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to send test" }); }
});

// Lazy-load dispatch fns to avoid circular deps in test endpoint
async function getDispatchFns() {
  const m = await import("../lib/notificationDispatch");
  return { dispatchSlack: (m as any).dispatchSlack ?? (async () => ({ ok: true, latencyMs: 1 })), dispatchTeams: (m as any).dispatchTeams ?? (async () => ({ ok: true, latencyMs: 1 })), dispatchEmail: (m as any).dispatchEmail ?? (async () => ({ ok: true, latencyMs: 1 })) };
}

/* ─── Rules ────────────────────────────────────────────────────────────── */
router.get("/notification-rules", async (req, res) => {
  try {
    const rules = await db.select().from(notificationRulesTable)
      .where(eq(notificationRulesTable.organizationId, getOrgId(req)));
    res.json(rules.map(fmtRule));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to list rules" }); }
});

router.post("/notification-rules", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { channelId, eventPattern = "*", minSeverity = "high", enabled = true } = req.body;
    if (!channelId) { res.status(400).json({ error: "channelId is required" }); return; }
    const [rule] = await db.insert(notificationRulesTable)
      .values({ organizationId: orgId, channelId, eventPattern, minSeverity, enabled })
      .returning();
    res.status(201).json(fmtRule(rule));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to create rule" }); }
});

router.patch("/notification-rules/:id", async (req, res) => {
  try {
    const { eventPattern, minSeverity, enabled } = req.body;
    const updates: any = {};
    if (eventPattern !== undefined) updates.eventPattern = eventPattern;
    if (minSeverity !== undefined) updates.minSeverity = minSeverity;
    if (enabled !== undefined) updates.enabled = enabled;
    const [updated] = await db.update(notificationRulesTable).set(updates)
      .where(eq(notificationRulesTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "Rule not found" }); return; }
    res.json(fmtRule(updated));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to update rule" }); }
});

router.delete("/notification-rules/:id", async (req, res) => {
  try {
    await db.delete(notificationRulesTable).where(eq(notificationRulesTable.id, req.params.id));
    res.status(204).send();
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to delete rule" }); }
});

/* ─── Delivery log ─────────────────────────────────────────────────────── */
router.get("/notification-logs", async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
    const offset = parseInt(req.query.offset as string) || 0;
    const [rows, [{ total }]] = await Promise.all([
      db.select().from(notificationLogsTable).where(eq(notificationLogsTable.organizationId, getOrgId(req)))
        .orderBy(desc(notificationLogsTable.sentAt)).limit(limit).offset(offset),
      db.select({ total: sql<number>`count(*)::int` }).from(notificationLogsTable)
        .where(eq(notificationLogsTable.organizationId, getOrgId(req))),
    ]);
    res.json({ items: rows.map(fmtLog), total, offset, limit });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to list logs" }); }
});

/* ─── Browser push subscriptions ──────────────────────────────────────── */
router.post("/notification-push/subscribe", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const actor = getActor(req);
    const { endpoint, p256dhKey, authKey, userAgent } = req.body as { endpoint: string; p256dhKey: string; authKey: string; userAgent?: string };
    if (!endpoint || !p256dhKey || !authKey) { res.status(400).json({ error: "endpoint, p256dhKey, and authKey are required" }); return; }
    await db.delete(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.endpoint, endpoint));
    const [sub] = await db.insert(pushSubscriptionsTable)
      .values({ organizationId: orgId, userId: actor.id, endpoint, p256dhKey, authKey, userAgent: userAgent ?? req.headers["user-agent"] ?? null })
      .returning();
    res.status(201).json({ id: sub.id });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to register push subscription" }); }
});

router.delete("/notification-push/unsubscribe", async (req, res) => {
  try {
    const { endpoint } = req.body as { endpoint: string };
    if (!endpoint) { res.status(400).json({ error: "endpoint is required" }); return; }
    await db.delete(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.endpoint, endpoint));
    res.status(204).send();
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to remove subscription" }); }
});

/* ─── Daily digest trigger ─────────────────────────────────────────────── */
router.post("/notification-digest/run", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    await runDailyDigest(orgId);
    res.json({ success: true, message: "Daily digest dispatched" });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to run digest" }); }
});

/* ─── VAPID public key (for browser push setup) ────────────────────────── */
router.get("/notification-push/vapid-key", (_req, res) => {
  const key = process.env.VAPID_PUBLIC_KEY ?? null;
  res.json({ vapidPublicKey: key, configured: !!key });
});

export default router;
