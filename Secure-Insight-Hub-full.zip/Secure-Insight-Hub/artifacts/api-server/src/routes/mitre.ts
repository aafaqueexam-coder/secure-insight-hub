import { Router } from "express";
import { db } from "@workspace/db";
import { alertsTable } from "@workspace/db";
import { eq, and, sql, desc, gte, isNotNull } from "drizzle-orm";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }

const MITRE_TACTICS = [
  { id: "TA0001", name: "Initial Access" },
  { id: "TA0002", name: "Execution" },
  { id: "TA0003", name: "Persistence" },
  { id: "TA0004", name: "Privilege Escalation" },
  { id: "TA0005", name: "Defense Evasion" },
  { id: "TA0006", name: "Credential Access" },
  { id: "TA0007", name: "Discovery" },
  { id: "TA0008", name: "Lateral Movement" },
  { id: "TA0009", name: "Collection" },
  { id: "TA0010", name: "Exfiltration" },
  { id: "TA0011", name: "Command and Control" },
  { id: "TA0040", name: "Impact" },
];

router.get("/mitre/coverage", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const tacticRows = await db.select({
      tactic: alertsTable.mitreTactic,
      count: sql<number>`count(*)::int`,
    }).from(alertsTable)
      .where(and(eq(alertsTable.organizationId, orgId), isNotNull(alertsTable.mitreTactic)))
      .groupBy(alertsTable.mitreTactic);

    const tacticMap = new Map(tacticRows.map(r => [r.tactic, r.count]));
    const covered = tacticRows.length;

    res.json({
      totalTechniques: 200,
      coveredTechniques: covered * 3,
      coveragePercent: Math.min(100, Math.round((covered / MITRE_TACTICS.length) * 100)),
      tacticBreakdown: MITRE_TACTICS.map(t => ({
        tactic: t.name,
        total: 15,
        covered: tacticMap.has(t.name) ? 8 : 0,
        alertCount: tacticMap.get(t.name) ?? 0,
      })),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get MITRE coverage" });
  }
});

router.get("/mitre/heatmap", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const rows = await db.select({
      mitreTactic: alertsTable.mitreTactic,
      mitreTechniqueId: alertsTable.mitreTechniqueId,
      mitreTechnique: alertsTable.mitreTechnique,
      alertCount: sql<number>`count(*)::int`,
      severity: sql<string>`mode() within group (order by severity)`,
    }).from(alertsTable)
      .where(and(
        eq(alertsTable.organizationId, orgId),
        isNotNull(alertsTable.mitreTechniqueId),
        isNotNull(alertsTable.mitreTactic),
      ))
      .groupBy(alertsTable.mitreTactic, alertsTable.mitreTechniqueId, alertsTable.mitreTechnique);

    res.json(rows.map(r => ({
      tacticId: MITRE_TACTICS.find(t => t.name === r.mitreTactic)?.id ?? "TA0000",
      tacticName: r.mitreTactic ?? "Unknown",
      techniqueId: r.mitreTechniqueId ?? "T0000",
      techniqueName: r.mitreTechnique ?? "Unknown",
      alertCount: r.alertCount,
      severity: r.severity ?? "low",
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get MITRE heatmap" });
  }
});

router.get("/mitre/techniques", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const rows = await db.select({
      techniqueId: alertsTable.mitreTechniqueId,
      techniqueName: alertsTable.mitreTechnique,
      tacticName: alertsTable.mitreTactic,
      alertCount: sql<number>`count(*)::int`,
      lastSeen: sql<string>`max(timestamp)::text`,
    }).from(alertsTable)
      .where(and(eq(alertsTable.organizationId, orgId), isNotNull(alertsTable.mitreTechniqueId)))
      .groupBy(alertsTable.mitreTechniqueId, alertsTable.mitreTechnique, alertsTable.mitreTactic)
      .orderBy(desc(sql`count(*)`));

    res.json(rows.map(r => ({
      techniqueId: r.techniqueId ?? "T0000",
      techniqueName: r.techniqueName ?? "Unknown",
      tacticId: MITRE_TACTICS.find(t => t.name === r.tacticName)?.id ?? "TA0000",
      tacticName: r.tacticName ?? "Unknown",
      alertCount: r.alertCount,
      lastSeen: r.lastSeen,
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list MITRE techniques" });
  }
});

router.get("/mitre/timeline", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const days = parseInt(req.query.days as string) || 7;
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const rows = await db.select({
      timestamp: alertsTable.timestamp,
      techniqueId: alertsTable.mitreTechniqueId,
      techniqueName: alertsTable.mitreTechnique,
      tacticName: alertsTable.mitreTactic,
      agentName: alertsTable.agentName,
      severity: alertsTable.severity,
    }).from(alertsTable)
      .where(and(
        eq(alertsTable.organizationId, orgId),
        isNotNull(alertsTable.mitreTechniqueId),
        gte(alertsTable.timestamp, since),
      ))
      .orderBy(desc(alertsTable.timestamp)).limit(100);

    res.json(rows.map(r => ({
      timestamp: r.timestamp.toISOString(),
      techniqueId: r.techniqueId ?? "T0000",
      techniqueName: r.techniqueName ?? "Unknown",
      tacticName: r.tacticName ?? "Unknown",
      agentName: r.agentName,
      severity: r.severity,
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get MITRE timeline" });
  }
});

export default router;
