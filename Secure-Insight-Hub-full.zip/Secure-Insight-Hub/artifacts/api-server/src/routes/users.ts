import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }
function formatUser(u: any) {
  return { ...u, lastActiveAt: u.lastActiveAt?.toISOString() ?? null, createdAt: u.createdAt.toISOString() };
}

router.get("/users/me", async (req, res) => {
  try {
    const userId = (req as any).auth?.userId;
    if (!userId) {
      res.json({ id: "demo-user", email: "analyst@demo.com", name: "Demo Analyst", role: "analyst", organizationId: "demo-org", avatarUrl: null, lastActiveAt: null, createdAt: new Date().toISOString() });
      return;
    }
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    if (!user) {
      res.json({ id: userId, email: "user@example.com", name: null, role: "analyst", organizationId: getOrgId(req), avatarUrl: null, lastActiveAt: null, createdAt: new Date().toISOString() });
      return;
    }
    res.json(formatUser(user));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get current user" });
  }
});

router.get("/users", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const users = await db.select().from(usersTable).where(eq(usersTable.organizationId, orgId));
    res.json(users.map(formatUser));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list users" });
  }
});

router.post("/users/invite", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { email, role } = req.body;
    const [user] = await db.insert(usersTable).values({ id: crypto.randomUUID(), email, role: role ?? "analyst", organizationId: orgId }).returning();
    res.status(201).json(formatUser(user));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to invite user" });
  }
});

router.patch("/users/:id", async (req, res) => {
  try {
    const { role, name } = req.body;
    const updates: any = {};
    if (role) updates.role = role;
    if (name) updates.name = name;
    const [updated] = await db.update(usersTable).set(updates).where(eq(usersTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "User not found" }); return; }
    res.json(formatUser(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update user" });
  }
});

router.delete("/users/:id", async (req, res) => {
  try {
    await db.delete(usersTable).where(eq(usersTable.id, req.params.id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to remove user" });
  }
});

export default router;
