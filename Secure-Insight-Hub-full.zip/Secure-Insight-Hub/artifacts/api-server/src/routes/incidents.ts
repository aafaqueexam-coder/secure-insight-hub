import { Router } from "express";
import { db } from "@workspace/db";
import {
  incidentsTable, incidentNotesTable, alertsTable, alertAnalysesTable,
  incidentTimelineTable, incidentEvidenceTable,
} from "@workspace/db";
import { eq, and, sql, desc, inArray } from "drizzle-orm";
import { requirePermission } from "../lib/rbac";
import { audit, fromRequest } from "../lib/auditWriter";
import { dispatchNotification } from "../lib/notificationDispatch";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }
function getActor(req: any): { id: string; name: string } {
  return { id: (req as any).auth?.userId ?? "demo-user", name: (req as any).auth?.userName ?? "Analyst" };
}

const STATUS_VALUES = ["open", "assigned", "investigating", "awaiting_approval", "resolved", "closed"] as const;
type IncidentStatus = (typeof STATUS_VALUES)[number];

const SEVERITY_TO_PRIORITY: Record<string, string> = {
  critical: "critical",
  high: "high",
  medium: "medium",
  low: "low",
};

function incidentNumber(seq: number) {
  return `INC-${1000 + seq}`;
}

function serializeIncident(i: typeof incidentsTable.$inferSelect) {
  return {
    ...i,
    incidentNumber: incidentNumber(i.incidentSeq),
    createdAt: i.createdAt.toISOString(),
    updatedAt: i.updatedAt.toISOString(),
    resolvedAt: i.resolvedAt?.toISOString() ?? null,
    closedAt: i.closedAt?.toISOString() ?? null,
  };
}

async function logTimeline(
  incidentId: string,
  organizationId: string,
  type: string,
  message: string,
  actorName: string,
  metadata?: Record<string, unknown>,
  occurredAt?: Date,
) {
  await db.insert(incidentTimelineTable).values({
    incidentId, organizationId, type, message, actorName,
    metadata: metadata ?? null,
    occurredAt: occurredAt ?? new Date(),
  });
}

/**
 * Links a set of alerts to an incident and seeds the timeline with their
 * history: when each alert fired, whether it already has AI analysis, and
 * whether that analysis was already reviewed by a human. Used by both manual
 * incident creation and the Alert → Incident conversion flow.
 */
async function linkAlertsAndSeedTimeline(incidentId: string, organizationId: string, alertIds: string[], actor: { id: string; name: string }) {
  if (!alertIds.length) return;
  await db.update(alertsTable).set({ incidentId }).where(and(eq(alertsTable.organizationId, organizationId), inArray(alertsTable.id, alertIds)));

  const alerts = await db.select().from(alertsTable).where(inArray(alertsTable.id, alertIds));
  const analyses = await db.select().from(alertAnalysesTable).where(inArray(alertAnalysesTable.alertId, alertIds));
  const analysisByAlert = new Map(analyses.map((a) => [a.alertId, a]));

  for (const alert of alerts) {
    await logTimeline(incidentId, organizationId, "alert_linked", `Alert "${alert.ruleName}" linked to incident`, actor.name, { alertId: alert.id }, alert.timestamp);
    const analysis = analysisByAlert.get(alert.id);
    if (analysis) {
      await logTimeline(incidentId, organizationId, "ai_analysis", `AI analysis available for "${alert.ruleName}" (confidence ${Math.round((analysis.confidenceScore ?? 0) * 100)}%)`, "AI Engine", { alertId: alert.id }, analysis.generatedAt);
      if (analysis.reviewStatus !== "pending_review" && analysis.reviewedAt) {
        await logTimeline(incidentId, organizationId, "human_review", `Analysis for "${alert.ruleName}" was ${analysis.reviewStatus} by ${analysis.reviewedBy ?? "an analyst"}`, analysis.reviewedBy ?? "Analyst", { alertId: alert.id }, analysis.reviewedAt);
      }
    }
  }
}

router.get("/incidents", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { status, priority } = req.query as Record<string, string>;
    const limit = parseInt(req.query.limit as string) || 20;
    const offset = parseInt(req.query.offset as string) || 0;
    const conditions = [eq(incidentsTable.organizationId, orgId)];
    if (status) conditions.push(eq(incidentsTable.status, status));
    if (priority) conditions.push(eq(incidentsTable.priority, priority));
    const [items, [{ total }]] = await Promise.all([
      db.select().from(incidentsTable).where(and(...conditions)).orderBy(desc(incidentsTable.createdAt)).limit(limit).offset(offset),
      db.select({ total: sql<number>`count(*)::int` }).from(incidentsTable).where(and(...conditions)),
    ]);
    res.json({ items: items.map(serializeIncident), total, offset, limit });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list incidents" });
  }
});

router.get("/incidents/stats", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [row] = await db.select({
      open: sql<number>`count(*) filter (where status='open')::int`,
      investigating: sql<number>`count(*) filter (where status='investigating')::int`,
      resolved: sql<number>`count(*) filter (where status='resolved')::int`,
      total: sql<number>`count(*)::int`,
    }).from(incidentsTable).where(eq(incidentsTable.organizationId, orgId));
    res.json({ open: row?.open ?? 0, investigating: row?.investigating ?? 0, resolved: row?.resolved ?? 0, total: row?.total ?? 0, avgResolutionHours: null });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get incident stats" });
  }
});

// Incident Creation: manual create, optionally with linked alerts. Fields the
// caller omits are auto-filled from the first linked alert when available.
router.post("/incidents", requirePermission("incidents:create"), async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const actor = getActor(req);
    const { title, description, priority, assigneeId, assigneeName, alertIds, tags } = req.body as {
      title?: string; description?: string; priority?: string; assigneeId?: string; assigneeName?: string; alertIds?: string[]; tags?: string[];
    };

    let autoTitle = title;
    let autoDescription = description;
    let autoPriority = priority;
    let autoTags = tags ?? [];

    if (alertIds?.length && (!autoTitle || !autoDescription || !autoPriority)) {
      const [firstAlert] = await db.select().from(alertsTable).where(eq(alertsTable.id, alertIds[0]));
      if (firstAlert) {
        autoTitle ??= alertIds.length > 1 ? `${firstAlert.ruleName} (+${alertIds.length - 1} more)` : firstAlert.ruleName;
        autoDescription ??= firstAlert.description;
        autoPriority ??= SEVERITY_TO_PRIORITY[firstAlert.severity] ?? "medium";
        if (firstAlert.mitreTechniqueId && !autoTags.includes(firstAlert.mitreTechniqueId)) autoTags = [...autoTags, firstAlert.mitreTechniqueId];
      }
    }

    if (!autoTitle) { res.status(400).json({ error: "title is required (or provide alertIds to auto-fill it)" }); return; }

    const [incident] = await db.insert(incidentsTable).values({
      organizationId: orgId,
      title: autoTitle,
      description: autoDescription,
      priority: autoPriority ?? "medium",
      assigneeId,
      assigneeName,
      tags: autoTags,
      status: assigneeId ? "assigned" : "open",
      alertCount: alertIds?.length ?? 0,
    }).returning();

    await logTimeline(incident.id, orgId, "incident_created", `Incident ${incidentNumber(incident.incidentSeq)} created`, actor.name);
    if (assigneeId) await logTimeline(incident.id, orgId, "assignment", `Assigned to ${assigneeName ?? assigneeId}`, actor.name);
    if (alertIds?.length) await linkAlertsAndSeedTimeline(incident.id, orgId, alertIds, actor);
    await audit({
      ...fromRequest(req), organizationId: orgId,
      eventType: "incident.created",
      summary: `Incident ${incidentNumber(incident.incidentSeq)} created: "${incident.title}"`,
      resourceType: "incident", resourceId: incident.id, resourceName: incidentNumber(incident.incidentSeq),
      details: { priority: incident.priority, alertIds: alertIds ?? [], assigneeName },
    });
    if (incident.priority === "critical" || incident.priority === "high") {
      dispatchNotification(orgId, "incident.created", {
        title: `New Incident: ${incident.title}`,
        body: `${incidentNumber(incident.incidentSeq)} · Priority: ${incident.priority}${assigneeName ? ` · Assigned to ${assigneeName}` : ""}`,
        severity: incident.priority as any,
        resourceType: "incident", resourceId: incident.id,
      }).catch(() => {});
    }

    res.status(201).json(serializeIncident(incident));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create incident" });
  }
});

router.get("/incidents/:id", async (req, res) => {
  try {
    const [incident] = await db.select().from(incidentsTable).where(eq(incidentsTable.id, req.params.id));
    if (!incident) { res.status(404).json({ error: "Incident not found" }); return; }
    res.json(serializeIncident(incident));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get incident" });
  }
});

router.get("/incidents/:id/alerts", async (req, res) => {
  try {
    const alerts = await db.select().from(alertsTable).where(eq(alertsTable.incidentId, req.params.id)).orderBy(desc(alertsTable.timestamp));
    res.json(alerts.map((a) => ({ ...a, timestamp: a.timestamp.toISOString(), createdAt: a.createdAt.toISOString(), updatedAt: a.updatedAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get incident alerts" });
  }
});

router.patch("/incidents/:id", requirePermission("incidents:update"), async (req, res) => {
  try {
    const { title, description, status, priority, assigneeId, assigneeName, resolutionSummary, tags } = req.body as {
      title?: string; description?: string; status?: string; priority?: string;
      assigneeId?: string; assigneeName?: string; resolutionSummary?: string; tags?: string[];
    };
    // Closing/resolving requires the incidents:close permission on top of incidents:update
    if ((status === "resolved" || status === "closed") && !(req as any).userRole) {
      res.status(403).json({ error: "Closing incidents requires the incidents:close permission" }); return;
    }
    const { requirePermission: rp } = await import("../lib/rbac");
    if (status === "resolved" || status === "closed") {
      const guard = rp("incidents:close");
      let blocked = false;
      guard(req as any, res, () => { blocked = false; });
      // If res was already sent (403) we stop
      if (res.headersSent) return;
    }
    const [existing] = await db.select().from(incidentsTable).where(eq(incidentsTable.id, req.params.id));
    if (!existing) { res.status(404).json({ error: "Incident not found" }); return; }

    if (status && !STATUS_VALUES.includes(status as IncidentStatus)) {
      res.status(400).json({ error: `status must be one of: ${STATUS_VALUES.join(", ")}` });
      return;
    }
    if ((status === "resolved" || status === "closed") && !resolutionSummary && !existing.resolutionSummary) {
      res.status(400).json({ error: "resolutionSummary is required to resolve or close an incident" });
      return;
    }

    const updates: Record<string, unknown> = {};
    if (title) updates.title = title;
    if (description !== undefined) updates.description = description;
    if (priority) updates.priority = priority;
    if (tags) updates.tags = tags;
    if (resolutionSummary !== undefined) updates.resolutionSummary = resolutionSummary;
    if (status) {
      updates.status = status;
      if (status === "resolved") updates.resolvedAt = new Date();
      if (status === "closed") updates.closedAt = new Date();
    }
    if (assigneeId !== undefined) { updates.assigneeId = assigneeId; updates.assigneeName = assigneeName ?? null; }

    const [updated] = await db.update(incidentsTable).set(updates).where(eq(incidentsTable.id, req.params.id)).returning();
    const actor = getActor(req);

    if (assigneeId !== undefined && assigneeId !== existing.assigneeId) {
      await logTimeline(updated.id, updated.organizationId, "assignment", assigneeId ? `Assigned to ${assigneeName ?? assigneeId}` : "Unassigned", actor.name);
      await audit({
        ...fromRequest(req), organizationId: updated.organizationId,
        eventType: "incident.assigned",
        summary: assigneeId ? `Incident ${incidentNumber(updated.incidentSeq)} assigned to ${assigneeName ?? assigneeId}` : `Incident ${incidentNumber(updated.incidentSeq)} unassigned`,
        resourceType: "incident", resourceId: updated.id, resourceName: incidentNumber(updated.incidentSeq),
        details: { previousAssignee: existing.assigneeName, newAssignee: assigneeName ?? assigneeId ?? null },
      });
    }
    if (status && status !== existing.status) {
      const isResolution = status === "resolved" || status === "closed";
      await logTimeline(
        updated.id, updated.organizationId,
        isResolution ? "resolution" : "status_change",
        isResolution ? `Marked ${status}${resolutionSummary ? `: ${resolutionSummary}` : ""}` : `Status changed from "${existing.status}" to "${status}"`,
        actor.name,
      );
      await audit({
        ...fromRequest(req), organizationId: updated.organizationId,
        eventType: isResolution ? "incident.closed" : "incident.updated",
        summary: isResolution
          ? `Incident ${incidentNumber(updated.incidentSeq)} ${status}`
          : `Incident ${incidentNumber(updated.incidentSeq)} status changed to "${status}"`,
        resourceType: "incident", resourceId: updated.id, resourceName: incidentNumber(updated.incidentSeq),
        details: { previousStatus: existing.status, newStatus: status, resolutionSummary: resolutionSummary ?? null },
      });
    }

    res.json(serializeIncident(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update incident" });
  }
});

// Convert Alert → Incident: auto-fills all incident fields from the alert
// (and its AI analysis, if one exists) and links the alert immediately.
router.post("/alerts/:id/convert-to-incident", requirePermission("incidents:create"), async (req, res) => {
  try {
    const [alert] = await db.select().from(alertsTable).where(eq(alertsTable.id, req.params.id));
    if (!alert) { res.status(404).json({ error: "Alert not found" }); return; }
    if (alert.incidentId) { res.status(409).json({ error: "Alert is already linked to an incident", incidentId: alert.incidentId }); return; }

    const [analysis] = await db.select().from(alertAnalysesTable).where(eq(alertAnalysesTable.alertId, alert.id));
    const orgId = alert.organizationId;
    const actor = getActor(req);

    const { assigneeId, assigneeName } = req.body as { assigneeId?: string; assigneeName?: string };

    const [incident] = await db.insert(incidentsTable).values({
      organizationId: orgId,
      title: alert.ruleName,
      description: analysis?.summary || alert.description,
      priority: SEVERITY_TO_PRIORITY[alert.severity] ?? "medium",
      tags: alert.mitreTechniqueId ? [alert.mitreTechniqueId] : [],
      assigneeId,
      assigneeName,
      status: assigneeId ? "assigned" : "investigating",
      alertCount: 1,
    }).returning();

    await logTimeline(incident.id, orgId, "incident_created", `Incident ${incidentNumber(incident.incidentSeq)} created from alert "${alert.ruleName}"`, actor.name);
    await linkAlertsAndSeedTimeline(incident.id, orgId, [alert.id], actor);
    if (assigneeId) await logTimeline(incident.id, orgId, "assignment", `Assigned to ${assigneeName ?? assigneeId}`, actor.name);

    res.status(201).json(serializeIncident(incident));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to convert alert to incident" });
  }
});

// Link additional existing alerts to an already-created incident.
router.post("/incidents/:id/alerts", async (req, res) => {
  try {
    const { alertIds } = req.body as { alertIds: string[] };
    if (!Array.isArray(alertIds) || !alertIds.length) { res.status(400).json({ error: "alertIds must be a non-empty array" }); return; }
    const [incident] = await db.select().from(incidentsTable).where(eq(incidentsTable.id, req.params.id));
    if (!incident) { res.status(404).json({ error: "Incident not found" }); return; }

    const actor = getActor(req);
    await linkAlertsAndSeedTimeline(incident.id, incident.organizationId, alertIds, actor);
    const [updated] = await db.update(incidentsTable).set({ alertCount: sql`${incidentsTable.alertCount} + ${alertIds.length}` }).where(eq(incidentsTable.id, incident.id)).returning();
    res.json(serializeIncident(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to link alerts" });
  }
});

// Analyst Notes: rich-ish text comments (markdown-lite), optionally internal-only.
router.get("/incidents/:id/notes", async (req, res) => {
  try {
    const notes = await db.select().from(incidentNotesTable).where(eq(incidentNotesTable.incidentId, req.params.id)).orderBy(incidentNotesTable.createdAt);
    const evidence = await db.select().from(incidentEvidenceTable).where(eq(incidentEvidenceTable.incidentId, req.params.id));
    const evidenceByNote = new Map<string, typeof evidence>();
    for (const e of evidence) {
      if (!e.noteId) continue;
      evidenceByNote.set(e.noteId, [...(evidenceByNote.get(e.noteId) ?? []), e]);
    }
    res.json(notes.map((n) => ({
      ...n,
      createdAt: n.createdAt.toISOString(),
      evidence: (evidenceByNote.get(n.id) ?? []).map((e) => ({ ...e, uploadedAt: e.uploadedAt.toISOString() })),
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list notes" });
  }
});

router.post("/incidents/:id/notes", async (req, res) => {
  try {
    const { content, internal } = req.body as { content: string; internal?: boolean };
    if (!content?.trim()) { res.status(400).json({ error: "content is required" }); return; }
    const [incident] = await db.select().from(incidentsTable).where(eq(incidentsTable.id, req.params.id));
    if (!incident) { res.status(404).json({ error: "Incident not found" }); return; }
    const actor = getActor(req);

    const [note] = await db.insert(incidentNotesTable).values({
      incidentId: req.params.id,
      organizationId: incident.organizationId,
      content: content.trim(),
      internal: internal ?? true,
      authorId: actor.id,
      authorName: actor.name,
    }).returning();

    await logTimeline(req.params.id, incident.organizationId, "comment_added", `${internal === false ? "Note" : "Internal note"} added`, actor.name, { noteId: note.id });

    res.status(201).json({ ...note, createdAt: note.createdAt.toISOString(), evidence: [] });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to add note" });
  }
});

// Evidence attachments: small files (sent as data URLs) or links, optionally
// attached to a specific note.
router.get("/incidents/:id/evidence", async (req, res) => {
  try {
    const evidence = await db.select().from(incidentEvidenceTable).where(eq(incidentEvidenceTable.incidentId, req.params.id)).orderBy(desc(incidentEvidenceTable.uploadedAt));
    res.json(evidence.map((e) => ({ ...e, uploadedAt: e.uploadedAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list evidence" });
  }
});

router.post("/incidents/:id/evidence", async (req, res) => {
  try {
    const { name, type, url, mimeType, sizeBytes, noteId } = req.body as {
      name: string; type: "file" | "link"; url: string; mimeType?: string; sizeBytes?: number; noteId?: string;
    };
    if (!name?.trim() || !url || !type) { res.status(400).json({ error: "name, type, and url are required" }); return; }
    if (type === "file" && sizeBytes && sizeBytes > 5 * 1024 * 1024) { res.status(400).json({ error: "File evidence is limited to 5MB" }); return; }

    const [incident] = await db.select().from(incidentsTable).where(eq(incidentsTable.id, req.params.id));
    if (!incident) { res.status(404).json({ error: "Incident not found" }); return; }
    const actor = getActor(req);

    const [item] = await db.insert(incidentEvidenceTable).values({
      incidentId: req.params.id,
      organizationId: incident.organizationId,
      noteId: noteId ?? null,
      name: name.trim(),
      type,
      url,
      mimeType: mimeType ?? null,
      sizeBytes: sizeBytes ?? null,
      uploadedBy: actor.name,
    }).returning();

    await logTimeline(req.params.id, incident.organizationId, "comment_added", `Evidence "${item.name}" attached`, actor.name, { evidenceId: item.id });

    res.status(201).json({ ...item, uploadedAt: item.uploadedAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to attach evidence" });
  }
});

// Incident Timeline: unified, chronological log of everything that happened.
router.get("/incidents/:id/timeline", async (req, res) => {
  try {
    const events = await db.select().from(incidentTimelineTable).where(eq(incidentTimelineTable.incidentId, req.params.id)).orderBy(incidentTimelineTable.occurredAt);
    res.json(events.map((e) => ({ ...e, occurredAt: e.occurredAt.toISOString(), createdAt: e.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get timeline" });
  }
});

export default router;
