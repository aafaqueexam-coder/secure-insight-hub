import { Router } from "express";
import { db } from "@workspace/db";
import { alertsTable, vulnerabilitiesTable, wazuhAgentsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }

router.get("/security-score", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [alerts, vulns, agents] = await Promise.all([
      db.select({ critical: sql<number>`count(*) filter (where severity='critical' and status='new')::int` }).from(alertsTable).where(eq(alertsTable.organizationId, orgId)),
      db.select({ critical: sql<number>`count(*) filter (where severity='critical' and status='open')::int`, total: sql<number>`count(*)::int` }).from(vulnerabilitiesTable).where(eq(vulnerabilitiesTable.organizationId, orgId)),
      db.select({ total: sql<number>`count(*)::int`, offline: sql<number>`count(*) filter (where status='disconnected')::int` }).from(wazuhAgentsTable).where(eq(wazuhAgentsTable.organizationId, orgId)),
    ]);

    const criticalAlerts = alerts[0]?.critical ?? 0;
    const criticalVulns = vulns[0]?.critical ?? 0;
    const totalAgents = agents[0]?.total ?? 1;
    const offlineAgents = agents[0]?.offline ?? 0;

    const alertPenalty = Math.min(30, criticalAlerts * 3);
    const vulnPenalty = Math.min(25, criticalVulns * 2);
    const agentPenalty = Math.min(15, Math.round((offlineAgents / Math.max(totalAgents, 1)) * 100 * 0.15));

    const score = Math.max(0, 100 - alertPenalty - vulnPenalty - agentPenalty);
    const grade = score >= 90 ? "A" : score >= 80 ? "B" : score >= 70 ? "C" : score >= 60 ? "D" : "F";

    res.json({
      score,
      grade,
      trend: "up",
      trendValue: 3.2,
      recommendations: [
        "Remediate critical vulnerabilities on exposed systems",
        "Acknowledge and resolve open critical alerts",
        "Reconnect offline agents to restore full coverage",
        "Enable automated patch management",
        "Review and update incident response procedures",
      ],
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to calculate security score" });
  }
});

router.get("/security-score/history", async (req, res) => {
  const days = parseInt(req.query.days as string) || 30;
  const history = [];
  let score = 68;
  for (let i = days; i >= 0; i--) {
    const date = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
    score = Math.min(100, Math.max(40, score + (Math.random() - 0.4) * 3));
    history.push({ date: date.toISOString().split("T")[0], score: Math.round(score) });
  }
  res.json(history);
});

router.get("/security-score/breakdown", async (req, res) => {
  res.json([
    { name: "Patch Compliance", score: 65, weight: 0.20, status: "warning", description: "Critical patches applied within SLA" },
    { name: "Vulnerability Severity", score: 58, weight: 0.25, status: "critical", description: "Weighted CVSS score across assets" },
    { name: "Endpoint Health", score: 82, weight: 0.15, status: "good", description: "Agent connectivity and coverage" },
    { name: "Identity Security", score: 74, weight: 0.15, status: "warning", description: "Authentication events and anomalies" },
    { name: "Alert Volume", score: 71, weight: 0.10, status: "warning", description: "Alert frequency and resolution rate" },
    { name: "Incident Response", score: 79, weight: 0.10, status: "good", description: "Mean time to detect and respond" },
    { name: "Config Compliance", score: 83, weight: 0.05, status: "good", description: "CIS Benchmark compliance rate" },
  ]);
});

export default router;
