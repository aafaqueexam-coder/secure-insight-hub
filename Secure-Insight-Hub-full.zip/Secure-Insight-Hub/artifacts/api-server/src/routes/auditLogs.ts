import { Router } from "express";
import { db } from "@workspace/db";
import { auditLogsTable } from "@workspace/db";
import { and, desc, eq, gte, lte, ilike, sql } from "drizzle-orm";

const router = Router();
function getOrgId(req: any): string { return (req.query.orgId as string) || "demo-org"; }

function fmt(r: any) {
  return { ...r, occurredAt: r.occurredAt.toISOString() };
}

/**
 * GET /audit-logs
 * Query params: eventType, actorId, resourceType, resourceId, search, dateFrom, dateTo, limit, offset
 */
router.get("/audit-logs", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { eventType, actorId, resourceType, resourceId, search, dateFrom, dateTo } = req.query as Record<string, string>;
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 500);
    const offset = parseInt(req.query.offset as string) || 0;

    const conditions = [eq(auditLogsTable.organizationId, orgId)];
    if (eventType) conditions.push(ilike(auditLogsTable.eventType, `${eventType}%`));
    if (actorId) conditions.push(eq(auditLogsTable.actorId, actorId));
    if (resourceType) conditions.push(eq(auditLogsTable.resourceType, resourceType));
    if (resourceId) conditions.push(eq(auditLogsTable.resourceId, resourceId));
    if (dateFrom) conditions.push(gte(auditLogsTable.occurredAt, new Date(dateFrom)));
    if (dateTo) conditions.push(lte(auditLogsTable.occurredAt, new Date(dateTo)));
    if (search) {
      const term = `%${search.toLowerCase()}%`;
      conditions.push(sql`(lower(${auditLogsTable.summary}) like ${term} or lower(${auditLogsTable.actorName}) like ${term} or lower(${auditLogsTable.eventType}) like ${term})`);
    }

    const where = and(...conditions);
    const [rows, [{ total }]] = await Promise.all([
      db.select().from(auditLogsTable).where(where).orderBy(desc(auditLogsTable.occurredAt)).limit(limit).offset(offset),
      db.select({ total: sql<number>`count(*)::int` }).from(auditLogsTable).where(where),
    ]);

    res.json({ items: rows.map(fmt), total, offset, limit });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list audit logs" });
  }
});

/**
 * GET /audit-logs/stats
 * Counts by event domain for the overview panel.
 */
router.get("/audit-logs/stats", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const rows = await db.select({
      domain: sql<string>`split_part(event_type, '.', 1)`,
      count: sql<number>`count(*)::int`,
    }).from(auditLogsTable)
      .where(eq(auditLogsTable.organizationId, orgId))
      .groupBy(sql`split_part(event_type, '.', 1)`)
      .orderBy(desc(sql`count(*)`));

    const total = rows.reduce((s, r) => s + r.count, 0);
    const domainMap = Object.fromEntries(rows.map((r) => [r.domain, r.count]));

    // Recent unique actors
    const actors = await db.select({
      actorId: auditLogsTable.actorId,
      actorName: auditLogsTable.actorName,
      count: sql<number>`count(*)::int`,
      lastSeen: sql<string>`max(occurred_at)::text`,
    }).from(auditLogsTable)
      .where(eq(auditLogsTable.organizationId, orgId))
      .groupBy(auditLogsTable.actorId, auditLogsTable.actorName)
      .orderBy(desc(sql`max(occurred_at)`))
      .limit(10);

    res.json({ total, byDomain: domainMap, actors });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load audit stats" });
  }
});

/**
 * GET /audit-logs/export/csv
 * Full audit log export as CSV (up to 5000 rows).
 */
router.get("/audit-logs/export/csv", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const rows = await db.select().from(auditLogsTable)
      .where(eq(auditLogsTable.organizationId, orgId))
      .orderBy(desc(auditLogsTable.occurredAt))
      .limit(5000);

    const header = ["Timestamp", "Event Type", "Summary", "Actor", "Role", "Resource Type", "Resource", "IP Address"];
    const lines = [
      header.map((h) => `"${h}"`).join(","),
      ...rows.map((r) => [
        r.occurredAt.toISOString(),
        r.eventType,
        r.summary.replace(/"/g, '""'),
        r.actorName.replace(/"/g, '""'),
        r.actorRole ?? "",
        r.resourceType ?? "",
        r.resourceName ?? "",
        r.ipAddress ?? "",
      ].map((v) => `"${v}"`).join(",")),
    ];

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="audit_log_${new Date().toISOString().split("T")[0]}.csv"`);
    res.send(lines.join("\n"));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to export audit log" });
  }
});

export default router;
