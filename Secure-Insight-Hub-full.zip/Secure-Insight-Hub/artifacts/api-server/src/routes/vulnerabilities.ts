import { Router } from "express";
import { db } from "@workspace/db";
import { vulnerabilitiesTable } from "@workspace/db";
import { eq, and, sql, desc } from "drizzle-orm";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }
function fmt(v: any) { return { ...v, detectedAt: v.detectedAt.toISOString(), patchedAt: v.patchedAt?.toISOString() ?? null }; }

router.get("/vulnerabilities", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { severity, status, agentId } = req.query as Record<string, string>;
    const limit = parseInt(req.query.limit as string) || 50;
    const offset = parseInt(req.query.offset as string) || 0;
    const conditions = [eq(vulnerabilitiesTable.organizationId, orgId)];
    if (severity) conditions.push(eq(vulnerabilitiesTable.severity, severity));
    if (status) conditions.push(eq(vulnerabilitiesTable.status, status));
    if (agentId) conditions.push(eq(vulnerabilitiesTable.agentId, agentId));
    const [items, [{ total }]] = await Promise.all([
      db.select().from(vulnerabilitiesTable).where(and(...conditions)).orderBy(desc(vulnerabilitiesTable.cvssScore)).limit(limit).offset(offset),
      db.select({ total: sql<number>`count(*)::int` }).from(vulnerabilitiesTable).where(and(...conditions)),
    ]);
    res.json({ items: items.map(fmt), total, offset, limit });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list vulnerabilities" });
  }
});

router.get("/vulnerabilities/stats", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [row] = await db.select({
      total: sql<number>`count(*)::int`,
      critical: sql<number>`count(*) filter (where severity='critical')::int`,
      high: sql<number>`count(*) filter (where severity='high')::int`,
      medium: sql<number>`count(*) filter (where severity='medium')::int`,
      low: sql<number>`count(*) filter (where severity='low')::int`,
      open: sql<number>`count(*) filter (where status='open')::int`,
      fixed: sql<number>`count(*) filter (where status='fixed')::int`,
      avgCvss: sql<number>`coalesce(avg(cvss_score), 0)::float`,
    }).from(vulnerabilitiesTable).where(eq(vulnerabilitiesTable.organizationId, orgId));
    res.json({ total: row?.total ?? 0, critical: row?.critical ?? 0, high: row?.high ?? 0, medium: row?.medium ?? 0, low: row?.low ?? 0, open: row?.open ?? 0, fixed: row?.fixed ?? 0, avgCvssScore: Math.round((row?.avgCvss ?? 0) * 10) / 10 });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get vulnerability stats" });
  }
});

router.get("/vulnerabilities/by-asset", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const rows = await db.select({
      agentId: vulnerabilitiesTable.agentId,
      agentName: vulnerabilitiesTable.agentName,
      total: sql<number>`count(*)::int`,
      critical: sql<number>`count(*) filter (where severity='critical')::int`,
      high: sql<number>`count(*) filter (where severity='high')::int`,
      medium: sql<number>`count(*) filter (where severity='medium')::int`,
      low: sql<number>`count(*) filter (where severity='low')::int`,
    }).from(vulnerabilitiesTable).where(eq(vulnerabilitiesTable.organizationId, orgId))
      .groupBy(vulnerabilitiesTable.agentId, vulnerabilitiesTable.agentName)
      .orderBy(desc(sql`count(*)`)).limit(20);
    res.json(rows);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get vulnerabilities by asset" });
  }
});

router.get("/vulnerabilities/:id", async (req, res) => {
  try {
    const [vuln] = await db.select().from(vulnerabilitiesTable).where(eq(vulnerabilitiesTable.id, req.params.id));
    if (!vuln) { res.status(404).json({ error: "Vulnerability not found" }); return; }
    res.json(fmt(vuln));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get vulnerability" });
  }
});

router.patch("/vulnerabilities/:id", async (req, res) => {
  try {
    const { status, remediationNote } = req.body;
    const updates: any = {};
    if (status) { updates.status = status; if (status === "fixed") updates.patchedAt = new Date(); }
    if (remediationNote) updates.remediationNote = remediationNote;
    const [updated] = await db.update(vulnerabilitiesTable).set(updates).where(eq(vulnerabilitiesTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "Vulnerability not found" }); return; }
    res.json(fmt(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update vulnerability" });
  }
});

export default router;
