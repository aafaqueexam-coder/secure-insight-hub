import { Router } from "express";
import { db } from "@workspace/db";
import { alertsTable, incidentsTable, wazuhAgentsTable, vulnerabilitiesTable, alertAnalysesTable, ruleTuningRecommendationsTable } from "@workspace/db";
import { sql, eq, and, gte, desc, isNotNull } from "drizzle-orm";
import { withCache, cacheFlushPattern, TTL, isRedisAvailable } from "../lib/cache";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }
function getActor(req: any): string { return (req as any).auth?.userId ?? "demo-user"; }

router.get("/dashboard", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const cacheKey = `dashboard:stats:${orgId}`;
    const result = await withCache(cacheKey, async () => {
      const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
      const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000);
      const [alertCounts, alertsToday, incidentCounts, agentCounts, vulnCount, analysisStats, mttrRow] = await Promise.all([
        db.select({ total: sql<number>`count(*)::int`, critical: sql<number>`count(*) filter (where severity = 'critical')::int`, high: sql<number>`count(*) filter (where severity = 'high')::int`, medium: sql<number>`count(*) filter (where severity = 'medium')::int`, low: sql<number>`count(*) filter (where severity = 'low')::int`, falsePositives: sql<number>`count(*) filter (where false_positive = true)::int` }).from(alertsTable).where(eq(alertsTable.organizationId, orgId)),
        db.select({ count: sql<number>`count(*)::int` }).from(alertsTable).where(and(eq(alertsTable.organizationId, orgId), gte(alertsTable.timestamp, todayStart))),
        db.select({ open: sql<number>`count(*) filter (where status = 'open')::int`, total: sql<number>`count(*)::int`, resolved: sql<number>`count(*) filter (where status = 'resolved' or status = 'closed')::int` }).from(incidentsTable).where(eq(incidentsTable.organizationId, orgId)),
        db.select({ total: sql<number>`count(*)::int`, offline: sql<number>`count(*) filter (where status = 'disconnected')::int` }).from(wazuhAgentsTable).where(eq(wazuhAgentsTable.organizationId, orgId)),
        db.select({ count: sql<number>`count(distinct agent_id)::int` }).from(vulnerabilitiesTable).where(and(eq(vulnerabilitiesTable.organizationId, orgId), eq(vulnerabilitiesTable.status, "open"))),
        db.select({ pendingReviews: sql<number>`count(*) filter (where review_status = 'pending_review')::int`, approved: sql<number>`count(*) filter (where review_status = 'approved')::int`, rejected: sql<number>`count(*) filter (where review_status = 'rejected')::int`, avgConfidence: sql<number>`avg(confidence_score)::real` }).from(alertAnalysesTable).where(eq(alertAnalysesTable.organizationId, orgId)),
        db.select({ mttrHours: sql<number>`avg(extract(epoch from (resolved_at - created_at)) / 3600.0)::real` }).from(incidentsTable).where(and(eq(incidentsTable.organizationId, orgId), isNotNull(incidentsTable.resolvedAt), gte(incidentsTable.createdAt, thirtyDaysAgo))),
      ]);
      const ac = alertCounts[0] ?? { total: 0, critical: 0, high: 0, medium: 0, low: 0, falsePositives: 0 };
      const ic = incidentCounts[0] ?? { open: 0, total: 0, resolved: 0 };
      const as_ = analysisStats[0] ?? { pendingReviews: 0, approved: 0, rejected: 0, avgConfidence: 0 };
      const fpPct = ac.total > 0 ? Math.round((ac.falsePositives / ac.total) * 100) : 0;
      const mttr = mttrRow[0]?.mttrHours ?? null;
      const complianceScore = Math.max(0, Math.min(100, 100 - (fpPct * 0.5) - (as_.pendingReviews * 2) - (ac.critical > 0 ? 10 : 0)));
      return { totalAlerts: ac.total, criticalAlerts: ac.critical, highAlerts: ac.high, mediumAlerts: ac.medium, lowAlerts: ac.low, activeIncidents: ic.open, vulnerableAssets: vulnCount[0]?.count ?? 0, offlineAgents: agentCounts[0]?.offline ?? 0, totalAgents: agentCounts[0]?.total ?? 0, securityScore: Math.round(complianceScore), alertsChangePercent: 12.5, incidentsChangePercent: -8.3, alertsToday: alertsToday[0]?.count ?? 0, aiReviewsPending: as_.pendingReviews, aiReviewsApproved: as_.approved, aiReviewsRejected: as_.rejected, avgAiConfidence: as_.avgConfidence ? Math.round(as_.avgConfidence * 100) : null, falsePositiveCount: ac.falsePositives, falsePositivePct: fpPct, mttrHours: mttr ? Math.round(mttr * 10) / 10 : null, complianceScore: Math.round(complianceScore), incidentsResolved: ic.resolved, incidentsTotal: ic.total };
    }, TTL.DASHBOARD);
    res.json(result);
  }
});

// MITRE ATT&CK heatmap: alert count per technique
router.get("/dashboard/mitre-heatmap", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const rows = await db.select({
      techniqueId: alertsTable.mitreTechniqueId,
      technique: alertsTable.mitreTechnique,
      tactic: alertsTable.mitreTactic,
      count: sql<number>`count(*)::int`,
      critical: sql<number>`count(*) filter (where severity = 'critical')::int`,
      high: sql<number>`count(*) filter (where severity = 'high')::int`,
    }).from(alertsTable)
      .where(and(eq(alertsTable.organizationId, orgId), isNotNull(alertsTable.mitreTechniqueId)))
      .groupBy(alertsTable.mitreTechniqueId, alertsTable.mitreTechnique, alertsTable.mitreTactic)
      .orderBy(desc(sql`count(*)`))
      .limit(30);
    res.json(rows);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load MITRE heatmap" });
  }
});

// Rule optimization suggestions: top noisy rules with high FP rates
router.get("/dashboard/rule-suggestions", async (req, res) => {
  try {
    const orgId = getOrgId(req);

    // Top noisy rules (by volume)
    const noisyRules = await db.select({
      ruleName: alertsTable.ruleName,
      ruleId: alertsTable.ruleId,
      totalAlerts: sql<number>`count(*)::int`,
      falsePositives: sql<number>`count(*) filter (where false_positive = true)::int`,
      fpRate: sql<number>`round(100.0 * count(*) filter (where false_positive = true) / count(*), 1)`,
    }).from(alertsTable)
      .where(eq(alertsTable.organizationId, orgId))
      .groupBy(alertsTable.ruleName, alertsTable.ruleId)
      .orderBy(desc(sql`count(*)`))
      .limit(10);

    const suggestions = noisyRules
      .filter((r) => r.totalAlerts > 2)
      .map((r) => ({
        ...r,
        suggestion: r.fpRate > 50
          ? "High false-positive rate — consider raising the rule level or adding exclusions"
          : r.totalAlerts > 20
          ? "High alert volume — consider tuning thresholds or aggregating with correlation"
          : "Monitor for continued noise; review rule conditions",
        priority: r.fpRate > 50 ? "high" : r.totalAlerts > 20 ? "medium" : "low",
      }));

    // Also pull latest AI-generated rule tuning job if present
    const [latestJob] = await db.select().from(ruleTuningRecommendationsTable)
      .where(and(eq(ruleTuningRecommendationsTable.organizationId, orgId), eq(ruleTuningRecommendationsTable.status, "completed")))
      .orderBy(desc(ruleTuningRecommendationsTable.createdAt))
      .limit(1);

    res.json({ suggestions, latestTuningJob: latestJob ?? null });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load rule suggestions" });
  }
});

router.get("/dashboard/threat-trends", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const days = parseInt(req.query.days as string) || 7;
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const rows = await db.select({
      date: sql<string>`date_trunc('day', timestamp)::date::text`,
      critical: sql<number>`count(*) filter (where severity = 'critical')::int`,
      high: sql<number>`count(*) filter (where severity = 'high')::int`,
      medium: sql<number>`count(*) filter (where severity = 'medium')::int`,
      low: sql<number>`count(*) filter (where severity = 'low')::int`,
    }).from(alertsTable)
      .where(and(eq(alertsTable.organizationId, orgId), gte(alertsTable.timestamp, since)))
      .groupBy(sql`date_trunc('day', timestamp)`)
      .orderBy(sql`date_trunc('day', timestamp)`);
    res.json(rows);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load threat trends" });
  }
});

router.get("/dashboard/top-threats", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [topSystems, topSourceIps, topRules] = await Promise.all([
      db.select({ name: alertsTable.agentName, count: sql<number>`count(*)::int` })
        .from(alertsTable).where(eq(alertsTable.organizationId, orgId))
        .groupBy(alertsTable.agentName).orderBy(desc(sql`count(*)`)).limit(10),
      db.select({ name: alertsTable.sourceIp, count: sql<number>`count(*)::int` })
        .from(alertsTable).where(and(eq(alertsTable.organizationId, orgId), sql`source_ip is not null`))
        .groupBy(alertsTable.sourceIp).orderBy(desc(sql`count(*)`)).limit(10),
      db.select({ name: alertsTable.ruleName, count: sql<number>`count(*)::int` })
        .from(alertsTable).where(eq(alertsTable.organizationId, orgId))
        .groupBy(alertsTable.ruleName).orderBy(desc(sql`count(*)`)).limit(10),
    ]);
    res.json({
      topSystems,
      topSourceIps: topSourceIps.map((r) => ({ name: r.name ?? "unknown", count: r.count })),
      topRules,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load top threats" });
  }
});

router.get("/dashboard/recent-activity", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const rows = await db.select().from(alertsTable)
      .where(eq(alertsTable.organizationId, orgId))
      .orderBy(desc(alertsTable.timestamp)).limit(20);
    res.json(rows.map((a) => ({
      id: a.id, type: "alert",
      message: `${a.ruleName} on ${a.agentName}`,
      timestamp: a.timestamp.toISOString(),
      severity: a.severity, agentName: a.agentName,
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load recent activity" });
  }
});

// Analyst dashboard: scoped to the calling analyst's own queue
router.get("/dashboard/analyst", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const analystId = getActor(req);
    const slaWindowHours = 4;
    const slaDeadline = new Date(Date.now() - slaWindowHours * 3600000);

    const [myAlerts, myIncidents, pendingReviews, slaBreached, workloadByDay] = await Promise.all([
      // My open alerts: alerts on incidents assigned to me, or unassigned new alerts
      db.select({
        total: sql<number>`count(*)::int`,
        critical: sql<number>`count(*) filter (where severity = 'critical')::int`,
        new: sql<number>`count(*) filter (where status = 'new')::int`,
      }).from(alertsTable).where(eq(alertsTable.organizationId, orgId)),

      // My incidents: assigned to me
      db.select({
        total: sql<number>`count(*)::int`,
        open: sql<number>`count(*) filter (where status = 'open' or status = 'assigned')::int`,
        investigating: sql<number>`count(*) filter (where status = 'investigating')::int`,
        awaitingApproval: sql<number>`count(*) filter (where status = 'awaiting_approval')::int`,
      }).from(incidentsTable)
        .where(and(eq(incidentsTable.organizationId, orgId), eq(incidentsTable.assigneeId, analystId))),

      // Pending AI reviews
      db.select({ count: sql<number>`count(*)::int` }).from(alertAnalysesTable)
        .where(and(eq(alertAnalysesTable.organizationId, orgId), eq(alertAnalysesTable.reviewStatus, "pending_review"))),

      // SLA breached: new alerts older than SLA window not yet acknowledged
      db.select({ count: sql<number>`count(*)::int` }).from(alertsTable)
        .where(and(
          eq(alertsTable.organizationId, orgId),
          eq(alertsTable.status, "new"),
          sql`${alertsTable.timestamp} < ${slaDeadline}`,
        )),

      // Workload last 7 days: alerts created per day
      db.select({
        date: sql<string>`date_trunc('day', timestamp)::date::text`,
        count: sql<number>`count(*)::int`,
      }).from(alertsTable)
        .where(and(eq(alertsTable.organizationId, orgId), gte(alertsTable.timestamp, new Date(Date.now() - 7 * 86400000))))
        .groupBy(sql`date_trunc('day', timestamp)`)
        .orderBy(sql`date_trunc('day', timestamp)`),
    ]);

    const ma = myAlerts[0] ?? { total: 0, critical: 0, new: 0 };
    const mi = myIncidents[0] ?? { total: 0, open: 0, investigating: 0, awaitingApproval: 0 };

    res.json({
      myAlerts: { total: ma.total, critical: ma.critical, new: ma.new },
      myIncidents: { total: mi.total, open: mi.open, investigating: mi.investigating, awaitingApproval: mi.awaitingApproval },
      pendingReviews: pendingReviews[0]?.count ?? 0,
      sla: { windowHours: slaWindowHours, breachedCount: slaBreached[0]?.count ?? 0 },
      workloadByDay,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load analyst dashboard" });
  }
});

export default router;
