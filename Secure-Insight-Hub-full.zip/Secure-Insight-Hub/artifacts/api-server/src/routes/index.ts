import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dashboardRouter from "./dashboard";
import alertsRouter from "./alerts";
import agentsRouter from "./agents";
import incidentsRouter from "./incidents";
import vulnerabilitiesRouter from "./vulnerabilities";
import mitreRouter from "./mitre";
import complianceRouter from "./compliance";
import securityScoreRouter from "./securityScore";
import wazuhRouter from "./wazuh";
import organizationsRouter from "./organizations";
import usersRouter from "./users";
import reportsRouter from "./reports";
import notificationsRouter from "./notifications";
import aiRouter from "./ai";
import ruleTuningRouter from "./ruleTuning";
import entityAIRouter from "./entityAI";
import threatIntelRouter from "./threatIntel";
import rbacRouter from "./rbac";
import auditLogsRouter from "./auditLogs";
import aiPipelineRouter from "./aiPipeline";
import { resolveUserRole } from "../lib/rbac";

const router: IRouter = Router();

// Resolve the calling user's role for every request before any route handler runs.
router.use(resolveUserRole);

router.use(healthRouter);
router.use(dashboardRouter);
router.use(alertsRouter);
router.use(agentsRouter);
router.use(incidentsRouter);
router.use(vulnerabilitiesRouter);
router.use(mitreRouter);
router.use(complianceRouter);
router.use(securityScoreRouter);
router.use(wazuhRouter);
router.use(organizationsRouter);
router.use(usersRouter);
router.use(reportsRouter);
router.use(notificationsRouter);
router.use(aiRouter);
router.use(ruleTuningRouter);
router.use(entityAIRouter);
router.use(threatIntelRouter);
router.use(rbacRouter);

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(alertsRouter);
router.use(agentsRouter);
router.use(incidentsRouter);
router.use(vulnerabilitiesRouter);
router.use(mitreRouter);
router.use(complianceRouter);
router.use(securityScoreRouter);
router.use(wazuhRouter);
router.use(organizationsRouter);
router.use(usersRouter);
router.use(reportsRouter);
router.use(notificationsRouter);
router.use(aiRouter);
router.use(ruleTuningRouter);
router.use(entityAIRouter);
router.use(threatIntelRouter);
router.use(rbacRouter);
router.use(auditLogsRouter);
router.use(aiPipelineRouter);

export default router;
