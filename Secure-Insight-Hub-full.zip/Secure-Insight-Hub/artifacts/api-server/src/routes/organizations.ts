import { Router } from "express";
import { db } from "@workspace/db";
import { organizationsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/organizations", async (req, res) => {
  try {
    const orgs = await db.select().from(organizationsTable);
    res.json(orgs.map(o => ({ ...o, userCount: 0, createdAt: o.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list organizations" });
  }
});

router.post("/organizations", async (req, res) => {
  try {
    const { name, plan } = req.body;
    const slug = name.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
    const [org] = await db.insert(organizationsTable).values({ name, slug, plan: plan ?? "starter" }).returning();
    res.status(201).json({ ...org, userCount: 0, createdAt: org.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create organization" });
  }
});

router.get("/organizations/:id", async (req, res) => {
  try {
    const [org] = await db.select().from(organizationsTable).where(eq(organizationsTable.id, req.params.id));
    if (!org) { res.status(404).json({ error: "Organization not found" }); return; }
    res.json({ ...org, userCount: 0, createdAt: org.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get organization" });
  }
});

router.patch("/organizations/:id", async (req, res) => {
  try {
    const { name, plan } = req.body;
    const updates: any = {};
    if (name) updates.name = name;
    if (plan) updates.plan = plan;
    const [updated] = await db.update(organizationsTable).set(updates).where(eq(organizationsTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "Organization not found" }); return; }
    res.json({ ...updated, userCount: 0, createdAt: updated.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update organization" });
  }
});

router.delete("/organizations/:id", async (req, res) => {
  try {
    await db.delete(organizationsTable).where(eq(organizationsTable.id, req.params.id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete organization" });
  }
});

export default router;
