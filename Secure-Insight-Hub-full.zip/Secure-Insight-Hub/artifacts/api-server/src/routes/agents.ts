import { Router } from "express";
import { db } from "@workspace/db";
import { wazuhAgentsTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }

router.get("/agents", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { status } = req.query as Record<string, string>;
    const conditions = [eq(wazuhAgentsTable.organizationId, orgId)];
    if (status) conditions.push(eq(wazuhAgentsTable.status, status));
    const agents = await db.select().from(wazuhAgentsTable).where(and(...conditions));
    res.json(agents.map(a => ({ ...a, lastKeepAlive: a.lastKeepAlive.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list agents" });
  }
});

router.get("/agents/stats", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [row] = await db.select({
      total: sql<number>`count(*)::int`,
      active: sql<number>`count(*) filter (where status='active')::int`,
      disconnected: sql<number>`count(*) filter (where status='disconnected')::int`,
      pending: sql<number>`count(*) filter (where status='pending')::int`,
      neverConnected: sql<number>`count(*) filter (where status='never_connected')::int`,
    }).from(wazuhAgentsTable).where(eq(wazuhAgentsTable.organizationId, orgId));
    res.json({
      total: row?.total ?? 0,
      active: row?.active ?? 0,
      disconnected: row?.disconnected ?? 0,
      pending: row?.pending ?? 0,
      neverConnected: row?.neverConnected ?? 0,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get agent stats" });
  }
});

router.get("/agents/:id", async (req, res) => {
  try {
    const [agent] = await db.select().from(wazuhAgentsTable).where(eq(wazuhAgentsTable.id, req.params.id));
    if (!agent) { res.status(404).json({ error: "Agent not found" }); return; }
    res.json({ ...agent, lastKeepAlive: agent.lastKeepAlive.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get agent" });
  }
});

export default router;
