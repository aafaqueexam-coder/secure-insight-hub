import { Router } from "express";
import { db } from "@workspace/db";
import { alertsTable, alertAnalysesTable, alertCommentsTable, savedAlertFiltersTable, alertAuditLogTable, incidentTimelineTable } from "@workspace/db";
import { eq, and, desc, sql, inArray } from "drizzle-orm";
import { requirePermission } from "../lib/rbac";
import { audit, fromRequest } from "../lib/auditWriter";
import { dispatchNotification } from "../lib/notificationDispatch";
import { runAlertPipeline, PROMPT_VERSION, AI_MODEL } from "../lib/aiPipeline";
import { buildAlertContext, countPreviousOccurrences } from "../lib/contextBuilder";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }
function getActor(req: any): { id: string; name: string } {
  return { id: (req as any).auth?.userId ?? "demo-user", name: (req as any).auth?.userName ?? "Analyst" };
}
async function logAudit(alertId: string, organizationId: string, action: string, actor: { id: string; name: string }, details?: Record<string, unknown>) {
  await db.insert(alertAuditLogTable).values({ alertId, organizationId, action, actorId: actor.id, actorName: actor.name, details: details ?? null });
}
// If this alert is linked to an incident, mirror the event onto that
// incident's timeline too. Best-effort: failures here must never break the
// underlying alert action.
async function logIncidentTimelineIfLinked(alertId: string, organizationId: string, type: string, message: string, actorName: string) {
  try {
    const [alert] = await db.select({ incidentId: alertsTable.incidentId }).from(alertsTable).where(eq(alertsTable.id, alertId));
    if (!alert?.incidentId) return;
    await db.insert(incidentTimelineTable).values({ incidentId: alert.incidentId, organizationId, type, message, actorName });
  } catch {
    // non-fatal
  }
}

router.get("/alerts", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const q = req.query as Record<string, string | string[]>;
    const toArray = (v: string | string[] | undefined) => (v === undefined ? [] : Array.isArray(v) ? v : v.split(","));

    const severities = toArray(q.severity);
    const statuses = toArray(q.status);
    const mitreIds = toArray(q.mitreTechniqueId);
    const reviewStatuses = toArray(q.reviewStatus);
    const agentId = q.agentId as string | undefined;
    const search = (q.search as string | undefined)?.trim();
    const dateFrom = q.dateFrom as string | undefined;
    const dateTo = q.dateTo as string | undefined;
    const limit = Math.min(parseInt(q.limit as string) || 50, 200);
    const offset = parseInt(q.offset as string) || 0;

    const conditions = [eq(alertsTable.organizationId, orgId)];
    if (severities.length) conditions.push(inArray(alertsTable.severity, severities));
    if (statuses.length) conditions.push(inArray(alertsTable.status, statuses));
    if (mitreIds.length) conditions.push(inArray(alertsTable.mitreTechniqueId, mitreIds));
    if (agentId) conditions.push(eq(alertsTable.agentId, agentId));
    if (dateFrom) conditions.push(sql`${alertsTable.timestamp} >= ${new Date(dateFrom)}`);
    if (dateTo) conditions.push(sql`${alertsTable.timestamp} <= ${new Date(dateTo)}`);
    if (search) {
      const term = `%${search.toLowerCase()}%`;
      conditions.push(sql`(
        lower(${alertsTable.ruleName}) like ${term}
        or lower(${alertsTable.description}) like ${term}
        or lower(${alertsTable.agentName}) like ${term}
        or lower(coalesce(${alertsTable.sourceIp}, '')) like ${term}
        or lower(coalesce(${alertsTable.mitreTechnique}, '')) like ${term}
        or lower(coalesce(${alertsTable.mitreTechniqueId}, '')) like ${term}
      )`);
    }
    if (reviewStatuses.length) {
      conditions.push(sql`exists (
        select 1 from alert_analyses aa
        where aa.alert_id = ${alertsTable.id}
        and aa.review_status = any(${reviewStatuses})
      )`);
    }

    const where = and(...conditions);
    const [items, [{ total }]] = await Promise.all([
      db.select().from(alertsTable).where(where).orderBy(desc(alertsTable.timestamp)).limit(limit).offset(offset),
      db.select({ total: sql<number>`count(*)::int` }).from(alertsTable).where(where),
    ]);
    res.json({ items, total, offset, limit });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list alerts" });
  }
});

// Bulk actions: apply a status/false-positive/incident change to many alerts at once.
router.post("/alerts/bulk", requirePermission("alerts:bulk_action"), async (req, res) => {
  try {
    const { ids, action } = req.body as { ids: string[]; action: "acknowledge" | "resolve" | "false_positive" | "new" };
    if (!Array.isArray(ids) || ids.length === 0) { res.status(400).json({ error: "ids must be a non-empty array" }); return; }

    const patch: Record<string, unknown> =
      action === "acknowledge" ? { status: "acknowledged" } :
      action === "resolve" ? { status: "resolved" } :
      action === "false_positive" ? { status: "resolved", falsePositive: true } :
      action === "new" ? { status: "new", falsePositive: false } :
      null as never;
    if (!patch) { res.status(400).json({ error: "Invalid action" }); return; }

    const updated = await db.update(alertsTable).set(patch).where(inArray(alertsTable.id, ids)).returning({ id: alertsTable.id });
    res.json({ updated: updated.length, ids: updated.map((u) => u.id) });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to apply bulk action" });
  }
});

// Saved filters: per-analyst presets for the advanced filter bar.
router.get("/alerts/saved-filters", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const userId = (req as any).auth?.userId ?? "demo-user";
    const rows = await db.select().from(savedAlertFiltersTable)
      .where(and(eq(savedAlertFiltersTable.organizationId, orgId), eq(savedAlertFiltersTable.userId, userId)))
      .orderBy(desc(savedAlertFiltersTable.createdAt));
    res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list saved filters" });
  }
});

router.post("/alerts/saved-filters", async (req, res) => {
  try {
    const { name, filters } = req.body as { name: string; filters: Record<string, unknown> };
    if (!name?.trim() || !filters) { res.status(400).json({ error: "name and filters are required" }); return; }
    const orgId = getOrgId(req);
    const userId = (req as any).auth?.userId ?? "demo-user";
    const [saved] = await db.insert(savedAlertFiltersTable).values({ organizationId: orgId, userId, name: name.trim(), filters }).returning();
    res.status(201).json({ ...saved, createdAt: saved.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to save filter" });
  }
});

router.delete("/alerts/saved-filters/:id", async (req, res) => {
  try {
    const deleted = await db.delete(savedAlertFiltersTable).where(eq(savedAlertFiltersTable.id, req.params.id)).returning({ id: savedAlertFiltersTable.id });
    if (!deleted.length) { res.status(404).json({ error: "Saved filter not found" }); return; }
    res.status(204).end();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete saved filter" });
  }
});

router.get("/alerts/stats", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [row] = await db.select({
      total: sql<number>`count(*)::int`,
      critical: sql<number>`count(*) filter (where severity='critical')::int`,
      high: sql<number>`count(*) filter (where severity='high')::int`,
      medium: sql<number>`count(*) filter (where severity='medium')::int`,
      low: sql<number>`count(*) filter (where severity='low')::int`,
      newAlerts: sql<number>`count(*) filter (where status='new')::int`,
      acknowledged: sql<number>`count(*) filter (where status='acknowledged')::int`,
      resolved: sql<number>`count(*) filter (where status='resolved')::int`,
    }).from(alertsTable).where(eq(alertsTable.organizationId, orgId));
    res.json({ total: row?.total ?? 0, critical: row?.critical ?? 0, high: row?.high ?? 0, medium: row?.medium ?? 0, low: row?.low ?? 0, new: row?.newAlerts ?? 0, acknowledged: row?.acknowledged ?? 0, resolved: row?.resolved ?? 0 });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load alert stats" });
  }
});

router.get("/alerts/:id", async (req, res) => {
  try {
    const [alert] = await db.select().from(alertsTable).where(eq(alertsTable.id, req.params.id));
    if (!alert) { res.status(404).json({ error: "Alert not found" }); return; }
    res.json(alert);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get alert" });
  }
});

router.patch("/alerts/:id", async (req, res) => {
  try {
    const { status, incidentId, falsePositive } = req.body;
    const patch: Record<string, unknown> = {};
    if (status !== undefined) patch.status = status;
    if (incidentId !== undefined) patch.incidentId = incidentId;
    if (falsePositive !== undefined) patch.falsePositive = falsePositive;
    const [updated] = await db.update(alertsTable)
      .set(patch)
      .where(eq(alertsTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "Alert not found" }); return; }
    res.json(updated);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update alert" });
  }
});

router.get("/alerts/:id/analysis", async (req, res) => {
  try {
    const [analysis] = await db.select().from(alertAnalysesTable).where(eq(alertAnalysesTable.alertId, req.params.id));
    if (!analysis) { res.status(404).json({ error: "No analysis found. POST to generate one." }); return; }
    res.json({ ...analysis, generatedAt: analysis.generatedAt.toISOString(), reviewedAt: analysis.reviewedAt?.toISOString() ?? null });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get analysis" });
  }
});

router.post("/alerts/:id/analysis", requirePermission("ai:run_analysis"), async (req, res) => {
  try {
    const [alert] = await db.select().from(alertsTable).where(eq(alertsTable.id, req.params.id));
    if (!alert) { res.status(404).json({ error: "Alert not found" }); return; }

    // Run the full AI pipeline (Context Builder → Redaction → Investigation → Recommendation)
    const result = await runAlertPipeline(alert);

    // Persist the analysis with all pipeline metadata
    await db.delete(alertAnalysesTable).where(eq(alertAnalysesTable.alertId, req.params.id));
    const [saved] = await db.insert(alertAnalysesTable).values({
      alertId: req.params.id,
      organizationId: alert.organizationId,
      summary: result.summary,
      threatDescription: result.threatDescription,
      businessImpact: result.businessImpact,
      investigationSteps: result.investigationSteps,
      affectedAssets: result.affectedAssets,
      executiveSummary: result.executiveSummary,
      confidenceScore: result.confidenceScore,
      reasoning: result.reasoning,
      rootCause: result.rootCause,
      mitreExplanation: result.mitreExplanation,
      falsePositiveProbability: result.falsePositiveProbability,
      evidence: result.evidence,
      iocs: result.iocs,
      investigationChecklist: result.investigationChecklist,
      remediationPlan: result.remediationPlan,
      recommendedActions: result.recommendedActions,
      containmentActions: result.containmentActions,
      analystNotes: result.analystNotes,
      severity: alert.severity,
      redactedFields: result.redactedFields,
      reviewStatus: "pending_review",
      aiModelUsed: result.aiModelUsed,
      promptVersion: result.promptVersion,
      promptTokens: result.promptTokens,
      completionTokens: result.completionTokens,
      totalTokens: result.totalTokens,
      retryCount: result.retryCount,
      pipelineDurationMs: result.pipelineDurationMs,
      fromCache: result.fromCache,
      generatedAt: new Date(),
    }).returning();

    const actor = getActor(req);
    await logAudit(req.params.id, alert.organizationId, "analysis_generated", actor, {
      aiModelUsed: saved.aiModelUsed, promptVersion: saved.promptVersion,
      promptTokens: saved.promptTokens, completionTokens: saved.completionTokens,
      totalTokens: saved.totalTokens, retryCount: saved.retryCount,
      pipelineDurationMs: saved.pipelineDurationMs, fromCache: saved.fromCache,
    });
    await logIncidentTimelineIfLinked(req.params.id, alert.organizationId, "ai_analysis", `AI analysis generated for "${alert.ruleName}"`, "AI Engine");
    await audit({
      ...fromRequest(req),
      organizationId: alert.organizationId,
      eventType: "ai.analysis.generated",
      summary: `AI analysis generated for alert "${alert.ruleName}"`,
      resourceType: "alert", resourceId: alert.id, resourceName: alert.ruleName,
      details: {
        aiModel: saved.aiModelUsed, promptVersion: saved.promptVersion,
        confidenceScore: saved.confidenceScore, falsePositiveProbability: (saved as any).falsePositiveProbability,
        promptTokens: saved.promptTokens, completionTokens: saved.completionTokens,
        totalTokens: saved.totalTokens, retryCount: saved.retryCount,
        pipelineDurationMs: saved.pipelineDurationMs, fromCache: saved.fromCache,
        redactedFields: saved.redactedFields,
      },
    });
    if (alert.severity === "critical" || alert.severity === "high") {
      dispatchNotification(alert.organizationId, "alert.analyzed", {
        title: `AI Analysis Ready: ${alert.ruleName}`,
        body: `Confidence: ${Math.round((saved.confidenceScore ?? 0) * 100)}%${result.fromCache ? " (cached)" : ""} · ${saved.summary ?? ""}`,
        severity: alert.severity as any,
        resourceType: "alert", resourceId: alert.id,
      }).catch(() => {});
    }

    res.json({ ...saved, generatedAt: saved.generatedAt.toISOString(), reviewedAt: null });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to generate analysis" });
  }
});

// Human Approval step: an analyst approves (clears the way to create an
// incident) or rejects (treated as "Ignore" — alert is marked a false
// positive and resolved) the AI's recommendation.
router.post("/alerts/:id/analysis/review", requirePermission("ai:review"), async (req, res) => {
  try {
    const { decision, note } = req.body as { decision: "approve" | "reject"; note?: string };
    if (decision !== "approve" && decision !== "reject") {
      res.status(400).json({ error: "decision must be 'approve' or 'reject'" });
      return;
    }

    const [analysis] = await db.select().from(alertAnalysesTable).where(eq(alertAnalysesTable.alertId, req.params.id));
    if (!analysis) { res.status(404).json({ error: "No analysis found for this alert" }); return; }
    const actor = getActor(req);

    const [updatedAnalysis] = await db.update(alertAnalysesTable).set({
      reviewStatus: decision === "approve" ? "approved" : "rejected",
      reviewedBy: actor.name,
      reviewedAt: new Date(),
      reviewNote: note ?? null,
    }).where(eq(alertAnalysesTable.alertId, req.params.id)).returning();

    if (decision === "reject") {
      // Ignore path: rejecting the AI's recommendation closes the alert as a false positive.
      await db.update(alertsTable).set({ falsePositive: true, status: "resolved" }).where(eq(alertsTable.id, req.params.id));
    }

    await logAudit(req.params.id, analysis.organizationId, decision === "approve" ? "approved" : "rejected", actor, { note: note ?? null });
    await logIncidentTimelineIfLinked(req.params.id, analysis.organizationId, "human_review", `Analysis ${decision === "approve" ? "approved" : "rejected"} by ${actor.name}`, actor.name);
    await audit({
      ...fromRequest(req),
      organizationId: analysis.organizationId,
      eventType: decision === "approve" ? "ai.review.approved" : "ai.review.rejected",
      summary: `AI analysis ${decision === "approve" ? "approved" : "rejected"} for alert "${req.params.id}"`,
      resourceType: "alert", resourceId: req.params.id,
      details: { decision, note: note ?? null, reviewedBy: actor.name },
    });

    res.json({
      ...updatedAnalysis,
      generatedAt: updatedAnalysis.generatedAt.toISOString(),
      reviewedAt: updatedAnalysis.reviewedAt?.toISOString() ?? null,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to record review decision" });
  }
});

// Human Review: let an analyst edit the AI's recommended actions / remediation
// plan / containment actions before approving. Tracked as "modified" with an
// audit entry capturing the before/after values.
router.patch("/alerts/:id/analysis", async (req, res) => {
  try {
    const { recommendedActions, remediationPlan, containmentActions, reviewNote } = req.body as {
      recommendedActions?: string[]; remediationPlan?: string[]; containmentActions?: string[]; reviewNote?: string;
    };
    const [existing] = await db.select().from(alertAnalysesTable).where(eq(alertAnalysesTable.alertId, req.params.id));
    if (!existing) { res.status(404).json({ error: "No analysis found for this alert" }); return; }

    const patch: Record<string, unknown> = { recommendationModified: true };
    if (recommendedActions !== undefined) patch.recommendedActions = recommendedActions;
    if (remediationPlan !== undefined) patch.remediationPlan = remediationPlan;
    if (containmentActions !== undefined) patch.containmentActions = containmentActions;
    if (reviewNote !== undefined) patch.reviewNote = reviewNote;

    const [updated] = await db.update(alertAnalysesTable).set(patch).where(eq(alertAnalysesTable.alertId, req.params.id)).returning();

    const actor = getActor(req);
    await logAudit(req.params.id, existing.organizationId, "recommendation_modified", actor, {
      before: { recommendedActions: existing.recommendedActions, remediationPlan: existing.remediationPlan, containmentActions: existing.containmentActions },
      after: { recommendedActions: updated.recommendedActions, remediationPlan: updated.remediationPlan, containmentActions: updated.containmentActions },
    });
    await audit({
      ...fromRequest(req),
      organizationId: existing.organizationId,
      eventType: "ai.recommendation.modified",
      summary: `AI recommendation manually edited for alert "${req.params.id}"`,
      resourceType: "alert", resourceId: req.params.id,
      details: { recommendedActions, remediationPlan, containmentActions },
    });

    res.json({ ...updated, generatedAt: updated.generatedAt.toISOString(), reviewedAt: updated.reviewedAt?.toISOString() ?? null });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to modify recommendation" });
  }
});

// Investigation checklist: toggle individual items as an analyst works through them.
router.patch("/alerts/:id/analysis/checklist", async (req, res) => {
  try {
    const { itemId, completed } = req.body as { itemId: string; completed: boolean };
    const [existing] = await db.select().from(alertAnalysesTable).where(eq(alertAnalysesTable.alertId, req.params.id));
    if (!existing) { res.status(404).json({ error: "No analysis found for this alert" }); return; }

    const checklist = (existing.investigationChecklist as Array<{ id: string; label: string; completed: boolean }>).map((item) =>
      item.id === itemId ? { ...item, completed } : item,
    );
    const [updated] = await db.update(alertAnalysesTable).set({ investigationChecklist: checklist }).where(eq(alertAnalysesTable.alertId, req.params.id)).returning();
    res.json({ ...updated, generatedAt: updated.generatedAt.toISOString(), reviewedAt: updated.reviewedAt?.toISOString() ?? null });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update checklist" });
  }
});

// Related alerts + previous occurrences, shown in the Alert Details panel.
router.get("/alerts/:id/related", async (req, res) => {
  try {
    const [alert] = await db.select().from(alertsTable).where(eq(alertsTable.id, req.params.id));
    if (!alert) { res.status(404).json({ error: "Alert not found" }); return; }
    const [context, previousOccurrences] = await Promise.all([
      buildAlertContext(alert),
      countPreviousOccurrences(alert),
    ]);
    res.json({ relatedAlerts: context.relatedAlerts, previousOccurrences });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load related alerts" });
  }
});

// Audit history: every action taken on this alert's analysis.
router.get("/alerts/:id/audit-log", async (req, res) => {
  try {
    const rows = await db.select().from(alertAuditLogTable)
      .where(eq(alertAuditLogTable.alertId, req.params.id))
      .orderBy(desc(alertAuditLogTable.createdAt));
    res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load audit log" });
  }
});

// Comments: lightweight analyst discussion thread attached to an alert.
router.get("/alerts/:id/comments", async (req, res) => {
  try {
    const comments = await db.select().from(alertCommentsTable)
      .where(eq(alertCommentsTable.alertId, req.params.id))
      .orderBy(alertCommentsTable.createdAt);
    res.json(comments.map((c) => ({ ...c, createdAt: c.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list comments" });
  }
});

router.post("/alerts/:id/comments", async (req, res) => {
  try {
    const { content } = req.body as { content: string };
    if (!content?.trim()) { res.status(400).json({ error: "content is required" }); return; }
    const [alert] = await db.select().from(alertsTable).where(eq(alertsTable.id, req.params.id));
    if (!alert) { res.status(404).json({ error: "Alert not found" }); return; }
    const actor = getActor(req);
    const [comment] = await db.insert(alertCommentsTable).values({
      alertId: req.params.id,
      organizationId: alert.organizationId,
      content: content.trim(),
      authorId: actor.id,
      authorName: actor.name,
    }).returning();
    await logAudit(req.params.id, alert.organizationId, "comment_added", actor, { commentId: comment.id });
    res.status(201).json({ ...comment, createdAt: comment.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to add comment" });
  }
});

export default router;
