import { Router } from "express";
import { db } from "@workspace/db";
import { iocEnrichmentsTable } from "@workspace/db";
import { eq, desc, and, ilike, sql } from "drizzle-orm";
import { enrichIndicator, enrichBulk } from "../lib/threatIntel";

const router = Router();
function getOrgId(req: any): string { return (req.query.orgId as string) || "demo-org"; }

/**
 * POST /threat-intel/enrich
 * Body: { indicator: string, forceFresh?: boolean }
 * Enriches a single IP, domain, hash, or URL.
 */
router.post("/threat-intel/enrich", async (req, res) => {
  try {
    const { indicator, forceFresh } = req.body as { indicator: string; forceFresh?: boolean };
    if (!indicator?.trim()) { res.status(400).json({ error: "indicator is required" }); return; }
    const result = await enrichIndicator(indicator.trim(), getOrgId(req), !!forceFresh);
    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Enrichment failed" });
  }
});

/**
 * POST /threat-intel/enrich/bulk
 * Body: { indicators: string[] }  — up to 20
 * Returns a map of indicator → enrichment result.
 */
router.post("/threat-intel/enrich/bulk", async (req, res) => {
  try {
    const { indicators } = req.body as { indicators: string[] };
    if (!Array.isArray(indicators) || !indicators.length) {
      res.status(400).json({ error: "indicators must be a non-empty array" }); return;
    }
    const results = await enrichBulk(indicators, getOrgId(req));
    res.json(results);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Bulk enrichment failed" });
  }
});

/**
 * GET /threat-intel/ioc-database
 * Lists all cached IOC enrichments for the org, newest first.
 * Supports: ?search=, ?verdict=, ?type=, ?limit=, ?offset=
 */
router.get("/threat-intel/ioc-database", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { verdict, type, search } = req.query as Record<string, string>;
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
    const offset = parseInt(req.query.offset as string) || 0;

    const conditions = [eq(iocEnrichmentsTable.organizationId, orgId)];
    if (verdict) conditions.push(eq(iocEnrichmentsTable.verdict, verdict));
    if (type) conditions.push(eq(iocEnrichmentsTable.indicatorType, type));
    if (search) conditions.push(ilike(iocEnrichmentsTable.indicator, `%${search}%`));

    const [rows, [{ total }]] = await Promise.all([
      db.select().from(iocEnrichmentsTable).where(and(...conditions)).orderBy(desc(iocEnrichmentsTable.enrichedAt)).limit(limit).offset(offset),
      db.select({ total: sql<number>`count(*)::int` }).from(iocEnrichmentsTable).where(and(...conditions)),
    ]);

    res.json({
      items: rows.map((r) => ({
        ...r,
        enrichedAt: r.enrichedAt.toISOString(),
        expiresAt: r.expiresAt.toISOString(),
        createdAt: r.createdAt.toISOString(),
      })),
      total,
      offset,
      limit,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list IOC database" });
  }
});

/**
 * GET /threat-intel/ioc-database/stats
 * Verdict and type breakdown counts.
 */
router.get("/threat-intel/ioc-database/stats", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [byVerdict, byType] = await Promise.all([
      db.select({
        verdict: iocEnrichmentsTable.verdict,
        count: sql<number>`count(*)::int`,
      }).from(iocEnrichmentsTable).where(eq(iocEnrichmentsTable.organizationId, orgId)).groupBy(iocEnrichmentsTable.verdict),
      db.select({
        type: iocEnrichmentsTable.indicatorType,
        count: sql<number>`count(*)::int`,
      }).from(iocEnrichmentsTable).where(eq(iocEnrichmentsTable.organizationId, orgId)).groupBy(iocEnrichmentsTable.indicatorType),
    ]);
    const verdictMap = Object.fromEntries(byVerdict.map((r) => [r.verdict, r.count]));
    const typeMap = Object.fromEntries(byType.map((r) => [r.type, r.count]));
    res.json({
      total: Object.values(verdictMap).reduce((s, n) => s + n, 0),
      malicious: verdictMap.malicious ?? 0,
      suspicious: verdictMap.suspicious ?? 0,
      clean: verdictMap.clean ?? 0,
      unknown: verdictMap.unknown ?? 0,
      byType: typeMap,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get IOC stats" });
  }
});

/**
 * DELETE /threat-intel/ioc-database/:id
 * Remove a single cached entry (forces re-enrichment next lookup).
 */
router.delete("/threat-intel/ioc-database/:id", async (req, res) => {
  try {
    const deleted = await db.delete(iocEnrichmentsTable).where(eq(iocEnrichmentsTable.id, req.params.id)).returning({ id: iocEnrichmentsTable.id });
    if (!deleted.length) { res.status(404).json({ error: "Entry not found" }); return; }
    res.status(204).end();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete entry" });
  }
});

export default router;
