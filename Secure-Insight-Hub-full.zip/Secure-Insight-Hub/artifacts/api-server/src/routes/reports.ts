import { Router } from "express";
import { db } from "@workspace/db";
import { reportsTable } from "@workspace/db";
import { eq, desc, and } from "drizzle-orm";
import { buildReportContent, periodForType, contentToCsvRows, rowsToCsvString, type ReportType } from "../lib/reportEngine";
import { audit, fromRequest } from "../lib/auditWriter";

const router = Router();
function getOrgId(req: any): string { return (req.query.orgId as string) || "demo-org"; }
function fmt(r: any) {
  return {
    ...r,
    content: undefined, // never leak full content in list responses
    createdAt: r.createdAt.toISOString(),
    generatedAt: r.generatedAt?.toISOString() ?? null,
  };
}

const REPORT_TITLES: Record<string, string> = {
  daily: "Daily Security Report",
  weekly: "Weekly Security Report",
  monthly: "Monthly Security Report",
  executive_summary: "Executive Summary",
  incident_report: "Incident Report",
  compliance_report: "Compliance Report",
  rule_optimization_report: "Rule Optimization Report",
};

const VALID_TYPES: ReportType[] = [
  "daily", "weekly", "monthly", "executive_summary",
  "incident_report", "compliance_report", "rule_optimization_report",
];
const VALID_FORMATS = ["pdf", "csv", "excel"];

router.get("/reports", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const reports = await db.select().from(reportsTable)
      .where(eq(reportsTable.organizationId, orgId))
      .orderBy(desc(reportsTable.createdAt)).limit(50);
    res.json(reports.map(fmt));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list reports" });
  }
});

router.post("/reports", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { type = "daily", formats = ["pdf"] } = req.body as { type?: ReportType; formats?: string[] };

    if (!VALID_TYPES.includes(type)) {
      res.status(400).json({ error: `Invalid type. Must be one of: ${VALID_TYPES.join(", ")}` }); return;
    }
    const validFormats = (Array.isArray(formats) ? formats : [formats]).filter((f) => VALID_FORMATS.includes(f));
    if (!validFormats.length) {
      res.status(400).json({ error: `Invalid format. Must include at least one of: ${VALID_FORMATS.join(", ")}` }); return;
    }

    const period = periodForType(type);
    const title = REPORT_TITLES[type] ?? "Security Report";

    const [report] = await db.insert(reportsTable).values({
      organizationId: orgId,
      type,
      title,
      period: period.label,
      formats: validFormats.join(","),
      status: "generating",
    }).returning();

    // Generate async — respond immediately with the "generating" record
    res.status(201).json(fmt(report));

    // Background generation
    setImmediate(async () => {
      try {
        const content = await buildReportContent(orgId, type, period);
        await db.update(reportsTable).set({ status: "ready", content: content as any, generatedAt: new Date() }).where(eq(reportsTable.id, report.id));
        await audit({
          organizationId: orgId, eventType: "report.generated",
          summary: `${title} generated for period "${period.label}"`,
          actorId: (report as any).actorId ?? "system", actorName: "System",
          resourceType: "report", resourceId: report.id, resourceName: title,
          details: { reportType: type, formats: validFormats, period: period.label },
        });
      } catch (err: any) {
        await db.update(reportsTable).set({ status: "failed", errorMessage: err?.message ?? "Unknown error" }).where(eq(reportsTable.id, report.id));
      }
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to generate report" });
  }
});

router.get("/reports/:id", async (req, res) => {
  try {
    const [report] = await db.select().from(reportsTable).where(eq(reportsTable.id, req.params.id));
    if (!report) { res.status(404).json({ error: "Report not found" }); return; }
    res.json({ ...report, createdAt: report.createdAt.toISOString(), generatedAt: report.generatedAt?.toISOString() ?? null });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get report" });
  }
});

router.delete("/reports/:id", async (req, res) => {
  try {
    await db.delete(reportsTable).where(eq(reportsTable.id, req.params.id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete report" });
  }
});

// ── Export endpoints ──────────────────────────────────────────────────────────

router.get("/reports/:id/export/pdf", async (req, res) => {
  try {
    const [report] = await db.select().from(reportsTable).where(eq(reportsTable.id, req.params.id));
    if (!report) { res.status(404).json({ error: "Report not found" }); return; }
    if (report.status !== "ready" || !report.content) { res.status(409).json({ error: "Report not ready" }); return; }

    const content = report.content as Record<string, unknown>;
    const alerts = content.alerts as any;
    const incidents = content.incidents as any;
    const ai = content.ai as any;
    const period = content.period as any;
    const vulns = content.vulnerabilities as any;
    const complianceScore = content.complianceScore as number;
    const topRules = (content.topRules as any[]) ?? [];
    const mitre = (content.mitre as any[]) ?? [];
    const complianceControls = (content.complianceControls as any[]) ?? [];

    const statusColor = (s: string) =>
      s === "pass" ? "#10b981" : s === "warn" ? "#f59e0b" : "#ef4444";

    const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>${report.title}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, 'Segoe UI', sans-serif; font-size: 13px; color: #1e293b; background: #fff; padding: 40px; }
  h1 { font-size: 24px; font-weight: 700; color: #0f172a; }
  h2 { font-size: 16px; font-weight: 600; color: #0f172a; margin: 28px 0 12px; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; }
  h3 { font-size: 13px; font-weight: 600; color: #334155; margin: 16px 0 8px; }
  .meta { color: #64748b; font-size: 12px; margin-top: 4px; }
  .grid { display: grid; gap: 12px; margin: 16px 0; }
  .g4 { grid-template-columns: repeat(4, 1fr); }
  .g3 { grid-template-columns: repeat(3, 1fr); }
  .g2 { grid-template-columns: repeat(2, 1fr); }
  .stat { border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; }
  .stat .val { font-size: 22px; font-weight: 700; color: #0f172a; }
  .stat .lbl { font-size: 11px; color: #64748b; margin-top: 2px; text-transform: uppercase; letter-spacing: .04em; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; margin: 8px 0; }
  th { background: #f8fafc; text-align: left; padding: 8px 10px; font-size: 11px; font-weight: 600; color: #475569; text-transform: uppercase; letter-spacing: .04em; border-bottom: 1px solid #e2e8f0; }
  td { padding: 8px 10px; border-bottom: 1px solid #f1f5f9; vertical-align: top; }
  tr:last-child td { border-bottom: none; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 9999px; font-size: 11px; font-weight: 500; }
  .critical { background:#fee2e2; color:#dc2626; }
  .high     { background:#ffedd5; color:#ea580c; }
  .medium   { background:#fef9c3; color:#ca8a04; }
  .low      { background:#dbeafe; color:#2563eb; }
  .pass     { background:#dcfce7; color:#16a34a; }
  .warn     { background:#fef9c3; color:#ca8a04; }
  .fail     { background:#fee2e2; color:#dc2626; }
  .bar-wrap { background:#f1f5f9; border-radius:4px; height:6px; overflow:hidden; margin-top:4px; }
  .bar      { height:100%; border-radius:4px; }
  .header   { border-bottom: 2px solid #0f172a; padding-bottom: 20px; margin-bottom: 24px; }
  .footer   { margin-top: 48px; padding-top: 16px; border-top: 1px solid #e2e8f0; color: #94a3b8; font-size: 11px; }
  @media print { body { padding: 20px; } .no-break { page-break-inside: avoid; } }
</style>
</head>
<body>
<div class="header">
  <h1>${report.title}</h1>
  <p class="meta">Period: ${period.label} &nbsp;·&nbsp; Generated: ${new Date(content.generatedAt as string).toLocaleString()} &nbsp;·&nbsp; Compliance Score: <strong>${complianceScore}/100</strong></p>
</div>

<h2>Alert Summary</h2>
<div class="grid g4">
  <div class="stat"><div class="val">${alerts.total}</div><div class="lbl">Total Alerts</div></div>
  <div class="stat"><div class="val" style="color:#dc2626">${alerts.critical}</div><div class="lbl">Critical</div></div>
  <div class="stat"><div class="val">${alerts.falsePositives}</div><div class="lbl">False Positives</div></div>
  <div class="stat"><div class="val">${alerts.fpPct}%</div><div class="lbl">FP Rate</div></div>
</div>

<h2>Incident Summary</h2>
<div class="grid g4">
  <div class="stat"><div class="val">${incidents.total}</div><div class="lbl">Total Incidents</div></div>
  <div class="stat"><div class="val">${incidents.resolved}</div><div class="lbl">Resolved</div></div>
  <div class="stat"><div class="val">${incidents.open}</div><div class="lbl">Still Open</div></div>
  <div class="stat"><div class="val">${incidents.mttrHours != null ? incidents.mttrHours + "h" : "N/A"}</div><div class="lbl">Avg MTTR</div></div>
</div>

<h2>AI Analysis</h2>
<div class="grid g3">
  <div class="stat"><div class="val">${ai.total}</div><div class="lbl">Analyses Run</div></div>
  <div class="stat"><div class="val">${ai.approved}</div><div class="lbl">Approved</div></div>
  <div class="stat"><div class="val">${ai.pending}</div><div class="lbl">Pending Review</div></div>
</div>

${topRules.length ? `
<h2>Top Noisy Rules</h2>
<table>
  <thead><tr><th>Rule</th><th>Alerts</th><th>False Positives</th><th>FP Rate</th></tr></thead>
  <tbody>
  ${topRules.map((r: any) => `<tr><td>${r.ruleName}</td><td>${r.total}</td><td>${r.falsePositives}</td><td>${r.fpRate}%</td></tr>`).join("")}
  </tbody>
</table>` : ""}

${mitre.length ? `
<h2>MITRE ATT&CK Techniques</h2>
<table>
  <thead><tr><th>Technique ID</th><th>Technique</th><th>Tactic</th><th>Alerts</th></tr></thead>
  <tbody>
  ${mitre.map((r: any) => `<tr><td style="font-family:monospace">${r.techniqueId ?? ""}</td><td>${r.technique ?? ""}</td><td>${r.tactic ?? ""}</td><td>${r.count}</td></tr>`).join("")}
  </tbody>
</table>` : ""}

${complianceControls.length ? `
<h2>Compliance Controls</h2>
<table>
  <thead><tr><th>Control</th><th>Status</th><th>Detail</th></tr></thead>
  <tbody>
  ${complianceControls.map((c: any) => `<tr><td>${c.control}</td><td><span class="badge ${c.status}">${c.status.toUpperCase()}</span></td><td>${c.detail}</td></tr>`).join("")}
  </tbody>
</table>` : ""}

${incidents.list?.length ? `
<h2>Incidents</h2>
<table>
  <thead><tr><th>#</th><th>Title</th><th>Priority</th><th>Status</th><th>Opened</th><th>Resolved</th></tr></thead>
  <tbody>
  ${incidents.list.slice(0, 20).map((i: any) => `
  <tr>
    <td style="font-family:monospace;white-space:nowrap">${i.incidentNumber}</td>
    <td>${i.title}</td>
    <td><span class="badge ${i.priority}">${i.priority}</span></td>
    <td>${i.status}</td>
    <td style="white-space:nowrap">${new Date(i.createdAt).toLocaleDateString()}</td>
    <td style="white-space:nowrap">${i.resolvedAt ? new Date(i.resolvedAt).toLocaleDateString() : "—"}</td>
  </tr>`).join("")}
  </tbody>
</table>` : ""}

<div class="footer">
  Generated by SentinelIQ &nbsp;·&nbsp; ${new Date().toISOString()} &nbsp;·&nbsp; Confidential
</div>
</body>
</html>`;

    const slug = report.title.toLowerCase().replace(/\s+/g, "_");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${slug}_${report.period}.html"`);
    await audit({
      ...fromRequest(req), organizationId: report.organizationId,
      eventType: "report.exported",
      summary: `${report.title} exported as PDF`,
      resourceType: "report", resourceId: report.id, resourceName: report.title,
      details: { format: "pdf", period: report.period },
    });
    res.send(html);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to export PDF" });
  }
});

router.get("/reports/:id/export/csv", async (req, res) => {
  try {
    const [report] = await db.select().from(reportsTable).where(eq(reportsTable.id, req.params.id));
    if (!report) { res.status(404).json({ error: "Report not found" }); return; }
    if (report.status !== "ready" || !report.content) { res.status(409).json({ error: "Report not ready" }); return; }

    const csvFiles = contentToCsvRows(report.type as ReportType, report.content as Record<string, unknown>);
    // For single-file simplicity, combine all sheets into one CSV separated by blank lines
    const combined = csvFiles.map((f) => `# ${f.filename}\n${rowsToCsvString(f.rows)}`).join("\n\n");
    const slug = report.title.toLowerCase().replace(/\s+/g, "_");

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${slug}_${report.period}.csv"`);
    res.send(combined);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to export CSV" });
  }
});

router.get("/reports/:id/export/excel", async (req, res) => {
  try {
    const [report] = await db.select().from(reportsTable).where(eq(reportsTable.id, req.params.id));
    if (!report) { res.status(404).json({ error: "Report not found" }); return; }
    if (report.status !== "ready" || !report.content) { res.status(409).json({ error: "Report not ready" }); return; }

    // Excel-compatible TSV (opens directly in Excel/Numbers with correct column separation)
    const csvFiles = contentToCsvRows(report.type as ReportType, report.content as Record<string, unknown>);
    const combined = csvFiles
      .map((f) => `# ${f.filename}\n${f.rows.map((row) => row.map((c) => String(c).replace(/\t/g, " ")).join("\t")).join("\n")}`)
      .join("\n\n");
    const slug = report.title.toLowerCase().replace(/\s+/g, "_");

    res.setHeader("Content-Type", "text/tab-separated-values; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${slug}_${report.period}.xls"`);
    res.send(combined);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to export Excel" });
  }
});

export default router;
