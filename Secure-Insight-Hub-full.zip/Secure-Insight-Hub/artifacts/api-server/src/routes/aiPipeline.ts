import { Router } from "express";
import { db } from "@workspace/db";
import { aiResponseCacheTable, promptVersionsTable, alertAnalysesTable } from "@workspace/db";
import { eq, desc, sql, and, lt } from "drizzle-orm";
import { enqueueAnalysis, enqueuePendingAlerts, queueStats } from "../lib/analysisQueue";
import { isRedisAvailable } from "../lib/cache";

const router = Router();
function getOrgId(req: any): string { return (req.query.orgId as string) || "demo-org"; }

/** GET /ai-pipeline/stats — token usage, cache hit rate, retry rate */
router.get("/ai-pipeline/stats", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [usage] = await db.select({
      totalAnalyses:     sql<number>`count(*)::int`,
      totalPromptTokens: sql<number>`coalesce(sum(prompt_tokens), 0)::int`,
      totalCompletionTokens: sql<number>`coalesce(sum(completion_tokens), 0)::int`,
      totalTokens:       sql<number>`coalesce(sum(total_tokens), 0)::int`,
      cacheHits:         sql<number>`count(*) filter (where from_cache = true)::int`,
      retriedAnalyses:   sql<number>`count(*) filter (where retry_count > 0)::int`,
      totalRetries:      sql<number>`coalesce(sum(retry_count), 0)::int`,
      avgConfidence:     sql<number>`round(avg(confidence_score)::numeric, 3)::real`,
      avgFpProb:         sql<number>`round(avg(false_positive_probability)::numeric, 3)::real`,
      avgDurationMs:     sql<number>`round(avg(pipeline_duration_ms)::numeric)::int`,
      pendingReviews:    sql<number>`count(*) filter (where review_status = 'pending_review')::int`,
      approved:          sql<number>`count(*) filter (where review_status = 'approved')::int`,
      rejected:          sql<number>`count(*) filter (where review_status = 'rejected')::int`,
    }).from(alertAnalysesTable).where(eq(alertAnalysesTable.organizationId, orgId));

    const [cacheStats] = await db.select({
      totalEntries: sql<number>`count(*)::int`,
      totalHits:    sql<number>`coalesce(sum(hit_count), 0)::int`,
      expired:      sql<number>`count(*) filter (where expires_at < now())::int`,
    }).from(aiResponseCacheTable);

    const u = usage ?? { totalAnalyses: 0, totalPromptTokens: 0, totalCompletionTokens: 0, totalTokens: 0, cacheHits: 0, retriedAnalyses: 0, totalRetries: 0, avgConfidence: 0, avgFpProb: 0, avgDurationMs: 0, pendingReviews: 0, approved: 0, rejected: 0 };
    const cs = cacheStats ?? { totalEntries: 0, totalHits: 0, expired: 0 };
    const cacheHitRate = u.totalAnalyses > 0 ? +((u.cacheHits / u.totalAnalyses) * 100).toFixed(1) : 0;
    const retryRate = u.totalAnalyses > 0 ? +((u.retriedAnalyses / u.totalAnalyses) * 100).toFixed(1) : 0;

    res.json({
      currentModel: AI_MODEL,
      currentPromptVersion: PROMPT_VERSION,
      usage: { ...u, cacheHitRate, retryRate },
      cache: { ...cs, hitRate: cs.totalEntries > 0 ? +((cs.totalHits / (cs.totalEntries + cs.totalHits)) * 100).toFixed(1) : 0 },
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load AI pipeline stats" });
  }
});

/** GET /ai-pipeline/cache — list recent cache entries */
router.get("/ai-pipeline/cache", async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
    const entries = await db.select().from(aiResponseCacheTable)
      .orderBy(desc(aiResponseCacheTable.createdAt)).limit(limit);
    res.json(entries.map((e) => ({
      id: e.id, cacheKey: e.cacheKey.slice(0, 16) + "…",
      model: e.model, promptVersion: e.promptVersion,
      promptTokens: e.promptTokens, completionTokens: e.completionTokens,
      hitCount: e.hitCount,
      createdAt: e.createdAt.toISOString(),
      expiresAt: e.expiresAt.toISOString(),
      expired: e.expiresAt < new Date(),
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list cache entries" });
  }
});

/** DELETE /ai-pipeline/cache — evict expired entries */
router.delete("/ai-pipeline/cache", async (req, res) => {
  try {
    const { force } = req.query;
    const result = force === "true"
      ? await db.delete(aiResponseCacheTable).returning({ id: aiResponseCacheTable.id })
      : await db.delete(aiResponseCacheTable).where(lt(aiResponseCacheTable.expiresAt, new Date())).returning({ id: aiResponseCacheTable.id });
    res.json({ deleted: result.length, force: force === "true" });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to evict cache" });
  }
});

/** GET /ai-pipeline/prompts — registered prompt versions */
router.get("/ai-pipeline/prompts", async (req, res) => {
  try {
    const versions = await db.select().from(promptVersionsTable).orderBy(desc(promptVersionsTable.createdAt));
    res.json({ versions: versions.map((v) => ({ ...v, createdAt: v.createdAt.toISOString() })), activeVersion: PROMPT_VERSION, activeModel: AI_MODEL });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list prompt versions" });
  }
});

/** GET /ai-pipeline/recent — recent analysis runs with metadata */
router.get("/ai-pipeline/recent", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);
    const rows = await db.select({
      id: alertAnalysesTable.id,
      alertId: alertAnalysesTable.alertId,
      aiModelUsed: alertAnalysesTable.aiModelUsed,
      promptVersion: alertAnalysesTable.promptVersion,
      confidenceScore: alertAnalysesTable.confidenceScore,
      falsePositiveProbability: alertAnalysesTable.falsePositiveProbability,
      promptTokens: alertAnalysesTable.promptTokens,
      completionTokens: alertAnalysesTable.completionTokens,
      totalTokens: alertAnalysesTable.totalTokens,
      retryCount: alertAnalysesTable.retryCount,
      pipelineDurationMs: alertAnalysesTable.pipelineDurationMs,
      fromCache: alertAnalysesTable.fromCache,
      reviewStatus: alertAnalysesTable.reviewStatus,
      generatedAt: alertAnalysesTable.generatedAt,
    }).from(alertAnalysesTable)
      .where(eq(alertAnalysesTable.organizationId, orgId))
      .orderBy(desc(alertAnalysesTable.generatedAt))
      .limit(limit);
    res.json(rows.map((r) => ({ ...r, generatedAt: r.generatedAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load recent analyses" });
  }
});

/** GET /ai-pipeline/queue — queue depth, in-flight, metrics */
router.get("/ai-pipeline/queue", (_req, res) => {
  res.json({ ...queueStats(), redisAvailable: isRedisAvailable() });
});

/** POST /ai-pipeline/queue/:alertId — manually enqueue a single alert */
router.post("/ai-pipeline/queue/:alertId", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const enqueued = await enqueueAnalysis(req.params.alertId, orgId);
    res.json({ enqueued, alertId: req.params.alertId, message: enqueued ? "Queued for analysis" : "Already queued or in-flight" });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to enqueue" });
  }
});

/** POST /ai-pipeline/queue/drain — enqueue all unanalysed critical/high alerts */
router.post("/ai-pipeline/queue/drain", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const queued = await enqueuePendingAlerts(orgId);
    res.json({ queued, message: `Enqueued ${queued} unanalysed alert(s)` });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to drain" });
  }
});

export default router;
