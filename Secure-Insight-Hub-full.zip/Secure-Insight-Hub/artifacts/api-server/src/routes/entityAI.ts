import { Router } from "express";
import { db } from "@workspace/db";
import {
  aiEntityAnalysesTable,
  incidentsTable,
  alertsTable,
  vulnerabilitiesTable,
} from "@workspace/db";
import { eq, and, desc, sql, isNotNull } from "drizzle-orm";
import OpenAI from "openai";

const router = Router();
function getOrgId(req: any): string { return (req.query.orgId as string) || "demo-org"; }
function getOpenAI() {
  return process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
}

async function saveAnalysis(orgId: string, entityType: string, entityId: string, summary: string, details: object, model: string | null) {
  await db.delete(aiEntityAnalysesTable).where(
    and(
      eq(aiEntityAnalysesTable.organizationId, orgId),
      eq(aiEntityAnalysesTable.entityType, entityType),
      eq(aiEntityAnalysesTable.entityId, entityId),
    ),
  );
  const [saved] = await db.insert(aiEntityAnalysesTable).values({
    organizationId: orgId,
    entityType,
    entityId,
    summary,
    details: JSON.stringify(details),
    aiModelUsed: model,
    generatedAt: new Date(),
  }).returning();
  return { ...saved, details: JSON.parse(saved.details) };
}

async function getAnalysis(orgId: string, entityType: string, entityId: string) {
  const [row] = await db.select().from(aiEntityAnalysesTable).where(
    and(
      eq(aiEntityAnalysesTable.organizationId, orgId),
      eq(aiEntityAnalysesTable.entityType, entityType),
      eq(aiEntityAnalysesTable.entityId, entityId),
    ),
  ).orderBy(desc(aiEntityAnalysesTable.generatedAt)).limit(1);
  if (!row) return null;
  return { ...row, details: JSON.parse(row.details) };
}

// ─── Incident Analysis ────────────────────────────────────────────────────────

router.get("/incidents/:id/analysis", async (req, res) => {
  try {
    const result = await getAnalysis(getOrgId(req), "incident", req.params.id);
    if (!result) { res.status(404).json({ error: "No analysis found. POST to generate." }); return; }
    res.json(result);
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to get analysis" }); }
});

router.post("/incidents/:id/analysis", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [incident] = await db.select().from(incidentsTable).where(eq(incidentsTable.id, req.params.id));
    if (!incident) { res.status(404).json({ error: "Incident not found" }); return; }

    const tacticRows = await db.select({
      tactic: alertsTable.mitreTactic,
      technique: alertsTable.mitreTechnique,
      techniqueId: alertsTable.mitreTechniqueId,
    }).from(alertsTable)
      .where(and(eq(alertsTable.incidentId, req.params.id), isNotNull(alertsTable.mitreTactic)))
      .groupBy(alertsTable.mitreTactic, alertsTable.mitreTechnique, alertsTable.mitreTechniqueId)
      .limit(10);

    const tacticChain = tacticRows.map(r => `${r.techniqueId} (${r.technique}) → ${r.tactic}`).join(" → ");
    const openai = getOpenAI();
    let details: any;
    let model: string | null = null;

    if (openai) {
      const prompt = `You are a senior SOC analyst. Analyze this security incident and return a JSON object.

Incident: ${incident.title}
Description: ${incident.description ?? "N/A"}
Priority: ${incident.priority}
Status: ${incident.status}
Alert Count: ${incident.alertCount ?? 0}
MITRE Chain Detected: ${tacticChain || "Unknown"}
Created: ${incident.createdAt.toISOString()}

Return JSON with keys: attackChain (string narrative of attack progression), riskLevel (critical|high|medium|low), threatActorProfile (string), immediateActions (string[]), investigationSteps (string[]), remediationSteps (string[]), similarPatterns (string[]), businessImpact (string), executiveSummary (string).`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });
      details = JSON.parse(completion.choices[0].message.content ?? "{}");
      model = "gpt-4o-mini";
    } else {
      details = {
        attackChain: tacticChain
          ? `Detected attack progression: ${tacticChain}. Classic multi-stage intrusion pattern.`
          : `${incident.priority.toUpperCase()} severity incident involving ${incident.alertCount ?? 0} alerts. Investigation ongoing.`,
        riskLevel: incident.priority,
        threatActorProfile: "Unknown — potentially opportunistic attacker leveraging known vulnerabilities.",
        immediateActions: [
          "Isolate affected systems from the network",
          "Revoke potentially compromised credentials",
          "Preserve forensic evidence (memory dumps, logs)",
          "Notify security leadership per escalation policy",
        ],
        investigationSteps: [
          "Review authentication logs for lateral movement indicators",
          "Correlate source IPs against threat intelligence feeds",
          "Examine process execution trees on affected hosts",
          "Check for persistence mechanisms (scheduled tasks, registry run keys)",
        ],
        remediationSteps: [
          "Patch exploited vulnerabilities identified during investigation",
          "Rotate all credentials on affected systems",
          "Harden firewall rules based on observed attack vectors",
          "Deploy enhanced monitoring on affected network segments",
        ],
        similarPatterns: [
          "T1110 Brute Force campaigns often precede T1078 Valid Account abuse",
          "Multi-host incidents typically indicate lateral movement capability",
        ],
        businessImpact: `This ${incident.priority} priority incident may result in data exposure, service disruption, or regulatory liability if not contained.`,
        executiveSummary: `A ${incident.priority} severity incident titled "${incident.title}" is under investigation. ${incident.alertCount ?? 0} related alerts have been correlated. Immediate containment and forensic investigation are underway.`,
      };
    }

    const summary = details.executiveSummary ?? details.attackChain ?? incident.title;
    const result = await saveAnalysis(orgId, "incident", req.params.id, summary, details, model);
    res.json(result);
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to generate analysis" }); }
});

// ─── Vulnerability Analysis ───────────────────────────────────────────────────

router.get("/vulnerabilities/:id/analysis", async (req, res) => {
  try {
    const result = await getAnalysis(getOrgId(req), "vulnerability", req.params.id);
    if (!result) { res.status(404).json({ error: "No analysis found. POST to generate." }); return; }
    res.json(result);
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to get analysis" }); }
});

router.post("/vulnerabilities/:id/analysis", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const [vuln] = await db.select().from(vulnerabilitiesTable).where(eq(vulnerabilitiesTable.id, req.params.id));
    if (!vuln) { res.status(404).json({ error: "Vulnerability not found" }); return; }

    const [{ affectedCount }] = await db.select({
      affectedCount: sql<number>`count(distinct agent_id)::int`,
    }).from(vulnerabilitiesTable).where(
      and(eq(vulnerabilitiesTable.organizationId, orgId), eq(vulnerabilitiesTable.cveId, vuln.cveId)),
    );

    const openai = getOpenAI();
    let details: any;
    let model: string | null = null;

    if (openai) {
      const prompt = `You are a vulnerability management expert. Analyze this CVE and provide remediation guidance as JSON.

CVE: ${vuln.cveId}
Title: ${vuln.title}
CVSS Score: ${vuln.cvssScore}
Severity: ${vuln.severity}
Package: ${vuln.packageName} ${vuln.packageVersion} → fixed in: ${vuln.fixedVersion ?? "N/A"}
Affected Machines in this org: ${affectedCount}
Status: ${vuln.status}

Return JSON with: riskAssessment (string), exploitability ("public"|"private"|"theoretical"|"none"), patchPriority ("immediate"|"7_days"|"30_days"|"monitor"), patchPriorityReason (string), remediationSteps (string[]), stagingPlan (string), testingApproach (string), compensatingControls (string[]).`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });
      details = JSON.parse(completion.choices[0].message.content ?? "{}");
      model = "gpt-4o-mini";
    } else {
      const urgency = (vuln.cvssScore ?? 0) >= 9 ? "immediate" : (vuln.cvssScore ?? 0) >= 7 ? "7_days" : (vuln.cvssScore ?? 0) >= 4 ? "30_days" : "monitor";
      details = {
        riskAssessment: `${vuln.cveId} (CVSS ${vuln.cvssScore}) affects ${affectedCount} machine(s) in your environment. ${vuln.severity.toUpperCase()} severity — ${vuln.fixedVersion ? `fix available in ${vuln.fixedVersion}` : "no fix available yet"}.`,
        exploitability: (vuln.cvssScore ?? 0) >= 9 ? "public" : "private",
        patchPriority: urgency,
        patchPriorityReason: `CVSS ${vuln.cvssScore} with ${affectedCount} affected system(s). ${(vuln.cvssScore ?? 0) >= 9 ? "Exploit code is likely publicly available." : "Risk is significant but manageable with timely patching."}`,
        remediationSteps: [
          vuln.fixedVersion ? `Upgrade ${vuln.packageName} from ${vuln.packageVersion} to ${vuln.fixedVersion}` : `Monitor for patch release for ${vuln.packageName} ${vuln.packageVersion}`,
          "Test the patch in a staging environment before production rollout",
          "Verify remediation by re-running vulnerability scan on patched systems",
          "Update asset inventory with patched version numbers",
        ],
        stagingPlan: `Patch 1-2 non-critical systems first, validate for 24 hours, then roll out to remaining ${affectedCount} affected machine(s) in batches.`,
        testingApproach: `Run the existing test suite for services dependent on ${vuln.packageName}. Check service health metrics after each patch batch. Confirm fix with a targeted vulnerability scan.`,
        compensatingControls: [
          `Restrict network access to services using ${vuln.packageName}`,
          "Enable WAF rules targeting known exploit signatures",
          "Increase logging verbosity on affected hosts during exposure window",
        ],
      };
    }

    const summary = details.riskAssessment ?? `${vuln.cveId} — ${vuln.severity} severity, ${affectedCount} affected machines`;
    const result = await saveAnalysis(orgId, "vulnerability", req.params.id, summary, details, model);
    res.json(result);
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to generate analysis" }); }
});

// ─── Compliance Gap Analysis ──────────────────────────────────────────────────

const COMPLIANCE_GAPS: Record<string, any[]> = {
  "iso27001": [
    { controlId: "GAP-01", controlName: "Patch Management", category: "Vulnerability Management", priority: "high" },
    { controlId: "GAP-02", controlName: "Security Awareness Training", category: "People Controls", priority: "medium" },
    { controlId: "GAP-03", controlName: "Incident Response Plan", category: "Incident Management", priority: "high" },
    { controlId: "GAP-04", controlName: "Data Encryption at Rest", category: "Data Protection", priority: "critical" },
    { controlId: "GAP-05", controlName: "MFA Enforcement", category: "Access Control", priority: "critical" },
  ],
  "pci-dss": [
    { controlId: "GAP-01", controlName: "Patch Management", category: "Vulnerability Management", priority: "high" },
    { controlId: "GAP-02", controlName: "Security Awareness Training", category: "People Controls", priority: "medium" },
    { controlId: "GAP-03", controlName: "Incident Response Plan", category: "Incident Management", priority: "high" },
    { controlId: "GAP-04", controlName: "Data Encryption at Rest", category: "Data Protection", priority: "critical" },
    { controlId: "GAP-05", controlName: "MFA Enforcement", category: "Access Control", priority: "critical" },
  ],
  "soc2": [
    { controlId: "GAP-01", controlName: "Patch Management", category: "Availability", priority: "medium" },
    { controlId: "GAP-02", controlName: "Security Awareness Training", category: "People", priority: "low" },
    { controlId: "GAP-03", controlName: "Vendor Risk Management", category: "Risk", priority: "medium" },
  ],
  "nist": [
    { controlId: "GAP-01", controlName: "Asset Inventory", category: "Identify", priority: "high" },
    { controlId: "GAP-02", controlName: "Patch Management", category: "Protect", priority: "high" },
    { controlId: "GAP-03", controlName: "Anomaly Detection", category: "Detect", priority: "medium" },
    { controlId: "GAP-04", controlName: "Recovery Planning", category: "Recover", priority: "medium" },
  ],
  "cis": [
    { controlId: "GAP-01", controlName: "Inventory of Enterprise Assets", category: "Basic", priority: "high" },
    { controlId: "GAP-02", controlName: "Data Protection", category: "Basic", priority: "critical" },
    { controlId: "GAP-03", controlName: "Secure Configuration", category: "Basic", priority: "high" },
    { controlId: "GAP-04", controlName: "Account Management", category: "Basic", priority: "medium" },
  ],
};

router.get("/compliance/:framework/gaps/:controlId/analysis", async (req, res) => {
  try {
    const entityId = `${req.params.framework}:${req.params.controlId}`;
    const result = await getAnalysis(getOrgId(req), "compliance_gap", entityId);
    if (!result) { res.status(404).json({ error: "No analysis found. POST to generate." }); return; }
    res.json(result);
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to get analysis" }); }
});

router.post("/compliance/:framework/gaps/:controlId/analysis", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { framework, controlId } = req.params;
    const entityId = `${framework}:${controlId}`;

    const gaps = COMPLIANCE_GAPS[framework] ?? COMPLIANCE_GAPS["iso27001"];
    const gap = gaps.find(g => g.controlId === controlId) ?? gaps[0];

    const openai = getOpenAI();
    let details: any;
    let model: string | null = null;

    if (openai) {
      const prompt = `You are a compliance and security architecture expert. Analyze this control gap and provide remediation guidance as JSON.

Framework: ${framework.toUpperCase()}
Control ID: ${gap.controlId}
Control Name: ${gap.controlName}
Category: ${gap.category}
Priority: ${gap.priority}

Return JSON with: gapAnalysis (string — why this gap exists and its compliance/risk implications), regulatoryRisk ("high"|"medium"|"low"), implementationSteps (string[]), toolingRecommendations (string[] — specific tools or platforms), effort ("hours"|"days"|"weeks"|"months"), costEstimate ("low"|"medium"|"high"), quickWin (string — fastest improvement possible), auditEvidence (string — what evidence to collect to demonstrate compliance).`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });
      details = JSON.parse(completion.choices[0].message.content ?? "{}");
      model = "gpt-4o-mini";
    } else {
      const fallbacks: Record<string, any> = {
        "Patch Management": {
          gapAnalysis: `Missing automated patch management violates ${framework.toUpperCase()} requirements for systematic vulnerability remediation. Unpatched systems represent the highest-probability attack vector.`,
          regulatoryRisk: "high",
          implementationSteps: ["Deploy patch management platform (Ansible, WSUS, or Jamf)", "Define SLA: critical patches within 24h, high within 7 days", "Create asset groups by criticality for staged rollout", "Implement automated compliance reporting"],
          toolingRecommendations: ["Ansible Automation Platform", "Microsoft WSUS / SCCM", "Jamf Pro (macOS/iOS)", "Tenable.io for patch verification"],
          effort: "weeks",
          costEstimate: "medium",
          quickWin: "Enable automatic OS updates on all workstations today — takes 30 minutes and shows immediate progress to auditors.",
          auditEvidence: "Patch management policy document, automated scan reports showing patch compliance %, change management tickets for patches",
        },
        "MFA Enforcement": {
          gapAnalysis: `MFA absence is the single highest-risk gap — 80%+ of breaches involve compromised credentials. ${framework.toUpperCase()} explicitly requires strong authentication for privileged access.`,
          regulatoryRisk: "high",
          implementationSteps: ["Enroll all admin accounts in MFA immediately (TOTP or hardware key)", "Enable conditional access policies in identity provider", "Enforce MFA for all VPN and remote access", "Roll out to all users within 30 days"],
          toolingRecommendations: ["Okta", "Microsoft Entra ID (Azure AD)", "Duo Security", "YubiKey for privileged users"],
          effort: "days",
          costEstimate: "low",
          quickWin: "Enable MFA on all admin accounts today using your existing identity provider — most support TOTP at no additional cost.",
          auditEvidence: "Screenshot of MFA policy configuration, list of accounts with MFA enabled vs total, sign-in logs showing MFA prompts",
        },
      };
      details = fallbacks[gap.controlName] ?? {
        gapAnalysis: `${gap.controlName} gap in ${framework.toUpperCase()} represents a ${gap.priority} risk. Immediate remediation recommended to avoid audit findings.`,
        regulatoryRisk: gap.priority === "critical" ? "high" : gap.priority,
        implementationSteps: ["Assess current state and document baseline", "Define target state and success criteria", "Implement controls in stages", "Validate with internal audit or pen test"],
        toolingRecommendations: ["Review current security stack for existing capabilities", "Evaluate purpose-built tools for this control category"],
        effort: "weeks",
        costEstimate: "medium",
        quickWin: "Document current compensating controls immediately — this demonstrates awareness and intent to auditors.",
        auditEvidence: "Policy document, implementation evidence, testing records, user acceptance sign-off",
      };
    }

    const summary = details.gapAnalysis ?? `${gap.controlName} gap in ${framework.toUpperCase()}`;
    const result = await saveAnalysis(orgId, "compliance_gap", entityId, summary, details, model);
    res.json(result);
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to generate analysis" }); }
});

// ─── MITRE Technique Analysis ─────────────────────────────────────────────────

router.get("/mitre/technique/:techniqueId/analysis", async (req, res) => {
  try {
    const result = await getAnalysis(getOrgId(req), "mitre_technique", req.params.techniqueId);
    if (!result) { res.status(404).json({ error: "No analysis found. POST to generate." }); return; }
    res.json(result);
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to get analysis" }); }
});

router.post("/mitre/technique/:techniqueId/analysis", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const { techniqueId } = req.params;

    const since30d = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const [row] = await db.select({
      techniqueId: alertsTable.mitreTechniqueId,
      techniqueName: alertsTable.mitreTechnique,
      tacticName: alertsTable.mitreTactic,
      alertCount: sql<number>`count(*)::int`,
      uniqueAgents: sql<number>`count(distinct agent_id)::int`,
      criticalCount: sql<number>`count(*) filter (where severity='critical')::int`,
    }).from(alertsTable).where(
      and(
        eq(alertsTable.organizationId, orgId),
        eq(alertsTable.mitreTechniqueId, techniqueId),
        isNotNull(alertsTable.mitreTechniqueId),
      ),
    ).groupBy(alertsTable.mitreTechniqueId, alertsTable.mitreTechnique, alertsTable.mitreTactic);

    const techniqueName = row?.techniqueName ?? req.body.techniqueName ?? techniqueId;
    const tacticName = row?.tacticName ?? "Unknown";
    const alertCount = row?.alertCount ?? 0;
    const uniqueAgents = row?.uniqueAgents ?? 0;

    const openai = getOpenAI();
    let details: any;
    let model: string | null = null;

    if (openai) {
      const prompt = `You are a threat intelligence analyst. Analyze this MITRE ATT&CK technique detection data from a SOC environment and return JSON.

Technique: ${techniqueId} - ${techniqueName}
Tactic: ${tacticName}
Detections in environment: ${alertCount} total alerts
Affected assets: ${uniqueAgents} unique agents
Critical severity alerts: ${row?.criticalCount ?? 0}

Return JSON with: narrative (2-3 sentences describing what attackers do with this technique and why it's dangerous), industryContext (string comparing this detection volume to typical environments), attackerMotivation (string), detectionConfidence ("high"|"medium"|"low"), mitigations (string[] — top 4 practical mitigations), huntingQueries (string[] — 3 detection/hunting ideas for a SOC analyst), relatedTechniques (string[] — 3 related MITRE technique IDs and names).`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });
      details = JSON.parse(completion.choices[0].message.content ?? "{}");
      model = "gpt-4o-mini";
    } else {
      const TECHNIQUE_FALLBACKS: Record<string, any> = {
        "T1110": {
          narrative: "Brute Force attacks systematically try credential combinations to gain unauthorized access. Attackers use automated tools against exposed services like SSH, RDP, and web applications. High-volume brute force often precedes lateral movement using compromised credentials.",
          industryContext: `${alertCount} detections is ${alertCount > 30 ? "above" : "at"} typical levels for this environment size. Sustained brute force campaigns often indicate a persistent threat actor.`,
          attackerMotivation: "Credential theft for initial access or privilege escalation without exploiting vulnerabilities.",
          detectionConfidence: "high",
          mitigations: ["Implement account lockout after 5 failed attempts", "Deploy IP-based rate limiting on all authentication endpoints", "Enforce MFA on all externally-facing services", "Use a CAPTCHA or progressive delay on login forms"],
          huntingQueries: ["Alert on >10 failed logins from same IP within 60 seconds", "Correlate successful login immediately following multiple failures from same source", "Flag logins from IPs with failed attempts across multiple accounts"],
          relatedTechniques: ["T1078 - Valid Accounts", "T1556 - Modify Authentication Process", "T1003 - OS Credential Dumping"],
        },
        "T1078": {
          narrative: "Valid Accounts abuse uses legitimate credentials to blend in with normal user activity, making detection extremely difficult. Attackers obtain credentials through phishing, brute force, or data breaches. This technique bypasses many signature-based controls.",
          industryContext: `${alertCount} alerts on valid account abuse warrants immediate investigation — even 1-2 detections may represent actual compromise.`,
          attackerMotivation: "Persistence and lateral movement while avoiding detection by appearing as legitimate users.",
          detectionConfidence: "medium",
          mitigations: ["Enforce MFA across all accounts", "Implement impossible travel detection", "Monitor for off-hours logins and unusual access patterns", "Deploy privileged access workstations (PAWs) for admin accounts"],
          huntingQueries: ["Flag logins from new geographies or unusual hours", "Alert on admin accounts used from non-admin workstations", "Detect password spraying: same password tried across multiple accounts"],
          relatedTechniques: ["T1110 - Brute Force", "T1134 - Access Token Manipulation", "T1021 - Remote Services"],
        },
        "T1190": {
          narrative: "Exploit Public-Facing Application targets internet-accessible services using known vulnerabilities. Attackers scan for unpatched systems and use public exploit code. This is the most common initial access vector in enterprise environments.",
          industryContext: `${alertCount} detections suggests active exploitation attempts against your perimeter. Prioritize patching and WAF rules immediately.`,
          attackerMotivation: "Initial access — once inside, attackers pivot to higher-value internal systems.",
          detectionConfidence: "high",
          mitigations: ["Patch public-facing systems within 24h of critical CVE disclosure", "Deploy WAF with virtual patching capabilities", "Minimize attack surface by disabling unused services", "Implement network segmentation between DMZ and internal networks"],
          huntingQueries: ["Alert on known exploit signatures in web traffic logs", "Monitor for unusual process spawning from web server processes (e.g., cmd.exe from IIS)", "Detect base64-encoded payloads in HTTP POST bodies"],
          relatedTechniques: ["T1133 - External Remote Services", "T1059 - Command and Scripting Interpreter", "T1505 - Server Software Component"],
        },
      };

      details = TECHNIQUE_FALLBACKS[techniqueId] ?? {
        narrative: `${techniqueId} (${techniqueName}) detected ${alertCount} times across ${uniqueAgents} asset(s) in your environment. This ${tacticName} technique requires investigation and targeted mitigations.`,
        industryContext: `${alertCount} detections indicates ${alertCount > 20 ? "elevated" : "moderate"} activity. Correlate with threat intelligence feeds for actor attribution.`,
        attackerMotivation: `This technique is used during the ${tacticName} phase to advance attacker objectives.`,
        detectionConfidence: alertCount > 10 ? "high" : "medium",
        mitigations: ["Review and harden configurations for affected systems", "Enable enhanced logging for this technique's indicators", "Verify detection coverage in your EDR/SIEM", "Implement network-level controls to reduce attack surface"],
        huntingQueries: [`Search logs for ${techniqueId} indicators of compromise`, "Correlate with lateral movement patterns across affected hosts", "Review parent-child process relationships on affected endpoints"],
        relatedTechniques: [],
      };
    }

    const summary = details.narrative ?? `${techniqueId} detected ${alertCount} times`;
    const result = await saveAnalysis(orgId, "mitre_technique", techniqueId, summary, details, model);
    res.json(result);
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed to generate analysis" }); }
});

export default router;
