import { Router } from "express";
import { db } from "@workspace/db";
import { aiConversationsTable, aiMessagesTable, alertsTable, incidentsTable, vulnerabilitiesTable } from "@workspace/db";
import { eq, and, desc, sql } from "drizzle-orm";
import OpenAI from "openai";

const router = Router();
function getOrgId(req: any): string { return req.query.orgId as string || "demo-org"; }

function getOpenAI() {
  if (process.env.OPENAI_API_KEY) {
    return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }
  return null;
}

router.get("/ai/conversations", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const userId = (req as any).auth?.userId ?? "demo-user";
    const convos = await db.select().from(aiConversationsTable)
      .where(and(eq(aiConversationsTable.organizationId, orgId), eq(aiConversationsTable.userId, userId)))
      .orderBy(desc(aiConversationsTable.updatedAt)).limit(20);
    res.json(convos.map(c => ({ ...c, createdAt: c.createdAt.toISOString(), updatedAt: c.updatedAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list conversations" });
  }
});

router.get("/ai/conversations/:id/messages", async (req, res) => {
  try {
    const messages = await db.select().from(aiMessagesTable)
      .where(eq(aiMessagesTable.conversationId, req.params.id))
      .orderBy(aiMessagesTable.createdAt);
    res.json(messages.map(m => ({ ...m, createdAt: m.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get messages" });
  }
});

router.post("/ai/chat", async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const userId = (req as any).auth?.userId ?? "demo-user";
    const { message, conversationId } = req.body;

    let convId = conversationId;

    if (!convId) {
      const title = message.length > 60 ? message.substring(0, 60) + "..." : message;
      const [convo] = await db.insert(aiConversationsTable).values({
        organizationId: orgId,
        userId,
        title,
        messageCount: 0,
      }).returning();
      convId = convo.id;
    }

    await db.insert(aiMessagesTable).values({
      conversationId: convId,
      organizationId: orgId,
      role: "user",
      content: message,
    });

    const [alertCount, incidentCount, vulnCount] = await Promise.all([
      db.select({ c: sql<number>`count(*)::int` }).from(alertsTable).where(and(eq(alertsTable.organizationId, orgId), eq(alertsTable.status, "new"))),
      db.select({ c: sql<number>`count(*)::int` }).from(incidentsTable).where(and(eq(incidentsTable.organizationId, orgId), eq(incidentsTable.status, "open"))),
      db.select({ c: sql<number>`count(*)::int` }).from(vulnerabilitiesTable).where(and(eq(vulnerabilitiesTable.organizationId, orgId), eq(vulnerabilitiesTable.severity, "critical"), eq(vulnerabilitiesTable.status, "open"))),
    ]);

    const systemContext = `You are SentinelIQ AI, an expert cybersecurity analyst assistant. You have access to the organization's security data.

Current Security Context:
- Open alerts (new): ${alertCount[0]?.c ?? 0}
- Active incidents: ${incidentCount[0]?.c ?? 0}
- Critical unpatched vulnerabilities: ${vulnCount[0]?.c ?? 0}

You help security analysts investigate incidents, understand alerts, interpret MITRE ATT&CK techniques, prioritize vulnerabilities, and navigate compliance requirements. Be concise, technically accurate, and actionable. Use markdown formatting for lists and code blocks.`;

    let assistantContent: string;
    const openai = getOpenAI();

    if (openai) {
      const history = await db.select().from(aiMessagesTable)
        .where(eq(aiMessagesTable.conversationId, convId))
        .orderBy(aiMessagesTable.createdAt).limit(20);

      const completion = await openai.chat.completions.create({
        model: "gpt-5-mini",
        messages: [
          { role: "system", content: systemContext },
          ...history.slice(-10).map(m => ({ role: m.role as "user" | "assistant", content: m.content })),
        ],
      });
      assistantContent = completion.choices[0].message.content ?? "I was unable to process your request.";
    } else {
      assistantContent = generateFallbackResponse(message, alertCount[0]?.c ?? 0, incidentCount[0]?.c ?? 0, vulnCount[0]?.c ?? 0);
    }

    const [assistantMsg] = await db.insert(aiMessagesTable).values({
      conversationId: convId,
      organizationId: orgId,
      role: "assistant",
      content: assistantContent,
    }).returning();

    await db.update(aiConversationsTable)
      .set({ messageCount: sql`message_count + 2`, updatedAt: new Date() })
      .where(eq(aiConversationsTable.id, convId));

    res.json({ ...assistantMsg, createdAt: assistantMsg.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to process message" });
  }
});

function generateFallbackResponse(message: string, alerts: number, incidents: number, vulns: number): string {
  const lower = message.toLowerCase();
  if (lower.includes("critical") || lower.includes("vuln")) {
    return `## Critical Vulnerabilities\n\nYou currently have **${vulns} critical unpatched vulnerabilities**.\n\nRecommended immediate actions:\n1. Identify affected systems in the Vulnerabilities dashboard\n2. Prioritize patches for internet-facing systems\n3. Apply available vendor patches\n4. Monitor for exploitation attempts\n\n*Note: Connect your OpenAI API key for full AI-powered analysis.*`;
  }
  if (lower.includes("incident") || lower.includes("happened")) {
    return `## Current Incident Status\n\nYou have **${incidents} active incidents** that require attention.\n\nTo investigate:\n1. Navigate to the Incidents page\n2. Review the timeline and linked alerts\n3. Assign an analyst and update the status\n4. Document findings in the incident notes\n\n*Note: Connect your OpenAI API key for AI-powered incident analysis.*`;
  }
  if (lower.includes("alert")) {
    return `## Alert Overview\n\nThere are currently **${alerts} new unacknowledged alerts** in your environment.\n\nPrioritization strategy:\n1. Review CRITICAL and HIGH severity alerts first\n2. Check for MITRE ATT&CK technique associations\n3. Correlate alerts from the same agent or IP\n4. Escalate potential incidents for investigation\n\n*Note: Connect your OpenAI API key for full AI-powered analysis.*`;
  }
  return `## SentinelIQ AI Assistant\n\nI can help you with:\n- **Incident investigation** — "What happened in the last 24 hours?"\n- **Alert analysis** — "Why did this alert trigger?"\n- **Vulnerability prioritization** — "Show critical CVEs"\n- **MITRE ATT&CK** — "Explain technique T1110"\n- **Compliance** — "What are our ISO 27001 gaps?"\n\nCurrent status: **${alerts}** new alerts, **${incidents}** open incidents, **${vulns}** critical vulnerabilities.\n\n*Note: Add your OpenAI API key in secrets for full AI-powered responses.*`;
}

export default router;
