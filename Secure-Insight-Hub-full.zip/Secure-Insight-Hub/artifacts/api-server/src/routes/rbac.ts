import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  PERMISSIONS, ROLE_META, ROLE_ORDER, PERMISSIONS as ALL_PERMS,
  permissionsForRole, hasPermission, canAssignRole, requirePermission,
  type Role, type Permission,
} from "../lib/rbac";
import { audit, fromRequest } from "../lib/auditWriter";

const router = Router();
function getOrgId(req: any): string { return (req.query.orgId as string) || "demo-org"; }
function getActor(req: any): { id: string; role: string } {
  return { id: (req as any).auth?.userId ?? "demo-user", role: (req as any).userRole ?? "l1_analyst" };
}
function fmtUser(u: any) {
  return { ...u, lastActiveAt: u.lastActiveAt?.toISOString() ?? null, createdAt: u.createdAt.toISOString(), updatedAt: u.updatedAt.toISOString() };
}

/** GET /rbac/meta — roles + permissions catalogue (no auth needed — purely descriptive) */
router.get("/rbac/meta", (_req, res) => {
  res.json({
    roles: Object.entries(ROLE_META).map(([id, m]) => ({
      id,
      label: m.label,
      description: m.description,
      color: m.color,
      level: m.level,
      permissions: permissionsForRole(id as Role),
    })),
    permissions: PERMISSIONS.slice(), // all defined permissions
  });
});

/** GET /rbac/me — current user's resolved role + permission set */
router.get("/rbac/me", async (req, res) => {
  const actor = getActor(req);
  res.json({
    userId: actor.id,
    role: actor.role,
    roleLabel: ROLE_META[actor.role as Role]?.label ?? actor.role,
    permissions: permissionsForRole(actor.role as Role),
  });
});

/** GET /rbac/users — full user list with roles (requires users:view) */
router.get("/rbac/users", requirePermission("users:view"), async (req, res) => {
  try {
    const orgId = getOrgId(req);
    const users = await db.select().from(usersTable).where(eq(usersTable.organizationId, orgId));
    res.json(users.map(fmtUser));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to list users" });
  }
});

/** PATCH /rbac/users/:id/role — assign a new role (requires users:assign_roles) */
router.patch("/rbac/users/:id/role", requirePermission("users:assign_roles"), async (req, res) => {
  try {
    const { role } = req.body as { role: string };
    const actor = getActor(req);

    if (!ROLE_ORDER.includes(role as Role)) {
      res.status(400).json({ error: `Invalid role. Must be one of: ${ROLE_ORDER.join(", ")}` }); return;
    }
    if (!canAssignRole(actor.role, role)) {
      res.status(403).json({ error: `You cannot assign a role (${role}) higher than your own (${actor.role})` }); return;
    }

    const [updated] = await db.update(usersTable).set({ role, updatedAt: new Date() })
      .where(eq(usersTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "User not found" }); return; }
    await audit({
      ...fromRequest(req), organizationId: getOrgId(req),
      eventType: "rbac.role.changed",
      summary: `User ${updated.email} role changed to "${ROLE_META[role as Role]?.label ?? role}"`,
      resourceType: "user", resourceId: updated.id, resourceName: updated.email,
      details: { previousRole: updated.role, newRole: role },
    });
    res.json(fmtUser(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update role" });
  }
});

/** PATCH /rbac/users/:id/status — activate/deactivate (requires users:manage) */
router.patch("/rbac/users/:id/status", requirePermission("users:manage"), async (req, res) => {
  try {
    const { isActive } = req.body as { isActive: boolean };
    const actor = getActor(req);
    if (req.params.id === actor.id) {
      res.status(400).json({ error: "Cannot deactivate yourself" }); return;
    }
    const [updated] = await db.update(usersTable).set({ isActive, updatedAt: new Date() })
      .where(eq(usersTable.id, req.params.id)).returning();
    if (!updated) { res.status(404).json({ error: "User not found" }); return; }
    await audit({
      ...fromRequest(req), organizationId: getOrgId(req),
      eventType: isActive ? "rbac.user.reactivated" : "rbac.user.deactivated",
      summary: `User ${updated.email} ${isActive ? "reactivated" : "deactivated"}`,
      resourceType: "user", resourceId: updated.id, resourceName: updated.email,
      details: { isActive },
    });
    res.json(fmtUser(updated));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update user status" });
  }
});

/** POST /rbac/check — check if a given role has a permission (dev/audit tool) */
router.post("/rbac/check", async (req, res) => {
  const { role, permission } = req.body as { role: string; permission: string };
  res.json({
    role, permission,
    allowed: hasPermission(role as Role, permission as Permission),
    roleLabel: ROLE_META[role as Role]?.label ?? role,
  });
});

export default router;
