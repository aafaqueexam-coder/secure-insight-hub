import { Router } from "express";
import { assessFramework, assessAllFrameworks } from "../lib/complianceEngine";

const router = Router();
function getOrgId(req: any): string { return (req.query.orgId as string) || "demo-org"; }

// List all frameworks with summary scores
router.get("/compliance", async (req, res) => {
  try {
    const assessments = await assessAllFrameworks(getOrgId(req));
    res.json(assessments.map(({ controls: _c, ...summary }) => summary));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to assess compliance frameworks" });
  }
});

// Full framework detail including all evaluated controls
router.get("/compliance/:framework", async (req, res) => {
  try {
    const assessment = await assessFramework(getOrgId(req), req.params.framework);
    if (!assessment) { res.status(404).json({ error: "Framework not found" }); return; }
    res.json(assessment);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to assess framework" });
  }
});

// Failed / partial controls as actionable gaps
router.get("/compliance/:framework/gaps", async (req, res) => {
  try {
    const assessment = await assessFramework(getOrgId(req), req.params.framework);
    if (!assessment) { res.status(404).json({ error: "Framework not found" }); return; }
    const gaps = assessment.controls
      .filter((c) => c.status === "failed" || c.status === "partial")
      .sort((a, b) => {
        const priority = { failed: 0, partial: 1 };
        return (priority[a.status as "failed"|"partial"] ?? 2) - (priority[b.status as "failed"|"partial"] ?? 2) || a.score - b.score;
      })
      .map((c) => ({
        controlId: c.id,
        controlName: c.name,
        category: c.category,
        status: c.status,
        score: c.score,
        evidence: c.evidence,
        evidenceData: c.evidenceData,
        recommendation: c.recommendation,
        remediationSteps: c.remediationSteps,
        evidenceHints: c.evidenceHints,
        priority: c.status === "failed" ? (c.weight >= 3 ? "critical" : "high") : "medium",
      }));
    res.json(gaps);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to load compliance gaps" });
  }
});

export default router;
