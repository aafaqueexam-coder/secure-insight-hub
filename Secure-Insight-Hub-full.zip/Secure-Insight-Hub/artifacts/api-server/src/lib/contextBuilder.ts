import { db } from "@workspace/db";
import { alertsTable } from "@workspace/db";
import { and, desc, eq, ne, sql } from "drizzle-orm";
import type { Alert } from "@workspace/db";

/**
 * Fields considered sensitive enough that they must never reach an LLM prompt
 * verbatim. Each is replaced with a deterministic placeholder so the model can
 * still reason about "an IP" / "a raw log line" existing without seeing the
 * actual value.
 */
const SENSITIVE_ALERT_FIELDS = ["agentIp", "sourceIp", "rawLog"] as const;
type SensitiveField = (typeof SENSITIVE_ALERT_FIELDS)[number];

export interface AlertContext {
  alert: Record<string, unknown>;
  relatedAlerts: Array<{
    ruleName: string;
    severity: string;
    timestamp: string;
    sameAgent: boolean;
    sameSourceIp: boolean;
  }>;
}

export interface RedactionResult {
  context: AlertContext;
  redactedFields: string[];
}

/**
 * Context Builder step: pulls in supporting data beyond the single alert row
 * so the AI has situational awareness (recent related activity on the same
 * agent / source IP) before it investigates.
 */
export async function buildAlertContext(alert: Alert): Promise<AlertContext> {
  const related = await db
    .select({
      ruleName: alertsTable.ruleName,
      severity: alertsTable.severity,
      timestamp: alertsTable.timestamp,
      agentId: alertsTable.agentId,
      sourceIp: alertsTable.sourceIp,
    })
    .from(alertsTable)
    .where(
      and(
        eq(alertsTable.organizationId, alert.organizationId),
        ne(alertsTable.id, alert.id),
        sql`(${alertsTable.agentId} = ${alert.agentId} OR ${alertsTable.sourceIp} = ${alert.sourceIp})`,
      ),
    )
    .orderBy(desc(alertsTable.timestamp))
    .limit(5);

  return {
    alert: { ...alert },
    relatedAlerts: related.map((r) => ({
      ruleName: r.ruleName,
      severity: r.severity,
      timestamp: r.timestamp.toISOString(),
      sameAgent: r.agentId === alert.agentId,
      sameSourceIp: !!alert.sourceIp && r.sourceIp === alert.sourceIp,
    })),
  };
}

/**
 * Remove Sensitive Fields step: strips/masks fields from the alert before any
 * part of the context is included in an AI prompt. Returns the redacted
 * context plus the list of field names that were removed, so the removal is
 * auditable and stored alongside the resulting analysis.
 */
export function redactSensitiveFields(context: AlertContext): RedactionResult {
  const redactedFields: string[] = [];
  const alert = { ...context.alert };

  for (const field of SENSITIVE_ALERT_FIELDS as readonly SensitiveField[]) {
    if (alert[field] !== undefined && alert[field] !== null && alert[field] !== "") {
      redactedFields.push(field);
      alert[field] = `[REDACTED_${field.toUpperCase()}]`;
    }
  }

  return {
    context: { ...context, alert },
    redactedFields,
  };
}

/**
 * Counts how many times this exact rule has previously fired on this agent
 * (excluding the current alert) — used for the "Previous occurrences" panel.
 */
export async function countPreviousOccurrences(alert: Alert): Promise<number> {
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(alertsTable)
    .where(
      and(
        eq(alertsTable.organizationId, alert.organizationId),
        eq(alertsTable.ruleId, alert.ruleId),
        eq(alertsTable.agentId, alert.agentId),
        ne(alertsTable.id, alert.id),
      ),
    );
  return row?.count ?? 0;
}

const IP_RE = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
const DOMAIN_RE = /\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}\b/gi;
const HASH_RE = /\b[a-f0-9]{32}\b|\b[a-f0-9]{40}\b|\b[a-f0-9]{64}\b/gi;

/**
 * Pulls likely indicators of compromise (IPs, hashes, domains) out of raw
 * alert text. This is a best-effort fallback used alongside whatever the AI
 * itself reports as IOCs in its structured response.
 */
export function extractIocs(text: string): Ioc[] {
  if (!text) return [];
  const found = new Map<string, Ioc>();

  for (const match of text.match(IP_RE) ?? []) {
    found.set(`ip:${match}`, { type: "ip", value: match });
  }
  for (const match of text.match(HASH_RE) ?? []) {
    const type = match.length === 32 ? "md5" : match.length === 40 ? "sha1" : "sha256";
    found.set(`${type}:${match}`, { type, value: match.toLowerCase() });
  }
  for (const match of text.match(DOMAIN_RE) ?? []) {
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(match)) continue;
    found.set(`domain:${match}`, { type: "domain", value: match.toLowerCase() });
  }

  return Array.from(found.values()).slice(0, 25);
}
