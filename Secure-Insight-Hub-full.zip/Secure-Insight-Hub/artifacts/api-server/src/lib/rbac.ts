import type { Request, Response, NextFunction } from "express";

/* ─── Permission catalogue ───────────────────────────────────────────────── */
export const PERMISSIONS = [
  // Alerts
  "alerts:view",
  "alerts:acknowledge",
  "alerts:bulk_action",
  // AI
  "ai:run_analysis",
  "ai:review",          // approve / reject AI recommendations
  // Incidents
  "incidents:view",
  "incidents:create",
  "incidents:update",   // change status, assign, add notes
  "incidents:close",    // resolve / close
  // Reports
  "reports:view",
  "reports:generate",
  // Rules
  "rules:view",
  "rules:modify",       // approve / reject rule optimisation changes
  "rules:run_tuning",
  // Threat intel
  "threat_intel:view",
  "threat_intel:enrich",
  // Compliance
  "compliance:view",
  // Vulnerabilities
  "vulnerabilities:view",
  // Users / RBAC
  "users:view",
  "users:manage",       // create, edit, deactivate
  "users:assign_roles", // can only assign roles ≤ own role
  // Dashboard
  "dashboard:view",
] as const;

export type Permission = (typeof PERMISSIONS)[number];

/* ─── Role definitions ──────────────────────────────────────────────────── */
export type Role = "l1_analyst" | "l2_analyst" | "l3_analyst" | "soc_manager" | "admin" | "auditor";

export const ROLE_META: Record<Role, { label: string; description: string; color: string; level: number }> = {
  auditor:     { label: "Auditor",     description: "Read-only access to alerts, reports, and compliance",            color: "text-slate-400",   level: 0 },
  l1_analyst:  { label: "L1 Analyst",  description: "Triage alerts, run AI analysis, acknowledge and filter",         color: "text-blue-400",    level: 1 },
  l2_analyst:  { label: "L2 Analyst",  description: "All L1 permissions plus AI review, incident creation, enrichment", color: "text-purple-400", level: 2 },
  l3_analyst:  { label: "L3 Analyst",  description: "All L2 permissions plus incident closure and rule modification",  color: "text-orange-400",  level: 3 },
  soc_manager: { label: "SOC Manager", description: "All L3 permissions plus team management and reporting",           color: "text-yellow-400",  level: 4 },
  admin:       { label: "Admin",       description: "Unrestricted access including user and role management",          color: "text-red-400",     level: 5 },
};

// Ordered list (lowest first) — used to validate that a manager can only
// assign roles at or below their own level.
export const ROLE_ORDER: Role[] = ["auditor", "l1_analyst", "l2_analyst", "l3_analyst", "soc_manager", "admin"];

/* ─── Permission → Role matrix ─────────────────────────────────────────── */
const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  auditor: [
    "alerts:view",
    "incidents:view",
    "reports:view",
    "compliance:view",
    "vulnerabilities:view",
    "threat_intel:view",
    "rules:view",
    "dashboard:view",
    "users:view",
  ],
  l1_analyst: [
    "alerts:view",
    "alerts:acknowledge",
    "alerts:bulk_action",
    "ai:run_analysis",
    "incidents:view",
    "incidents:create",
    "reports:view",
    "compliance:view",
    "vulnerabilities:view",
    "threat_intel:view",
    "threat_intel:enrich",
    "rules:view",
    "dashboard:view",
    "users:view",
  ],
  l2_analyst: [
    "alerts:view",
    "alerts:acknowledge",
    "alerts:bulk_action",
    "ai:run_analysis",
    "ai:review",
    "incidents:view",
    "incidents:create",
    "incidents:update",
    "reports:view",
    "reports:generate",
    "compliance:view",
    "vulnerabilities:view",
    "threat_intel:view",
    "threat_intel:enrich",
    "rules:view",
    "dashboard:view",
    "users:view",
  ],
  l3_analyst: [
    "alerts:view",
    "alerts:acknowledge",
    "alerts:bulk_action",
    "ai:run_analysis",
    "ai:review",
    "incidents:view",
    "incidents:create",
    "incidents:update",
    "incidents:close",
    "reports:view",
    "reports:generate",
    "compliance:view",
    "vulnerabilities:view",
    "threat_intel:view",
    "threat_intel:enrich",
    "rules:view",
    "rules:modify",
    "rules:run_tuning",
    "dashboard:view",
    "users:view",
  ],
  soc_manager: [
    "alerts:view",
    "alerts:acknowledge",
    "alerts:bulk_action",
    "ai:run_analysis",
    "ai:review",
    "incidents:view",
    "incidents:create",
    "incidents:update",
    "incidents:close",
    "reports:view",
    "reports:generate",
    "compliance:view",
    "vulnerabilities:view",
    "threat_intel:view",
    "threat_intel:enrich",
    "rules:view",
    "rules:modify",
    "rules:run_tuning",
    "dashboard:view",
    "users:view",
    "users:manage",
    "users:assign_roles",
  ],
  admin: [
    // Admin has every permission
    ...PERMISSIONS,
  ],
};

/* ─── Public helpers ────────────────────────────────────────────────────── */

/** Returns true if the given role carries the requested permission. */
export function hasPermission(role: Role | string, permission: Permission): boolean {
  const perms = ROLE_PERMISSIONS[role as Role];
  if (!perms) return false;
  return perms.includes(permission);
}

/** Returns the full set of permissions for a role. */
export function permissionsForRole(role: Role | string): Permission[] {
  return ROLE_PERMISSIONS[role as Role] ?? [];
}

/** Returns role level (0 = lowest). Used to gate role assignment. */
export function roleLevel(role: Role | string): number {
  return ROLE_META[role as Role]?.level ?? -1;
}

/** Returns true if `actor` is allowed to assign `target` to someone else. */
export function canAssignRole(actorRole: Role | string, targetRole: Role | string): boolean {
  return roleLevel(actorRole) >= roleLevel(targetRole);
}

/* ─── Express middleware ─────────────────────────────────────────────────── */

/**
 * Reads the actor's role from req.userRole (set by the auth resolver below)
 * and rejects the request with 403 if the role lacks the given permission.
 *
 * Usage:
 *   router.post("/incidents", requirePermission("incidents:create"), handler);
 */
export function requirePermission(...required: Permission[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const role: string = (req as any).userRole ?? "l1_analyst";
    const missing = required.filter((p) => !hasPermission(role, p));
    if (missing.length) {
      res.status(403).json({
        error: "Forbidden",
        required: missing,
        yourRole: role,
        message: `Your role (${ROLE_META[role as Role]?.label ?? role}) does not have the required permission(s): ${missing.join(", ")}`,
      });
      return;
    }
    next();
  };
}

/**
 * Must run after Clerk middleware. Looks up the current user's role from the
 * DB and attaches it to req.userRole. Falls back to "l1_analyst" for unknown
 * or unauthenticated users (demo mode).
 *
 * Mount once at the top of the API router:
 *   router.use(resolveUserRole);
 */
export async function resolveUserRole(req: Request, res: Response, next: NextFunction) {
  try {
    const userId: string | undefined = (req as any).auth?.userId;
    if (!userId) {
      (req as any).userRole = "l1_analyst"; // demo mode — treat as L1
      next(); return;
    }
    // Lazy import to avoid circular deps
    const { db } = await import("@workspace/db");
    const { usersTable } = await import("@workspace/db");
    const { eq } = await import("drizzle-orm");
    const [user] = await db.select({ role: usersTable.role }).from(usersTable).where(eq(usersTable.id, userId));
    (req as any).userRole = user?.role ?? "l1_analyst";
    next();
  } catch {
    (req as any).userRole = "l1_analyst";
    next();
  }
}
