/**
 * Wazuh REST API Client
 *
 * Implements JWT authentication (POST /security/user/authenticate) and all
 * data-stream endpoints needed for the 8 integration checkboxes.
 *
 * Auth flow:
 *   1. POST /security/user/authenticate → JWT token (expires in 900s)
 *   2. Bearer token on all subsequent requests
 *   3. Token cached per connection; auto-refreshed when expired
 *
 * All methods return typed data or throw WazuhApiError.
 */

const TOKEN_CACHE = new Map<string, { token: string; expiresAt: number }>();

export class WazuhApiError extends Error {
  constructor(public statusCode: number, message: string) {
    super(message);
    this.name = "WazuhApiError";
  }
}

async function fetchWazuh<T>(baseUrl: string, token: string, path: string, opts: RequestInit = {}, timeout = 10000): Promise<T> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(`${baseUrl.replace(/\/$/, "")}${path}`, {
      ...opts,
      signal: ctrl.signal,
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
        ...(opts.headers as Record<string, string> ?? {}),
      },
    });
    if (!res.ok) throw new WazuhApiError(res.status, `Wazuh API ${path} → HTTP ${res.status}`);
    return res.json() as Promise<T>;
  } finally {
    clearTimeout(t);
  }
}

export async function authenticate(baseUrl: string, username: string, password: string): Promise<string> {
  const cacheKey = `${baseUrl}:${username}`;
  const cached = TOKEN_CACHE.get(cacheKey);
  if (cached && cached.expiresAt > Date.now() + 30000) return cached.token;

  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 10000);
  try {
    const res = await fetch(`${baseUrl.replace(/\/$/, "")}/security/user/authenticate`, {
      method: "POST",
      signal: ctrl.signal,
      headers: {
        "Authorization": `Basic ${Buffer.from(`${username}:${password}`).toString("base64")}`,
        "Content-Type": "application/json",
      },
    });
    if (!res.ok) throw new WazuhApiError(res.status, `Authentication failed: HTTP ${res.status}`);
    const data: any = await res.json();
    const token = data?.data?.token;
    if (!token) throw new WazuhApiError(401, "No token in authentication response");
    TOKEN_CACHE.set(cacheKey, { token, expiresAt: Date.now() + 900000 }); // 15 min
    return token;
  } finally {
    clearTimeout(t);
  }
}

export function clearTokenCache(baseUrl: string, username: string) {
  TOKEN_CACHE.delete(`${baseUrl}:${username}`);
}

/* ─── Agent Status ─────────────────────────────────────────────────────── */
export interface WazuhAgent {
  id: string; name: string; ip: string; status: string;
  os?: { name?: string; platform?: string; version?: string; arch?: string };
  version?: string; manager?: string; group?: string[]; groups?: string[];
  lastKeepAlive?: string; dateAdd?: string; registerIP?: string;
  configSum?: string; mergedSum?: string; node_name?: string;
}

export async function fetchAgents(baseUrl: string, token: string, limit = 500): Promise<WazuhAgent[]> {
  const data: any = await fetchWazuh(baseUrl, token, `/agents?limit=${limit}&select=id,name,ip,status,os,version,manager,group,groups,lastKeepAlive,dateAdd`);
  return data?.data?.affected_items ?? [];
}

/* ─── Live Alerts ──────────────────────────────────────────────────────── */
export interface WazuhAlert {
  _id: string;
  _source: {
    timestamp?: string;
    agent?: { id?: string; name?: string; ip?: string };
    rule?: { id?: string; level?: number; description?: string; groups?: string[]; mitre?: { id?: string[]; tactic?: string[]; technique?: string[] } };
    data?: { srcip?: string; dstip?: string; protocol?: string; action?: string; [k: string]: unknown };
    location?: string;
    full_log?: string;
    decoder?: { name?: string };
    manager?: { name?: string };
    id?: string;
  };
}

export async function fetchAlerts(baseUrl: string, token: string, options: { limit?: number; minLevel?: number; agentId?: string; from?: string } = {}): Promise<WazuhAlert[]> {
  const qs = new URLSearchParams({
    limit: String(options.limit ?? 100),
    sort: "-timestamp",
  });
  if (options.minLevel) qs.set("q", `rule.level>=${options.minLevel}`);
  if (options.agentId) qs.set("agents_list", options.agentId);
  if (options.from) qs.set("older_than", "0s"); // placeholder; real time filter uses q param

  const data: any = await fetchWazuh(baseUrl, token, `/alerts?${qs}`);
  return data?.data?.affected_items ?? [];
}

/* ─── Rule Metadata ────────────────────────────────────────────────────── */
export interface WazuhRule {
  id: number; level: number; description: string;
  groups: string[]; file: string; path?: string; status?: string;
  details?: { mitre?: { id?: string[]; tactic?: string[]; technique?: string[] } };
}

export async function fetchRules(baseUrl: string, token: string, limit = 2000): Promise<WazuhRule[]> {
  const data: any = await fetchWazuh(baseUrl, token, `/rules?limit=${limit}&select=id,level,description,groups,file,path,status,details`);
  return data?.data?.affected_items ?? [];
}

/* ─── MITRE Mapping ─────────────────────────────────────────────────────── */
export interface WazuhMitreTechnique {
  id: string; name: string; url?: string;
  tactics?: string[]; references?: string[];
}

export async function fetchMitreTechniques(baseUrl: string, token: string): Promise<WazuhMitreTechnique[]> {
  const data: any = await fetchWazuh(baseUrl, token, `/mitre/techniques?limit=500`);
  return data?.data?.affected_items ?? [];
}

/* ─── Vulnerability Data ────────────────────────────────────────────────── */
export interface WazuhVuln {
  cve: string; name: string; version: string;
  severity: string; cvss2_score?: number; cvss3_score?: number;
  condition?: string; status?: string; detection_time?: string;
  external_references?: string[];
}

export async function fetchVulnerabilities(baseUrl: string, token: string, agentId: string, limit = 200): Promise<WazuhVuln[]> {
  const data: any = await fetchWazuh(baseUrl, token, `/vulnerability/${agentId}?limit=${limit}&sort=-severity`);
  return data?.data?.affected_items ?? [];
}

/* ─── FIM Events ─────────────────────────────────────────────────────── */
export interface WazuhFimEvent {
  type: string; file: string; agent?: { id?: string; name?: string };
  attributes?: { type?: string; mode?: string; hash_md5?: string; hash_sha256?: string; perm?: string; uid?: string; gid?: string; size?: number };
  changed_attributes?: string[];
  old_attributes?: { hash_md5?: string; hash_sha256?: string; perm?: string; uid?: string; size?: number };
  timestamp?: string;
}

export async function fetchFimEvents(baseUrl: string, token: string, agentId: string, limit = 100): Promise<WazuhFimEvent[]> {
  const data: any = await fetchWazuh(baseUrl, token, `/syscheck/${agentId}?limit=${limit}&sort=-timestamp`);
  return data?.data?.affected_items ?? [];
}

/* ─── Active Response Status ─────────────────────────────────────────── */
export interface WazuhActiveResponse {
  command: string; location: string; arguments?: string[];
  status?: string; timeout?: number;
}

export async function triggerActiveResponse(
  baseUrl: string, token: string,
  agentId: string, command: string, args: string[] = [],
): Promise<{ success: boolean; data?: unknown; error?: string }> {
  try {
    const data = await fetchWazuh(baseUrl, token, `/active-response`, {
      method: "PUT",
      body: JSON.stringify({
        command,
        arguments: args,
        alert: { agent: { id: agentId } },
      }),
    });
    return { success: true, data };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

export async function fetchActiveResponseCommands(baseUrl: string, token: string): Promise<string[]> {
  try {
    const data: any = await fetchWazuh(baseUrl, token, `/lists/files?limit=100`);
    return data?.data?.affected_items?.map((i: any) => i.filename) ?? [];
  } catch { return []; }
}

/* ─── Cluster / Manager Info ─────────────────────────────────────────── */
export interface WazuhManagerInfo {
  version?: string; compilation_date?: string; type?: string;
  max_agents?: string; openssl_support?: string; ruleset_version?: string;
  path?: string; tz_name?: string;
}

export async function fetchManagerInfo(baseUrl: string, token: string): Promise<WazuhManagerInfo> {
  const data: any = await fetchWazuh(baseUrl, token, `/manager/info`);
  return data?.data ?? {};
}
