import { db } from "@workspace/db";
import { auditLogsTable } from "@workspace/db";
import type { Request } from "express";

export interface AuditEvent {
  organizationId: string;
  eventType: string;
  summary: string;
  actorId: string;
  actorName: string;
  actorRole?: string;
  resourceType?: string;
  resourceId?: string;
  resourceName?: string;
  details?: Record<string, unknown>;
  ipAddress?: string;
}

/**
 * Write a single audit event. Never throws — failures are swallowed so they
 * never break the primary action that caused them.
 */
export async function audit(event: AuditEvent): Promise<void> {
  try {
    await db.insert(auditLogsTable).values({
      ...event,
      occurredAt: new Date(),
    });
  } catch (err) {
    // Audit failures must never break the calling request.
    console.error("[audit] Failed to write audit log:", err);
  }
}

/**
 * Convenience: derive actor + org + IP from an Express Request.
 * Returns a partial AuditEvent that callers merge with the domain-specific
 * fields they know.
 */
export function fromRequest(req: Request): Pick<AuditEvent, "actorId" | "actorName" | "actorRole" | "organizationId" | "ipAddress"> {
  const auth = (req as any).auth;
  const ip = (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() ?? req.socket?.remoteAddress ?? undefined;
  return {
    actorId: auth?.userId ?? "demo-user",
    actorName: (req as any).auth?.userName ?? "Analyst",
    actorRole: (req as any).userRole ?? "l1_analyst",
    organizationId: (req.query.orgId as string) || "demo-org",
    ipAddress: ip,
  };
}
