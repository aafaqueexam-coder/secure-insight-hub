import { db } from "@workspace/db";
import {
  alertsTable, incidentsTable, alertAnalysesTable, iocEnrichmentsTable,
  ruleTuningRecommendationsTable, vulnerabilitiesTable, wazuhAgentsTable,
} from "@workspace/db";
import { and, eq, gte, lte, sql, desc, isNotNull } from "drizzle-orm";

export type ReportType =
  | "daily"
  | "weekly"
  | "monthly"
  | "executive_summary"
  | "incident_report"
  | "compliance_report"
  | "rule_optimization_report";

export interface ReportPeriod { from: Date; to: Date; label: string; }

export function periodForType(type: ReportType, reference = new Date()): ReportPeriod {
  const to = new Date(reference);
  to.setHours(23, 59, 59, 999);
  const from = new Date(reference);
  if (type === "daily") {
    from.setHours(0, 0, 0, 0);
    return { from, to, label: to.toISOString().split("T")[0] };
  }
  if (type === "weekly") {
    from.setDate(from.getDate() - 6); from.setHours(0, 0, 0, 0);
    return { from, to, label: `${from.toISOString().split("T")[0]} – ${to.toISOString().split("T")[0]}` };
  }
  if (type === "monthly") {
    from.setDate(1); from.setHours(0, 0, 0, 0);
    return { from, to, label: to.toLocaleString("en-US", { month: "long", year: "numeric" }) };
  }
  // executive_summary, incident_report, compliance_report, rule_optimization_report → last 30 days
  from.setDate(from.getDate() - 29); from.setHours(0, 0, 0, 0);
  return { from, to, label: `${from.toISOString().split("T")[0]} – ${to.toISOString().split("T")[0]}` };
}

export async function buildReportContent(
  orgId: string,
  type: ReportType,
  period: ReportPeriod,
): Promise<Record<string, unknown>> {
  const w = and(eq(alertsTable.organizationId, orgId), gte(alertsTable.timestamp, period.from), lte(alertsTable.timestamp, period.to));

  /* ── Core alert metrics (used by most report types) ── */
  const alertMetrics = await db.select({
    total:          sql<number>`count(*)::int`,
    critical:       sql<number>`count(*) filter (where severity = 'critical')::int`,
    high:           sql<number>`count(*) filter (where severity = 'high')::int`,
    medium:         sql<number>`count(*) filter (where severity = 'medium')::int`,
    low:            sql<number>`count(*) filter (where severity = 'low')::int`,
    falsePositives: sql<number>`count(*) filter (where false_positive = true)::int`,
    resolved:       sql<number>`count(*) filter (where status = 'resolved')::int`,
    acknowledged:   sql<number>`count(*) filter (where status = 'acknowledged')::int`,
  }).from(alertsTable).where(w);

  const a = alertMetrics[0] ?? { total: 0, critical: 0, high: 0, medium: 0, low: 0, falsePositives: 0, resolved: 0, acknowledged: 0 };
  const fpPct = a.total > 0 ? +((a.falsePositives / a.total) * 100).toFixed(1) : 0;

  /* ── Alert trend (day by day) ── */
  const dailyAlerts = await db.select({
    date:     sql<string>`date_trunc('day', timestamp)::date::text`,
    critical: sql<number>`count(*) filter (where severity = 'critical')::int`,
    high:     sql<number>`count(*) filter (where severity = 'high')::int`,
    medium:   sql<number>`count(*) filter (where severity = 'medium')::int`,
    low:      sql<number>`count(*) filter (where severity = 'low')::int`,
    total:    sql<number>`count(*)::int`,
  }).from(alertsTable).where(w).groupBy(sql`date_trunc('day', timestamp)`).orderBy(sql`date_trunc('day', timestamp)`);

  /* ── Top noisy rules ── */
  const topRules = await db.select({
    ruleName:       alertsTable.ruleName,
    ruleId:         alertsTable.ruleId,
    total:          sql<number>`count(*)::int`,
    falsePositives: sql<number>`count(*) filter (where false_positive = true)::int`,
  }).from(alertsTable).where(w)
    .groupBy(alertsTable.ruleName, alertsTable.ruleId)
    .orderBy(desc(sql`count(*)`)).limit(10);

  /* ── MITRE technique breakdown ── */
  const mitreBreakdown = await db.select({
    techniqueId: alertsTable.mitreTechniqueId,
    technique:   alertsTable.mitreTechnique,
    tactic:      alertsTable.mitreTactic,
    count:       sql<number>`count(*)::int`,
  }).from(alertsTable).where(and(w, isNotNull(alertsTable.mitreTechniqueId)))
    .groupBy(alertsTable.mitreTechniqueId, alertsTable.mitreTechnique, alertsTable.mitreTactic)
    .orderBy(desc(sql`count(*)`)).limit(15);

  /* ── Incident metrics ── */
  const iw = and(
    eq(incidentsTable.organizationId, orgId),
    gte(incidentsTable.createdAt, period.from),
    lte(incidentsTable.createdAt, period.to),
  );
  const incidentMetrics = await db.select({
    total:    sql<number>`count(*)::int`,
    open:     sql<number>`count(*) filter (where status = 'open')::int`,
    resolved: sql<number>`count(*) filter (where status = 'resolved' or status = 'closed')::int`,
    critical: sql<number>`count(*) filter (where priority = 'critical')::int`,
    high:     sql<number>`count(*) filter (where priority = 'high')::int`,
  }).from(incidentsTable).where(iw);
  const im = incidentMetrics[0] ?? { total: 0, open: 0, resolved: 0, critical: 0, high: 0 };

  const mttrRow = await db.select({
    mttrHours: sql<number>`avg(extract(epoch from (resolved_at - created_at)) / 3600.0)::real`,
  }).from(incidentsTable).where(and(iw, isNotNull(incidentsTable.resolvedAt)));
  const mttrHours = mttrRow[0]?.mttrHours != null ? +mttrRow[0].mttrHours.toFixed(1) : null;

  const recentIncidents = await db.select({
    id: incidentsTable.id,
    incidentSeq: incidentsTable.incidentSeq,
    title: incidentsTable.title,
    priority: incidentsTable.priority,
    status: incidentsTable.status,
    assigneeName: incidentsTable.assigneeName,
    resolutionSummary: incidentsTable.resolutionSummary,
    createdAt: incidentsTable.createdAt,
    resolvedAt: incidentsTable.resolvedAt,
  }).from(incidentsTable).where(iw).orderBy(desc(incidentsTable.createdAt)).limit(20);

  /* ── AI analysis metrics ── */
  const aiMetrics = await db.select({
    total:    sql<number>`count(*)::int`,
    approved: sql<number>`count(*) filter (where review_status = 'approved')::int`,
    rejected: sql<number>`count(*) filter (where review_status = 'rejected')::int`,
    pending:  sql<number>`count(*) filter (where review_status = 'pending_review')::int`,
    avgConf:  sql<number>`avg(confidence_score)::real`,
    avgFpProb: sql<number>`avg(false_positive_probability)::real`,
  }).from(alertAnalysesTable).where(eq(alertAnalysesTable.organizationId, orgId));
  const ai = aiMetrics[0] ?? { total: 0, approved: 0, rejected: 0, pending: 0, avgConf: 0, avgFpProb: 0 };

  /* ── Vulnerability metrics ── */
  const vulnMetrics = await db.select({
    total:    sql<number>`count(*)::int`,
    critical: sql<number>`count(*) filter (where severity = 'critical')::int`,
    high:     sql<number>`count(*) filter (where severity = 'high')::int`,
    open:     sql<number>`count(*) filter (where status = 'open')::int`,
  }).from(vulnerabilitiesTable).where(eq(vulnerabilitiesTable.organizationId, orgId));
  const vm = vulnMetrics[0] ?? { total: 0, critical: 0, high: 0, open: 0 };

  /* ── Rule tuning ── */
  const [latestTuning] = await db.select().from(ruleTuningRecommendationsTable)
    .where(eq(ruleTuningRecommendationsTable.organizationId, orgId))
    .orderBy(desc(ruleTuningRecommendationsTable.jobRunAt)).limit(1);
  const tuningRecs = latestTuning
    ? (JSON.parse(latestTuning.recommendations) as any[]).filter((r: any) => r.action !== "keep").slice(0, 10)
    : [];

  /* ── IOC summary ── */
  const iocStats = await db.select({
    total:     sql<number>`count(*)::int`,
    malicious: sql<number>`count(*) filter (where verdict = 'malicious')::int`,
    suspicious: sql<number>`count(*) filter (where verdict = 'suspicious')::int`,
  }).from(iocEnrichmentsTable).where(eq(iocEnrichmentsTable.organizationId, orgId));
  const ioc = iocStats[0] ?? { total: 0, malicious: 0, suspicious: 0 };

  /* ── Agent health ── */
  const agentStats = await db.select({
    total: sql<number>`count(*)::int`,
    offline: sql<number>`count(*) filter (where status = 'disconnected')::int`,
  }).from(wazuhAgentsTable).where(eq(wazuhAgentsTable.organizationId, orgId));
  const ag = agentStats[0] ?? { total: 0, offline: 0 };

  /* ── Compliance score (heuristic) ── */
  const complianceScore = Math.max(0, Math.min(100,
    100 - (fpPct * 0.5) - (ai.pending * 2) - (a.critical > 0 ? 10 : 0) - (vm.critical > 0 ? 10 : 0)
  ));

  /* ── Assemble content ── */
  const base = {
    generatedAt: new Date().toISOString(),
    period: { from: period.from.toISOString(), to: period.to.toISOString(), label: period.label },
    alerts: { ...a, fpPct, dailyTrend: dailyAlerts },
    topRules: topRules.map((r) => ({
      ...r,
      fpRate: r.total > 0 ? +((r.falsePositives / r.total) * 100).toFixed(1) : 0,
    })),
    mitre: mitreBreakdown,
    incidents: {
      ...im, mttrHours,
      list: recentIncidents.map((i) => ({
        ...i,
        incidentNumber: `INC-${1000 + i.incidentSeq}`,
        createdAt: i.createdAt.toISOString(),
        resolvedAt: i.resolvedAt?.toISOString() ?? null,
      })),
    },
    ai: { ...ai, avgConfPct: ai.avgConf != null ? +(ai.avgConf * 100).toFixed(1) : null, avgFpProbPct: ai.avgFpProb != null ? +(ai.avgFpProb * 100).toFixed(1) : null },
    vulnerabilities: vm,
    agents: ag,
    ioc,
    complianceScore: Math.round(complianceScore),
    ruleOptimization: {
      jobRunAt: latestTuning?.jobRunAt?.toISOString() ?? null,
      totalRulesAnalyzed: latestTuning?.totalRulesAnalyzed ?? 0,
      recommendations: tuningRecs,
    },
  };

  // Type-specific extras
  if (type === "incident_report") {
    return { ...base, focus: "incidents", summary: `${im.total} incidents opened in this period. ${im.resolved} resolved. MTTR: ${mttrHours != null ? `${mttrHours}h` : "N/A"}.` };
  }
  if (type === "compliance_report") {
    const controls = [
      { control: "Alert triage within SLA",      status: fpPct < 20 ? "pass" : "warn",  detail: `FP rate: ${fpPct}%` },
      { control: "AI reviews actioned",           status: ai.pending === 0 ? "pass" : "warn", detail: `${ai.pending} pending reviews` },
      { control: "Critical alerts resolved",      status: a.critical === 0 ? "pass" : "fail", detail: `${a.critical} open critical alerts` },
      { control: "Critical vulnerabilities",      status: vm.critical === 0 ? "pass" : "fail", detail: `${vm.critical} open critical vulns` },
      { control: "Agent connectivity",            status: ag.offline === 0 ? "pass" : "warn", detail: `${ag.offline} offline agents` },
      { control: "Incident management",           status: im.open < 5 ? "pass" : "warn", detail: `${im.open} open incidents` },
    ];
    return { ...base, complianceControls: controls };
  }
  if (type === "rule_optimization_report") {
    return { ...base, focus: "rules", allRecommendations: tuningRecs };
  }
  return base;
}

/* ── CSV serialisation ── */
export function contentToCsvRows(type: ReportType, content: Record<string, unknown>): { filename: string; rows: string[][] }[] {
  const files: { filename: string; rows: string[][] }[] = [];
  const alerts = content.alerts as any;
  const incidents = content.incidents as any;

  files.push({
    filename: "summary.csv",
    rows: [
      ["Metric", "Value"],
      ["Period", (content.period as any).label],
      ["Total Alerts", String(alerts.total)],
      ["Critical Alerts", String(alerts.critical)],
      ["High Alerts", String(alerts.high)],
      ["False Positive %", String(alerts.fpPct)],
      ["Total Incidents", String(incidents.total)],
      ["Incidents Resolved", String(incidents.resolved)],
      ["MTTR (hours)", String(incidents.mttrHours ?? "N/A")],
      ["Compliance Score", String((content as any).complianceScore)],
    ],
  });

  const topRules = (content.topRules as any[]) ?? [];
  if (topRules.length) {
    files.push({
      filename: "top_rules.csv",
      rows: [
        ["Rule ID", "Rule Name", "Total Alerts", "False Positives", "FP Rate %"],
        ...topRules.map((r: any) => [r.ruleId, r.ruleName, String(r.total), String(r.falsePositives), String(r.fpRate)]),
      ],
    });
  }

  if (incidents.list?.length) {
    files.push({
      filename: "incidents.csv",
      rows: [
        ["Incident #", "Title", "Priority", "Status", "Assigned To", "Created", "Resolved", "Resolution Summary"],
        ...incidents.list.map((i: any) => [
          i.incidentNumber, i.title, i.priority, i.status,
          i.assigneeName ?? "", i.createdAt, i.resolvedAt ?? "", i.resolutionSummary ?? "",
        ]),
      ],
    });
  }

  const mitre = (content.mitre as any[]) ?? [];
  if (mitre.length) {
    files.push({
      filename: "mitre_techniques.csv",
      rows: [
        ["Technique ID", "Technique", "Tactic", "Alert Count"],
        ...mitre.map((r: any) => [r.techniqueId ?? "", r.technique ?? "", r.tactic ?? "", String(r.count)]),
      ],
    });
  }

  if (type === "compliance_report") {
    const controls = (content.complianceControls as any[]) ?? [];
    files.push({
      filename: "compliance_controls.csv",
      rows: [
        ["Control", "Status", "Detail"],
        ...controls.map((c: any) => [c.control, c.status, c.detail]),
      ],
    });
  }

  const dailyTrend = alerts.dailyTrend ?? [];
  if (dailyTrend.length) {
    files.push({
      filename: "daily_trend.csv",
      rows: [
        ["Date", "Critical", "High", "Medium", "Low", "Total"],
        ...dailyTrend.map((d: any) => [d.date, String(d.critical), String(d.high), String(d.medium), String(d.low), String(d.total)]),
      ],
    });
  }

  return files;
}

export function rowsToCsvString(rows: string[][]): string {
  return rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");
}
