import { db } from "@workspace/db";
import {
  wazuhConnectionsTable, alertsTable, wazuhAgentsTable,
  vulnerabilitiesTable, fimEventsTable,
} from "@workspace/db";
import { eq, and, inArray, sql } from "drizzle-orm";
import {
  authenticate, fetchAgents, fetchAlerts, fetchRules, fetchMitreTechniques,
  fetchVulnerabilities, fetchFimEvents, fetchManagerInfo, clearTokenCache,
  WazuhApiError,
} from "./wazuhClient";

/* ─── Severity mapping ─────────────────────────────────────────────────── */
function levelToSeverity(level: number): "low" | "medium" | "high" | "critical" {
  if (level >= 12) return "critical";
  if (level >= 8) return "high";
  if (level >= 4) return "medium";
  return "low";
}

function vulnSeverityMap(s: string): "low" | "medium" | "high" | "critical" {
  const lower = s?.toLowerCase() ?? "";
  if (lower === "critical") return "critical";
  if (lower === "high") return "high";
  if (lower === "medium") return "medium";
  return "low";
}

/* ─── Sync result ──────────────────────────────────────────────────────── */
export interface SyncResult {
  connectionId: string;
  alertsSynced: number;
  agentsSynced: number;
  vulnerabilitiesSynced: number;
  fimEventsSynced: number;
  rulesSynced: number;
  mitreTechniquesSynced: number;
  managerInfo: Record<string, unknown> | null;
  errors: string[];
  durationMs: number;
}

/* ─── Main sync orchestrator ────────────────────────────────────────────── */
export async function syncWazuhConnection(connectionId: string): Promise<SyncResult> {
  const t0 = Date.now();
  const result: SyncResult = {
    connectionId, alertsSynced: 0, agentsSynced: 0, vulnerabilitiesSynced: 0,
    fimEventsSynced: 0, rulesSynced: 0, mitreTechniquesSynced: 0, managerInfo: null, errors: [],
  };

  const [conn] = await db.select().from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.id, connectionId));
  if (!conn) throw new Error("Connection not found");

  const orgId = conn.organizationId;
  const { apiUrl, username, passwordHash: password } = conn;

  // ── Authenticate ────────────────────────────────────────────────────────
  let token: string;
  try {
    token = await authenticate(apiUrl, username, password);
    await db.update(wazuhConnectionsTable).set({ status: "connected" }).where(eq(wazuhConnectionsTable.id, connectionId));
  } catch (err: any) {
    const msg = err instanceof WazuhApiError ? err.message : "Authentication failed";
    await db.update(wazuhConnectionsTable).set({ status: "error", lastSyncStatus: "failed", lastErrorAt: new Date(), lastErrorMessage: msg }).where(eq(wazuhConnectionsTable.id, connectionId));
    throw err;
  }

  // ── Manager info ────────────────────────────────────────────────────────
  try {
    result.managerInfo = await fetchManagerInfo(apiUrl, token) as unknown as Record<string, unknown>;
  } catch (err: any) { result.errors.push(`Manager info: ${err.message}`); }

  // ── Agent Status ─────────────────────────────────────────────────────────
  if (conn.syncAgents !== false) {
    try {
      const agents = await fetchAgents(apiUrl, token);
      for (const agent of agents) {
        const os = [agent.os?.name, agent.os?.version, agent.os?.arch].filter(Boolean).join(" ") || "Unknown";
        await db.insert(wazuhAgentsTable).values({
          id: agent.id,
          organizationId: orgId,
          connectionId,
          name: agent.name,
          status: agent.status,
          os,
          ip: agent.ip ?? "0.0.0.0",
          version: agent.version ?? "unknown",
          groups: agent.groups ?? agent.group ?? [],
          lastKeepAlive: agent.lastKeepAlive ? new Date(agent.lastKeepAlive) : new Date(),
        }).onConflictDoUpdate({
          target: wazuhAgentsTable.id,
          set: { name: agent.name, status: agent.status, os, ip: agent.ip ?? "0.0.0.0", version: agent.version ?? "unknown", groups: agent.groups ?? agent.group ?? [], lastKeepAlive: agent.lastKeepAlive ? new Date(agent.lastKeepAlive) : new Date(), updatedAt: new Date() },
        });
      }
      result.agentsSynced = agents.length;
      await db.update(wazuhConnectionsTable).set({ agentCount: agents.length }).where(eq(wazuhConnectionsTable.id, connectionId));
    } catch (err: any) { result.errors.push(`Agents: ${err.message}`); }
  }

  // ── Rule Metadata + MITRE Mapping ────────────────────────────────────────
  // Rules are fetched to populate MITRE metadata used during alert normalisation.
  // We build an in-memory lookup for the alert sync below.
  const ruleMetaMap = new Map<string, { mitreTactic?: string; mitreTechnique?: string; mitreTechniqueId?: string }>();
  try {
    const rules = await fetchRules(apiUrl, token);
    result.rulesSynced = rules.length;
    for (const rule of rules) {
      const mitre = rule.details?.mitre;
      if (mitre) {
        ruleMetaMap.set(String(rule.id), {
          mitreTechniqueId: mitre.id?.[0],
          mitreTactic: mitre.tactic?.[0],
          mitreTechnique: mitre.technique?.[0],
        });
      }
    }
  } catch (err: any) { result.errors.push(`Rules: ${err.message}`); }

  try {
    const techniques = await fetchMitreTechniques(apiUrl, token);
    result.mitreTechniquesSynced = techniques.length;
  } catch (err: any) { result.errors.push(`MITRE techniques: ${err.message}`); }

  // ── Live Alerts ──────────────────────────────────────────────────────────
  if (conn.syncAlerts !== false) {
    try {
      const rawAlerts = await fetchAlerts(apiUrl, token, { limit: 200, minLevel: 3 });
      const toInsert = rawAlerts.map((a) => {
        const src = a._source;
        const ruleId = src.rule?.id ?? "unknown";
        const ruleMeta = ruleMetaMap.get(String(ruleId)) ?? {};
        return {
          id: a._id,
          organizationId: orgId,
          connectionId,
          ruleId: String(ruleId),
          ruleName: src.rule?.description ?? "Unknown rule",
          ruleLevel: src.rule?.level ?? 0,
          severity: levelToSeverity(src.rule?.level ?? 0),
          description: src.full_log ?? src.rule?.description ?? "No description",
          agentId: src.agent?.id ?? "000",
          agentName: src.agent?.name ?? "manager",
          agentIp: src.agent?.ip ?? null,
          sourceIp: (src.data as any)?.srcip ?? null,
          status: "new" as const,
          mitreTactic: ruleMeta.mitreTactic ?? src.rule?.mitre?.tactic?.[0] ?? null,
          mitreTechnique: ruleMeta.mitreTechnique ?? src.rule?.mitre?.technique?.[0] ?? null,
          mitreTechniqueId: ruleMeta.mitreTechniqueId ?? src.rule?.mitre?.id?.[0] ?? null,
          rawLog: JSON.stringify(src),
          timestamp: src.timestamp ? new Date(src.timestamp) : new Date(),
        };
      });

      for (const alert of toInsert) {
        await db.insert(alertsTable).values(alert).onConflictDoNothing();
      }
      result.alertsSynced = toInsert.length;
    } catch (err: any) { result.errors.push(`Alerts: ${err.message}`); }
  }

  // ── Vulnerability Data ────────────────────────────────────────────────────
  if (conn.syncVulnerabilities !== false) {
    try {
      const agents = await db.select({ id: wazuhAgentsTable.id }).from(wazuhAgentsTable)
        .where(and(eq(wazuhAgentsTable.organizationId, orgId), eq(wazuhAgentsTable.connectionId, connectionId)));

      for (const agent of agents.slice(0, 20)) { // cap at 20 agents per sync to stay within rate limits
        try {
          const vulns = await fetchVulnerabilities(apiUrl, token, agent.id);
          for (const v of vulns) {
            await db.insert(vulnerabilitiesTable).values({
              organizationId: orgId,
              agentId: agent.id,
              cve: v.cve,
              name: v.name,
              version: v.version,
              severity: vulnSeverityMap(v.severity),
              cvss3Score: v.cvss3_score?.toString(),
              status: v.status === "Active" ? "open" : "resolved",
            }).onConflictDoNothing().catch(() => {}); // ignore duplicate CVE+agent
          }
          result.vulnerabilitiesSynced += vulns.length;
        } catch { /* individual agent failure — continue */ }
      }
    } catch (err: any) { result.errors.push(`Vulnerabilities: ${err.message}`); }
  }

  // ── FIM Events ────────────────────────────────────────────────────────────
  if (conn.syncFim !== false) {
    try {
      const agents = await db.select({ id: wazuhAgentsTable.id, name: wazuhAgentsTable.name }).from(wazuhAgentsTable)
        .where(and(eq(wazuhAgentsTable.organizationId, orgId), eq(wazuhAgentsTable.connectionId, connectionId)));

      for (const agent of agents.slice(0, 10)) {
        try {
          const events = await fetchFimEvents(apiUrl, token, agent.id, 50);
          for (const ev of events) {
            await db.insert(fimEventsTable).values({
              organizationId: orgId,
              connectionId,
              agentId: agent.id,
              agentName: agent.name,
              type: ev.type ?? "modified",
              path: ev.file ?? "unknown",
              mode: ev.attributes?.mode ?? null,
              md5Before: ev.old_attributes?.hash_md5 ?? null,
              md5After: ev.attributes?.hash_md5 ?? null,
              sha256Before: ev.old_attributes?.hash_sha256 ?? null,
              sha256After: ev.attributes?.hash_sha256 ?? null,
              permissionsBefore: ev.old_attributes?.perm ?? null,
              permissionsAfter: ev.attributes?.perm ?? null,
              ownerBefore: ev.old_attributes?.uid ?? null,
              ownerAfter: ev.attributes?.uid ?? null,
              sizeBefore: ev.old_attributes?.size?.toString() ?? null,
              sizeAfter: ev.attributes?.size?.toString() ?? null,
              eventTimestamp: ev.timestamp ? new Date(ev.timestamp) : new Date(),
            }).onConflictDoNothing().catch(() => {});
          }
          result.fimEventsSynced += events.length;
        } catch { /* continue on per-agent failure */ }
      }
    } catch (err: any) { result.errors.push(`FIM: ${err.message}`); }
  }

  // ── Finalise ──────────────────────────────────────────────────────────────
  result.durationMs = Date.now() - t0;
  await db.update(wazuhConnectionsTable).set({
    lastSyncAt: new Date(),
    lastSyncStatus: result.errors.length === 0 ? "success" : "partial",
    ...(result.errors.length > 0 ? { lastErrorMessage: result.errors.join("; ") } : {}),
  }).where(eq(wazuhConnectionsTable.id, connectionId));

  return result;
}
