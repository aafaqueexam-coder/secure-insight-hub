/**
 * Redis cache layer.
 *
 * When REDIS_URL is set the platform uses Redis for:
 *   - API response caching (dashboard, alert list, compliance assessments)
 *   - AI analysis queue deduplication
 *   - Session/rate-limit state
 *
 * When REDIS_URL is not set everything degrades gracefully to a no-op
 * (requests fall through to the DB) — Redis is an enhancement, not a
 * hard dependency.
 *
 * Dependencies: ioredis (optional — installed separately)
 *   pnpm --filter @workspace/api-server add ioredis
 */

import { logger } from "./logger";

interface RedisLike {
  get(key: string): Promise<string | null>;
  set(key: string, value: string, ex: "EX", ttl: number): Promise<unknown>;
  del(key: string): Promise<unknown>;
  keys(pattern: string): Promise<string[]>;
  ping(): Promise<string>;
  quit(): Promise<unknown>;
}

let _client: RedisLike | null = null;
let _connected = false;

async function getClient(): Promise<RedisLike | null> {
  if (_client) return _client;
  const url = process.env.REDIS_URL;
  if (!url) return null;

  try {
    const { default: Redis } = await import("ioredis");
    const client = new Redis(url, { lazyConnect: true, enableOfflineQueue: false, maxRetriesPerRequest: 1 });
    await client.connect();
    _client = client as unknown as RedisLike;
    _connected = true;
    logger.info("Redis connected");
    return _client;
  } catch (err) {
    logger.warn({ err }, "Redis unavailable — caching disabled");
    return null;
  }
}

const DEFAULT_TTL_SECONDS = 60; // 1 minute default

export function isRedisAvailable(): boolean { return _connected; }

/** Get a cached value. Returns null on miss or Redis unavailable. */
export async function cacheGet<T = unknown>(key: string): Promise<T | null> {
  try {
    const client = await getClient();
    if (!client) return null;
    const raw = await client.get(key);
    if (!raw) return null;
    return JSON.parse(raw) as T;
  } catch { return null; }
}

/** Set a cached value. No-op if Redis unavailable. */
export async function cacheSet(key: string, value: unknown, ttlSeconds = DEFAULT_TTL_SECONDS): Promise<void> {
  try {
    const client = await getClient();
    if (!client) return;
    await client.set(key, JSON.stringify(value), "EX", ttlSeconds);
  } catch { /* non-fatal */ }
}

/** Delete a cached key. */
export async function cacheDel(key: string): Promise<void> {
  try {
    const client = await getClient();
    if (!client) return;
    await client.del(key);
  } catch { /* non-fatal */ }
}

/** Invalidate all keys matching a glob pattern. */
export async function cacheFlushPattern(pattern: string): Promise<void> {
  try {
    const client = await getClient();
    if (!client) return;
    const keys = await client.keys(pattern);
    await Promise.all(keys.map((k) => client.del(k)));
  } catch { /* non-fatal */ }
}

/** Wrap a DB/compute function with a cache-aside pattern. */
export async function withCache<T>(
  key: string,
  fn: () => Promise<T>,
  ttlSeconds = DEFAULT_TTL_SECONDS,
): Promise<T> {
  const cached = await cacheGet<T>(key);
  if (cached !== null) return cached;
  const result = await fn();
  await cacheSet(key, result, ttlSeconds);
  return result;
}

/** Cache TTL constants (seconds) for common resource types. */
export const TTL = {
  DASHBOARD: 30,          // high-churn metrics
  ALERT_LIST: 15,         // paginated alert feed
  COMPLIANCE: 120,        // compliance assessment (expensive query)
  RULE_TUNING: 300,       // rule tuning results
  MITRE_HEATMAP: 60,      // aggregated MITRE data
  THREAT_INTEL: 3600,     // IOC enrichment (already has own DB cache)
  AGENT_LIST: 30,         // agent status
  REPORT_CONTENT: 600,    // generated report content
} as const;
