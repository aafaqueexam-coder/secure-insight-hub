/**
 * AI Analysis Job Queue
 *
 * Lightweight in-process queue built on node-cron + a simple async queue.
 * When REDIS_URL is set, deduplication keys are stored in Redis so
 * duplicate enqueue calls across restarts are also deduplicated.
 * Without Redis, deduplication is in-memory only.
 *
 * Features:
 *   - Concurrency limit (default: 3 parallel AI calls)
 *   - Per-alert deduplication — won't queue an alert already being analysed
 *   - Exponential backoff retry (3 attempts, handled by runAlertPipeline)
 *   - Graceful drain on process shutdown
 *   - Queue depth, in-flight, and completed metrics
 */

import { db } from "@workspace/db";
import { alertsTable, alertAnalysesTable, alertAuditLogTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "../lib/logger";
import { runAlertPipeline, PROMPT_VERSION, AI_MODEL } from "./aiPipeline";
import { cacheGet, cacheSet, cacheDel, cacheFlushPattern } from "./cache";
import { audit } from "./auditWriter";

/* ─── Types ─────────────────────────────────────────────────────────────── */

interface QueueJob {
  alertId: string;
  organizationId: string;
  enqueuedAt: number;
  attempts: number;
}

/* ─── State ──────────────────────────────────────────────────────────────── */

const CONCURRENCY = parseInt(process.env.AI_QUEUE_CONCURRENCY ?? "3");
const queue: QueueJob[] = [];
const inflight = new Set<string>();
const dedupKeys = new Set<string>(); // in-memory dedup (Redis supplements this)

const metrics = { enqueued: 0, completed: 0, failed: 0, cacheHits: 0 };

/* ─── Deduplication ──────────────────────────────────────────────────────── */

const DEDUP_TTL = 300; // 5 min — how long to suppress duplicate enqueues

async function isDuplicate(alertId: string): Promise<boolean> {
  if (dedupKeys.has(alertId)) return true;
  const redisKey = `ai:queue:dedup:${alertId}`;
  return !!(await cacheGet(redisKey));
}

async function markDuplicate(alertId: string): Promise<void> {
  dedupKeys.add(alertId);
  await cacheSet(`ai:queue:dedup:${alertId}`, 1, DEDUP_TTL);
}

async function clearDuplicate(alertId: string): Promise<void> {
  dedupKeys.delete(alertId);
  await cacheDel(`ai:queue:dedup:${alertId}`);
}

/* ─── Worker ─────────────────────────────────────────────────────────────── */

async function processJob(job: QueueJob): Promise<void> {
  inflight.add(job.alertId);
  const t0 = Date.now();
  try {
    const [alert] = await db.select().from(alertsTable).where(eq(alertsTable.id, job.alertId));
    if (!alert) { logger.warn({ alertId: job.alertId }, "AI queue: alert not found, skipping"); return; }

    const result = await runAlertPipeline(alert);

    await db.delete(alertAnalysesTable).where(eq(alertAnalysesTable.alertId, job.alertId));
    await db.insert(alertAnalysesTable).values({
      alertId: job.alertId,
      organizationId: job.organizationId,
      summary: result.summary,
      threatDescription: result.threatDescription,
      businessImpact: result.businessImpact,
      investigationSteps: result.investigationSteps,
      affectedAssets: result.affectedAssets,
      executiveSummary: result.executiveSummary,
      confidenceScore: result.confidenceScore,
      reasoning: result.reasoning,
      rootCause: result.rootCause,
      mitreExplanation: result.mitreExplanation,
      falsePositiveProbability: result.falsePositiveProbability,
      evidence: result.evidence,
      iocs: result.iocs,
      investigationChecklist: result.investigationChecklist,
      remediationPlan: result.remediationPlan,
      recommendedActions: result.recommendedActions,
      containmentActions: result.containmentActions,
      analystNotes: result.analystNotes,
      severity: alert.severity,
      redactedFields: result.redactedFields,
      reviewStatus: "pending_review",
      aiModelUsed: result.aiModelUsed,
      promptVersion: result.promptVersion,
      promptTokens: result.promptTokens,
      completionTokens: result.completionTokens,
      totalTokens: result.totalTokens,
      retryCount: result.retryCount,
      pipelineDurationMs: result.pipelineDurationMs,
      fromCache: result.fromCache,
      generatedAt: new Date(),
    });

    if (result.fromCache) metrics.cacheHits++;
    metrics.completed++;

    // Invalidate the alert's cached analysis
    await cacheFlushPattern(`alert:analysis:${job.alertId}*`);

    await audit({
      actorId: "system", actorName: "AI Queue", actorRole: "system",
      organizationId: job.organizationId,
      eventType: "ai.analysis.generated",
      summary: `[Queue] AI analysis generated for alert "${alert.ruleName}"`,
      resourceType: "alert", resourceId: alert.id, resourceName: alert.ruleName,
      details: { aiModel: result.aiModelUsed, promptVersion: result.promptVersion, totalTokens: result.totalTokens, fromCache: result.fromCache, durationMs: Date.now() - t0, queuedFor: Date.now() - job.enqueuedAt },
    });

    logger.info({ alertId: job.alertId, durationMs: Date.now() - t0, fromCache: result.fromCache }, "AI queue: analysis complete");
  } catch (err) {
    metrics.failed++;
    logger.error({ err, alertId: job.alertId, attempt: job.attempts }, "AI queue: job failed");
  } finally {
    inflight.delete(job.alertId);
    await clearDuplicate(job.alertId);
    // Kick off next job
    setImmediate(drain);
  }
}

/* ─── Drain loop ─────────────────────────────────────────────────────────── */

function drain(): void {
  while (inflight.size < CONCURRENCY && queue.length > 0) {
    const job = queue.shift()!;
    processJob(job);
  }
}

/* ─── Public API ─────────────────────────────────────────────────────────── */

/** Enqueue an alert for AI analysis. Returns false if already queued/in-flight. */
export async function enqueueAnalysis(alertId: string, organizationId: string): Promise<boolean> {
  if (inflight.has(alertId)) return false;
  if (await isDuplicate(alertId)) return false;

  await markDuplicate(alertId);
  queue.push({ alertId, organizationId, enqueuedAt: Date.now(), attempts: 0 });
  metrics.enqueued++;
  logger.debug({ alertId }, "AI queue: enqueued");
  setImmediate(drain);
  return true;
}

/** Enqueue all unanalysed critical/high alerts for the given org. */
export async function enqueuePendingAlerts(orgId: string): Promise<number> {
  const { and, eq: deq, isNull, inArray } = await import("drizzle-orm");

  // Alerts without any analysis
  const analysedIds = (await db.select({ alertId: alertAnalysesTable.alertId }).from(alertAnalysesTable).where(deq(alertAnalysesTable.organizationId, orgId))).map((r) => r.alertId);
  const conditions = [deq(alertsTable.organizationId, orgId), deq(alertsTable.status, "new"), inArray(alertsTable.severity, ["critical", "high"])];

  const unanalysed = await db.select({ id: alertsTable.id, organizationId: alertsTable.organizationId })
    .from(alertsTable).where(and(...conditions)).limit(50);

  let queued = 0;
  for (const a of unanalysed) {
    if (analysedIds.includes(a.id)) continue;
    if (await enqueueAnalysis(a.id, a.organizationId)) queued++;
  }
  return queued;
}

/** Queue depth and in-flight count for health/monitoring. */
export function queueStats() {
  return { depth: queue.length, inflight: inflight.size, concurrency: CONCURRENCY, ...metrics };
}

/** Graceful shutdown — wait for in-flight jobs (max 30s). */
export async function drainQueue(timeoutMs = 30000): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (inflight.size > 0 && Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 200));
  }
  if (inflight.size > 0) logger.warn({ inflight: inflight.size }, "AI queue: shutdown with in-flight jobs");
}
