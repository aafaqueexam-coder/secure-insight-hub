import { db } from "@workspace/db";
import {
  alertsTable, incidentsTable, alertAnalysesTable, vulnerabilitiesTable,
  wazuhAgentsTable, iocEnrichmentsTable, ruleTuningRecommendationsTable,
} from "@workspace/db";
import { and, desc, eq, gt, isNotNull, sql } from "drizzle-orm";
import { FRAMEWORK_CATALOG, ALL_FRAMEWORKS, type ControlDefinition } from "./complianceCatalogs";

export type ControlStatus = "passed" | "partial" | "failed" | "not_applicable";

export interface EvaluatedControl {
  id: string;
  name: string;
  description: string;
  category: string;
  requirement: string;
  status: ControlStatus;
  score: number; // 0-100
  evidence: string;          // human-readable summary of what the engine found
  evidenceData: Record<string, unknown>; // raw numbers for display
  recommendation: string;
  remediationSteps: string[];
  evidenceHints: string[];
  weight: number;
}

export interface FrameworkAssessment {
  id: string;
  name: string;
  shortName: string;
  version: string;
  description: string;
  score: number;
  status: string;
  controlsTotal: number;
  controlsPassed: number;
  controlsFailed: number;
  controlsPartial: number;
  controls: EvaluatedControl[];
  lastAssessedAt: string;
}

/* ─── Live-data snapshot (fetched once, shared across all control evaluations) ─── */
interface DataSnapshot {
  totalAlerts: number;
  criticalAlerts: number;
  falsePositives: number;
  acknowledgedAlerts: number;
  resolvedAlerts: number;
  mitreMappedAlerts: number;
  totalIncidents: number;
  resolvedIncidents: number;
  openIncidents: number;
  mttrHours: number | null;
  pendingAiReviews: number;
  totalAgents: number;
  offlineAgents: number;
  openCriticalVulns: number;
  totalIocEnrichments: number;
  lastRuleTuningDays: number | null; // days since last job, null = never
}

async function getDataSnapshot(orgId: string): Promise<DataSnapshot> {
  const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000);

  const [alertStats, incidentStats, agentStats, vulnStats, aiStats, iocStats, tuningStats, mttrRow] = await Promise.all([
    db.select({
      total: sql<number>`count(*)::int`,
      critical: sql<number>`count(*) filter (where severity = 'critical')::int`,
      fp: sql<number>`count(*) filter (where false_positive = true)::int`,
      ack: sql<number>`count(*) filter (where status = 'acknowledged')::int`,
      resolved: sql<number>`count(*) filter (where status = 'resolved')::int`,
      mitreMapped: sql<number>`count(*) filter (where mitre_technique_id is not null)::int`,
    }).from(alertsTable).where(and(eq(alertsTable.organizationId, orgId), gt(alertsTable.timestamp, thirtyDaysAgo))),

    db.select({
      total: sql<number>`count(*)::int`,
      resolved: sql<number>`count(*) filter (where status = 'resolved' or status = 'closed')::int`,
      open: sql<number>`count(*) filter (where status = 'open' or status = 'assigned' or status = 'investigating')::int`,
    }).from(incidentsTable).where(eq(incidentsTable.organizationId, orgId)),

    db.select({
      total: sql<number>`count(*)::int`,
      offline: sql<number>`count(*) filter (where status = 'disconnected')::int`,
    }).from(wazuhAgentsTable).where(eq(wazuhAgentsTable.organizationId, orgId)),

    db.select({
      criticalOpen: sql<number>`count(*) filter (where severity = 'critical' and status = 'open')::int`,
    }).from(vulnerabilitiesTable).where(eq(vulnerabilitiesTable.organizationId, orgId)),

    db.select({
      pending: sql<number>`count(*) filter (where review_status = 'pending_review')::int`,
    }).from(alertAnalysesTable).where(eq(alertAnalysesTable.organizationId, orgId)),

    db.select({
      total: sql<number>`count(*)::int`,
    }).from(iocEnrichmentsTable).where(eq(iocEnrichmentsTable.organizationId, orgId)),

    db.select({ jobRunAt: ruleTuningRecommendationsTable.jobRunAt })
      .from(ruleTuningRecommendationsTable)
      .where(eq(ruleTuningRecommendationsTable.organizationId, orgId))
      .orderBy(desc(ruleTuningRecommendationsTable.jobRunAt)).limit(1),

    db.select({
      mttrHours: sql<number>`avg(extract(epoch from (resolved_at - created_at)) / 3600.0)::real`,
    }).from(incidentsTable).where(and(eq(incidentsTable.organizationId, orgId), isNotNull(incidentsTable.resolvedAt))),
  ]);

  const a = alertStats[0] ?? { total: 0, critical: 0, fp: 0, ack: 0, resolved: 0, mitreMapped: 0 };
  const i = incidentStats[0] ?? { total: 0, resolved: 0, open: 0 };
  const ag = agentStats[0] ?? { total: 0, offline: 0 };
  const lastTuning = tuningStats[0]?.jobRunAt;
  const lastTuningDays = lastTuning
    ? Math.floor((Date.now() - new Date(lastTuning).getTime()) / 86400000)
    : null;

  return {
    totalAlerts: a.total,
    criticalAlerts: a.critical,
    falsePositives: a.fp,
    acknowledgedAlerts: a.ack,
    resolvedAlerts: a.resolved,
    mitreMappedAlerts: a.mitreMapped,
    totalIncidents: i.total,
    resolvedIncidents: i.resolved,
    openIncidents: i.open,
    mttrHours: mttrRow[0]?.mttrHours ?? null,
    pendingAiReviews: aiStats[0]?.pending ?? 0,
    totalAgents: ag.total,
    offlineAgents: ag.offline,
    openCriticalVulns: vulnStats[0]?.criticalOpen ?? 0,
    totalIocEnrichments: iocStats[0]?.total ?? 0,
    lastRuleTuningDays: lastTuningDays,
  };
}

/* ─── Individual control evaluator ─── */
function evaluateControl(def: ControlDefinition, snap: DataSnapshot): EvaluatedControl {
  let status: ControlStatus = "failed";
  let score = 0;
  let evidence = "";
  const evidenceData: Record<string, unknown> = {};

  switch (def.evaluator) {
    case "alert_logging": {
      const alertsPerAgent = snap.totalAgents > 0 ? snap.totalAlerts / snap.totalAgents : 0;
      evidenceData.totalAlerts = snap.totalAlerts;
      evidenceData.totalAgents = snap.totalAgents;
      if (snap.totalAgents === 0) {
        status = "failed"; score = 0; evidence = "No agents deployed — no security logging in place.";
      } else if (alertsPerAgent > 0.1) {
        status = "passed"; score = 100; evidence = `${snap.totalAgents} agent(s) producing ${snap.totalAlerts} alerts in 30 days — logging is active.`;
      } else {
        status = "partial"; score = 50; evidence = `Agents deployed but alert volume is low (${snap.totalAlerts} in 30 days). Verify rules are active.`;
      }
      break;
    }
    case "incident_response": {
      evidenceData.totalIncidents = snap.totalIncidents;
      evidenceData.resolvedIncidents = snap.resolvedIncidents;
      if (snap.totalIncidents === 0 && snap.criticalAlerts > 0) {
        status = "failed"; score = 0; evidence = `${snap.criticalAlerts} critical alert(s) exist but no incidents have been created.`;
      } else if (snap.totalIncidents > 0) {
        score = snap.totalIncidents > 0 ? Math.round((snap.resolvedIncidents / snap.totalIncidents) * 100) : 0;
        status = score >= 80 ? "passed" : score >= 40 ? "partial" : "failed";
        evidence = `${snap.totalIncidents} incident(s) created, ${snap.resolvedIncidents} resolved (${score}% closure rate).`;
      } else {
        status = "not_applicable"; score = 100; evidence = "No critical alerts to respond to.";
      }
      break;
    }
    case "false_positive_rate": {
      const fpPct = snap.totalAlerts > 0 ? (snap.falsePositives / snap.totalAlerts) * 100 : 0;
      evidenceData.fpPct = +fpPct.toFixed(1);
      evidenceData.falsePositives = snap.falsePositives;
      if (fpPct <= 10) { status = "passed"; score = 100; evidence = `FP rate is ${fpPct.toFixed(1)}% — well within acceptable range.`; }
      else if (fpPct <= 25) { status = "partial"; score = 60; evidence = `FP rate is ${fpPct.toFixed(1)}% — above target. Review rule tuning.`; }
      else { status = "failed"; score = 20; evidence = `FP rate is ${fpPct.toFixed(1)}% — too high, generating analyst fatigue.`; }
      break;
    }
    case "ai_reviews_actioned": {
      evidenceData.pendingReviews = snap.pendingAiReviews;
      if (snap.pendingAiReviews === 0 && snap.totalAlerts === 0) {
        status = "not_applicable"; score = 100; evidence = "No alerts to review.";
      } else if (snap.pendingAiReviews === 0) {
        status = "passed"; score = 100; evidence = "All AI analyses have been reviewed by an analyst.";
      } else if (snap.pendingAiReviews <= 5) {
        status = "partial"; score = 70; evidence = `${snap.pendingAiReviews} AI analysis review(s) pending — action promptly.`;
      } else {
        status = "failed"; score = Math.max(0, 100 - snap.pendingAiReviews * 5);
        evidence = `${snap.pendingAiReviews} AI analysis reviews pending — analysts are not keeping up with the queue.`;
      }
      break;
    }
    case "vulnerability_mgmt": {
      evidenceData.openCriticalVulns = snap.openCriticalVulns;
      if (snap.openCriticalVulns === 0) {
        status = "passed"; score = 100; evidence = "No open critical vulnerabilities detected.";
      } else if (snap.openCriticalVulns <= 3) {
        status = "partial"; score = 60; evidence = `${snap.openCriticalVulns} open critical vulnerability(ies) — remediate within 30 days.`;
      } else {
        status = "failed"; score = 10; evidence = `${snap.openCriticalVulns} open critical vulnerabilities — immediate remediation required.`;
      }
      break;
    }
    case "agent_coverage": {
      const coveragePct = snap.totalAgents > 0 ? ((snap.totalAgents - snap.offlineAgents) / snap.totalAgents) * 100 : 0;
      evidenceData.totalAgents = snap.totalAgents;
      evidenceData.offlineAgents = snap.offlineAgents;
      evidenceData.coveragePct = +coveragePct.toFixed(0);
      if (snap.totalAgents === 0) {
        status = "failed"; score = 0; evidence = "No agents deployed.";
      } else if (coveragePct >= 95) {
        status = "passed"; score = 100; evidence = `${snap.totalAgents} agents, ${snap.offlineAgents} offline (${coveragePct.toFixed(0)}% online).`;
      } else if (coveragePct >= 80) {
        status = "partial"; score = 65; evidence = `${snap.offlineAgents} agents offline — ${coveragePct.toFixed(0)}% coverage.`;
      } else {
        status = "failed"; score = 20; evidence = `${snap.offlineAgents} of ${snap.totalAgents} agents offline — coverage critically low at ${coveragePct.toFixed(0)}%.`;
      }
      break;
    }
    case "mttr_sla": {
      evidenceData.mttrHours = snap.mttrHours;
      if (snap.mttrHours === null) {
        status = "not_applicable"; score = 100; evidence = "No resolved incidents yet — MTTR cannot be measured.";
      } else if (snap.mttrHours <= 4) {
        status = "passed"; score = 100; evidence = `MTTR is ${snap.mttrHours.toFixed(1)}h — excellent response time.`;
      } else if (snap.mttrHours <= 24) {
        status = "partial"; score = 70; evidence = `MTTR is ${snap.mttrHours.toFixed(1)}h — within 24h target.`;
      } else {
        status = "failed"; score = 20; evidence = `MTTR is ${snap.mttrHours.toFixed(1)}h — exceeds 24h SLA target.`;
      }
      break;
    }
    case "alert_triage_rate": {
      const triaged = snap.acknowledgedAlerts + snap.resolvedAlerts;
      const triagePct = snap.totalAlerts > 0 ? (triaged / snap.totalAlerts) * 100 : 100;
      evidenceData.triagePct = +triagePct.toFixed(0);
      evidenceData.triaged = triaged;
      evidenceData.total = snap.totalAlerts;
      if (triagePct >= 90) { status = "passed"; score = 100; evidence = `${triagePct.toFixed(0)}% of alerts triaged (acknowledged or resolved).`; }
      else if (triagePct >= 60) { status = "partial"; score = 65; evidence = `${triagePct.toFixed(0)}% of alerts triaged — ${snap.totalAlerts - triaged} still need action.`; }
      else { status = "failed"; score = 20; evidence = `Only ${triagePct.toFixed(0)}% of alerts triaged — alert backlog is significant.`; }
      break;
    }
    case "mitre_coverage": {
      const mitrePct = snap.totalAlerts > 0 ? (snap.mitreMappedAlerts / snap.totalAlerts) * 100 : 0;
      evidenceData.mitreMapped = snap.mitreMappedAlerts;
      evidenceData.mitrePct = +mitrePct.toFixed(0);
      if (snap.mitreMappedAlerts === 0) { status = "failed"; score = 0; evidence = "No alerts have MITRE ATT&CK techniques mapped. Run AI analysis to populate."; }
      else if (mitrePct >= 50) { status = "passed"; score = 100; evidence = `${snap.mitreMappedAlerts} alerts (${mitrePct.toFixed(0)}%) mapped to MITRE ATT&CK techniques.`; }
      else { status = "partial"; score = 60; evidence = `${snap.mitreMappedAlerts} alerts (${mitrePct.toFixed(0)}%) mapped to MITRE — run AI analysis on remaining alerts.`; }
      break;
    }
    case "incident_closure_rate": {
      const closurePct = snap.totalIncidents > 0 ? (snap.resolvedIncidents / snap.totalIncidents) * 100 : 100;
      evidenceData.closurePct = +closurePct.toFixed(0);
      evidenceData.openIncidents = snap.openIncidents;
      if (snap.totalIncidents === 0) { status = "not_applicable"; score = 100; evidence = "No incidents created yet."; }
      else if (closurePct >= 90) { status = "passed"; score = 100; evidence = `${closurePct.toFixed(0)}% of incidents resolved or closed.`; }
      else if (closurePct >= 60) { status = "partial"; score = 65; evidence = `${closurePct.toFixed(0)}% closure rate — ${snap.openIncidents} incident(s) still open.`; }
      else { status = "failed"; score = 20; evidence = `Only ${closurePct.toFixed(0)}% of incidents resolved — ${snap.openIncidents} outstanding.`; }
      break;
    }
    case "ioc_enrichment": {
      evidenceData.iocCount = snap.totalIocEnrichments;
      if (snap.totalIocEnrichments >= 10) { status = "passed"; score = 100; evidence = `${snap.totalIocEnrichments} indicators enriched from threat feeds.`; }
      else if (snap.totalIocEnrichments > 0) { status = "partial"; score = 60; evidence = `${snap.totalIocEnrichments} indicator(s) enriched — enrich more IOCs from alerts.`; }
      else { status = "failed"; score = 0; evidence = "No IOC enrichment performed. Use Threat Intelligence to enrich indicators from your alerts."; }
      break;
    }
    case "rule_tuning": {
      evidenceData.lastTuningDays = snap.lastRuleTuningDays;
      if (snap.lastRuleTuningDays === null) { status = "failed"; score = 0; evidence = "Rule optimization has never been run."; }
      else if (snap.lastRuleTuningDays <= 30) { status = "passed"; score = 100; evidence = `Rule optimization last run ${snap.lastRuleTuningDays} day(s) ago — within 30-day window.`; }
      else if (snap.lastRuleTuningDays <= 60) { status = "partial"; score = 60; evidence = `Rule optimization run ${snap.lastRuleTuningDays} days ago — re-run recommended.`; }
      else { status = "failed"; score = 20; evidence = `Rule optimization last run ${snap.lastRuleTuningDays} days ago — overdue.`; }
      break;
    }
    case "critical_alert_ratio": {
      const critPct = snap.totalAlerts > 0 ? (snap.criticalAlerts / snap.totalAlerts) * 100 : 0;
      evidenceData.critPct = +critPct.toFixed(0);
      evidenceData.criticalAlerts = snap.criticalAlerts;
      if (snap.criticalAlerts === 0) { status = "passed"; score = 100; evidence = "No open critical alerts."; }
      else if (critPct <= 10) { status = "passed"; score = 90; evidence = `${snap.criticalAlerts} critical alert(s) — ${critPct.toFixed(0)}% of total, within acceptable range.`; }
      else if (critPct <= 25) { status = "partial"; score = 50; evidence = `${snap.criticalAlerts} critical alerts (${critPct.toFixed(0)}% of total) — investigate promptly.`; }
      else { status = "failed"; score = 10; evidence = `${critPct.toFixed(0)}% of alerts are critical (${snap.criticalAlerts}) — risk level is very high.`; }
      break;
    }
    default:
      status = "not_applicable"; score = 100; evidence = "Evaluation not available.";
  }

  const recommendation = status === "passed"
    ? "Control is operating effectively. Continue monitoring."
    : def.remediationSteps[0] ?? "Review and remediate according to framework guidance.";

  return {
    id: def.id,
    name: def.name,
    description: def.description,
    category: def.category,
    requirement: def.requirement,
    status,
    score,
    evidence,
    evidenceData,
    recommendation,
    remediationSteps: def.remediationSteps,
    evidenceHints: def.evidenceHints,
    weight: def.weight,
  };
}

/* ─── Public: assess a single framework ─── */
export async function assessFramework(orgId: string, frameworkId: string): Promise<FrameworkAssessment | null> {
  const def = FRAMEWORK_CATALOG[frameworkId];
  if (!def) return null;

  const snap = await getDataSnapshot(orgId);
  const controls = def.controls.map((c) => evaluateControl(c, snap));

  const passed = controls.filter((c) => c.status === "passed").length;
  const failed = controls.filter((c) => c.status === "failed").length;
  const partial = controls.filter((c) => c.status === "partial").length;
  const applicable = controls.filter((c) => c.status !== "not_applicable");

  // Weighted score
  const totalWeight = applicable.reduce((s, c) => s + c.weight, 0);
  const earnedWeight = applicable.reduce((s, c) => s + (c.score / 100) * c.weight, 0);
  const score = totalWeight > 0 ? Math.round((earnedWeight / totalWeight) * 100) : 100;

  const status = score >= 80 ? "compliant" : score >= 60 ? "partial" : "non-compliant";

  return {
    id: def.id,
    name: def.name,
    shortName: def.shortName,
    version: def.version,
    description: def.description,
    score,
    status,
    controlsTotal: controls.length,
    controlsPassed: passed,
    controlsFailed: failed,
    controlsPartial: partial,
    controls,
    lastAssessedAt: new Date().toISOString(),
  };
}

/* ─── Public: assess all frameworks ─── */
export async function assessAllFrameworks(orgId: string): Promise<FrameworkAssessment[]> {
  const snap = await getDataSnapshot(orgId);
  return ALL_FRAMEWORKS.map((def) => {
    const controls = def.controls.map((c) => evaluateControl(c, snap));
    const passed = controls.filter((c) => c.status === "passed").length;
    const failed = controls.filter((c) => c.status === "failed").length;
    const partial = controls.filter((c) => c.status === "partial").length;
    const applicable = controls.filter((c) => c.status !== "not_applicable");
    const totalWeight = applicable.reduce((s, c) => s + c.weight, 0);
    const earnedWeight = applicable.reduce((s, c) => s + (c.score / 100) * c.weight, 0);
    const score = totalWeight > 0 ? Math.round((earnedWeight / totalWeight) * 100) : 100;
    return {
      id: def.id, name: def.name, shortName: def.shortName, version: def.version,
      description: def.description,
      score, status: score >= 80 ? "compliant" : score >= 60 ? "partial" : "non-compliant",
      controlsTotal: controls.length, controlsPassed: passed, controlsFailed: failed, controlsPartial: partial,
      controls, lastAssessedAt: new Date().toISOString(),
    };
  });
}
