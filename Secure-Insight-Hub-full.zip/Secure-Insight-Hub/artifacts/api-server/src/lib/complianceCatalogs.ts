/**
 * Compliance control catalogs.
 *
 * Each control has:
 *   - id, name, description, category, requirement (framework reference)
 *   - evaluator: key that maps to a live-data check in complianceEngine.ts
 *   - remediationSteps: concrete actions to fix a failing control
 *   - evidenceHints: what evidence an analyst should attach
 */

export interface ControlDefinition {
  id: string;
  name: string;
  description: string;
  category: string;
  requirement: string; // official ref e.g. "PCI DSS 10.2.1"
  evaluator: string;   // key used by the engine to compute status
  remediationSteps: string[];
  evidenceHints: string[];
  weight: number; // 1-3, used in score calculation
}

export interface FrameworkDefinition {
  id: string;
  name: string;
  shortName: string;
  version: string;
  description: string;
  controls: ControlDefinition[];
}

/* ─── Shared evaluator keys ─────────────────────────────────────────────────
  alert_logging          — are agents producing alerts?
  incident_response      — are incidents being created and resolved?
  false_positive_rate    — FP rate < 20%
  ai_reviews_actioned    — no pending AI reviews older than 24h
  vulnerability_mgmt     — open critical vulns = 0
  agent_coverage         — all agents online
  mttr_sla               — MTTR < 24h
  alert_triage_rate      — % alerts acknowledged or resolved
  mitre_coverage         — at least 1 MITRE-mapped alert (detection breadth)
  incident_closure_rate  — % incidents resolved or closed
  ioc_enrichment         — IOC enrichment in use (threat intel)
  rule_tuning            — rule tuning job run in last 30 days
  critical_alert_ratio   — critical alerts < 10% of total
─────────────────────────────────────────────────────────────────────────── */

// ─── PCI DSS v4.0 ────────────────────────────────────────────────────────────
const PCI_DSS: FrameworkDefinition = {
  id: "pci-dss",
  name: "PCI DSS",
  shortName: "PCI DSS",
  version: "v4.0",
  description: "Payment Card Industry Data Security Standard — protects cardholder data environments.",
  controls: [
    { id: "PCI-10.2.1",  name: "Audit Log Generation",        description: "Implement audit logs to capture all security events across CDE systems.",              category: "Logging & Monitoring",     requirement: "Req 10.2.1", evaluator: "alert_logging",          weight: 3, remediationSteps: ["Enable Wazuh agents on all in-scope hosts","Verify alert forwarding pipeline"], evidenceHints: ["Wazuh agent list","Alert volume per agent"] },
    { id: "PCI-10.6.1",  name: "Security Log Review",          description: "Review security logs at least daily for critical systems.",                            category: "Logging & Monitoring",     requirement: "Req 10.6.1", evaluator: "ai_reviews_actioned",    weight: 2, remediationSteps: ["Enable AI analysis on all alerts","Action pending reviews within SLA"], evidenceHints: ["AI analysis completion rate","Pending review count"] },
    { id: "PCI-6.3.3",   name: "Vulnerability Management",     description: "Address vulnerabilities according to risk ranking; critical within one month.",       category: "Vulnerability Mgmt",       requirement: "Req 6.3.3",  evaluator: "vulnerability_mgmt",    weight: 3, remediationSteps: ["Triage all critical vulnerabilities","Patch or apply compensating controls within 30 days"], evidenceHints: ["Open critical vuln count","Patch timestamps"] },
    { id: "PCI-12.10.1", name: "Incident Response Plan",       description: "Implement and maintain an incident response plan.",                                    category: "Incident Response",        requirement: "Req 12.10.1",evaluator: "incident_response",     weight: 3, remediationSteps: ["Create incidents for all critical alerts","Document resolution actions"], evidenceHints: ["Incident list","MTTR metric","Resolution summaries"] },
    { id: "PCI-12.10.4", name: "Incident Response MTTR",       description: "Respond to security incidents within defined SLAs.",                                  category: "Incident Response",        requirement: "Req 12.10.4",evaluator: "mttr_sla",             weight: 2, remediationSteps: ["Set SLA targets","Monitor MTTR on dashboard"], evidenceHints: ["Average MTTR","Incident resolved timestamps"] },
    { id: "PCI-5.3.1",   name: "Anti-malware / Detection",     description: "Deploy anti-malware and security monitoring on all applicable systems.",              category: "Malware Protection",       requirement: "Req 5.3.1",  evaluator: "agent_coverage",        weight: 3, remediationSteps: ["Deploy Wazuh agents to all hosts","Resolve agent connectivity issues"], evidenceHints: ["Agent coverage report","Offline agent count"] },
    { id: "PCI-6.4.1",   name: "Web App Security Monitoring",  description: "Monitor and detect attacks on public-facing web applications.",                       category: "Secure Dev & Monitoring",  requirement: "Req 6.4.1",  evaluator: "mitre_coverage",        weight: 2, remediationSteps: ["Enable WAF rules in Wazuh","Map web attacks to MITRE ATT&CK"], evidenceHints: ["MITRE technique coverage","Web-category alert count"] },
    { id: "PCI-10.7.1",  name: "Alert Triage Completeness",    description: "Failures of critical security controls are detected and reported promptly.",          category: "Logging & Monitoring",     requirement: "Req 10.7.1", evaluator: "alert_triage_rate",    weight: 2, remediationSteps: ["Acknowledge all alerts within 4 hours","Use bulk-action to triage alert queues"], evidenceHints: ["Alert acknowledgment rate","Unacknowledged alert age"] },
  ],
};

// ─── ISO 27001:2022 ───────────────────────────────────────────────────────────
const ISO27001: FrameworkDefinition = {
  id: "iso27001",
  name: "ISO 27001",
  shortName: "ISO 27001",
  version: "2022",
  description: "International standard for information security management systems (ISMS).",
  controls: [
    { id: "ISO-8.8",   name: "Vulnerability Management",    description: "Information about technical vulnerabilities shall be obtained and addressed.",            category: "Technological Controls",  requirement: "Clause 8.8",   evaluator: "vulnerability_mgmt",    weight: 3, remediationSteps: ["Run regular vulnerability scans","Track and remediate critical vulns"], evidenceHints: ["Vulnerability scan results","Patch records"] },
    { id: "ISO-8.15",  name: "Logging",                    description: "Logs recording user activities and security events shall be produced, protected.",         category: "Technological Controls",  requirement: "Clause 8.15",  evaluator: "alert_logging",         weight: 3, remediationSteps: ["Ensure all hosts forward logs to Wazuh","Validate log completeness"], evidenceHints: ["Log volume report","Agent alert count"] },
    { id: "ISO-8.16",  name: "Monitoring Activities",      description: "Networks, systems and applications shall be monitored for anomalous behaviour.",           category: "Technological Controls",  requirement: "Clause 8.16",  evaluator: "ai_reviews_actioned",   weight: 2, remediationSteps: ["Enable AI analysis on all alerts","Set up daily review workflow"], evidenceHints: ["AI analysis count","Analyst review timestamps"] },
    { id: "ISO-5.26",  name: "Response to IS Incidents",   description: "IS incidents shall be responded to in accordance with documented procedures.",             category: "Organizational Controls", requirement: "Clause 5.26",  evaluator: "incident_response",    weight: 3, remediationSteps: ["Create incident for every critical alert","Document response steps in notes"], evidenceHints: ["Incident count","Timeline events","Resolution summaries"] },
    { id: "ISO-5.29",  name: "IS During Disruption",       description: "The org shall plan how to maintain IS at an appropriate level during disruption.",        category: "Organizational Controls", requirement: "Clause 5.29",  evaluator: "incident_closure_rate", weight: 2, remediationSteps: ["Resolve or close all open incidents","Track incident closure rate"], evidenceHints: ["Incident closure rate","Open incident count"] },
    { id: "ISO-8.23",  name: "Web Filtering / IOC",        description: "Access to external websites shall be managed to reduce exposure to malicious content.",   category: "Technological Controls",  requirement: "Clause 8.23",  evaluator: "ioc_enrichment",        weight: 2, remediationSteps: ["Enrich all IOCs from alerts","Block malicious IPs at firewall"], evidenceHints: ["IOC enrichment count","Malicious IP blocks"] },
    { id: "ISO-8.7",   name: "Protection Against Malware", description: "Protection against malware shall be implemented and supported by user awareness.",         category: "Technological Controls",  requirement: "Clause 8.7",   evaluator: "agent_coverage",       weight: 3, remediationSteps: ["Achieve 100% agent coverage","Resolve all offline agents"], evidenceHints: ["Agent coverage %","Offline agent list"] },
    { id: "ISO-8.9",   name: "Configuration Mgmt",         description: "Configurations including security configurations of hardware and software shall be managed.", category: "Technological Controls", requirement: "Clause 8.9",   evaluator: "rule_tuning",           weight: 2, remediationSteps: ["Run rule tuning analysis monthly","Apply approved rule changes"], evidenceHints: ["Rule tuning job history","Approved changes count"] },
    { id: "ISO-8.12",  name: "Data Leakage Prevention",    description: "Measures shall be applied to prevent data leakage across systems.",                       category: "Technological Controls",  requirement: "Clause 8.12",  evaluator: "critical_alert_ratio",  weight: 2, remediationSteps: ["Investigate all critical alerts for data exfiltration","Enable DLP rules in Wazuh"], evidenceHints: ["Critical alert count","Exfiltration MITRE techniques"] },
  ],
};

// ─── CIS Controls v8 ─────────────────────────────────────────────────────────
const CIS_CONTROLS: FrameworkDefinition = {
  id: "cis",
  name: "CIS Controls",
  shortName: "CIS Controls",
  version: "v8",
  description: "Prioritized set of actions to protect against the most pervasive cyber attacks.",
  controls: [
    { id: "CIS-1",  name: "Asset Inventory",              description: "Actively manage all enterprise assets to maintain accurate inventory.",                   category: "Basic Hygiene",            requirement: "Control 1",  evaluator: "agent_coverage",        weight: 3, remediationSteps: ["Ensure all hosts have Wazuh agents","Resolve agent gaps"], evidenceHints: ["Agent inventory list","Unmonitored host count"] },
    { id: "CIS-3",  name: "Data Protection",              description: "Develop processes to identify, classify, and protect sensitive data.",                   category: "Data",                     requirement: "Control 3",  evaluator: "ioc_enrichment",        weight: 2, remediationSteps: ["Enrich all IOCs","Track data-related MITRE techniques"], evidenceHints: ["IOC database","MITRE data technique coverage"] },
    { id: "CIS-5",  name: "Account Management",           description: "Use processes to actively manage the lifecycle of system and application accounts.",      category: "Access Control",           requirement: "Control 5",  evaluator: "critical_alert_ratio",  weight: 2, remediationSteps: ["Review all critical alerts for account abuse","Investigate failed logins"], evidenceHints: ["Critical alerts by category","Account MITRE techniques"] },
    { id: "CIS-7",  name: "Continuous Vulnerability Mgmt", description: "Continuously acquire, assess, and remediate vulnerabilities on all assets.",           category: "Vulnerability Mgmt",       requirement: "Control 7",  evaluator: "vulnerability_mgmt",    weight: 3, remediationSteps: ["Scan all assets for vulnerabilities","Patch critical vulns within 30 days"], evidenceHints: ["Vulnerability counts","Patch dates"] },
    { id: "CIS-8",  name: "Audit Log Management",         description: "Collect, alert, review, and retain audit logs that could detect or assist in an attack.",  category: "Audit & Accountability",   requirement: "Control 8",  evaluator: "alert_logging",         weight: 3, remediationSteps: ["Enable logging on all systems","Review logs daily"], evidenceHints: ["Alert log volume","Agent count","Log review records"] },
    { id: "CIS-13", name: "Network Monitoring & Defense", description: "Operate processes and tooling to establish and maintain monitoring of the network.",       category: "Network",                  requirement: "Control 13", evaluator: "mitre_coverage",        weight: 3, remediationSteps: ["Map all alerts to MITRE ATT&CK","Enable network-based detection rules"], evidenceHints: ["MITRE technique count","Network alert volume"] },
    { id: "CIS-17", name: "Incident Response Management", description: "Establish a programme to develop and maintain incident response capability.",             category: "Incident Response",        requirement: "Control 17", evaluator: "incident_response",    weight: 3, remediationSteps: ["Create incidents for critical alerts","Document response in timeline"], evidenceHints: ["Incident list","Timeline event history"] },
    { id: "CIS-18", name: "Penetration Testing",          description: "Test effectiveness of controls by simulating attacker objectives and actions.",            category: "Pen Testing",              requirement: "Control 18", evaluator: "rule_tuning",           weight: 2, remediationSteps: ["Run rule optimization analysis","Apply tuning recommendations"], evidenceHints: ["Rule tuning job results","Approved changes"] },
  ],
};

// ─── NIST CSF 2.0 ─────────────────────────────────────────────────────────────
const NIST_CSF: FrameworkDefinition = {
  id: "nist",
  name: "NIST CSF",
  shortName: "NIST CSF",
  version: "2.0",
  description: "NIST Cybersecurity Framework — Govern, Identify, Protect, Detect, Respond, Recover.",
  controls: [
    { id: "NIST-ID.AM", name: "Asset Management",           description: "Assets associated with data, personnel, and systems are identified and managed.",       category: "Identify",   requirement: "ID.AM",   evaluator: "agent_coverage",        weight: 3, remediationSteps: ["Deploy agents to all assets","Maintain asset registry"], evidenceHints: ["Agent inventory","Unmonitored hosts"] },
    { id: "NIST-ID.RA", name: "Risk Assessment",            description: "The org understands the cybersecurity risk to operations and assets.",                  category: "Identify",   requirement: "ID.RA",   evaluator: "vulnerability_mgmt",    weight: 3, remediationSteps: ["Run vulnerability scans","Track risk scoring per asset"], evidenceHints: ["Vulnerability report","Risk scores"] },
    { id: "NIST-PR.AC", name: "Identity & Access Mgmt",     description: "Access to assets is limited to authorized users, processes, and devices.",              category: "Protect",    requirement: "PR.AC",   evaluator: "critical_alert_ratio",  weight: 2, remediationSteps: ["Investigate access-related critical alerts","Review IAM policies"], evidenceHints: ["Access control alerts","MITRE credential access techniques"] },
    { id: "NIST-DE.CM", name: "Security Continuous Monitoring", description: "The IS and assets are monitored to identify events and verify effectiveness of controls.", category: "Detect",   requirement: "DE.CM",   evaluator: "alert_logging",        weight: 3, remediationSteps: ["Ensure 100% agent coverage","Review alerts daily"], evidenceHints: ["Alert log volume","Agent health"] },
    { id: "NIST-DE.AE", name: "Anomalies & Events",         description: "Anomalous activity is detected and potential impact is understood.",                    category: "Detect",     requirement: "DE.AE",   evaluator: "mitre_coverage",        weight: 3, remediationSteps: ["Enable AI analysis on all alerts","Map alerts to MITRE"], evidenceHints: ["MITRE heatmap","AI analysis count"] },
    { id: "NIST-RS.RP", name: "Response Planning",          description: "Response processes and procedures are maintained to ensure timely response.",            category: "Respond",    requirement: "RS.RP",   evaluator: "incident_response",    weight: 3, remediationSteps: ["Create incidents for all critical alerts","Maintain response playbooks"], evidenceHints: ["Incident list","Timeline events"] },
    { id: "NIST-RS.MI", name: "Mitigation",                 description: "Activities are performed to prevent expansion of an event and resolve the incident.",   category: "Respond",    requirement: "RS.MI",   evaluator: "mttr_sla",             weight: 2, remediationSteps: ["Meet MTTR targets","Use containment actions from AI analysis"], evidenceHints: ["MTTR report","Containment action log"] },
    { id: "NIST-RC.RP", name: "Recovery Planning",          description: "Recovery processes are executed and maintained to restore systems.",                    category: "Recover",    requirement: "RC.RP",   evaluator: "incident_closure_rate", weight: 2, remediationSteps: ["Close all resolved incidents","Record resolution summaries"], evidenceHints: ["Incident closure rate","Resolution notes"] },
    { id: "NIST-GV.OC", name: "Organizational Context",     description: "The org mission, objectives, and legal requirements are understood and inform security.", category: "Govern",    requirement: "GV.OC",   evaluator: "rule_tuning",          weight: 2, remediationSteps: ["Align rule set to business risk","Run rule optimization analysis"], evidenceHints: ["Rule tuning results","Approved changes"] },
  ],
};

// ─── HIPAA Security Rule ───────────────────────────────────────────────────────
const HIPAA: FrameworkDefinition = {
  id: "hipaa",
  name: "HIPAA",
  shortName: "HIPAA",
  version: "Security Rule",
  description: "HIPAA Security Rule — protects electronic protected health information (ePHI).",
  controls: [
    { id: "HIPAA-164.308a1", name: "Security Management Process", description: "Implement policies to prevent, detect, contain, and correct security violations.", category: "Administrative", requirement: "§164.308(a)(1)", evaluator: "incident_response",    weight: 3, remediationSteps: ["Document security management process","Create incidents for violations"], evidenceHints: ["Incident list","Policy documents"] },
    { id: "HIPAA-164.308a5", name: "Security Awareness",          description: "Implement security awareness and training program for all workforce members.",    category: "Administrative", requirement: "§164.308(a)(5)", evaluator: "alert_triage_rate",    weight: 2, remediationSteps: ["Track alert acknowledgment rate","Train analysts on triage workflows"], evidenceHints: ["Alert triage rate","Training records"] },
    { id: "HIPAA-164.308a6", name: "Security Incident Procedures", description: "Implement policies to address security incidents including response and reporting.", category: "Administrative", requirement: "§164.308(a)(6)", evaluator: "mttr_sla",            weight: 3, remediationSteps: ["Meet incident response SLAs","Document response in timeline"], evidenceHints: ["MTTR metric","Incident timeline events"] },
    { id: "HIPAA-164.312a1", name: "Access Control",              description: "Implement technical policies to allow access only to authorized persons.",        category: "Technical",      requirement: "§164.312(a)(1)", evaluator: "critical_alert_ratio",  weight: 3, remediationSteps: ["Investigate access-related critical alerts","Review access control rules"], evidenceHints: ["Access alert count","MITRE initial access techniques"] },
    { id: "HIPAA-164.312b",  name: "Audit Controls",              description: "Implement hardware, software, and procedural mechanisms to audit ePHI access.",   category: "Technical",      requirement: "§164.312(b)",    evaluator: "alert_logging",        weight: 3, remediationSteps: ["Enable audit logging on all ePHI systems","Forward all logs to Wazuh"], evidenceHints: ["Agent log volume","Audit log completeness"] },
    { id: "HIPAA-164.312c1", name: "Integrity Controls",          description: "Implement mechanisms to authenticate ePHI and corroborate it has not been altered.", category: "Technical",   requirement: "§164.312(c)(1)", evaluator: "ioc_enrichment",        weight: 2, remediationSteps: ["Enrich all hash IOCs from alerts","Track file integrity alerts"], evidenceHints: ["Hash IOC enrichment count","File integrity alert count"] },
    { id: "HIPAA-164.312e1", name: "Transmission Security",       description: "Guard against unauthorized access to ePHI during transmission over networks.",    category: "Technical",      requirement: "§164.312(e)(1)", evaluator: "mitre_coverage",        weight: 2, remediationSteps: ["Monitor network traffic alerts","Map transmission events to MITRE"], evidenceHints: ["Network alert count","MITRE network technique coverage"] },
    { id: "HIPAA-164.308a8", name: "Evaluation",                  description: "Perform periodic technical and non-technical evaluation of security controls.",   category: "Administrative", requirement: "§164.308(a)(8)", evaluator: "rule_tuning",           weight: 2, remediationSteps: ["Run quarterly rule optimization","Document evaluation results"], evidenceHints: ["Rule tuning job history","Evaluation reports"] },
  ],
};

export const FRAMEWORK_CATALOG: Record<string, FrameworkDefinition> = {
  "pci-dss": PCI_DSS,
  "iso27001": ISO27001,
  "cis": CIS_CONTROLS,
  "nist": NIST_CSF,
  "hipaa": HIPAA,
};

export const ALL_FRAMEWORKS = Object.values(FRAMEWORK_CATALOG);
