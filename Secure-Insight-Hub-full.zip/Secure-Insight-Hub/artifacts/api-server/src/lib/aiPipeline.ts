/**
 * AI Pipeline Engine
 *
 * Implements the full alert investigation pipeline:
 *   Alert → Context Builder → Redaction → AI Investigation →
 *   Confidence Score → Recommendation → (stored for Human Approval)
 *
 * Features:
 *   ✓ Prompt versioning  — every call references a named prompt version
 *   ✓ AI model version   — model pinned per stage, stored on the analysis row
 *   ✓ Retry logic        — exponential backoff up to MAX_RETRIES on transient errors
 *   ✓ Token tracking     — prompt + completion tokens stored per analysis
 *   ✓ Response caching   — identical context + prompt version → cache hit, no API call
 */

import { createHash } from "crypto";
import OpenAI from "openai";
import { db } from "@workspace/db";
import { aiResponseCacheTable } from "@workspace/db";
import { and, eq, gt } from "drizzle-orm";
import type { Alert } from "@workspace/db";
import { buildAlertContext, redactSensitiveFields, extractIocs, countPreviousOccurrences, type AlertContext } from "./contextBuilder";

/* ─── Prompt registry ──────────────────────────────────────────────────── */

export const PROMPT_VERSION = "v2";
export const AI_MODEL = "gpt-4o-mini";

// A prompt template is a function that takes structured context and returns
// the user message string. This makes it fully testable and version-diffable.
const PROMPTS: Record<string, Record<string, (ctx: string) => string>> = {
  v2: {
    investigation: (ctx) => `You are a senior SOC analyst performing the INVESTIGATION phase only. Do not provide remediation yet.

Analyze the following security alert and related context, then respond with a JSON object containing:
- summary: 2-3 sentence overview of what happened
- threatDescription: what threat this represents
- businessImpact: potential business impact
- reasoning: step-by-step reasoning for why this alert was triggered (cite specific fields)
- rootCause: most likely root cause (1-2 sentences)
- mitreExplanation: why the mapped MITRE technique applies, or why none applies
- falsePositiveProbability: 0.0-1.0 estimate
- confidenceScore: 0.0-1.0 confidence in the analysis
- investigationSteps: array of concrete analyst steps to verify
- affectedAssets: array of impacted hostnames/IPs/users
- executiveSummary: 1-sentence summary for non-technical stakeholders
- evidence: array of specific data points from the alert supporting the conclusion
- investigationChecklist: array of {label} objects for the analyst to tick off
- iocs: array of {type, value} indicators of compromise (ip, domain, hash_md5, hash_sha1, hash_sha256)

${ctx}`,

    recommendation: (ctx) => `You are a senior SOC analyst performing the RECOMMENDATION phase based on a completed investigation.

Given the investigation findings below, respond with a JSON object containing:
- remediationPlan: ordered array of remediation steps
- recommendedActions: immediate actions the analyst should take right now
- containmentActions: actions to limit the blast radius if this is confirmed malicious
- analystNotes: any additional context or caveats for the analyst

${ctx}`,
  },

  v1: {
    investigation: (ctx) => `You are a cybersecurity analyst. Analyze this security alert.

${ctx}

Respond with JSON: summary, threatDescription, businessImpact, investigationSteps, affectedAssets, executiveSummary, confidenceScore (0-1), reasoning, rootCause, mitreExplanation, falsePositiveProbability (0-1), evidence, investigationChecklist [{label}], iocs [{type,value}].`,

    recommendation: (ctx) => `Based on the investigation, provide recommendations as JSON: remediationPlan, recommendedActions, containmentActions, analystNotes.

${ctx}`,
  },
};

function getPrompt(version: string, stage: "investigation" | "recommendation"): ((ctx: string) => string) | null {
  return PROMPTS[version]?.[stage] ?? null;
}

/* ─── Cache ─────────────────────────────────────────────────────────────── */

const CACHE_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours

function makeCacheKey(model: string, promptVersion: string, contextFingerprint: string): string {
  return createHash("sha256").update(`${model}:${promptVersion}:${contextFingerprint}`).digest("hex");
}

function fingerprintContext(ctx: AlertContext): string {
  const alert = ctx.alert as Record<string, unknown>;
  // Use only stable, non-sensitive fields for the fingerprint
  const stable = { ruleId: alert.ruleId, ruleLevel: alert.ruleLevel, agentId: alert.agentId, severity: alert.severity, mitreTechniqueId: alert.mitreTechniqueId, relatedCount: ctx.relatedAlerts.length };
  return createHash("sha256").update(JSON.stringify(stable)).digest("hex");
}

async function getCached(cacheKey: string): Promise<Record<string, unknown> | null> {
  const [row] = await db.select().from(aiResponseCacheTable)
    .where(and(eq(aiResponseCacheTable.cacheKey, cacheKey), gt(aiResponseCacheTable.expiresAt, new Date())));
  if (!row) return null;
  // Increment hit count (best-effort, non-blocking)
  db.update(aiResponseCacheTable).set({ hitCount: row.hitCount + 1 }).where(eq(aiResponseCacheTable.id, row.id)).catch(() => {});
  return row.response;
}

async function setCached(cacheKey: string, model: string, promptVersion: string, response: Record<string, unknown>, tokens: { prompt?: number; completion?: number }): Promise<void> {
  const expiresAt = new Date(Date.now() + CACHE_TTL_MS);
  await db.insert(aiResponseCacheTable).values({
    cacheKey, model, promptVersion, response,
    promptTokens: tokens.prompt ?? null,
    completionTokens: tokens.completion ?? null,
    expiresAt,
  }).onConflictDoNothing();
}

/* ─── Retry logic ───────────────────────────────────────────────────────── */

const MAX_RETRIES = 3;
const RETRY_DELAYS_MS = [1000, 3000, 9000]; // exponential backoff

function isRetryable(err: unknown): boolean {
  if (err instanceof Error) {
    const msg = err.message.toLowerCase();
    // Retry on rate limits (429) and server errors (500, 503)
    if (msg.includes("rate limit") || msg.includes("429") || msg.includes("503") || msg.includes("500")) return true;
    // Retry on network-level failures
    if (msg.includes("econnreset") || msg.includes("etimedout") || msg.includes("fetch failed")) return true;
  }
  return false;
}

async function callWithRetry(
  openai: OpenAI,
  model: string,
  prompt: string,
  retryState: { count: number },
): Promise<{ parsed: Record<string, unknown>; promptTokens: number; completionTokens: number }> {
  let lastErr: unknown;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      const completion = await openai.chat.completions.create({
        model,
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        temperature: 0.2, // low temperature for deterministic structured outputs
      });
      const raw = completion.choices[0]?.message?.content ?? "{}";
      const parsed = JSON.parse(raw);
      retryState.count = attempt;
      return {
        parsed,
        promptTokens: completion.usage?.prompt_tokens ?? 0,
        completionTokens: completion.usage?.completion_tokens ?? 0,
      };
    } catch (err) {
      lastErr = err;
      retryState.count = attempt + 1;
      if (attempt < MAX_RETRIES && isRetryable(err)) {
        await new Promise((r) => setTimeout(r, RETRY_DELAYS_MS[attempt] ?? 9000));
        continue;
      }
      throw err;
    }
  }
  throw lastErr;
}

/* ─── Fallback (no OpenAI key) ──────────────────────────────────────────── */

function buildFallback(alert: Alert, ctx: AlertContext): { investigation: Record<string, unknown>; recommendation: Record<string, unknown> } {
  const a = alert;
  const fpProbability = a.severity === "low" ? 0.5 : a.severity === "medium" ? 0.25 : 0.1;
  return {
    investigation: {
      summary: `${a.ruleName} detected on ${a.agentName} (${a.severity} severity).`,
      threatDescription: `A ${a.severity} security event matching rule "${a.ruleName}" was triggered. ${a.description}`,
      businessImpact: "Potential unauthorized access or system compromise if not addressed promptly.",
      reasoning: `Rule level ${a.ruleLevel} triggered on ${a.agentName}. ${ctx.relatedAlerts.length ? `${ctx.relatedAlerts.length} related alert(s) found in the recent window.` : "No recent related activity."}`,
      rootCause: `Activity matching rule "${a.ruleName}" was observed on ${a.agentName}. Manual log review required to confirm root cause.`,
      mitreExplanation: a.mitreTechniqueId ? `This alert maps to ${a.mitreTechniqueId} (${a.mitreTechnique ?? "unknown technique"}), consistent with the observed behaviour.` : "No MITRE technique is mapped to this rule.",
      falsePositiveProbability: fpProbability,
      confidenceScore: 0.7,
      investigationSteps: [`Review logs on ${a.agentName} around ${a.timestamp}`, "Check for lateral movement from the source IP", "Verify system integrity and running processes"],
      affectedAssets: [a.agentName],
      executiveSummary: `A ${a.severity} security alert requires analyst review on ${a.agentName}.`,
      evidence: [a.description, `Rule level: ${a.ruleLevel}`, `Agent: ${a.agentName}`],
      investigationChecklist: [
        { label: `Confirm ${a.agentName} is not compromised` },
        { label: "Review authentication logs around the alert timestamp" },
        { label: "Check for related alerts from the same source" },
      ],
      iocs: extractIocs(`${a.description} ${a.sourceIp ?? ""}`),
    },
    recommendation: {
      remediationPlan: ["Isolate affected system if compromise confirmed", "Reset credentials for affected accounts", "Apply relevant security patches"],
      recommendedActions: ["Escalate to L2 analyst for deeper investigation", "Enable enhanced monitoring on the affected host"],
      containmentActions: ["Block source IP at perimeter firewall", "Disable compromised account temporarily"],
      analystNotes: `Rule ${a.ruleId} (level ${a.ruleLevel}). MITRE: ${a.mitreTechniqueId ?? "N/A"}. ${ctx.relatedAlerts.length} related alert(s) in window.`,
    },
  };
}

/* ─── Pipeline result ──────────────────────────────────────────────────── */

export interface PipelineResult {
  // Investigation fields
  summary: string;
  threatDescription: string;
  businessImpact: string;
  reasoning: string;
  rootCause: string;
  mitreExplanation: string;
  falsePositiveProbability: number;
  confidenceScore: number;
  investigationSteps: string[];
  affectedAssets: string[];
  executiveSummary: string;
  evidence: string[];
  investigationChecklist: Array<{ id: string; label: string; completed: boolean }>;
  iocs: Array<{ type: string; value: string }>;
  // Recommendation fields
  remediationPlan: string[];
  recommendedActions: string[];
  containmentActions: string[];
  analystNotes: string;
  // Pipeline metadata
  aiModelUsed: string;
  promptVersion: string;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  retryCount: number;
  pipelineDurationMs: number;
  fromCache: boolean;
  redactedFields: string[];
  previousOccurrences: number;
}

/* ─── Main pipeline ──────────────────────────────────────────────────────── */

export async function runAlertPipeline(alert: Alert): Promise<PipelineResult> {
  const t0 = Date.now();
  const apiKey = process.env.OPENAI_API_KEY;
  const openai = apiKey ? new OpenAI({ apiKey }) : null;

  const retryState = { count: 0 };
  let promptTokensTotal = 0;
  let completionTokensTotal = 0;
  let fromCache = false;

  // Step 1: Context Builder
  const rawContext = await buildAlertContext(alert);
  const previousOccurrences = await countPreviousOccurrences(alert);

  // Step 2: Redaction
  const { context, redactedFields } = redactSensitiveFields(rawContext);
  const a = context.alert as typeof alert;

  const contextFingerprint = fingerprintContext(rawContext);

  let investigation: Record<string, unknown>;
  let recommendation: Record<string, unknown>;

  if (!openai) {
    // Fallback: rule-based heuristics (no OpenAI key)
    const fallback = buildFallback(alert, rawContext);
    investigation = fallback.investigation;
    recommendation = fallback.recommendation;
  } else {
    // Build shared context block (used in both prompts)
    const relatedSummary = context.relatedAlerts.length
      ? context.relatedAlerts.map((r) => `  - ${r.ruleName} (${r.severity}) at ${r.timestamp}${r.sameAgent ? " [same agent]" : ""}${r.sameSourceIp ? " [same source IP]" : ""}`).join("\n")
      : "  No related alerts in the recent window.";

    const contextBlock = `ALERT DETAILS (sensitive fields redacted: ${redactedFields.join(", ") || "none"}):
  Rule: ${a.ruleName} (Level ${a.ruleLevel})
  Severity: ${a.severity}
  Description: ${a.description}
  Agent: ${a.agentName}
  MITRE Tactic: ${a.mitreTactic ?? "N/A"}
  MITRE Technique: ${a.mitreTechniqueId ?? "N/A"} — ${a.mitreTechnique ?? "N/A"}
  Previous occurrences of this rule on this agent: ${previousOccurrences}
  Timestamp: ${alert.timestamp.toISOString()}

RELATED RECENT ACTIVITY:
${relatedSummary}`;

    // Step 3: AI Investigation (with cache)
    const invCacheKey = makeCacheKey(AI_MODEL, PROMPT_VERSION, `inv:${contextFingerprint}`);
    const cachedInv = await getCached(invCacheKey);
    if (cachedInv) {
      investigation = cachedInv;
      fromCache = true;
    } else {
      const invPromptFn = getPrompt(PROMPT_VERSION, "investigation");
      const invPrompt = invPromptFn ? invPromptFn(contextBlock) : PROMPTS.v1.investigation(contextBlock);
      const invResult = await callWithRetry(openai, AI_MODEL, invPrompt, retryState);
      investigation = invResult.parsed;
      promptTokensTotal += invResult.promptTokens;
      completionTokensTotal += invResult.completionTokens;
      await setCached(invCacheKey, AI_MODEL, PROMPT_VERSION, investigation, { prompt: invResult.promptTokens, completion: invResult.completionTokens });
    }

    // Step 4: AI Recommendation (with cache, using investigation output as extra context)
    const recContextBlock = `${contextBlock}

INVESTIGATION FINDINGS:
${JSON.stringify(investigation, null, 2)}`;
    const recCacheKey = makeCacheKey(AI_MODEL, PROMPT_VERSION, `rec:${contextFingerprint}`);
    const cachedRec = await getCached(recCacheKey);
    if (cachedRec) {
      recommendation = cachedRec;
    } else {
      const recPromptFn = getPrompt(PROMPT_VERSION, "recommendation");
      const recPrompt = recPromptFn ? recPromptFn(recContextBlock) : PROMPTS.v1.recommendation(recContextBlock);
      const recResult = await callWithRetry(openai, AI_MODEL, recPrompt, retryState);
      recommendation = recResult.parsed;
      promptTokensTotal += recResult.promptTokens;
      completionTokensTotal += recResult.completionTokens;
      await setCached(recCacheKey, AI_MODEL, PROMPT_VERSION, recommendation, { prompt: recResult.promptTokens, completion: recResult.completionTokens });
    }
  }

  // Step 5: Normalise checklist
  const checklist = ((investigation.investigationChecklist ?? []) as any[]).map((item: any, i: number) => ({
    id: `chk_${i}`,
    label: typeof item === "string" ? item : item.label ?? String(item),
    completed: false,
  }));

  // Step 6: IOC extraction (merge AI + regex)
  const aiIocs = (investigation.iocs ?? []) as Array<{ type: string; value: string }>;
  const regexIocs = extractIocs(`${a.description} ${alert.rawLog ?? ""}`);
  const iocMap = new Map<string, { type: string; value: string }>();
  for (const ioc of [...regexIocs, ...aiIocs]) iocMap.set(`${ioc.type}:${ioc.value}`, ioc);
  const iocs = Array.from(iocMap.values()).slice(0, 30);

  const pipelineDurationMs = Date.now() - t0;

  return {
    summary: String(investigation.summary ?? ""),
    threatDescription: String(investigation.threatDescription ?? ""),
    businessImpact: String(investigation.businessImpact ?? ""),
    reasoning: String(investigation.reasoning ?? ""),
    rootCause: String(investigation.rootCause ?? ""),
    mitreExplanation: String(investigation.mitreExplanation ?? ""),
    falsePositiveProbability: Number(investigation.falsePositiveProbability ?? 0),
    confidenceScore: Number(investigation.confidenceScore ?? 0.7),
    investigationSteps: (investigation.investigationSteps ?? []) as string[],
    affectedAssets: (investigation.affectedAssets ?? [a.agentName]) as string[],
    executiveSummary: String(investigation.executiveSummary ?? ""),
    evidence: (investigation.evidence ?? []) as string[],
    investigationChecklist: checklist,
    iocs,
    remediationPlan: (recommendation.remediationPlan ?? []) as string[],
    recommendedActions: (recommendation.recommendedActions ?? []) as string[],
    containmentActions: (recommendation.containmentActions ?? []) as string[],
    analystNotes: String(recommendation.analystNotes ?? ""),
    aiModelUsed: openai ? AI_MODEL : "rule-based-fallback",
    promptVersion: PROMPT_VERSION,
    promptTokens: promptTokensTotal,
    completionTokens: completionTokensTotal,
    totalTokens: promptTokensTotal + completionTokensTotal,
    retryCount: retryState.count,
    pipelineDurationMs,
    fromCache,
    redactedFields,
    previousOccurrences,
  };
}
