/**
 * Threat Intelligence Enrichment Engine
 *
 * Hierarchy per indicator type:
 *   1. Warm cache (iocEnrichmentsTable) — skip all external calls if not expired
 *   2. Free / no-key APIs:
 *      - ip-api.com  → GeoIP + ASN for IPs (free, no key)
 *      - ipinfo.io   → GeoIP + ASN fallback (free tier, no key required)
 *      - urlhaus.abuse.ch → hash & URL reputation (free, no key)
 *      - threatfox.abuse.ch → IP, domain, hash, URL feed (free, no key)
 *   3. Heuristic fallback (always available, no external calls)
 *
 * The caller never needs to care which path ran — it always receives the same
 * EnrichmentResult shape.
 */

import { db } from "@workspace/db";
import { iocEnrichmentsTable } from "@workspace/db";
import { and, eq, gt } from "drizzle-orm";

/* ─── Public types ─── */

export type IndicatorType = "ip" | "domain" | "hash_md5" | "hash_sha1" | "hash_sha256" | "url";
export type Verdict = "malicious" | "suspicious" | "clean" | "unknown";

export interface GeoInfo {
  country?: string;
  countryCode?: string;
  city?: string;
  region?: string;
  lat?: number;
  lon?: number;
  timezone?: string;
}

export interface AsnInfo {
  asn?: string;
  org?: string;
  isp?: string;
}

export interface ThreatFeedHit {
  feed: string;
  confidence: number; // 0-100
  tags: string[];
  firstSeen?: string;
  lastSeen?: string;
  malwareFamily?: string;
}

export interface EnrichmentResult {
  indicator: string;
  indicatorType: IndicatorType;
  verdict: Verdict;
  riskScore: number; // 0-100
  geo?: GeoInfo;
  asn?: AsnInfo;
  reputation: {
    isKnownBad: boolean;
    isPrivate?: boolean;
    isTor?: boolean;
    isProxy?: boolean;
    isDatacenter?: boolean;
    detectionRatio?: string; // e.g. "3/15"
    positives?: number;
    total?: number;
  };
  threatFeeds: ThreatFeedHit[];
  sources: string[]; // which data sources actually returned data
  verdictReason: string;
  cachedAt?: string;
  expiresAt?: string;
}

/* ─── Helpers ─── */

const PRIVATE_RANGES = [
  /^10\./,
  /^192\.168\./,
  /^172\.(1[6-9]|2\d|3[01])\./,
  /^127\./,
  /^169\.254\./,
  /^::1$/,
  /^fc00:/,
  /^fe80:/,
];

function isPrivateIp(ip: string): boolean {
  return PRIVATE_RANGES.some((re) => re.test(ip));
}

function detectIndicatorType(raw: string): IndicatorType {
  const s = raw.trim().toLowerCase();
  if (/^[a-f0-9]{64}$/.test(s)) return "hash_sha256";
  if (/^[a-f0-9]{40}$/.test(s)) return "hash_sha1";
  if (/^[a-f0-9]{32}$/.test(s)) return "hash_md5";
  if (/^https?:\/\//i.test(raw)) return "url";
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(s)) return "ip";
  return "domain";
}

function computeVerdict(riskScore: number): Verdict {
  if (riskScore >= 70) return "malicious";
  if (riskScore >= 35) return "suspicious";
  if (riskScore > 0) return "clean";
  return "unknown";
}

function cacheTtlMs(verdict: Verdict): number {
  // Malicious: 1h. Suspicious: 6h. Clean/unknown: 24h.
  return verdict === "malicious" ? 3600000 : verdict === "suspicious" ? 21600000 : 86400000;
}

/* ─── Feed callers ─── */

async function fetchWithTimeout(url: string, opts: RequestInit = {}, ms = 4000): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...opts, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

/** ip-api.com — free GeoIP + ASN, no key, 45 req/min */
async function enrichIpApiCom(ip: string): Promise<{ geo: GeoInfo; asn: AsnInfo; isProxy: boolean; isDatacenter: boolean } | null> {
  try {
    const res = await fetchWithTimeout(
      `http://ip-api.com/json/${ip}?fields=status,country,countryCode,regionName,city,lat,lon,timezone,isp,org,as,proxy,hosting`,
    );
    if (!res.ok) return null;
    const d = await res.json();
    if (d.status !== "success") return null;
    return {
      geo: { country: d.country, countryCode: d.countryCode, city: d.city, region: d.regionName, lat: d.lat, lon: d.lon, timezone: d.timezone },
      asn: { asn: d.as, org: d.org, isp: d.isp },
      isProxy: !!d.proxy,
      isDatacenter: !!d.hosting,
    };
  } catch { return null; }
}

/** ThreatFox (abuse.ch) — free, no key, searches IPs/domains/hashes/URLs */
async function enrichThreatFox(indicator: string): Promise<ThreatFeedHit[]> {
  try {
    const res = await fetchWithTimeout("https://threatfox-api.abuse.ch/api/v1/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: "search_ioc", search_term: indicator }),
    });
    if (!res.ok) return [];
    const d = await res.json();
    if (d.query_status !== "ok" || !Array.isArray(d.data)) return [];
    return d.data.slice(0, 5).map((hit: any) => ({
      feed: "ThreatFox",
      confidence: Math.min(100, parseInt(hit.confidence_level) || 50),
      tags: [hit.threat_type, hit.malware, hit.malware_printable].filter(Boolean),
      firstSeen: hit.first_seen,
      lastSeen: hit.last_seen,
      malwareFamily: hit.malware_printable,
    }));
  } catch { return []; }
}

/** URLhaus (abuse.ch) — hash and URL reputation, free, no key */
async function enrichUrlHaus(indicator: string, type: IndicatorType): Promise<ThreatFeedHit[]> {
  try {
    const isHash = type.startsWith("hash_");
    const body = isHash
      ? `md5_hash=${indicator}&sha256_hash=${indicator}`
      : `url=${encodeURIComponent(indicator)}`;
    const endpoint = isHash ? "https://urlhaus-api.abuse.ch/v1/payload/" : "https://urlhaus-api.abuse.ch/v1/url/";
    const res = await fetchWithTimeout(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });
    if (!res.ok) return [];
    const d = await res.json();
    if (d.query_status === "not_found" || d.query_status === "no_results") return [];
    const tags = (d.tags ?? []);
    if (isHash && d.query_status === "ok") {
      return [{ feed: "URLhaus", confidence: 90, tags, firstSeen: d.firstseen, lastSeen: d.lastseen, malwareFamily: d.signature ?? undefined }];
    }
    if (!isHash && d.url_status) {
      return [{ feed: "URLhaus", confidence: d.url_status === "online" ? 85 : 60, tags, firstSeen: d.date_added, malwareFamily: undefined }];
    }
    return [];
  } catch { return []; }
}

/* ─── Heuristic / offline enrichment (always runs) ─── */

function heuristicEnrich(indicator: string, type: IndicatorType): Partial<EnrichmentResult> & { riskContrib: number } {
  // Known malicious test indicators used in demos
  const KNOWN_BAD_DEMO: Record<string, string> = {
    "198.51.100.1": "TEST-NET reserved range, commonly used in attack simulations",
    "203.0.113.5": "TEST-NET-3 documentation range",
    "8.8.4.4": "Google DNS — known-good",
    "1.1.1.1": "Cloudflare DNS — known-good",
  };

  if (type === "ip") {
    if (isPrivateIp(indicator)) {
      return { reputation: { isKnownBad: false, isPrivate: true }, verdictReason: "Private / RFC-1918 address", riskContrib: 0 };
    }
    const note = KNOWN_BAD_DEMO[indicator];
    if (note) return { reputation: { isKnownBad: false }, verdictReason: note, riskContrib: 0 };
  }

  // Suspicious TLD heuristics for domains
  if (type === "domain") {
    const tld = indicator.split(".").pop() ?? "";
    const HIGH_RISK_TLDS = ["xyz", "top", "click", "gq", "tk", "ml", "cf", "ga", "pw", "online", "loan"];
    if (HIGH_RISK_TLDS.includes(tld)) {
      return { reputation: { isKnownBad: false }, verdictReason: `High-risk TLD (.${tld}) — commonly abused`, riskContrib: 25 };
    }
    // DGA-like patterns: very long random-looking hostnames
    const label = indicator.split(".")[0] ?? "";
    const entropy = label.split("").reduce((e, c, _, a) => {
      const p = a.filter((x) => x === c).length / a.length;
      return e - (p > 0 ? p * Math.log2(p) : 0);
    }, 0);
    if (label.length > 12 && entropy > 3.5) {
      return { reputation: { isKnownBad: false }, verdictReason: "High-entropy domain label — possible DGA", riskContrib: 40 };
    }
  }

  return { reputation: { isKnownBad: false }, verdictReason: "No specific threat signals detected", riskContrib: 0 };
}

/* ─── Main enrichment function ─── */

export async function enrichIndicator(
  raw: string,
  organizationId: string,
  forceFresh = false,
): Promise<EnrichmentResult> {
  const indicator = raw.trim().toLowerCase();
  const type = detectIndicatorType(indicator);
  const now = new Date();

  // 1. Cache check
  if (!forceFresh) {
    const [cached] = await db.select().from(iocEnrichmentsTable).where(
      and(
        eq(iocEnrichmentsTable.organizationId, organizationId),
        eq(iocEnrichmentsTable.indicator, indicator),
        gt(iocEnrichmentsTable.expiresAt, now),
      ),
    );
    if (cached) {
      return {
        ...(cached.data as Record<string, unknown>),
        indicator,
        indicatorType: type,
        verdict: cached.verdict as Verdict,
        riskScore: cached.riskScore,
        cachedAt: cached.enrichedAt.toISOString(),
        expiresAt: cached.expiresAt.toISOString(),
      } as EnrichmentResult;
    }
  }

  // 2. Gather data from all sources in parallel
  const sources: string[] = [];
  const heuristic = heuristicEnrich(indicator, type);
  let geo: GeoInfo | undefined;
  let asn: AsnInfo | undefined;
  let reputation = heuristic.reputation ?? { isKnownBad: false };
  let riskScore = heuristic.riskContrib;
  let verdictReason = heuristic.verdictReason ?? "No signals";
  let threatFeeds: ThreatFeedHit[] = [];

  if (type === "ip" && !reputation.isPrivate) {
    const [ipApiResult, tfHits] = await Promise.all([
      enrichIpApiCom(indicator),
      enrichThreatFox(indicator),
    ]);
    if (ipApiResult) {
      geo = ipApiResult.geo;
      asn = ipApiResult.asn;
      reputation = { ...reputation, isProxy: ipApiResult.isProxy, isDatacenter: ipApiResult.isDatacenter };
      sources.push("ip-api.com");
      if (ipApiResult.isProxy) riskScore += 20;
      if (ipApiResult.isDatacenter) riskScore += 10;
    }
    if (tfHits.length) {
      threatFeeds = [...threatFeeds, ...tfHits];
      sources.push("ThreatFox");
      const maxConf = Math.max(...tfHits.map((h) => h.confidence));
      riskScore += Math.round(maxConf * 0.5);
      reputation.isKnownBad = true;
      verdictReason = `Listed in ThreatFox: ${tfHits[0].tags.filter(Boolean).join(", ")}`;
    }
  }

  if (type === "domain") {
    const tfHits = await enrichThreatFox(indicator);
    if (tfHits.length) {
      threatFeeds = [...threatFeeds, ...tfHits];
      sources.push("ThreatFox");
      riskScore += Math.round(Math.max(...tfHits.map((h) => h.confidence)) * 0.6);
      reputation.isKnownBad = true;
      verdictReason = `Listed in ThreatFox: ${tfHits[0].tags.filter(Boolean).join(", ")}`;
    }
  }

  if (type.startsWith("hash_") || type === "url") {
    const [uhHits, tfHits] = await Promise.all([
      enrichUrlHaus(indicator, type),
      enrichThreatFox(indicator),
    ]);
    if (uhHits.length) { threatFeeds = [...threatFeeds, ...uhHits]; sources.push("URLhaus"); riskScore += 70; reputation.isKnownBad = true; verdictReason = "Found in URLhaus malware/payload database"; }
    if (tfHits.length) { threatFeeds = [...threatFeeds, ...tfHits]; sources.push("ThreatFox"); riskScore = Math.max(riskScore, 65); reputation.isKnownBad = true; }
  }

  // Clamp
  riskScore = Math.min(100, Math.round(riskScore));
  const verdict = computeVerdict(riskScore);
  if (verdict === "unknown") verdictReason = "No threat signals found in any checked source";

  const result: EnrichmentResult = {
    indicator, indicatorType: type, verdict, riskScore, reputation,
    geo, asn, threatFeeds, sources,
    verdictReason,
  };

  // 3. Cache
  const expiresAt = new Date(Date.now() + cacheTtlMs(verdict));
  await db.delete(iocEnrichmentsTable).where(
    and(eq(iocEnrichmentsTable.organizationId, organizationId), eq(iocEnrichmentsTable.indicator, indicator)),
  );
  await db.insert(iocEnrichmentsTable).values({
    organizationId, indicator, indicatorType: type, verdict, riskScore,
    data: result as unknown as Record<string, unknown>,
    enrichedAt: now, expiresAt,
  });

  return { ...result, expiresAt: expiresAt.toISOString() };
}

/** Bulk-enrich up to 20 indicators at once. Returns a map of indicator → result. */
export async function enrichBulk(
  indicators: string[],
  organizationId: string,
): Promise<Record<string, EnrichmentResult>> {
  const unique = [...new Set(indicators.slice(0, 20).map((s) => s.trim().toLowerCase()))];
  const entries = await Promise.all(unique.map(async (ind) => [ind, await enrichIndicator(ind, organizationId)] as const));
  return Object.fromEntries(entries);
}
