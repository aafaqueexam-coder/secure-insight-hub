/**
 * Notification Dispatch Engine
 *
 * Channels implemented:
 *   slack   — Incoming Webhooks (POST JSON)
 *   teams   — Adaptive Card via Incoming Webhook
 *   email   — Nodemailer over SMTP (or logs to console when unconfigured)
 *   browser — Web Push API via web-push library (or console fallback)
 *   digest  — Aggregated daily summary, delivered via the other channels
 *
 * Entry points:
 *   dispatchNotification(orgId, eventType, payload) — call from any route
 *   runDailyDigest(orgId) — called by a cron job or manual trigger
 */

import { db } from "@workspace/db";
import {
  notificationChannelsTable, notificationRulesTable,
  notificationLogsTable, pushSubscriptionsTable,
} from "@workspace/db";
import { and, eq } from "drizzle-orm";

/* ─── Types ─── */
export interface NotificationPayload {
  title: string;
  body: string;
  severity?: "low" | "medium" | "high" | "critical";
  resourceType?: string;
  resourceId?: string;
  url?: string;
  details?: Record<string, unknown>;
}

interface Channel {
  id: string;
  type: string;
  name: string;
  config: Record<string, unknown>;
}

/* ─── Severity ordering ─── */
const SEV_ORDER = { low: 0, medium: 1, high: 2, critical: 3 };
function severityMeetsThreshold(eventSev: string | undefined, minSev: string): boolean {
  if (!eventSev) return true; // non-alert events always pass
  return (SEV_ORDER[eventSev as keyof typeof SEV_ORDER] ?? 0) >= (SEV_ORDER[minSev as keyof typeof SEV_ORDER] ?? 0);
}

/* ─── Pattern matching ─── */
function matchesPattern(eventType: string, pattern: string): boolean {
  if (pattern === "*") return true;
  if (pattern.endsWith(".*")) return eventType.startsWith(pattern.slice(0, -2));
  return eventType === pattern;
}

/* ─── Slack ─── */
async function dispatchSlack(channel: Channel, payload: NotificationPayload): Promise<{ ok: boolean; latencyMs: number; error?: string }> {
  const webhookUrl = channel.config.webhookUrl as string;
  if (!webhookUrl) return { ok: false, latencyMs: 0, error: "webhookUrl not configured" };

  const colorMap: Record<string, string> = { critical: "#ef4444", high: "#f97316", medium: "#eab308", low: "#3b82f6" };
  const color = colorMap[payload.severity ?? "low"] ?? "#6b7280";
  const t0 = Date.now();
  try {
    const res = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        attachments: [{
          color,
          fallback: `${payload.title}: ${payload.body}`,
          title: payload.title,
          text: payload.body,
          footer: "SentinelIQ",
          ts: Math.floor(Date.now() / 1000),
          ...(payload.url ? { title_link: payload.url } : {}),
        }],
      }),
    });
    return { ok: res.ok, latencyMs: Date.now() - t0, error: res.ok ? undefined : `HTTP ${res.status}` };
  } catch (err: any) {
    return { ok: false, latencyMs: Date.now() - t0, error: err.message };
  }
}

/* ─── Microsoft Teams ─── */
async function dispatchTeams(channel: Channel, payload: NotificationPayload): Promise<{ ok: boolean; latencyMs: number; error?: string }> {
  const webhookUrl = channel.config.webhookUrl as string;
  if (!webhookUrl) return { ok: false, latencyMs: 0, error: "webhookUrl not configured" };

  const t0 = Date.now();
  try {
    const res = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: "message",
        attachments: [{
          contentType: "application/vnd.microsoft.card.adaptive",
          content: {
            type: "AdaptiveCard",
            version: "1.4",
            body: [
              { type: "TextBlock", text: payload.title, weight: "Bolder", size: "Medium" },
              { type: "TextBlock", text: payload.body, wrap: true },
              ...(payload.severity ? [{ type: "TextBlock", text: `Severity: ${payload.severity.toUpperCase()}`, color: payload.severity === "critical" || payload.severity === "high" ? "Attention" : "Default" }] : []),
            ],
            ...(payload.url ? { actions: [{ type: "Action.OpenUrl", title: "View in SentinelIQ", url: payload.url }] } : {}),
          },
        }],
      }),
    });
    return { ok: res.ok, latencyMs: Date.now() - t0, error: res.ok ? undefined : `HTTP ${res.status}` };
  } catch (err: any) {
    return { ok: false, latencyMs: Date.now() - t0, error: err.message };
  }
}

/* ─── Email ─── */
async function dispatchEmail(channel: Channel, payload: NotificationPayload): Promise<{ ok: boolean; latencyMs: number; error?: string }> {
  const config = channel.config as { to?: string[]; smtpHost?: string; smtpPort?: number; smtpUser?: string; smtpPass?: string; fromAddress?: string };
  const recipients = config.to ?? [];
  if (!recipients.length) return { ok: false, latencyMs: 0, error: "No recipients configured" };

  const t0 = Date.now();
  try {
    // Try nodemailer if SMTP is configured, else log to console (dev/demo mode)
    if (config.smtpHost && config.smtpUser && config.smtpPass) {
      const nodemailer = await import("nodemailer").catch(() => null);
      if (!nodemailer) { console.log(`[Email] Would send to ${recipients.join(", ")}: ${payload.title}`); return { ok: true, latencyMs: 1 }; }
      const transporter = nodemailer.default.createTransport({
        host: config.smtpHost, port: config.smtpPort ?? 587, secure: (config.smtpPort ?? 587) === 465,
        auth: { user: config.smtpUser, pass: config.smtpPass },
      });
      await transporter.sendMail({
        from: config.fromAddress ?? config.smtpUser,
        to: recipients.join(", "),
        subject: `[SentinelIQ] ${payload.title}`,
        text: payload.body,
        html: `<h2>${payload.title}</h2><p>${payload.body}</p>${payload.url ? `<p><a href="${payload.url}">View in SentinelIQ</a></p>` : ""}`,
      });
    } else {
      // Demo/dev: log to console
      console.log(`[Email → ${recipients.join(", ")}] ${payload.title}\n${payload.body}`);
    }
    return { ok: true, latencyMs: Date.now() - t0 };
  } catch (err: any) {
    return { ok: false, latencyMs: Date.now() - t0, error: err.message };
  }
}

/* ─── Browser push ─── */
async function dispatchBrowser(channel: Channel, orgId: string, payload: NotificationPayload): Promise<{ ok: boolean; latencyMs: number; error?: string; sent: number }> {
  const t0 = Date.now();
  const subs = await db.select().from(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.organizationId, orgId));
  if (!subs.length) return { ok: true, latencyMs: 1, sent: 0 };

  let sent = 0;
  let lastError: string | undefined;

  for (const sub of subs) {
    try {
      const webpush = await import("web-push").catch(() => null);
      if (!webpush) {
        // No web-push lib — emit a server-sent event instead (SSE handled elsewhere)
        console.log(`[Browser Push] ${payload.title}: ${payload.body}`);
        sent++;
        continue;
      }
      const vapidPublic = process.env.VAPID_PUBLIC_KEY;
      const vapidPrivate = process.env.VAPID_PRIVATE_KEY;
      const vapidSubject = process.env.VAPID_SUBJECT ?? "mailto:admin@sentineliq.local";
      if (vapidPublic && vapidPrivate) {
        webpush.default.setVapidDetails(vapidSubject, vapidPublic, vapidPrivate);
        await webpush.default.sendNotification(
          { endpoint: sub.endpoint, keys: { p256dh: sub.p256dhKey, auth: sub.authKey } },
          JSON.stringify({ title: payload.title, body: payload.body, url: payload.url }),
        );
        sent++;
      }
    } catch (err: any) {
      lastError = err.message;
      // Delete stale subscription (410 Gone)
      if (err.statusCode === 410) {
        await db.delete(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.id, sub.id));
      }
    }
  }
  return { ok: sent > 0 || !lastError, latencyMs: Date.now() - t0, sent, error: lastError };
}

/* ─── Log delivery result ─── */
async function logDelivery(orgId: string, channelId: string, eventType: string, payload: NotificationPayload, result: { ok: boolean; latencyMs: number; error?: string }) {
  await db.insert(notificationLogsTable).values({
    organizationId: orgId,
    channelId,
    eventType,
    summary: payload.title,
    status: result.ok ? "sent" : "failed",
    errorMessage: result.error ?? null,
    latencyMs: result.latencyMs,
  });
}

/* ─── Main dispatch ─── */
export async function dispatchNotification(orgId: string, eventType: string, payload: NotificationPayload): Promise<void> {
  try {
    // Find all enabled rules that match this event
    const rules = await db.select({
      rule: notificationRulesTable,
      channel: notificationChannelsTable,
    }).from(notificationRulesTable)
      .innerJoin(notificationChannelsTable, eq(notificationRulesTable.channelId, notificationChannelsTable.id))
      .where(and(
        eq(notificationRulesTable.organizationId, orgId),
        eq(notificationRulesTable.enabled, true),
        eq(notificationChannelsTable.enabled, true),
      ));

    const matched = rules.filter((r) =>
      matchesPattern(eventType, r.rule.eventPattern) &&
      severityMeetsThreshold(payload.severity, r.rule.minSeverity)
    );

    if (!matched.length) return;

    // Dispatch to each matched channel (parallel, fire-and-forget style)
    await Promise.allSettled(matched.map(async ({ channel: c }) => {
      let result: { ok: boolean; latencyMs: number; error?: string };
      const ch = { ...c, config: c.config as Record<string, unknown> };
      if (c.type === "slack") result = await dispatchSlack(ch, payload);
      else if (c.type === "teams") result = await dispatchTeams(ch, payload);
      else if (c.type === "email") result = await dispatchEmail(ch, payload);
      else if (c.type === "browser") {
        const r = await dispatchBrowser(ch, orgId, payload);
        result = { ok: r.ok, latencyMs: r.latencyMs, error: r.error };
      }
      else result = { ok: false, latencyMs: 0, error: `Unknown channel type: ${c.type}` };
      await logDelivery(orgId, c.id, eventType, payload, result);
    }));
  } catch (err) {
    console.error("[dispatchNotification] Error:", err);
  }
}

/* ─── Daily digest ─── */
export async function runDailyDigest(orgId: string): Promise<void> {
  // Find digest channels
  const digestChannels = await db.select().from(notificationChannelsTable).where(
    and(eq(notificationChannelsTable.organizationId, orgId), eq(notificationChannelsTable.type, "digest"), eq(notificationChannelsTable.enabled, true))
  );
  if (!digestChannels.length) return;

  // Aggregate last 24h of delivery logs for the digest summary
  const since = new Date(Date.now() - 86400000);
  const { alertsTable, incidentsTable, alertAnalysesTable } = await import("@workspace/db");
  const { sql, gte } = await import("drizzle-orm");

  const [alertStats] = await db.select({
    total: sql<number>`count(*)::int`,
    critical: sql<number>`count(*) filter (where severity = 'critical')::int`,
    resolved: sql<number>`count(*) filter (where status = 'resolved')::int`,
  }).from(alertsTable).where(and(eq(alertsTable.organizationId, orgId), gte(alertsTable.timestamp, since)));

  const [incidentStats] = await db.select({
    total: sql<number>`count(*)::int`,
    resolved: sql<number>`count(*) filter (where status = 'resolved' or status = 'closed')::int`,
  }).from(incidentsTable).where(and(eq(incidentsTable.organizationId, orgId), gte(incidentsTable.createdAt, since)));

  const [aiStats] = await db.select({
    pending: sql<number>`count(*) filter (where review_status = 'pending_review')::int`,
  }).from(alertAnalysesTable).where(eq(alertAnalysesTable.organizationId, orgId));

  const a = alertStats ?? { total: 0, critical: 0, resolved: 0 };
  const i = incidentStats ?? { total: 0, resolved: 0 };
  const ai = aiStats ?? { pending: 0 };

  const payload: NotificationPayload = {
    title: `SentinelIQ Daily Digest — ${new Date().toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}`,
    body: [
      `📊 Alerts: ${a.total} total, ${a.critical} critical, ${a.resolved} resolved`,
      `🚨 Incidents: ${i.total} opened, ${i.resolved} resolved`,
      `🤖 AI Reviews: ${ai.pending} pending analyst review`,
    ].join("\n"),
    details: { alertTotal: a.total, alertCritical: a.critical, incidentTotal: i.total, aiPending: ai.pending },
  };

  for (const ch of digestChannels) {
    const config = ch.config as Record<string, unknown>;
    const deliveryType = (config.deliveryVia as string) ?? "email";
    // Deliver via the configured sub-channel type
    let result: { ok: boolean; latencyMs: number; error?: string } = { ok: false, latencyMs: 0, error: "No delivery method" };
    if (deliveryType === "slack") result = await dispatchSlack({ ...ch, config }, payload);
    else if (deliveryType === "teams") result = await dispatchTeams({ ...ch, config }, payload);
    else result = await dispatchEmail({ ...ch, config }, payload);
    await logDelivery(orgId, ch.id, "digest.daily", payload, result);
  }
}
