import cron from "node-cron";
import { runRuleTuningJob } from "./ruleTuningJob";
import { logger } from "../lib/logger";
import { enqueuePendingAlerts, drainQueue, queueStats } from "../lib/analysisQueue";
import { runDailyDigest } from "../lib/notificationDispatch";
import { cacheFlushPattern } from "../lib/cache";
import { db } from "@workspace/db";
import { wazuhConnectionsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { syncWazuhConnection } from "../lib/wazuhSync";
import { aiResponseCacheTable } from "@workspace/db";
import { lt } from "drizzle-orm";

// Orgs to run scheduled jobs for.
// In production this should be fetched from the DB.
const ORGS = (process.env.SCHEDULED_ORGS ?? "demo-org").split(",").map((s) => s.trim());

export function startScheduler(): void {
  // ── Every 2 minutes: drain AI analysis queue for unanalysed critical/high alerts
  cron.schedule("*/2 * * * *", async () => {
    for (const orgId of ORGS) {
      try {
        const queued = await enqueuePendingAlerts(orgId);
        if (queued > 0) logger.info({ orgId, queued }, "AI queue: auto-enqueued unanalysed alerts");
      } catch (err) {
        logger.error({ err, orgId }, "AI queue: auto-enqueue failed");
      }
    }
  });

  // ── Every 15 minutes: Wazuh sync for all active connections
  cron.schedule("*/15 * * * *", async () => {
    try {
      const connections = await db.select({ id: wazuhConnectionsTable.id }).from(wazuhConnectionsTable).where(eq(wazuhConnectionsTable.status, "connected"));
      for (const conn of connections) {
        try {
          await syncWazuhConnection(conn.id);
        } catch (err) {
          logger.error({ err, connectionId: conn.id }, "Scheduled Wazuh sync failed");
        }
      }
    } catch (err) {
      logger.error({ err }, "Wazuh sync schedule failed");
    }
  });

  // ── Every hour: flush expired Redis cache entries
  cron.schedule("0 * * * *", async () => {
    try {
      await cacheFlushPattern("dashboard:*");
      logger.debug("Cache flush: dashboard keys evicted");
    } catch (err) {
      logger.error({ err }, "Cache flush failed");
    }
  });

  // ── Every 6 hours: evict expired AI response cache entries from DB
  cron.schedule("0 */6 * * *", async () => {
    try {
      const deleted = await db.delete(aiResponseCacheTable).where(lt(aiResponseCacheTable.expiresAt, new Date())).returning({ id: aiResponseCacheTable.id });
      if (deleted.length > 0) logger.info({ deleted: deleted.length }, "AI cache: evicted expired entries");
    } catch (err) {
      logger.error({ err }, "AI cache eviction failed");
    }
  });

  // ── Daily at 02:00: rule tuning analysis
  cron.schedule("0 2 * * *", async () => {
    logger.info("Scheduled rule tuning job triggered (daily 02:00)");
    for (const orgId of ORGS) {
      try {
        await runRuleTuningJob(orgId, "scheduler");
      } catch (err) {
        logger.error({ err, orgId }, "Scheduled rule tuning failed");
      }
    }
  });

  // ── Daily at 08:00: daily digest notifications
  cron.schedule("0 8 * * *", async () => {
    logger.info("Daily digest triggered (08:00)");
    for (const orgId of ORGS) {
      try {
        await runDailyDigest(orgId);
      } catch (err) {
        logger.error({ err, orgId }, "Daily digest failed");
      }
    }
  });

  logger.info({
    jobs: ["AI queue (*/2m)", "Wazuh sync (*/15m)", "Cache flush (hourly)", "AI cache eviction (*/6h)", "Rule tuning (02:00)", "Daily digest (08:00)"],
  }, "Scheduler started");
}

// Called on SIGTERM / SIGINT — let in-flight AI jobs finish
export async function stopScheduler(): Promise<void> {
  logger.info("Scheduler stopping — draining AI queue...");
  await drainQueue(30000);
  logger.info({ stats: queueStats() }, "AI queue drained");
}
