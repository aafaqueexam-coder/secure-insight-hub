import { db } from "@workspace/db";
import { alertsTable, ruleTuningRecommendationsTable } from "@workspace/db";
import { eq, and, gte, sql } from "drizzle-orm";
import OpenAI from "openai";
import { logger } from "../lib/logger";

export interface RuleTuningRecommendation {
  ruleId: string;
  ruleName: string;
  action: "suppress" | "raise_threshold" | "tune_frequency" | "investigate_fp" | "keep";
  priority: "high" | "medium" | "low";
  reason: string;
  suggestedChange: string;
  // 0–100: composite score of noise volume, FP rate, and analyst workload impact
  riskScore: number;
  // Plain-language estimate of the benefit if the suggestion is applied
  expectedImprovement: string;
  metrics: {
    totalAlerts: number;
    falsePositiveRatio: number;
    alertsPerDay: number;
    avgResolutionHours: number | null;
    uniqueSourceIps: number;
    uniqueAgents: number;
    resolvedCount: number;
  };
}

function buildFallbackRecommendations(enriched: any[]): RuleTuningRecommendation[] {
  return enriched.map((m) => {
    let action: RuleTuningRecommendation["action"] = "keep";
    let priority: RuleTuningRecommendation["priority"] = "low";
    let reason = "";
    let suggestedChange = "";

    if (m.falsePositiveRatio > 0.5) {
      action = "investigate_fp";
      priority = "high";
      reason = `${(m.falsePositiveRatio * 100).toFixed(0)}% of alerts were marked as false positives. This rule is generating significant noise with little investigative value.`;
      suggestedChange = `Audit rule conditions and add exclusions for known-good source IPs, internal subnets, or specific agent groups.`;
    } else if (m.alertsPerDay > 20) {
      action = "raise_threshold";
      priority = "high";
      reason = `Rule fires ${m.alertsPerDay.toFixed(1)} times per day on average, creating high analyst workload and alert fatigue.`;
      suggestedChange = `Add rate-limiting: suppress repeated triggers from the same source IP within a 10-minute window.`;
    } else if (m.alertsPerDay > 5 && m.falsePositiveRatio > 0.2) {
      action = "tune_frequency";
      priority = "medium";
      reason = `Moderate noise (${m.alertsPerDay.toFixed(1)}/day) combined with ${(m.falsePositiveRatio * 100).toFixed(0)}% false positive rate reduces signal quality.`;
      suggestedChange = `Review rule frequency configuration and consider adding context-based filters (time of day, user type).`;
    } else if (m.alertsPerDay < 0.1 && m.totalAlerts > 0) {
      action = "keep";
      priority = "low";
      reason = `Low-frequency rule (${m.totalAlerts} alerts in 30 days) but alerts are likely high-value detections worth keeping.`;
      suggestedChange = `No changes needed. Monitor to ensure the rule continues to fire correctly.`;
    } else {
      reason = `Rule is well-calibrated: ${m.alertsPerDay.toFixed(1)} alerts/day with ${(m.falsePositiveRatio * 100).toFixed(0)}% false positive rate.`;
      suggestedChange = `No changes needed at this time.`;
    }

    const fpWeight = m.falsePositiveRatio * 40;
    const volumeWeight = Math.min(m.alertsPerDay / 50, 1) * 40;
    const priorityWeight = priority === "high" ? 20 : priority === "medium" ? 10 : 0;
    const riskScore = Math.round(fpWeight + volumeWeight + priorityWeight);

    const expectedImprovement =
      action === "suppress" ? "Eliminates all noise from this rule; verify no true positives are lost first." :
      action === "raise_threshold" ? `Estimated ${Math.round(m.alertsPerDay * 0.6 * 30)} fewer alerts over the next 30 days.` :
      action === "tune_frequency" ? `Estimated ${Math.round(m.falsePositiveRatio * m.totalAlerts)} fewer false positives over 30 days.` :
      action === "investigate_fp" ? "Resolving root cause could reduce FP rate to below 10%, saving significant analyst time." :
      "No improvement needed — rule is performing well.";

    return {
      ruleId: m.ruleId,
      ruleName: m.ruleName,
      action,
      priority,
      reason,
      suggestedChange,
      riskScore,
      expectedImprovement,
      metrics: {
        totalAlerts: m.totalAlerts,
        falsePositiveRatio: m.falsePositiveRatio,
        alertsPerDay: m.alertsPerDay,
        avgResolutionHours: m.avgResolutionHours,
        uniqueSourceIps: m.uniqueSourceIps,
        uniqueAgents: m.uniqueAgents,
        resolvedCount: m.resolvedCount,
      },
    };
  });
}

export async function runRuleTuningJob(
  orgId: string = "demo-org",
  triggeredBy: "scheduler" | "manual" = "scheduler",
): Promise<typeof ruleTuningRecommendationsTable.$inferSelect> {
  const windowDays = 30;
  const since = new Date(Date.now() - windowDays * 24 * 60 * 60 * 1000);

  logger.info({ orgId, triggeredBy }, "Rule tuning job started");

  const jobStart = new Date();

  const raw = await db
    .select({
      ruleId: alertsTable.ruleId,
      ruleName: alertsTable.ruleName,
      totalAlerts: sql<number>`count(*)::int`,
      falsePositives: sql<number>`count(*) filter (where false_positive = true)::int`,
      resolvedCount: sql<number>`count(*) filter (where status = 'resolved')::int`,
      avgResolutionSeconds: sql<number>`avg(extract(epoch from (updated_at - timestamp))) filter (where status = 'resolved')`,
      uniqueSourceIps: sql<number>`count(distinct source_ip)::int`,
      uniqueAgents: sql<number>`count(distinct agent_id)::int`,
    })
    .from(alertsTable)
    .where(and(eq(alertsTable.organizationId, orgId), gte(alertsTable.timestamp, since)))
    .groupBy(alertsTable.ruleId, alertsTable.ruleName);

  const totalAlertsAnalyzed = raw.reduce((s, r) => s + r.totalAlerts, 0);

  const enriched = raw.map((m) => ({
    ruleId: m.ruleId,
    ruleName: m.ruleName,
    totalAlerts: m.totalAlerts,
    falsePositives: m.falsePositives,
    resolvedCount: m.resolvedCount,
    falsePositiveRatio:
      m.totalAlerts > 0 ? parseFloat((m.falsePositives / m.totalAlerts).toFixed(3)) : 0,
    alertsPerDay: parseFloat((m.totalAlerts / windowDays).toFixed(2)),
    avgResolutionHours:
      m.avgResolutionSeconds != null
        ? parseFloat((m.avgResolutionSeconds / 3600).toFixed(2))
        : null,
    uniqueSourceIps: m.uniqueSourceIps,
    uniqueAgents: m.uniqueAgents,
  }));

  let recommendations: RuleTuningRecommendation[];
  let aiModelUsed: string | null = null;

  const openai = process.env.OPENAI_API_KEY
    ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
    : null;

  if (openai && enriched.length > 0) {
    try {
      const systemPrompt = `You are a Wazuh SIEM rule tuning expert. Analyze alert aggregation metrics and return structured tuning recommendations as JSON.

For each rule, choose an action:
- "suppress" — disable or severely limit (extremely noisy, near-zero true positive rate)
- "raise_threshold" — increase detection threshold to reduce volume
- "tune_frequency" — add rate limiting or time-window deduplication
- "investigate_fp" — high false positive rate, needs immediate review
- "keep" — well-calibrated, no changes needed

Thresholds to guide you:
- falsePositiveRatio > 0.6 → investigate_fp or suppress
- alertsPerDay > 20 → raise_threshold or suppress
- alertsPerDay > 5 AND falsePositiveRatio > 0.25 → tune_frequency
- avgResolutionHours < 0.2 for high volume → likely auto-resolved false positives`;

      const userPrompt = `Analyze these Wazuh rule metrics from the past ${windowDays} days.

Rule metrics:
${JSON.stringify(enriched, null, 2)}

Return a JSON object with a "recommendations" array. Each element must have:
- ruleId (string)
- ruleName (string)  
- action ("suppress"|"raise_threshold"|"tune_frequency"|"investigate_fp"|"keep")
- priority ("high"|"medium"|"low")
- reason (1-2 sentences explaining the finding)
- suggestedChange (specific actionable Wazuh config change)
- riskScore (number 0-100: composite of FP rate, daily volume, and priority severity)
- expectedImprovement (string: plain-language estimate of benefit if suggestion is applied)
- metrics (object with totalAlerts, falsePositiveRatio, alertsPerDay, avgResolutionHours, uniqueSourceIps, uniqueAgents, resolvedCount)`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        response_format: { type: "json_object" },
      });

      const parsed = JSON.parse(completion.choices[0].message.content ?? "{}");
      recommendations = Array.isArray(parsed) ? parsed : (parsed.recommendations ?? []);
      aiModelUsed = "gpt-4o-mini";
    } catch (aiErr) {
      logger.warn({ err: aiErr }, "OpenAI call failed, falling back to rule-based analysis");
      recommendations = buildFallbackRecommendations(enriched);
    }
  } else {
    recommendations = buildFallbackRecommendations(enriched);
  }

  const [saved] = await db
    .insert(ruleTuningRecommendationsTable)
    .values({
      organizationId: orgId,
      status: "completed",
      jobRunAt: jobStart,
      aggregationWindowDays: windowDays,
      totalAlertsAnalyzed,
      recommendations: JSON.stringify(recommendations),
      rawMetrics: JSON.stringify(enriched),
      aiModelUsed,
      triggeredBy,
    })
    .returning();

  logger.info(
    { orgId, totalAlertsAnalyzed, ruleCount: raw.length, aiUsed: !!aiModelUsed },
    "Rule tuning job completed",
  );

  return saved;
}
