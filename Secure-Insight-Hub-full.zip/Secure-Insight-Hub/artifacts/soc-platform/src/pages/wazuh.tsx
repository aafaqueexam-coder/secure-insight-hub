import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { format, formatDistanceToNow } from "date-fns";
import {
  Shield, Server, CheckCircle2, XCircle, AlertTriangle, RefreshCw,
  Plus, Trash2, Loader2, Wifi, WifiOff, Activity, Lock, FileSearch,
  Crosshair, Bug, Zap, ChevronRight, Eye, ToggleLeft, ToggleRight,
  Database, Clock,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ─── Types ─── */
interface Connection {
  id: string; name: string; apiUrl: string; username: string; status: string;
  syncAlerts: boolean; syncAgents: boolean; syncVulnerabilities: boolean; syncFim: boolean;
  syncInterval: number; lastSyncAt: string | null; lastSyncStatus: string | null;
  lastErrorAt: string | null; lastErrorMessage: string | null; agentCount: number | null;
}
interface Agent { id: string; name: string; ip: string; status: string; os?: { name?: string }; version?: string; lastKeepAlive?: string; }
interface Rule { id: number; level: number; description: string; groups: string[]; details?: { mitre?: { id?: string[]; tactic?: string[] } }; }
interface MitreTechnique { id: string; name: string; tactics?: string[]; }
interface FimEvent { agentId?: string; agentName?: string; type: string; path: string; md5After?: string | null; sha256After?: string | null; eventTimestamp: string; }
interface SyncResult { alertsSynced: number; agentsSynced: number; vulnerabilitiesSynced: number; fimEventsSynced: number; rulesSynced: number; mitreTechniquesSynced: number; managerInfo: Record<string, unknown> | null; errors: string[]; durationMs: number; }

/* ─── Status badge ─── */
function ConnStatus({ status }: { status: string }) {
  const meta: Record<string, { label: string; chip: string; icon: typeof Wifi }> = {
    connected: { label: "Connected", chip: "border-emerald-500/30 text-emerald-400", icon: Wifi },
    error:     { label: "Error",     chip: "border-red-500/30 text-red-400",         icon: WifiOff },
    pending:   { label: "Pending",   chip: "border-border text-muted-foreground",    icon: Clock },
  };
  const m = meta[status] ?? meta.pending;
  const Icon = m.icon;
  return <Badge variant="outline" className={cn("gap-1 text-xs", m.chip)}><Icon className="h-3 w-3" />{m.label}</Badge>;
}

function agentStatusColor(status: string) {
  switch (status) {
    case "active": return "text-emerald-400";
    case "disconnected": return "text-red-400";
    case "pending": return "text-yellow-400";
    default: return "text-muted-foreground";
  }
}

/* ─── Add Connection Dialog ─── */
function AddConnectionDialog({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (c: Connection) => void }) {
  const [form, setForm] = useState({ name: "", apiUrl: "https://", username: "wazuh", password: "", syncInterval: "300" });
  const [features, setFeatures] = useState({ syncAlerts: true, syncAgents: true, syncVulnerabilities: true, syncFim: true });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const set = (k: string, v: string) => setForm((p) => ({ ...p, [k]: v }));

  async function handleCreate() {
    if (!form.name || !form.apiUrl || !form.username || !form.password) { setError("All fields are required"); return; }
    setSaving(true); setError(null);
    try {
      const res = await fetch("/api/wazuh-connections", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, syncInterval: parseInt(form.syncInterval) || 300, ...features }),
      });
      if (!res.ok) { const d = await res.json(); setError(d.error ?? "Failed"); return; }
      onCreated(await res.json());
      setForm({ name: "", apiUrl: "https://", username: "wazuh", password: "", syncInterval: "300" });
      onClose();
    } finally { setSaving(false); }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Add Wazuh Connection</DialogTitle>
          <DialogDescription>Connect to your Wazuh Manager REST API to start syncing data.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-1">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Connection name</Label><Input placeholder="Production Wazuh" value={form.name} onChange={(e) => set("name", e.target.value)} /></div>
            <div className="space-y-1.5"><Label>API URL</Label><Input placeholder="https://wazuh.example.com:55000" value={form.apiUrl} onChange={(e) => set("apiUrl", e.target.value)} /></div>
            <div className="space-y-1.5"><Label>Username</Label><Input value={form.username} onChange={(e) => set("username", e.target.value)} /></div>
            <div className="space-y-1.5"><Label>Password</Label><Input type="password" value={form.password} onChange={(e) => set("password", e.target.value)} /></div>
            <div className="space-y-1.5 col-span-2"><Label>Sync interval (seconds)</Label><Input type="number" value={form.syncInterval} onChange={(e) => set("syncInterval", e.target.value)} /></div>
          </div>
          <Separator />
          <p className="text-xs font-medium text-muted-foreground">Data streams</p>
          <div className="grid grid-cols-2 gap-2">
            {[
              { key: "syncAlerts", label: "Live Alerts", icon: Activity },
              { key: "syncAgents", label: "Agent Status", icon: Server },
              { key: "syncVulnerabilities", label: "Vulnerabilities", icon: Bug },
              { key: "syncFim", label: "FIM Events", icon: FileSearch },
            ].map(({ key, label, icon: Icon }) => (
              <button key={key} onClick={() => setFeatures((p) => ({ ...p, [key]: !p[key as keyof typeof p] }))}
                className={cn("flex items-center gap-2 rounded-md border px-3 py-2 text-xs text-left transition-colors", features[key as keyof typeof features] ? "border-primary/40 bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-accent/20")}>
                <Icon className="h-3.5 w-3.5 flex-shrink-0" />{label}
              </button>
            ))}
          </div>
          {error && <p className="text-xs text-destructive">{error}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button disabled={saving} onClick={handleCreate}>{saving && <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />}Add Connection</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ─── Connection detail tabs ─── */
function ConnectionDetail({ conn, onDelete }: { conn: Connection; onDelete: () => void }) {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [rules, setRules] = useState<Rule[]>([]);
  const [mitre, setMitre] = useState<MitreTechnique[]>([]);
  const [fim, setFim] = useState<FimEvent[]>([]);
  const [activeTab, setActiveTab] = useState("overview");
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string; latencyMs?: number; managerVersion?: string } | null>(null);
  const [syncResult, setSyncResult] = useState<SyncResult | null>(null);
  const [arCommand, setArCommand] = useState("host-deny");
  const [arAgentId, setArAgentId] = useState("");
  const [arArg, setArArg] = useState("");
  const [arResult, setArResult] = useState<{ success: boolean; error?: string } | null>(null);
  const [arLoading, setArLoading] = useState(false);
  const [arCommands, setArCommands] = useState<string[]>(["restart-wazuh", "host-deny", "firewall-drop", "disable-account", "netsh", "route-null"]);

  async function loadAgents() {
    setLoading(true);
    try {
      const res = await fetch(`/api/wazuh-connections/${conn.id}/agents`);
      if (res.ok) setAgents(await res.json());
    } finally { setLoading(false); }
  }

  async function loadRules() {
    setLoading(true);
    try {
      const res = await fetch(`/api/wazuh-connections/${conn.id}/rules?limit=200`);
      if (res.ok) setRules((await res.json()).slice(0, 200));
    } finally { setLoading(false); }
  }

  async function loadMitre() {
    setLoading(true);
    try {
      const res = await fetch(`/api/wazuh-connections/${conn.id}/mitre`);
      if (res.ok) setMitre(await res.json());
    } finally { setLoading(false); }
  }

  async function loadFim() {
    setLoading(true);
    try {
      const res = await fetch(`/api/wazuh-connections/${conn.id}/fim`);
      if (res.ok) setFim(await res.json());
    } finally { setLoading(false); }
  }

  async function loadArCommands() {
    const res = await fetch(`/api/wazuh-connections/${conn.id}/active-response/commands`);
    if (res.ok) setArCommands(await res.json());
  }

  useEffect(() => {
    if (activeTab === "agents") loadAgents();
    else if (activeTab === "rules") loadRules();
    else if (activeTab === "mitre") loadMitre();
    else if (activeTab === "fim") loadFim();
    else if (activeTab === "ar") loadArCommands();
  }, [activeTab, conn.id]);

  async function handleTest() {
    setTesting(true); setTestResult(null);
    try {
      const res = await fetch(`/api/wazuh-connections/${conn.id}/test`, { method: "POST" });
      setTestResult(await res.json());
    } finally { setTesting(false); }
  }

  async function handleSync() {
    setSyncing(true); setSyncResult(null);
    try {
      const res = await fetch(`/api/wazuh-connections/${conn.id}/sync-now`, { method: "POST" });
      if (res.ok) setSyncResult(await res.json());
    } finally { setSyncing(false); }
  }

  async function triggerAR() {
    if (!arAgentId || !arCommand) return;
    setArLoading(true); setArResult(null);
    try {
      const res = await fetch(`/api/wazuh-connections/${conn.id}/active-response`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agentId: arAgentId, command: arCommand, arguments: arArg ? [arArg] : [] }),
      });
      setArResult(await res.json());
    } finally { setArLoading(false); }
  }

  const activeAgents = agents.filter((a) => a.status === "active").length;

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pt-4 pb-3 px-5 border-b border-border">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-0.5"><CardTitle className="text-base">{conn.name}</CardTitle><ConnStatus status={conn.status} /></div>
            <CardDescription className="text-xs font-mono">{conn.apiUrl}</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5" disabled={testing} onClick={handleTest}>
              {testing ? <Loader2 className="h-3 w-3 animate-spin" /> : <Wifi className="h-3 w-3" />}Test
            </Button>
            <Button size="sm" className="h-7 text-xs gap-1.5" disabled={syncing} onClick={handleSync}>
              {syncing ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}Sync Now
            </Button>
            <Button size="sm" variant="ghost" className="h-7 text-xs text-muted-foreground hover:text-destructive" onClick={onDelete}>
              <Trash2 className="h-3 w-3" />
            </Button>
          </div>
        </div>
        {testResult && (
          <div className={cn("mt-2 flex items-center gap-2 text-xs rounded-md px-3 py-2 border", testResult.success ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-red-500/10 border-red-500/20 text-red-400")}>
            {testResult.success ? <CheckCircle2 className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}
            {testResult.message}
            {testResult.managerVersion && <span className="ml-2 text-muted-foreground">· Wazuh {testResult.managerVersion}</span>}
            {testResult.latencyMs && <span className="ml-auto text-muted-foreground">{testResult.latencyMs}ms</span>}
          </div>
        )}
        {syncResult && (
          <div className="mt-2 rounded-md bg-muted/30 border border-border px-3 py-2">
            <div className="grid grid-cols-4 gap-2 text-xs">
              {[
                { label: "Alerts", val: syncResult.alertsSynced, icon: Activity },
                { label: "Agents", val: syncResult.agentsSynced, icon: Server },
                { label: "Vulns", val: syncResult.vulnerabilitiesSynced, icon: Bug },
                { label: "FIM", val: syncResult.fimEventsSynced, icon: FileSearch },
              ].map(({ label, val, icon: Icon }) => (
                <div key={label} className="flex items-center gap-1.5"><Icon className="h-3 w-3 text-muted-foreground" /><span className="font-semibold text-foreground">{val}</span><span className="text-muted-foreground">{label}</span></div>
              ))}
            </div>
            {syncResult.errors.length > 0 && <p className="text-[11px] text-orange-400 mt-1">Partial: {syncResult.errors.join(" · ")}</p>}
            <p className="text-[11px] text-muted-foreground mt-0.5">{syncResult.durationMs}ms · {conn.lastSyncAt ? format(new Date(conn.lastSyncAt), "HH:mm:ss") : "—"}</p>
          </div>
        )}
      </CardHeader>
      <CardContent className="p-0">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="px-5 pt-3 border-b border-border">
            <TabsList className="h-8">
              <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
              <TabsTrigger value="agents" className="text-xs">Agents</TabsTrigger>
              <TabsTrigger value="rules" className="text-xs">Rules</TabsTrigger>
              <TabsTrigger value="mitre" className="text-xs">MITRE</TabsTrigger>
              <TabsTrigger value="fim" className="text-xs">FIM</TabsTrigger>
              <TabsTrigger value="ar" className="text-xs">Active Response</TabsTrigger>
            </TabsList>
          </div>

          {/* Overview */}
          <TabsContent value="overview" className="px-5 py-4 space-y-3 m-0">
            <div className="grid grid-cols-2 gap-3">
              <div><p className="text-[11px] text-muted-foreground">Last sync</p><p className="text-sm font-medium">{conn.lastSyncAt ? formatDistanceToNow(new Date(conn.lastSyncAt), { addSuffix: true }) : "Never"}</p></div>
              <div><p className="text-[11px] text-muted-foreground">Sync status</p><p className="text-sm font-medium capitalize">{conn.lastSyncStatus ?? "—"}</p></div>
              <div><p className="text-[11px] text-muted-foreground">Agents</p><p className="text-sm font-medium">{conn.agentCount ?? "—"}</p></div>
              <div><p className="text-[11px] text-muted-foreground">Sync interval</p><p className="text-sm font-medium">{conn.syncInterval}s</p></div>
            </div>
            <Separator />
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-2">Data streams</p>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { label: "Live Alerts", on: conn.syncAlerts },
                  { label: "Agent Status", on: conn.syncAgents },
                  { label: "Vulnerabilities", on: conn.syncVulnerabilities },
                  { label: "FIM Events", on: conn.syncFim },
                  { label: "Rule Metadata", on: true },
                  { label: "MITRE Mapping", on: true },
                ].map(({ label, on }) => (
                  <div key={label} className="flex items-center gap-1.5 text-xs">
                    {on ? <CheckCircle2 className="h-3 w-3 text-emerald-400" /> : <XCircle className="h-3 w-3 text-muted-foreground/40" />}
                    <span className={on ? "text-foreground/80" : "text-muted-foreground/50"}>{label}</span>
                  </div>
                ))}
              </div>
            </div>
            {conn.lastErrorMessage && (
              <div className="flex items-start gap-2 rounded-md bg-red-500/10 border border-red-500/20 px-3 py-2">
                <AlertTriangle className="h-3.5 w-3.5 text-red-400 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-red-400">{conn.lastErrorMessage}</p>
              </div>
            )}
          </TabsContent>

          {/* Agents */}
          <TabsContent value="agents" className="m-0">
            {loading ? <div className="p-4 space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div> : (
              <>
                <div className="px-5 py-2 border-b border-border flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="text-emerald-400 font-medium">{activeAgents} active</span>
                  <span>{agents.length - activeAgents} offline</span>
                  <span>{agents.length} total</span>
                </div>
                <div className="divide-y divide-border/50 max-h-64 overflow-auto">
                  {agents.map((a) => (
                    <div key={a.id} className="flex items-center gap-3 px-5 py-2.5">
                      <Server className={cn("h-4 w-4 flex-shrink-0", agentStatusColor(a.status))} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{a.name}</p>
                        <p className="text-[11px] text-muted-foreground">{a.ip} · {a.os?.name ?? "Unknown OS"} · v{a.version ?? "?"}</p>
                      </div>
                      <Badge variant="outline" className={cn("text-[10px] capitalize", a.status === "active" ? "border-emerald-500/30 text-emerald-400" : "border-border text-muted-foreground")}>{a.status}</Badge>
                    </div>
                  ))}
                  {agents.length === 0 && <p className="text-sm text-muted-foreground px-5 py-8 text-center">Sync to see agent status.</p>}
                </div>
              </>
            )}
          </TabsContent>

          {/* Rules */}
          <TabsContent value="rules" className="m-0">
            {loading ? <Skeleton className="h-32 w-full m-4" /> : (
              <div className="divide-y divide-border/50 max-h-72 overflow-auto">
                {rules.map((r) => (
                  <div key={r.id} className="flex items-start gap-3 px-5 py-2.5">
                    <span className={cn("text-[11px] font-bold flex-shrink-0 mt-0.5", r.level >= 12 ? "text-red-400" : r.level >= 8 ? "text-orange-400" : r.level >= 4 ? "text-yellow-400" : "text-blue-400")}>L{r.level}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{r.description}</p>
                      <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                        <span className="text-[10px] font-mono text-muted-foreground">#{r.id}</span>
                        {r.details?.mitre?.id?.[0] && <Badge variant="outline" className="text-[9px] border-primary/30 text-primary font-mono">{r.details.mitre.id[0]}</Badge>}
                        {r.groups.slice(0, 2).map((g) => <span key={g} className="text-[10px] text-muted-foreground">{g}</span>)}
                      </div>
                    </div>
                  </div>
                ))}
                {rules.length === 0 && <p className="text-sm text-muted-foreground px-5 py-8 text-center">Click the Rules tab to load rule metadata from Wazuh.</p>}
              </div>
            )}
          </TabsContent>

          {/* MITRE */}
          <TabsContent value="mitre" className="m-0">
            {loading ? <Skeleton className="h-32 w-full m-4" /> : (
              <>
                <div className="px-5 py-2 border-b border-border text-xs text-muted-foreground">{mitre.length} techniques mapped</div>
                <div className="flex flex-wrap gap-1.5 p-4 max-h-64 overflow-auto">
                  {mitre.map((t) => (
                    <Badge key={t.id} variant="outline" className="text-[10px] font-mono border-primary/20 text-primary" title={t.name}>{t.id}</Badge>
                  ))}
                  {mitre.length === 0 && <p className="text-sm text-muted-foreground w-full text-center py-8">Click the MITRE tab to load technique data.</p>}
                </div>
              </>
            )}
          </TabsContent>

          {/* FIM */}
          <TabsContent value="fim" className="m-0">
            {loading ? <Skeleton className="h-32 w-full m-4" /> : (
              <div className="divide-y divide-border/50 max-h-72 overflow-auto">
                {fim.map((e, i) => (
                  <div key={i} className="flex items-start gap-3 px-5 py-2.5">
                    <Badge variant="outline" className={cn("text-[10px] flex-shrink-0 capitalize mt-0.5", e.type === "added" ? "border-emerald-500/30 text-emerald-400" : e.type === "deleted" ? "border-red-500/30 text-red-400" : "border-yellow-500/30 text-yellow-400")}>{e.type}</Badge>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-mono text-foreground truncate">{e.path}</p>
                      <p className="text-[11px] text-muted-foreground">{e.agentName ?? e.agentId} · {e.eventTimestamp ? format(new Date(e.eventTimestamp), "MMM d, HH:mm") : "—"}</p>
                      {e.md5After && <p className="text-[10px] font-mono text-muted-foreground/70">MD5: {e.md5After}</p>}
                    </div>
                  </div>
                ))}
                {fim.length === 0 && <p className="text-sm text-muted-foreground px-5 py-8 text-center">No FIM events found. Run a sync to populate.</p>}
              </div>
            )}
          </TabsContent>

          {/* Active Response */}
          <TabsContent value="ar" className="px-5 py-4 space-y-4 m-0">
            <div className="flex items-start gap-2 rounded-md bg-orange-500/10 border border-orange-500/20 px-3 py-2">
              <AlertTriangle className="h-3.5 w-3.5 text-orange-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-orange-400">Active responses execute commands directly on endpoints. Use with caution in production environments.</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Agent ID</Label>
                <Input placeholder="001" value={arAgentId} onChange={(e) => setArAgentId(e.target.value)} className="h-8 text-sm font-mono" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Command</Label>
                <Select value={arCommand} onValueChange={setArCommand}>
                  <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>{arCommands.map((c) => <SelectItem key={c} value={c} className="font-mono text-xs">{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-xs">Argument (optional, e.g. IP to block)</Label>
                <Input placeholder="e.g. 192.168.1.100" value={arArg} onChange={(e) => setArArg(e.target.value)} className="h-8 text-sm font-mono" />
              </div>
            </div>
            <Button size="sm" className="gap-1.5 bg-orange-600 hover:bg-orange-700 text-white" disabled={arLoading || !arAgentId || !arCommand} onClick={triggerAR}>
              {arLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Zap className="h-3.5 w-3.5" />}Execute Active Response
            </Button>
            {arResult && (
              <div className={cn("flex items-center gap-2 rounded-md border px-3 py-2 text-xs", arResult.success ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-red-500/10 border-red-500/20 text-red-400")}>
                {arResult.success ? <CheckCircle2 className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}
                {arResult.success ? "Command dispatched successfully" : arResult.error}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

/* ─── Page ─── */
export default function WazuhIntegration() {
  const [connections, setConnections] = useState<Connection[]>([]);
  const [loading, setLoading] = useState(true);
  const [addOpen, setAddOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/wazuh-connections");
      if (res.ok) setConnections(await res.json());
    } finally { setLoading(false); }
  }

  useEffect(() => { load(); }, []);
  useEffect(() => { if (connections.length > 0 && !selectedId) setSelectedId(connections[0].id); }, [connections]);

  async function deleteConn(id: string) {
    await fetch(`/api/wazuh-connections/${id}`, { method: "DELETE" });
    setConnections((prev) => prev.filter((c) => c.id !== id));
    if (selectedId === id) setSelectedId(connections.find((c) => c.id !== id)?.id ?? null);
  }

  const selected = connections.find((c) => c.id === selectedId) ?? null;
  const totalAgents = connections.reduce((s, c) => s + (c.agentCount ?? 0), 0);
  const connected = connections.filter((c) => c.status === "connected").length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Wazuh Integration</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Connect your Wazuh manager — alerts, agents, FIM, vulnerabilities, active response</p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="gap-1.5" onClick={load}><RefreshCw className="h-3.5 w-3.5" />Refresh</Button>
          <Button size="sm" className="gap-1.5" onClick={() => setAddOpen(true)}><Plus className="h-4 w-4" />Add Connection</Button>
        </div>
      </div>

      {/* Stats */}
      {!loading && connections.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Connections", val: connections.length, color: "text-foreground" },
            { label: "Connected", val: `${connected}/${connections.length}`, color: connected === connections.length ? "text-emerald-400" : "text-yellow-400" },
            { label: "Total Agents", val: totalAgents, color: "text-foreground" },
          ].map(({ label, val, color }) => (
            <Card key={label} className="border-border bg-card">
              <CardContent className="px-4 py-3"><p className={cn("text-2xl font-bold", color)}>{val}</p><p className="text-xs text-muted-foreground mt-0.5">{label}</p></CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Connection list */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Connections</p>
          {loading ? Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />) :
          connections.length === 0 ? (
            <Card className="border-dashed border-border bg-card">
              <CardContent className="p-8 flex flex-col items-center gap-2 text-center">
                <Shield className="h-8 w-8 text-muted-foreground/40" />
                <p className="text-xs text-muted-foreground">No Wazuh connections yet.</p>
                <Button size="sm" variant="outline" className="mt-1 text-xs gap-1" onClick={() => setAddOpen(true)}><Plus className="h-3.5 w-3.5" />Add</Button>
              </CardContent>
            </Card>
          ) : connections.map((c) => (
            <button key={c.id} onClick={() => setSelectedId(c.id)} className={cn("w-full text-left rounded-xl border p-3 transition-all", selectedId === c.id ? "border-primary/50 bg-primary/10" : "border-border bg-card hover:bg-accent/20")}>
              <div className="flex items-center justify-between gap-2 mb-1">
                <p className="text-sm font-semibold text-foreground truncate">{c.name}</p>
                <ConnStatus status={c.status} />
              </div>
              <p className="text-[11px] font-mono text-muted-foreground truncate">{c.apiUrl}</p>
              {c.lastSyncAt && <p className="text-[10px] text-muted-foreground mt-0.5">{formatDistanceToNow(new Date(c.lastSyncAt), { addSuffix: true })}</p>}
            </button>
          ))}
        </div>

        {/* Detail */}
        <div className="lg:col-span-3">
          {selected ? (
            <ConnectionDetail conn={selected} onDelete={() => deleteConn(selected.id)} />
          ) : (
            <div className="h-full flex flex-col items-center justify-center gap-3 py-24 rounded-xl border border-dashed border-border text-center">
              <Shield className="h-12 w-12 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">Select a connection or add a new one to get started.</p>
            </div>
          )}
        </div>
      </div>

      <AddConnectionDialog open={addOpen} onClose={() => setAddOpen(false)} onCreated={(c) => { setConnections((p) => [...p, c]); setSelectedId(c.id); }} />
    </div>
  );
}
