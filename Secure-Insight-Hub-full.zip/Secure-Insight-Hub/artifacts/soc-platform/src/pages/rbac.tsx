import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  ShieldCheck, ShieldX, Users, Lock, CheckCircle2, XCircle,
  RefreshCw, AlertTriangle, Eye, ChevronRight,
} from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

/* ─── types ─── */
interface RoleMeta {
  id: string; label: string; description: string; color: string; level: number;
  permissions: string[];
}
interface RbacMeta { roles: RoleMeta[]; permissions: string[]; }
interface Me { userId: string; role: string; roleLabel: string; permissions: string[]; }
interface UserRow {
  id: string; email: string; name?: string | null; role: string;
  isActive: boolean; lastActiveAt?: string | null; createdAt: string;
}

/* ─── Permission group labels for display ─── */
const PERM_GROUPS: Record<string, { label: string; perms: string[] }> = {
  alerts:       { label: "Alerts",          perms: ["alerts:view", "alerts:acknowledge", "alerts:bulk_action"] },
  ai:           { label: "AI Analysis",     perms: ["ai:run_analysis", "ai:review"] },
  incidents:    { label: "Incidents",       perms: ["incidents:view", "incidents:create", "incidents:update", "incidents:close"] },
  reports:      { label: "Reports",         perms: ["reports:view", "reports:generate"] },
  rules:        { label: "Rules",           perms: ["rules:view", "rules:modify", "rules:run_tuning"] },
  threat_intel: { label: "Threat Intel",    perms: ["threat_intel:view", "threat_intel:enrich"] },
  compliance:   { label: "Compliance",      perms: ["compliance:view"] },
  vulns:        { label: "Vulnerabilities", perms: ["vulnerabilities:view"] },
  users:        { label: "Users & RBAC",    perms: ["users:view", "users:manage", "users:assign_roles"] },
  dashboard:    { label: "Dashboard",       perms: ["dashboard:view"] },
};

function permLabel(perm: string): string {
  const parts = perm.split(":");
  return parts[1]?.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()) ?? perm;
}

/* ─── Role badge ─── */
function RoleBadge({ role, meta }: { role: string; meta?: RoleMeta }) {
  const color = meta?.color ?? "text-muted-foreground";
  return (
    <Badge variant="outline" className={cn("text-xs border-current/30 bg-current/10", color)}>
      {meta?.label ?? role}
    </Badge>
  );
}

/* ─── Permission matrix table ─── */
function PermissionMatrix({ meta }: { meta: RbacMeta }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="border-b border-border">
            <th className="text-left py-3 px-3 font-medium text-muted-foreground w-48">Permission</th>
            {meta.roles.map((role) => (
              <th key={role.id} className="text-center py-3 px-2 font-medium min-w-[90px]">
                <span className={cn("font-semibold", role.color)}>{role.label}</span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {Object.entries(PERM_GROUPS).map(([groupKey, group]) => (
            <>
              <tr key={`group-${groupKey}`} className="bg-muted/20">
                <td colSpan={meta.roles.length + 1} className="px-3 py-1.5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">
                  {group.label}
                </td>
              </tr>
              {group.perms.map((perm) => (
                <tr key={perm} className="border-b border-border/40 hover:bg-accent/10 transition-colors">
                  <td className="py-2 px-3 font-mono text-[11px] text-foreground/80">{perm}</td>
                  {meta.roles.map((role) => {
                    const allowed = role.permissions.includes(perm);
                    return (
                      <td key={role.id} className="text-center py-2 px-2">
                        {allowed
                          ? <CheckCircle2 className="h-4 w-4 text-emerald-400 mx-auto" />
                          : <XCircle className="h-4 w-4 text-muted-foreground/30 mx-auto" />
                        }
                      </td>
                    );
                  })}
                </tr>
              ))}
            </>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ─── Role card ─── */
function RoleCard({ role }: { role: RoleMeta }) {
  return (
    <Card className="border-border bg-card">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className={cn("font-bold text-base", role.color)}>{role.label}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{role.description}</p>
          </div>
          <Badge variant="outline" className="text-[10px] border-border text-muted-foreground flex-shrink-0">
            Level {role.level}
          </Badge>
        </div>
        <Separator />
        <div className="space-y-1.5">
          <p className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide">Permissions ({role.permissions.length})</p>
          <div className="flex flex-wrap gap-1">
            {Object.entries(PERM_GROUPS).flatMap(([_, group]) =>
              group.perms.filter((p) => role.permissions.includes(p)).map((p) => (
                <Badge key={p} variant="outline" className="text-[10px] border-border text-foreground/70 font-mono">
                  {p}
                </Badge>
              ))
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

/* ─── User row ─── */
function UserRowItem({
  user, meta, me, onRoleChange, onStatusToggle,
}: {
  user: UserRow; meta: RbacMeta; me: Me;
  onRoleChange: (id: string, role: string) => void;
  onStatusToggle: (id: string, active: boolean) => void;
}) {
  const roleMeta = meta.roles.find((r) => r.id === user.role);
  const canEdit = me.permissions.includes("users:assign_roles");
  const canManage = me.permissions.includes("users:manage");
  const myLevel = meta.roles.find((r) => r.id === me.role)?.level ?? 0;
  const isSelf = user.id === me.userId;

  return (
    <tr className="border-b border-border hover:bg-accent/20 transition-colors">
      <td className="px-4 py-3">
        <div>
          <p className="text-sm font-medium text-foreground">{user.name ?? user.email.split("@")[0]}</p>
          <p className="text-xs text-muted-foreground">{user.email}</p>
        </div>
      </td>
      <td className="px-4 py-3">
        {canEdit && !isSelf ? (
          <Select value={user.role} onValueChange={(val) => onRoleChange(user.id, val)}>
            <SelectTrigger className="h-7 w-36 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {meta.roles
                .filter((r) => r.level <= myLevel) // can only assign up to own level
                .map((r) => (
                  <SelectItem key={r.id} value={r.id} className="text-xs">
                    <span className={r.color}>{r.label}</span>
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        ) : (
          <RoleBadge role={user.role} meta={roleMeta} />
        )}
      </td>
      <td className="px-4 py-3">
        <Badge
          variant="outline"
          className={cn("text-xs gap-1", user.isActive
            ? "border-emerald-500/30 text-emerald-400"
            : "border-border text-muted-foreground"
          )}
        >
          {user.isActive ? <CheckCircle2 className="h-2.5 w-2.5" /> : <XCircle className="h-2.5 w-2.5" />}
          {user.isActive ? "Active" : "Inactive"}
        </Badge>
      </td>
      <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
        {user.lastActiveAt ? format(new Date(user.lastActiveAt), "MMM d, HH:mm") : "Never"}
      </td>
      <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
        {format(new Date(user.createdAt), "MMM d, yyyy")}
      </td>
      <td className="px-4 py-3">
        {canManage && !isSelf && (
          <Button
            size="sm"
            variant="ghost"
            className={cn("h-7 text-xs", user.isActive ? "text-muted-foreground hover:text-red-400" : "text-muted-foreground hover:text-emerald-400")}
            onClick={() => onStatusToggle(user.id, !user.isActive)}
          >
            {user.isActive ? "Deactivate" : "Reactivate"}
          </Button>
        )}
        {isSelf && <span className="text-[11px] text-muted-foreground italic">you</span>}
      </td>
    </tr>
  );
}

/* ─── My permissions card ─── */
function MyPermissionsCard({ me, meta }: { me: Me; meta: RbacMeta }) {
  const roleMeta = meta.roles.find((r) => r.id === me.role);
  return (
    <Card className="border-border bg-card">
      <CardHeader className="pt-4 pb-3 px-4">
        <CardTitle className="text-sm flex items-center gap-2">
          <Lock className="h-4 w-4 text-primary" />Your Permissions
        </CardTitle>
      </CardHeader>
      <CardContent className="px-4 pb-4 space-y-3">
        <div className="flex items-center gap-2">
          <p className="text-sm text-muted-foreground">Role:</p>
          <RoleBadge role={me.role} meta={roleMeta} />
        </div>
        <p className="text-xs text-muted-foreground">{roleMeta?.description}</p>
        <Separator />
        <div className="space-y-2">
          {Object.entries(PERM_GROUPS).map(([groupKey, group]) => {
            const myPerms = group.perms.filter((p) => me.permissions.includes(p));
            const missing = group.perms.filter((p) => !me.permissions.includes(p));
            if (!myPerms.length && !missing.length) return null;
            return (
              <div key={groupKey}>
                <p className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide mb-1">{group.label}</p>
                <div className="flex flex-wrap gap-1">
                  {myPerms.map((p) => (
                    <span key={p} className="flex items-center gap-0.5 text-[11px] text-emerald-400">
                      <CheckCircle2 className="h-3 w-3" />{permLabel(p)}
                    </span>
                  ))}
                  {missing.map((p) => (
                    <span key={p} className="flex items-center gap-0.5 text-[11px] text-muted-foreground/50">
                      <XCircle className="h-3 w-3" />{permLabel(p)}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

/* ─── Page ─── */
export default function RbacManagement() {
  const [meta, setMeta] = useState<RbacMeta | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [usersLoading, setUsersLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      fetch("/api/rbac/meta").then((r) => r.json()),
      fetch("/api/rbac/me").then((r) => r.json()),
    ]).then(([m, myData]) => { setMeta(m); setMe(myData); setLoading(false); });
  }, []);

  useEffect(() => {
    if (!me?.permissions.includes("users:view")) { setUsersLoading(false); return; }
    fetch("/api/rbac/users").then((r) => r.ok ? r.json() : []).then((u) => { setUsers(u); setUsersLoading(false); });
  }, [me]);

  async function handleRoleChange(userId: string, newRole: string) {
    setSaving(userId);
    try {
      const res = await fetch(`/api/rbac/users/${userId}/role`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: newRole }),
      });
      if (res.ok) {
        const updated = await res.json();
        setUsers((prev) => prev.map((u) => u.id === userId ? updated : u));
      }
    } finally { setSaving(null); }
  }

  async function handleStatusToggle(userId: string, isActive: boolean) {
    setSaving(userId);
    try {
      const res = await fetch(`/api/rbac/users/${userId}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive }),
      });
      if (res.ok) {
        const updated = await res.json();
        setUsers((prev) => prev.map((u) => u.id === userId ? updated : u));
      }
    } finally { setSaving(null); }
  }

  const canViewUsers = me?.permissions.includes("users:view");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Access Control</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Role-based access control — manage who can do what across the platform</p>
      </div>

      {loading ? (
        <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>
      ) : !meta || !me ? null : (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left: my permissions + role summary */}
          <div className="space-y-4">
            <MyPermissionsCard me={me} meta={meta} />

            {/* Quick role stats */}
            <Card className="border-border bg-card">
              <CardHeader className="pt-4 pb-2 px-4">
                <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Role Hierarchy</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4 space-y-2">
                {[...meta.roles].reverse().map((role, i, arr) => (
                  <div key={role.id} className="flex items-center gap-2">
                    <div className={cn("h-1.5 w-1.5 rounded-full flex-shrink-0", role.id === me.role ? "bg-primary" : "bg-muted-foreground/40")} />
                    <span className={cn("text-xs font-medium", role.color, role.id === me.role ? "font-bold" : "")}>{role.label}</span>
                    {role.id === me.role && <Badge variant="outline" className="text-[9px] border-primary/30 text-primary ml-auto">you</Badge>}
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Right: main tabs */}
          <div className="lg:col-span-3">
            <Tabs defaultValue={canViewUsers ? "users" : "roles"}>
              <TabsList className="h-9">
                {canViewUsers && <TabsTrigger value="users" className="text-xs gap-1.5"><Users className="h-3.5 w-3.5" />Users ({users.length})</TabsTrigger>}
                <TabsTrigger value="roles" className="text-xs gap-1.5"><ShieldCheck className="h-3.5 w-3.5" />Roles</TabsTrigger>
                <TabsTrigger value="matrix" className="text-xs gap-1.5"><Lock className="h-3.5 w-3.5" />Permission Matrix</TabsTrigger>
              </TabsList>

              {/* Users tab */}
              {canViewUsers && (
                <TabsContent value="users" className="mt-4">
                  <Card className="border-border bg-card">
                    <CardContent className="p-0">
                      {usersLoading ? (
                        <div className="p-4 space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
                      ) : users.length === 0 ? (
                        <div className="p-12 text-center text-muted-foreground">
                          <Users className="h-8 w-8 mx-auto mb-2 opacity-40" />
                          <p className="text-sm">No team members yet.</p>
                        </div>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b border-border">
                                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">User</th>
                                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Role</th>
                                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Status</th>
                                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Last Active</th>
                                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Joined</th>
                                <th className="px-4 py-3" />
                              </tr>
                            </thead>
                            <tbody>
                              {users.map((u) => (
                                <UserRowItem
                                  key={u.id}
                                  user={u}
                                  meta={meta}
                                  me={me}
                                  onRoleChange={handleRoleChange}
                                  onStatusToggle={handleStatusToggle}
                                />
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              )}

              {/* Roles tab */}
              <TabsContent value="roles" className="mt-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {meta.roles.map((role) => (
                    <RoleCard key={role.id} role={role} />
                  ))}
                </div>
              </TabsContent>

              {/* Matrix tab */}
              <TabsContent value="matrix" className="mt-4">
                <Card className="border-border bg-card">
                  <CardHeader className="pt-4 pb-2 px-4">
                    <CardTitle className="text-sm">Permission Matrix</CardTitle>
                    <p className="text-xs text-muted-foreground mt-0.5">Complete view of which roles carry which permissions</p>
                  </CardHeader>
                  <CardContent className="p-0">
                    <PermissionMatrix meta={meta} />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      )}
    </div>
  );
}
