import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useListAgents } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import {
  ShieldAlert, AlertTriangle, AlertCircle, Info, Crosshair,
  ChevronLeft, ChevronRight, CheckCheck, ShieldX, ShieldOff, RotateCcw, X,
} from "lucide-react";
import { AlertDetailSheet } from "@/components/alert-detail-sheet";
import { AlertFiltersBar, EMPTY_FILTERS, type AlertFilters } from "@/components/alert-filters-bar";
import { cn } from "@/lib/utils";

const getSeverityBadge = (severity: string) => {
  switch (severity.toUpperCase()) {
    case 'CRITICAL': return <Badge variant="destructive" className="bg-red-600 hover:bg-red-700"><ShieldAlert className="w-3 h-3 mr-1" /> CRITICAL</Badge>;
    case 'HIGH': return <Badge className="bg-orange-500 hover:bg-orange-600 text-white border-transparent"><AlertTriangle className="w-3 h-3 mr-1" /> HIGH</Badge>;
    case 'MEDIUM': return <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-500 hover:bg-yellow-500/30"><AlertCircle className="w-3 h-3 mr-1" /> MEDIUM</Badge>;
    case 'LOW': return <Badge variant="outline" className="text-blue-400 border-blue-400/30"><Info className="w-3 h-3 mr-1" /> LOW</Badge>;
    default: return <Badge variant="outline">{severity}</Badge>;
  }
};

const SEVERITY_RAIL: Record<string, string> = {
  CRITICAL: "bg-red-500",
  HIGH: "bg-orange-500",
  MEDIUM: "bg-yellow-500",
  LOW: "bg-blue-500",
};

const getStatusBadge = (status: string) => {
  switch (status.toLowerCase()) {
    case 'new': return <Badge variant="outline" className="border-blue-500/30 text-blue-400">New</Badge>;
    case 'acknowledged': return <Badge variant="outline" className="border-yellow-500/30 text-yellow-500">Acknowledged</Badge>;
    case 'resolved': return <Badge variant="outline" className="border-green-500/30 text-green-500">Resolved</Badge>;
    default: return <Badge variant="outline">{status}</Badge>;
  }
};

const PAGE_SIZE = 25;

interface AlertRow {
  id: string;
  ruleName: string;
  severity: string;
  status: string;
  timestamp: string;
  agentName: string;
  agentIp?: string | null;
  mitreTechniqueId?: string | null;
}

function buildQueryString(filters: AlertFilters, offset: number) {
  const p = new URLSearchParams();
  if (filters.severities.length) p.set("severity", filters.severities.join(","));
  if (filters.statuses.length) p.set("status", filters.statuses.join(","));
  if (filters.reviewStatuses.length) p.set("reviewStatus", filters.reviewStatuses.join(","));
  if (filters.agentId) p.set("agentId", filters.agentId);
  if (filters.search) p.set("search", filters.search);
  if (filters.dateFrom) p.set("dateFrom", filters.dateFrom);
  if (filters.dateTo) p.set("dateTo", filters.dateTo);
  p.set("limit", String(PAGE_SIZE));
  p.set("offset", String(offset));
  return p.toString();
}

export default function Alerts() {
  const [filters, setFilters] = useState<AlertFilters>(EMPTY_FILTERS);
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [selectedAlertId, setSelectedAlertId] = useState<string | null>(null);
  const [bulkPending, setBulkPending] = useState(false);
  const qc = useQueryClient();

  // Reset to page 0 whenever filters change.
  useEffect(() => { setPage(0); setSelected(new Set()); }, [filters]);

  const queryString = buildQueryString(filters, page * PAGE_SIZE);
  const { data: alertList, isLoading } = useQuery({
    queryKey: ["alerts-table", queryString],
    queryFn: async () => {
      const res = await fetch(`/api/alerts?${queryString}`);
      if (!res.ok) throw new Error("Failed to load alerts");
      return res.json() as Promise<{ items: AlertRow[]; total: number; limit: number; offset: number }>;
    },
  });

  const { data: agentList } = useListAgents();
  const agents = (agentList ?? []).map((a: any) => ({ id: a.id, name: a.name }));

  const items = alertList?.items ?? [];
  const total = alertList?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const allSelected = items.length > 0 && items.every((a) => selected.has(a.id));

  function toggleAll() {
    if (allSelected) {
      setSelected((prev) => {
        const next = new Set(prev);
        items.forEach((a) => next.delete(a.id));
        return next;
      });
    } else {
      setSelected((prev) => {
        const next = new Set(prev);
        items.forEach((a) => next.add(a.id));
        return next;
      });
    }
  }

  function toggleOne(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  async function runBulkAction(action: "acknowledge" | "resolve" | "false_positive" | "new") {
    if (selected.size === 0) return;
    setBulkPending(true);
    try {
      await fetch("/api/alerts/bulk", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: Array.from(selected), action }),
      });
      setSelected(new Set());
      await qc.invalidateQueries({ queryKey: ["alerts-table"] });
    } finally {
      setBulkPending(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Alert Management</h1>
      </div>

      <AlertFiltersBar filters={filters} onChange={setFilters} agents={agents} />

      {selected.size > 0 && (
        <div className="flex items-center gap-2 rounded-lg border border-primary/30 bg-primary/10 px-4 py-2.5">
          <span className="text-sm font-medium text-foreground">{selected.size} selected</span>
          <div className="flex-1" />
          <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5" disabled={bulkPending} onClick={() => runBulkAction("acknowledge")}>
            <CheckCheck className="h-3.5 w-3.5" /> Acknowledge
          </Button>
          <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5" disabled={bulkPending} onClick={() => runBulkAction("resolve")}>
            <ShieldX className="h-3.5 w-3.5" /> Resolve
          </Button>
          <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5 border-red-500/40 text-red-400 hover:bg-red-500/10" disabled={bulkPending} onClick={() => runBulkAction("false_positive")}>
            <ShieldOff className="h-3.5 w-3.5" /> Mark false positive
          </Button>
          <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5" disabled={bulkPending} onClick={() => runBulkAction("new")}>
            <RotateCcw className="h-3.5 w-3.5" /> Reopen
          </Button>
          <Button size="sm" variant="ghost" className="h-7 text-xs gap-1" onClick={() => setSelected(new Set())}>
            <X className="h-3.5 w-3.5" /> Clear
          </Button>
        </div>
      )}

      <Card className="border-border bg-card">
        <CardHeader className="border-b border-border py-4 flex-row items-center justify-between">
          <CardTitle className="text-lg">Recent Alerts</CardTitle>
          {!isLoading && (
            <span className="text-xs text-muted-foreground">
              {total === 0 ? "0 results" : `${page * PAGE_SIZE + 1}–${Math.min((page + 1) * PAGE_SIZE, total)} of ${total}`}
            </span>
          )}
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="w-10">
                  <Checkbox checked={allSelected} onCheckedChange={toggleAll} aria-label="Select all" />
                </TableHead>
                <TableHead className="w-1"></TableHead>
                <TableHead>Time</TableHead>
                <TableHead>Severity</TableHead>
                <TableHead>Rule</TableHead>
                <TableHead>MITRE</TableHead>
                <TableHead>Agent</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <TableRow key={i} className="border-border">
                    <TableCell><Skeleton className="h-4 w-4" /></TableCell>
                    <TableCell className="w-1 p-0"></TableCell>
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-64" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                  </TableRow>
                ))
              ) : items.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="h-24 text-center text-muted-foreground">
                    No alerts match your filters.
                  </TableCell>
                </TableRow>
              ) : (
                items.map((alert) => (
                  <TableRow
                    key={alert.id}
                    className={cn("border-border hover:bg-accent/50 cursor-pointer", selected.has(alert.id) && "bg-accent/30")}
                    onClick={() => setSelectedAlertId(alert.id)}
                  >
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      <Checkbox checked={selected.has(alert.id)} onCheckedChange={() => toggleOne(alert.id)} aria-label={`Select ${alert.ruleName}`} />
                    </TableCell>
                    <TableCell className="w-1 p-0">
                      <div className={cn("w-1 h-8 rounded-full", SEVERITY_RAIL[alert.severity.toUpperCase()] ?? "bg-muted")} />
                    </TableCell>
                    <TableCell className="text-muted-foreground whitespace-nowrap">
                      {format(new Date(alert.timestamp), "MMM d, HH:mm:ss")}
                    </TableCell>
                    <TableCell>{getSeverityBadge(alert.severity)}</TableCell>
                    <TableCell className="font-medium max-w-[320px] truncate" title={alert.ruleName}>
                      {alert.ruleName}
                    </TableCell>
                    <TableCell>
                      {alert.mitreTechniqueId ? (
                        <span className="inline-flex items-center gap-1 text-xs font-mono text-primary">
                          <Crosshair className="h-3 w-3" />
                          {alert.mitreTechniqueId}
                        </span>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="text-sm">{alert.agentName}</span>
                        {alert.agentIp && <span className="text-xs text-muted-foreground">{alert.agentIp}</span>}
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(alert.status)}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>

        {!isLoading && total > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border">
            <span className="text-xs text-muted-foreground">Page {page + 1} of {totalPages}</span>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="h-7 text-xs gap-1" disabled={page === 0} onClick={() => setPage((p) => Math.max(0, p - 1))}>
                <ChevronLeft className="h-3.5 w-3.5" /> Previous
              </Button>
              <Button size="sm" variant="outline" className="h-7 text-xs gap-1" disabled={page + 1 >= totalPages} onClick={() => setPage((p) => p + 1)}>
                Next <ChevronRight className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      <AlertDetailSheet alertId={selectedAlertId} onOpenChange={(open) => !open && setSelectedAlertId(null)} />
    </div>
  );
}
