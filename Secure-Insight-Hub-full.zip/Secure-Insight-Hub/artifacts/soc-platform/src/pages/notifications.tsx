import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { format } from "date-fns";
import {
  Mail, MessageSquare, Bell, CalendarClock, Webhook, Plus, Trash2,
  RefreshCw, CheckCircle2, XCircle, Send, ToggleLeft, ToggleRight,
  Loader2, Info, AlertTriangle, ChevronDown, ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ─── Types ─── */
interface Channel { id: string; name: string; type: string; enabled: boolean; config: Record<string, unknown>; createdAt: string; }
interface Rule { id: string; channelId: string; eventPattern: string; minSeverity: string; enabled: boolean; }
interface LogEntry { id: string; channelId: string; eventType: string; summary: string; status: string; errorMessage?: string | null; latencyMs?: number | null; sentAt: string; }

/* ─── Channel type meta ─── */
const CH_META: Record<string, { label: string; icon: typeof Mail; color: string; description: string; configFields: { key: string; label: string; placeholder: string; type?: string; required?: boolean }[] }> = {
  slack: { label: "Slack", icon: MessageSquare, color: "text-[#4A154B]", description: "Post to a Slack channel via Incoming Webhook", configFields: [{ key: "webhookUrl", label: "Webhook URL", placeholder: "https://hooks.slack.com/services/...", required: true }] },
  teams: { label: "Teams", icon: Webhook, color: "text-[#6264A7]", description: "Post an Adaptive Card to Microsoft Teams", configFields: [{ key: "webhookUrl", label: "Webhook URL", placeholder: "https://outlook.office.com/webhook/...", required: true }] },
  email: { label: "Email", icon: Mail, color: "text-blue-400", description: "Send email via SMTP", configFields: [
    { key: "to", label: "Recipients", placeholder: "analyst@company.com, manager@company.com", required: true },
    { key: "smtpHost", label: "SMTP Host", placeholder: "smtp.gmail.com" },
    { key: "smtpPort", label: "SMTP Port", placeholder: "587" },
    { key: "smtpUser", label: "SMTP Username", placeholder: "sender@company.com" },
    { key: "smtpPass", label: "SMTP Password", placeholder: "••••••••", type: "password" },
    { key: "fromAddress", label: "From Address", placeholder: "sentineliq@company.com" },
  ]},
  browser: { label: "Browser Push", icon: Bell, color: "text-primary", description: "Web Push notifications to subscribed browsers", configFields: [] },
  digest: { label: "Daily Digest", icon: CalendarClock, color: "text-emerald-400", description: "Aggregated daily summary via email, Slack, or Teams", configFields: [
    { key: "deliveryVia", label: "Deliver via", placeholder: "email" },
    { key: "scheduleHour", label: "Send at (UTC hour)", placeholder: "8" },
    { key: "to", label: "Email recipients", placeholder: "soc-team@company.com" },
    { key: "webhookUrl", label: "Or Slack/Teams webhook", placeholder: "https://hooks.slack.com/..." },
  ]},
};

const EVENT_PATTERNS = [
  { value: "*", label: "All events" },
  { value: "alert.*", label: "All alerts" },
  { value: "alert.analyzed", label: "Alert AI analysis ready" },
  { value: "incident.*", label: "All incidents" },
  { value: "incident.created", label: "Incident created" },
  { value: "incident.closed", label: "Incident closed/resolved" },
  { value: "rule.*", label: "All rule changes" },
  { value: "ai.review.*", label: "AI review decisions" },
  { value: "rbac.*", label: "Access control changes" },
];

const SEVERITIES = ["critical", "high", "medium", "low"];

function statusBadge(status: string) {
  if (status === "sent") return <Badge variant="outline" className="text-[10px] gap-0.5 border-emerald-500/30 text-emerald-400"><CheckCircle2 className="h-2.5 w-2.5" />Sent</Badge>;
  if (status === "failed") return <Badge variant="outline" className="text-[10px] gap-0.5 border-red-500/30 text-red-400"><XCircle className="h-2.5 w-2.5" />Failed</Badge>;
  return <Badge variant="outline" className="text-[10px] border-border text-muted-foreground">{status}</Badge>;
}

/* ─── Add Channel Dialog ─── */
function AddChannelDialog({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (ch: Channel) => void }) {
  const [type, setType] = useState("slack");
  const [name, setName] = useState("");
  const [configValues, setConfigValues] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const meta = CH_META[type];

  async function handleCreate() {
    if (!name.trim()) { setError("Name is required"); return; }
    setSaving(true); setError(null);
    try {
      const config: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(configValues)) {
        if (k === "to") config[k] = v.split(",").map((s) => s.trim()).filter(Boolean);
        else if (k === "scheduleHour") config[k] = parseInt(v) || 8;
        else config[k] = v;
      }
      const res = await fetch("/api/notification-channels", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), type, config }),
      });
      if (!res.ok) { const d = await res.json(); setError(d.error ?? "Failed"); return; }
      onCreated(await res.json());
      setName(""); setConfigValues({}); setType("slack"); onClose();
    } finally { setSaving(false); }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Add Notification Channel</DialogTitle>
          <DialogDescription>Configure where SentinelIQ sends alerts and updates.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-1">
          <div className="space-y-1.5">
            <Label>Channel type</Label>
            <div className="grid grid-cols-5 gap-1.5">
              {Object.entries(CH_META).map(([t, m]) => {
                const Icon = m.icon;
                return (
                  <button key={t} onClick={() => setType(t)} className={cn("flex flex-col items-center gap-1 rounded-lg border p-2 text-center transition-colors text-xs", type === t ? "border-primary/50 bg-primary/10" : "border-border hover:bg-accent/20")}>
                    <Icon className={cn("h-5 w-5", type === t ? "text-primary" : m.color)} />
                    <span className={cn("font-medium", type === t ? "text-primary" : "text-foreground/80")}>{m.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ch-name">Display name <span className="text-destructive">*</span></Label>
            <Input id="ch-name" placeholder={`e.g. ${meta.label} SOC Alerts`} value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          {meta.configFields.map((field) => (
            <div key={field.key} className="space-y-1.5">
              <Label htmlFor={`cfg-${field.key}`}>{field.label}{field.required && <span className="text-destructive ml-0.5">*</span>}</Label>
              <Input id={`cfg-${field.key}`} type={field.type ?? "text"} placeholder={field.placeholder}
                value={configValues[field.key] ?? ""}
                onChange={(e) => setConfigValues((p) => ({ ...p, [field.key]: e.target.value }))} />
            </div>
          ))}
          {meta.configFields.length === 0 && type === "browser" && (
            <div className="flex items-start gap-2 rounded-md bg-primary/10 border border-primary/20 px-3 py-2">
              <Info className="h-3.5 w-3.5 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-xs text-primary">Browser push requires no configuration here. Once created, use the "Enable Push" button on the channel to subscribe your browser.</p>
            </div>
          )}
          {error && <p className="text-xs text-destructive">{error}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button disabled={saving || !name.trim()} onClick={handleCreate}>
            {saving && <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />}Add Channel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ─── Channel card ─── */
function ChannelCard({ channel, rules, onToggle, onDelete, onTest, onAddRule, onToggleRule, onDeleteRule }:
  { channel: Channel; rules: Rule[]; onToggle: () => void; onDelete: () => void; onTest: () => void;
    onAddRule: (ch: Channel) => void; onToggleRule: (r: Rule) => void; onDeleteRule: (id: string) => void }) {
  const meta = CH_META[channel.type] ?? CH_META.slack;
  const Icon = meta.icon;
  const [expanded, setExpanded] = useState(false);
  const chRules = rules.filter((r) => r.channelId === channel.id);

  return (
    <Card className={cn("border-border bg-card transition-colors", !channel.enabled && "opacity-60")}>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-lg bg-muted/40 flex-shrink-0"><Icon className={cn("h-4 w-4", meta.color)} /></div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-foreground">{channel.name}</p>
              <p className="text-[11px] text-muted-foreground">{meta.label} · {chRules.length} rule{chRules.length !== 1 ? "s" : ""}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <button onClick={onToggle} className="text-muted-foreground hover:text-foreground transition-colors">
              {channel.enabled ? <ToggleRight className="h-5 w-5 text-emerald-400" /> : <ToggleLeft className="h-5 w-5" />}
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5" onClick={onTest}>
            <Send className="h-3 w-3" />Test
          </Button>
          <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5" onClick={() => onAddRule(channel)}>
            <Plus className="h-3 w-3" />Add rule
          </Button>
          <Button size="sm" variant="ghost" className="h-7 text-xs gap-1 text-muted-foreground hover:text-destructive ml-auto" onClick={onDelete}>
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>

        {chRules.length > 0 && (
          <div>
            <button className="flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground w-full" onClick={() => setExpanded((v) => !v)}>
              {expanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
              Rules ({chRules.length})
            </button>
            {expanded && (
              <div className="mt-1.5 space-y-1">
                {chRules.map((rule) => (
                  <div key={rule.id} className="flex items-center justify-between gap-2 rounded-md border border-border px-2.5 py-1.5">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-[11px] font-mono text-foreground/80 truncate">{rule.eventPattern}</span>
                      <Badge variant="outline" className="text-[9px] border-border text-muted-foreground capitalize">{rule.minSeverity}+</Badge>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button onClick={() => onToggleRule(rule)} className="text-muted-foreground hover:text-foreground">
                        {rule.enabled ? <ToggleRight className="h-4 w-4 text-emerald-400" /> : <ToggleLeft className="h-4 w-4" />}
                      </button>
                      <button onClick={() => onDeleteRule(rule.id)} className="text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ─── Add Rule Dialog ─── */
function AddRuleDialog({ channel, open, onClose, onCreated }:
  { channel: Channel | null; open: boolean; onClose: () => void; onCreated: (r: Rule) => void }) {
  const [pattern, setPattern] = useState("*");
  const [severity, setSeverity] = useState("high");
  const [saving, setSaving] = useState(false);

  async function handleCreate() {
    if (!channel) return;
    setSaving(true);
    try {
      const res = await fetch("/api/notification-rules", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ channelId: channel.id, eventPattern: pattern, minSeverity: severity }),
      });
      if (res.ok) { onCreated(await res.json()); onClose(); }
    } finally { setSaving(false); }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Add Notification Rule</DialogTitle>
          <DialogDescription>When should "{channel?.name}" be triggered?</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-1">
          <div className="space-y-1.5">
            <Label>Event pattern</Label>
            <Select value={pattern} onValueChange={setPattern}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {EVENT_PATTERNS.map((ep) => <SelectItem key={ep.value} value={ep.value}>{ep.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Minimum severity (alerts only)</Label>
            <Select value={severity} onValueChange={setSeverity}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {SEVERITIES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button disabled={saving} onClick={handleCreate}>
            {saving && <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />}Add Rule
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ─── Browser push helper ─── */
function BrowserPushCard() {
  const [status, setStatus] = useState<"idle" | "pending" | "granted" | "denied">("idle");

  async function requestPush() {
    setStatus("pending");
    try {
      const perm = await Notification.requestPermission();
      if (perm !== "granted") { setStatus("denied"); return; }
      const reg = await navigator.serviceWorker.getRegistration();
      if (!reg) { setStatus("denied"); return; }
      const vapidRes = await fetch("/api/notification-push/vapid-key");
      const { vapidPublicKey } = await vapidRes.json();
      if (!vapidPublicKey) { setStatus("denied"); return; }
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: vapidPublicKey });
      const keys = sub.toJSON().keys as any;
      await fetch("/api/notification-push/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: sub.endpoint, p256dhKey: keys.p256dh, authKey: keys.auth }),
      });
      setStatus("granted");
    } catch { setStatus("denied"); }
  }

  const supported = typeof window !== "undefined" && "Notification" in window && "serviceWorker" in navigator;

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pt-4 pb-3 px-4">
        <CardTitle className="text-sm flex items-center gap-2"><Bell className="h-4 w-4 text-primary" />Browser Push Notifications</CardTitle>
        <CardDescription className="text-xs">Receive real-time alerts directly in your browser, even when the tab is closed.</CardDescription>
      </CardHeader>
      <CardContent className="px-4 pb-4">
        {!supported ? (
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><Info className="h-3.5 w-3.5" />Your browser doesn't support Web Push.</div>
        ) : status === "granted" ? (
          <div className="flex items-center gap-2 text-xs text-emerald-400"><CheckCircle2 className="h-4 w-4" />Push notifications enabled for this browser.</div>
        ) : status === "denied" ? (
          <div className="flex items-center gap-2 text-xs text-red-400"><XCircle className="h-4 w-4" />Permission denied. Enable notifications in your browser settings.</div>
        ) : (
          <Button size="sm" className="gap-1.5" disabled={status === "pending"} onClick={requestPush}>
            {status === "pending" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Bell className="h-3.5 w-3.5" />}
            Enable Push Notifications
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

/* ─── Page ─── */
export default function Notifications() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [rules, setRules] = useState<Rule[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [addOpen, setAddOpen] = useState(false);
  const [addRuleTarget, setAddRuleTarget] = useState<Channel | null>(null);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [digestRunning, setDigestRunning] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const [chRes, rRes, lRes] = await Promise.all([
        fetch("/api/notification-channels").then((r) => r.ok ? r.json() : []),
        fetch("/api/notification-rules").then((r) => r.ok ? r.json() : []),
        fetch("/api/notification-logs?limit=50").then((r) => r.ok ? r.json() : { items: [] }),
      ]);
      setChannels(chRes); setRules(rRes); setLogs(lRes.items ?? []);
    } finally { setLoading(false); }
  }

  useEffect(() => { load(); }, []);

  async function toggleChannel(ch: Channel) {
    const res = await fetch(`/api/notification-channels/${ch.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled: !ch.enabled }) });
    if (res.ok) setChannels((prev) => prev.map((c) => c.id === ch.id ? { ...c, enabled: !ch.enabled } : c));
  }

  async function deleteChannel(id: string) {
    await fetch(`/api/notification-channels/${id}`, { method: "DELETE" });
    setChannels((prev) => prev.filter((c) => c.id !== id));
    setRules((prev) => prev.filter((r) => r.channelId !== id));
  }

  async function testChannel(id: string) {
    setTestingId(id);
    try {
      await fetch(`/api/notification-channels/${id}/test`, { method: "POST" });
      await load();
    } finally { setTestingId(null); }
  }

  async function addRule(r: Rule) { setRules((prev) => [...prev, r]); }

  async function toggleRule(rule: Rule) {
    const res = await fetch(`/api/notification-rules/${rule.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled: !rule.enabled }) });
    if (res.ok) setRules((prev) => prev.map((r) => r.id === rule.id ? { ...r, enabled: !rule.enabled } : r));
  }

  async function deleteRule(id: string) {
    await fetch(`/api/notification-rules/${id}`, { method: "DELETE" });
    setRules((prev) => prev.filter((r) => r.id !== id));
  }

  async function triggerDigest() {
    setDigestRunning(true);
    try { await fetch("/api/notification-digest/run", { method: "POST" }); await load(); }
    finally { setDigestRunning(false); }
  }

  const sentCount = logs.filter((l) => l.status === "sent").length;
  const failedCount = logs.filter((l) => l.status === "failed").length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Notifications</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Deliver alerts to Slack, Teams, email, and browser — on your terms</p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="gap-1.5" onClick={load}><RefreshCw className="h-3.5 w-3.5" />Refresh</Button>
          <Button size="sm" className="gap-1.5" onClick={() => setAddOpen(true)}><Plus className="h-4 w-4" />Add Channel</Button>
        </div>
      </div>

      <Tabs defaultValue="channels">
        <TabsList className="h-9">
          <TabsTrigger value="channels" className="text-xs">Channels ({channels.length})</TabsTrigger>
          <TabsTrigger value="browser" className="text-xs">Browser Push</TabsTrigger>
          <TabsTrigger value="digest" className="text-xs">Daily Digest</TabsTrigger>
          <TabsTrigger value="log" className="text-xs">Delivery Log ({logs.length})</TabsTrigger>
        </TabsList>

        {/* Channels */}
        <TabsContent value="channels" className="mt-4 space-y-4">
          {loading ? (
            Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-32 w-full rounded-xl" />)
          ) : channels.length === 0 ? (
            <Card className="border-dashed border-border bg-card">
              <CardContent className="p-12 flex flex-col items-center gap-3 text-center">
                <Bell className="h-10 w-10 text-muted-foreground/40" />
                <p className="text-sm text-muted-foreground">No channels configured yet.</p>
                <Button size="sm" className="gap-1.5 mt-1" onClick={() => setAddOpen(true)}><Plus className="h-4 w-4" />Add your first channel</Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {channels.map((ch) => (
                <ChannelCard key={ch.id} channel={ch} rules={rules}
                  onToggle={() => toggleChannel(ch)}
                  onDelete={() => deleteChannel(ch.id)}
                  onTest={() => testChannel(ch.id)}
                  onAddRule={(c) => setAddRuleTarget(c)}
                  onToggleRule={toggleRule}
                  onDeleteRule={deleteRule}
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* Browser Push */}
        <TabsContent value="browser" className="mt-4 max-w-md">
          <BrowserPushCard />
        </TabsContent>

        {/* Daily Digest */}
        <TabsContent value="digest" className="mt-4 max-w-lg space-y-4">
          <Card className="border-border bg-card">
            <CardHeader className="pt-4 pb-3 px-4">
              <CardTitle className="text-sm flex items-center gap-2"><CalendarClock className="h-4 w-4 text-emerald-400" />Daily Digest</CardTitle>
              <CardDescription className="text-xs">A daily summary of alerts, incidents, and AI reviews — delivered via any configured channel.</CardDescription>
            </CardHeader>
            <CardContent className="px-4 pb-4 space-y-3">
              <div className="rounded-md border border-border bg-muted/20 px-3 py-2.5 text-xs text-muted-foreground space-y-1">
                <p className="font-medium text-foreground">What's in the digest:</p>
                <p>• Alerts: total, critical count, resolved count</p>
                <p>• Incidents: opened and resolved in the last 24h</p>
                <p>• AI reviews: pending analyst approval</p>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="gap-1.5" disabled={digestRunning} onClick={triggerDigest}>
                  {digestRunning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                  Send digest now
                </Button>
                <Button size="sm" variant="ghost" className="text-xs text-muted-foreground gap-1.5" onClick={() => setAddOpen(true)}>
                  <Plus className="h-3.5 w-3.5" />Add digest channel
                </Button>
              </div>
              <p className="text-[11px] text-muted-foreground">Auto-scheduling: add a "Daily Digest" channel with a <code className="font-mono">scheduleHour</code> (UTC) in the config, then call <code className="font-mono">POST /api/notification-digest/run</code> from a daily cron job.</p>
            </CardContent>
          </Card>
          {channels.filter((c) => c.type === "digest").length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Digest channels</p>
              {channels.filter((c) => c.type === "digest").map((ch) => (
                <div key={ch.id} className="flex items-center justify-between rounded-lg border border-border px-3 py-2.5">
                  <div>
                    <p className="text-sm font-medium text-foreground">{ch.name}</p>
                    <p className="text-[11px] text-muted-foreground">via {(ch.config.deliveryVia as string) ?? "email"} · hour {ch.config.scheduleHour ?? "8"} UTC</p>
                  </div>
                  <Badge variant="outline" className={cn("text-xs", ch.enabled ? "border-emerald-500/30 text-emerald-400" : "border-border text-muted-foreground")}>
                    {ch.enabled ? "Active" : "Disabled"}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Delivery Log */}
        <TabsContent value="log" className="mt-4 space-y-3">
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1 text-emerald-400"><CheckCircle2 className="h-3 w-3" />{sentCount} sent</span>
            <span className="flex items-center gap-1 text-red-400"><XCircle className="h-3 w-3" />{failedCount} failed</span>
            <Button size="sm" variant="ghost" className="h-6 text-xs gap-1 ml-auto" onClick={load}><RefreshCw className="h-3 w-3" />Refresh</Button>
          </div>
          <Card className="border-border bg-card">
            <CardContent className="p-0">
              {loading ? (
                Array.from({ length: 4 }).map((_, i) => <div key={i} className="flex gap-3 px-4 py-3 border-b border-border/50"><Skeleton className="h-4 w-full" /></div>)
              ) : logs.length === 0 ? (
                <div className="p-12 text-center text-sm text-muted-foreground">No notifications sent yet.</div>
              ) : (
                <div className="divide-y divide-border/50">
                  {logs.map((log) => {
                    const ch = channels.find((c) => c.id === log.channelId);
                    const ChIcon = ch ? (CH_META[ch.type]?.icon ?? Bell) : Bell;
                    return (
                      <div key={log.id} className="flex items-start gap-3 px-4 py-3">
                        <ChIcon className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-foreground/90 truncate">{log.summary}</p>
                          <div className="flex items-center gap-2 mt-0.5 text-[11px] text-muted-foreground">
                            <span>{ch?.name ?? log.channelId}</span>
                            <span>·</span>
                            <span className="font-mono">{log.eventType}</span>
                            {log.latencyMs != null && <span>· {log.latencyMs}ms</span>}
                            {log.errorMessage && <span className="text-red-400">· {log.errorMessage}</span>}
                          </div>
                        </div>
                        <div className="flex-shrink-0 text-right">
                          {statusBadge(log.status)}
                          <p className="text-[10px] text-muted-foreground mt-0.5">{format(new Date(log.sentAt), "MMM d, HH:mm")}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <AddChannelDialog open={addOpen} onClose={() => setAddOpen(false)} onCreated={(ch) => setChannels((p) => [...p, ch])} />
      <AddRuleDialog channel={addRuleTarget} open={!!addRuleTarget} onClose={() => setAddRuleTarget(null)} onCreated={addRule} />
    </div>
  );
}
