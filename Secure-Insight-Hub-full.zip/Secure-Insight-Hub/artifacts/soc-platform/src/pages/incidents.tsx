import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import {
  ShieldAlert, AlertTriangle, AlertCircle, Info, Plus, ChevronLeft,
  ChevronRight, RefreshCw,
} from "lucide-react";
import { CreateIncidentDialog } from "@/components/create-incident-dialog";
import { IncidentDetailSheet } from "@/components/incident-detail-sheet";
import { cn } from "@/lib/utils";

interface Incident {
  id: string;
  incidentSeq: number;
  incidentNumber: string;
  title: string;
  description?: string | null;
  status: string;
  priority: string;
  assigneeName?: string | null;
  alertCount: number;
  tags: string[];
  resolutionSummary?: string | null;
  resolvedAt?: string | null;
  closedAt?: string | null;
  createdAt: string;
  updatedAt: string;
}

const PRIORITY_META: Record<string, { chip: string; icon: typeof ShieldAlert; rail: string }> = {
  critical: { chip: "bg-red-500/15 text-red-400 border-red-500/30", icon: ShieldAlert, rail: "bg-red-500" },
  high: { chip: "bg-orange-500/15 text-orange-400 border-orange-500/30", icon: AlertTriangle, rail: "bg-orange-500" },
  medium: { chip: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30", icon: AlertCircle, rail: "bg-yellow-500" },
  low: { chip: "bg-blue-500/15 text-blue-400 border-blue-500/30", icon: Info, rail: "bg-blue-500" },
};

const STATUS_META: Record<string, string> = {
  open: "border-blue-500/30 text-blue-400",
  assigned: "border-purple-500/30 text-purple-400",
  investigating: "border-yellow-500/30 text-yellow-500",
  awaiting_approval: "border-orange-500/30 text-orange-400",
  resolved: "border-emerald-500/30 text-emerald-400",
  closed: "border-border text-muted-foreground",
};

const STAT_ITEMS = [
  { key: "open", label: "Open" },
  { key: "investigating", label: "Investigating" },
  { key: "resolved", label: "Resolved" },
  { key: "total", label: "Total" },
] as const;

const PAGE_SIZE = 20;

export default function Incidents() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [stats, setStats] = useState<Record<string, number>>({});
  const [createOpen, setCreateOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  async function fetchIncidents(p = page, s = statusFilter, pr = priorityFilter) {
    setLoading(true);
    try {
      const qs = new URLSearchParams({ limit: String(PAGE_SIZE), offset: String(p * PAGE_SIZE) });
      if (s !== "all") qs.set("status", s);
      if (pr !== "all") qs.set("priority", pr);
      const res = await fetch(`/api/incidents?${qs}`);
      if (res.ok) {
        const data = await res.json();
        setIncidents(data.items);
        setTotal(data.total);
      }
    } finally {
      setLoading(false);
    }
  }

  async function fetchStats() {
    const res = await fetch("/api/incidents/stats");
    if (res.ok) setStats(await res.json());
  }

  useEffect(() => { fetchIncidents(); fetchStats(); }, []);

  function handleFilterChange(type: "status" | "priority", val: string) {
    setPage(0);
    if (type === "status") { setStatusFilter(val); fetchIncidents(0, val, priorityFilter); }
    else { setPriorityFilter(val); fetchIncidents(0, statusFilter, val); }
  }

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Incident Management</h1>
        <Button className="gap-1.5" onClick={() => setCreateOpen(true)}>
          <Plus className="h-4 w-4" />New Incident
        </Button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-4 gap-3">
        {STAT_ITEMS.map(({ key, label }) => (
          <Card key={key} className="border-border bg-card">
            <CardContent className="pt-4 pb-3">
              <p className="text-2xl font-bold text-foreground">{stats[key] ?? "—"}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-2">
        <Select value={statusFilter} onValueChange={(v) => handleFilterChange("status", v)}>
          <SelectTrigger className="w-[170px]"><SelectValue placeholder="All statuses" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="assigned">Assigned</SelectItem>
            <SelectItem value="investigating">Investigating</SelectItem>
            <SelectItem value="awaiting_approval">Awaiting Approval</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
          </SelectContent>
        </Select>
        <Select value={priorityFilter} onValueChange={(v) => handleFilterChange("priority", v)}>
          <SelectTrigger className="w-[150px]"><SelectValue placeholder="All priorities" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All priorities</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="low">Low</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon" className="h-10 w-10" onClick={() => { fetchIncidents(); fetchStats(); }}>
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      {/* Table */}
      <Card className="border-border bg-card">
        <CardHeader className="border-b border-border py-4 flex-row items-center justify-between">
          <CardTitle className="text-lg">Incidents</CardTitle>
          {!loading && (
            <span className="text-xs text-muted-foreground">
              {total === 0 ? "0 results" : `${page * PAGE_SIZE + 1}–${Math.min((page + 1) * PAGE_SIZE, total)} of ${total}`}
            </span>
          )}
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="w-1" />
                <TableHead>Incident</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Assigned</TableHead>
                <TableHead>Alerts</TableHead>
                <TableHead>Opened</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <TableRow key={i} className="border-border">
                    <TableCell className="w-1 p-0" />
                    {Array.from({ length: 6 }).map((__, j) => (
                      <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : incidents.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                    No incidents found.
                  </TableCell>
                </TableRow>
              ) : (
                incidents.map((inc) => {
                  const pm = PRIORITY_META[inc.priority] ?? PRIORITY_META.medium;
                  const PIcon = pm.icon;
                  return (
                    <TableRow
                      key={inc.id}
                      className="border-border hover:bg-accent/50 cursor-pointer"
                      onClick={() => setSelectedId(inc.id)}
                    >
                      <TableCell className="w-1 p-0">
                        <div className={cn("w-1 h-10 rounded-full", pm.rail)} />
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-0.5">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[11px] font-mono text-muted-foreground">{inc.incidentNumber}</span>
                            {inc.tags.slice(0, 1).map((t) => (
                              <Badge key={t} variant="outline" className="text-[10px] font-mono border-border py-0">{t}</Badge>
                            ))}
                          </div>
                          <span className="text-sm font-medium text-foreground truncate max-w-[280px]">{inc.title}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn("gap-1 capitalize", pm.chip)}>
                          <PIcon className="h-3 w-3" />{inc.priority}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn("capitalize", STATUS_META[inc.status] ?? "border-border text-muted-foreground")}>
                          {inc.status.replace(/_/g, " ")}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">{inc.assigneeName ?? "—"}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{inc.alertCount}</TableCell>
                      <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                        {format(new Date(inc.createdAt), "MMM d, HH:mm")}
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>

        {!loading && total > PAGE_SIZE && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border">
            <span className="text-xs text-muted-foreground">Page {page + 1} of {totalPages}</span>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="h-7 text-xs gap-1" disabled={page === 0}
                onClick={() => { const p = page - 1; setPage(p); fetchIncidents(p); }}>
                <ChevronLeft className="h-3.5 w-3.5" />Previous
              </Button>
              <Button size="sm" variant="outline" className="h-7 text-xs gap-1" disabled={page + 1 >= totalPages}
                onClick={() => { const p = page + 1; setPage(p); fetchIncidents(p); }}>
                Next<ChevronRight className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      <CreateIncidentDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCreated={(inc) => {
          setSelectedId(inc.id);
          fetchIncidents();
          fetchStats();
        }}
      />

      <IncidentDetailSheet
        incidentId={selectedId}
        onOpenChange={(open) => !open && setSelectedId(null)}
        onUpdated={() => { fetchIncidents(); fetchStats(); }}
      />
    </div>
  );
}
