import { useState } from "react";
import {
  useListVulnerabilities,
  useGetVulnerabilityStats,
  useGetVulnerability,
  useGetVulnerabilityAnalysis,
  useGenerateVulnerabilityAnalysis,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AiAnalysisPanel, AiList, AiBadge } from "@/components/ai-analysis-panel";
import { format } from "date-fns";
import { Bug, Shield, X, AlertTriangle, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const SEV_STYLES: Record<string, string> = {
  critical: "border-red-500/50 text-red-400 bg-red-500/10",
  high:     "border-orange-500/50 text-orange-400 bg-orange-500/10",
  medium:   "border-yellow-500/50 text-yellow-400 bg-yellow-500/10",
  low:      "border-blue-500/50 text-blue-400 bg-blue-500/10",
};

const PRIORITY_COLORS: Record<string, string> = {
  immediate: "bg-red-500/10 text-red-400 border-red-500/30",
  "7_days":  "bg-orange-500/10 text-orange-400 border-orange-500/30",
  "30_days": "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
  monitor:   "bg-blue-500/10 text-blue-400 border-blue-500/30",
};

const EXPLOIT_COLORS: Record<string, string> = {
  public:       "bg-red-500/10 text-red-400 border-red-500/30",
  private:      "bg-orange-500/10 text-orange-400 border-orange-500/30",
  theoretical:  "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
  none:         "bg-green-500/10 text-green-400 border-green-500/30",
};

function VulnDetail({ vulnId }: { vulnId: string }) {
  const { toast } = useToast();
  const { data: vuln, isLoading } = useGetVulnerability(vulnId);
  const { data: analysis, isLoading: analysisLoading, refetch } = useGetVulnerabilityAnalysis(vulnId);
  const { mutateAsync: generate, isPending: isGenerating } = useGenerateVulnerabilityAnalysis();

  const handleGenerate = async () => {
    try {
      await generate({ id: vulnId });
      await refetch();
    } catch {
      toast({ title: "Analysis failed", variant: "destructive" });
    }
  };

  if (isLoading) return (
    <div className="p-6 space-y-3">
      <Skeleton className="h-6 w-2/3" /><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-5/6" />
    </div>
  );
  if (!vuln) return null;

  return (
    <div className="p-6 space-y-5 overflow-y-auto h-full">
      <div className="space-y-2">
        <div className="flex items-center gap-2 flex-wrap">
          <Badge variant="outline" className={`text-xs ${SEV_STYLES[vuln.severity] ?? ""}`}>{vuln.severity}</Badge>
          <Badge variant="outline" className={`text-xs ${vuln.status === "fixed" ? "text-green-400 border-green-500/40" : "text-red-400 border-red-500/40"}`}>
            {vuln.status === "fixed" ? <CheckCircle2 className="h-3 w-3 mr-1" /> : <AlertTriangle className="h-3 w-3 mr-1" />}
            {vuln.status}
          </Badge>
          <span className="text-xs font-mono text-primary ml-auto">{vuln.cveId}</span>
        </div>
        <h2 className="text-base font-semibold leading-tight">{vuln.title}</h2>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-background/60 rounded px-3 py-2 border border-border/50">
            <span className="text-muted-foreground">CVSS Score</span>
            <p className="font-bold text-lg mt-0.5">{vuln.cvssScore}</p>
          </div>
          <div className="bg-background/60 rounded px-3 py-2 border border-border/50">
            <span className="text-muted-foreground">Package</span>
            <p className="font-medium mt-0.5 truncate">{vuln.packageName}</p>
            <p className="text-muted-foreground font-mono">{vuln.packageVersion} → {vuln.fixedVersion ?? "N/A"}</p>
          </div>
        </div>
        <div className="text-xs text-muted-foreground">
          <span>Agent: </span><span className="text-foreground font-medium">{vuln.agentName}</span>
          <span className="mx-2">·</span>
          <span>Detected: </span><span className="text-foreground">{format(new Date(vuln.detectedAt), "MMM d, yyyy")}</span>
        </div>
      </div>

      <Separator className="bg-border/50" />

      <AiAnalysisPanel
        analysis={analysis}
        isLoading={analysisLoading}
        error={false}
        onGenerate={handleGenerate}
        isGenerating={isGenerating}
        label="Vulnerability AI Analysis"
      >
        {(d) => (
          <div className="space-y-4">
            {d.riskAssessment && (
              <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                <p className="text-xs text-foreground/90 leading-relaxed">{d.riskAssessment}</p>
              </div>
            )}

            <div className="flex flex-wrap gap-3">
              {d.patchPriority && <AiBadge label="Patch Priority" value={d.patchPriority.replace("_", " ")} colorMap={PRIORITY_COLORS} />}
              {d.exploitability && <AiBadge label="Exploitability" value={d.exploitability} colorMap={EXPLOIT_COLORS} />}
            </div>

            {d.patchPriorityReason && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">Why This Priority</p>
                <p className="text-xs text-foreground/90 leading-relaxed">{d.patchPriorityReason}</p>
              </div>
            )}

            <Separator className="bg-border/40" />

            <AiList label="Remediation Steps" items={d.remediationSteps} />

            {d.stagingPlan && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">Staging Plan</p>
                <p className="text-xs text-foreground/90 leading-relaxed">{d.stagingPlan}</p>
              </div>
            )}

            {d.testingApproach && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">Testing Approach</p>
                <p className="text-xs text-foreground/90 leading-relaxed">{d.testingApproach}</p>
              </div>
            )}

            <AiList label="Compensating Controls" items={d.compensatingControls} />

            <div className="text-[10px] text-muted-foreground pt-1">
              Generated {analysis?.generatedAt ? format(new Date(analysis.generatedAt), "MMM d, HH:mm") : "—"}
            </div>
          </div>
        )}
      </AiAnalysisPanel>
    </div>
  );
}

export default function Vulnerabilities() {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const { data: stats } = useGetVulnerabilityStats();
  const { data: vulnList, isLoading } = useListVulnerabilities({}, { query: { queryKey: ["vulns"] } });
  const vulns = vulnList?.items ?? [];

  return (
    <div className="flex h-full gap-0 -m-6">
      <div className={`flex flex-col transition-all ${selectedId ? "w-[520px] flex-shrink-0" : "flex-1"} border-r border-border`}>
        <div className="px-6 py-4 border-b border-border">
          <h1 className="text-2xl font-bold tracking-tight mb-3">Vulnerabilities</h1>
          {stats && (
            <div className="grid grid-cols-4 gap-2">
              {[
                { label: "Critical", value: stats.critical, cls: "text-red-400" },
                { label: "High", value: stats.high, cls: "text-orange-400" },
                { label: "Open", value: stats.open, cls: "text-yellow-400" },
                { label: "Fixed", value: stats.fixed, cls: "text-green-400" },
              ].map(({ label, value, cls }) => (
                <div key={label} className="bg-card/50 rounded-lg p-2.5 border border-border/50 text-center">
                  <div className={`text-xl font-bold ${cls}`}>{value}</div>
                  <div className="text-[10px] text-muted-foreground">{label}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex-1 overflow-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent sticky top-0 bg-background/95">
                <TableHead className="text-xs">CVE ID</TableHead>
                <TableHead className="text-xs">Title</TableHead>
                <TableHead className="text-xs">Severity</TableHead>
                <TableHead className="text-xs">CVSS</TableHead>
                <TableHead className="text-xs">Agent</TableHead>
                <TableHead className="text-xs">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <TableRow key={i} className="border-border">
                    {Array.from({ length: 6 }).map((_, j) => (
                      <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : vulns.map((v) => (
                <TableRow
                  key={v.id}
                  onClick={() => setSelectedId(selectedId === v.id ? null : v.id)}
                  className={`border-border hover:bg-accent/50 cursor-pointer transition-colors ${selectedId === v.id ? "bg-primary/5 border-l-2 border-l-primary" : ""}`}
                >
                  <TableCell className="font-mono text-xs text-primary">{v.cveId}</TableCell>
                  <TableCell className="text-xs max-w-[160px] truncate">{v.title}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={`text-[10px] ${SEV_STYLES[v.severity] ?? ""}`}>{v.severity}</Badge>
                  </TableCell>
                  <TableCell className="text-xs font-bold">{v.cvssScore}</TableCell>
                  <TableCell className="text-xs text-muted-foreground truncate max-w-[80px]">{v.agentName}</TableCell>
                  <TableCell>
                    <Badge className={`text-[10px] ${v.status === "fixed" ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"}`}>
                      {v.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {selectedId && (
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-6 py-3 border-b border-border bg-card/20">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Bug className="h-4 w-4" /><span>Vulnerability Detail</span>
            </div>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setSelectedId(null)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex-1 overflow-hidden">
            <VulnDetail vulnId={selectedId} />
          </div>
        </div>
      )}

      {!selectedId && (
        <div className="flex-1 flex items-center justify-center text-muted-foreground">
          <div className="text-center space-y-2">
            <Bug className="h-10 w-10 mx-auto opacity-30" />
            <p className="text-sm">Select a vulnerability for AI-powered remediation guidance</p>
          </div>
        </div>
      )}
    </div>
  );
}
