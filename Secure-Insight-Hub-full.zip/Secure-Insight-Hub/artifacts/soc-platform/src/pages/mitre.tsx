import { useState } from "react";
import {
  useGetMitreHeatmap,
  useGetMitreCoverage,
  useGetMitreTechniqueAnalysis,
  useGenerateMitreTechniqueAnalysis,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { AiAnalysisPanel, AiList, AiBadge } from "@/components/ai-analysis-panel";
import { Crosshair, X, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const TACTIC_ORDER = [
  "Initial Access", "Execution", "Persistence", "Privilege Escalation",
  "Defense Evasion", "Credential Access", "Discovery", "Lateral Movement",
  "Collection", "Exfiltration", "Command and Control", "Impact",
];

const SEVERITY_BG: Record<string, string> = {
  critical: "bg-red-500/80 border-red-400/60",
  high:     "bg-orange-500/70 border-orange-400/60",
  medium:   "bg-yellow-500/60 border-yellow-400/50",
  low:      "bg-blue-500/40 border-blue-400/40",
};

const CONFIDENCE_COLORS: Record<string, string> = {
  high:   "bg-green-500/10 text-green-400 border-green-500/30",
  medium: "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
  low:    "bg-red-500/10 text-red-400 border-red-500/30",
};

function heatColor(count: number): string {
  if (count === 0) return "bg-muted/20 border-border/30 text-muted-foreground/40";
  if (count >= 20) return "bg-red-500/70 border-red-400/60 text-white";
  if (count >= 10) return "bg-orange-500/60 border-orange-400/50 text-white";
  if (count >= 5)  return "bg-yellow-500/50 border-yellow-400/40 text-foreground";
  return "bg-blue-500/40 border-blue-400/40 text-white";
}

function TechniquePanel({ technique, onClose }: { technique: any; onClose: () => void }) {
  const { toast } = useToast();
  const { data: analysis, isLoading, refetch } = useGetMitreTechniqueAnalysis(technique.techniqueId);
  const { mutateAsync: generate, isPending: isGenerating } = useGenerateMitreTechniqueAnalysis();

  const handleGenerate = async () => {
    try {
      await generate({ techniqueId: technique.techniqueId });
      await refetch();
    } catch {
      toast({ title: "Analysis failed", variant: "destructive" });
    }
  };

  return (
    <div className="w-[400px] flex-shrink-0 flex flex-col border-l border-border overflow-hidden">
      <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-card/20">
        <div className="flex items-center gap-2 min-w-0">
          <Crosshair className="h-4 w-4 text-primary flex-shrink-0" />
          <span className="text-xs font-mono text-primary font-medium">{technique.techniqueId}</span>
          <Badge className={`text-[10px] ml-1 ${heatColor(technique.alertCount)}`}>{technique.alertCount} alerts</Badge>
        </div>
        <Button variant="ghost" size="icon" className="h-7 w-7 flex-shrink-0" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        <div>
          <h3 className="font-semibold text-base leading-tight">{technique.techniqueName}</h3>
          <p className="text-xs text-muted-foreground mt-1">{technique.tacticName}</p>
        </div>

        <Separator className="bg-border/50" />

        <AiAnalysisPanel
          analysis={analysis}
          isLoading={isLoading}
          error={false}
          onGenerate={handleGenerate}
          isGenerating={isGenerating}
          label="Threat Intelligence"
        >
          {(d) => (
            <div className="space-y-4">
              {d.narrative && (
                <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                  <p className="text-xs text-foreground/90 leading-relaxed">{d.narrative}</p>
                </div>
              )}

              {d.industryContext && (
                <div>
                  <p className="text-xs font-medium text-muted-foreground mb-1">Industry Context</p>
                  <p className="text-xs text-foreground/90 leading-relaxed">{d.industryContext}</p>
                </div>
              )}

              {d.attackerMotivation && (
                <div>
                  <p className="text-xs font-medium text-muted-foreground mb-1">Attacker Motivation</p>
                  <p className="text-xs text-foreground/90 leading-relaxed">{d.attackerMotivation}</p>
                </div>
              )}

              {d.detectionConfidence && (
                <div className="flex items-center gap-2">
                  <AiBadge label="Detection Confidence" value={d.detectionConfidence} colorMap={CONFIDENCE_COLORS} />
                </div>
              )}

              <Separator className="bg-border/40" />

              <AiList label="Mitigations" items={d.mitigations} />
              <AiList label="Detection / Hunting Ideas" items={d.huntingQueries} />
              {d.relatedTechniques?.length > 0 && <AiList label="Related Techniques" items={d.relatedTechniques} />}
            </div>
          )}
        </AiAnalysisPanel>
      </div>
    </div>
  );
}

export default function Mitre() {
  const [selectedTechnique, setSelectedTechnique] = useState<any | null>(null);
  const { data: heatmap, isLoading: heatmapLoading } = useGetMitreHeatmap();
  const { data: coverage } = useGetMitreCoverage();

  const byTactic = TACTIC_ORDER.reduce<Record<string, any[]>>((acc, tactic) => {
    acc[tactic] = (heatmap ?? []).filter((r: any) => r.tacticName === tactic);
    return acc;
  }, {});

  const activeTactics = TACTIC_ORDER.filter(t => byTactic[t]?.length > 0);

  return (
    <div className="flex h-full gap-0 -m-6">
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-6 py-4 border-b border-border flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">MITRE ATT&CK</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Click any technique for AI threat intelligence narration
            </p>
          </div>
          {coverage && (
            <div className="flex items-center gap-4 text-sm">
              <div className="text-center">
                <div className="text-xl font-bold text-primary">{coverage.coveragePercent}%</div>
                <div className="text-xs text-muted-foreground">Coverage</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold">{coverage.coveredTechniques}</div>
                <div className="text-xs text-muted-foreground">Techniques</div>
              </div>
            </div>
          )}
        </div>

        <div className="flex-1 overflow-auto p-6">
          {heatmapLoading ? (
            <div className="grid grid-cols-4 gap-3">
              {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-48 w-full" />)}
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex flex-wrap gap-3 text-xs text-muted-foreground items-center">
                <span>Frequency:</span>
                {[
                  { label: "0", cls: "bg-muted/20 border-border/30" },
                  { label: "1–4", cls: "bg-blue-500/40 border-blue-400/40" },
                  { label: "5–9", cls: "bg-yellow-500/50 border-yellow-400/40" },
                  { label: "10–19", cls: "bg-orange-500/60 border-orange-400/50" },
                  { label: "20+", cls: "bg-red-500/70 border-red-400/60" },
                ].map(({ label, cls }) => (
                  <span key={label} className="flex items-center gap-1.5">
                    <span className={`inline-block w-3 h-3 rounded-sm border ${cls}`} />
                    {label}
                  </span>
                ))}
              </div>

              <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${Math.min(activeTactics.length, 6)}, minmax(0, 1fr))` }}>
                {activeTactics.map((tactic) => (
                  <div key={tactic} className="space-y-2">
                    <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider truncate border-b border-border pb-1.5">
                      {tactic}
                    </div>
                    <div className="space-y-1.5">
                      {byTactic[tactic].map((tech: any) => (
                        <button
                          key={tech.techniqueId}
                          onClick={() => setSelectedTechnique(selectedTechnique?.techniqueId === tech.techniqueId ? null : tech)}
                          className={`w-full text-left p-2 rounded border text-xs transition-all hover:scale-[1.02] hover:shadow-md ${
                            selectedTechnique?.techniqueId === tech.techniqueId
                              ? "ring-2 ring-primary ring-offset-1 ring-offset-background"
                              : ""
                          } ${heatColor(tech.alertCount)}`}
                        >
                          <div className="font-mono font-bold text-[10px] opacity-80">{tech.techniqueId}</div>
                          <div className="font-medium leading-tight mt-0.5 text-[11px]">{tech.techniqueName}</div>
                          {tech.alertCount > 0 && (
                            <div className="text-[10px] opacity-70 mt-1">{tech.alertCount} alerts</div>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {activeTactics.length === 0 && (
                <div className="flex flex-col items-center justify-center h-64 gap-3 text-muted-foreground">
                  <Shield className="h-12 w-12 opacity-30" />
                  <p className="text-sm">No MITRE technique detections yet</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {selectedTechnique && (
        <TechniquePanel technique={selectedTechnique} onClose={() => setSelectedTechnique(null)} />
      )}
    </div>
  );
}
