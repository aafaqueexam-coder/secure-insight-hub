import { useState, useEffect } from "react";
import { useListReports, getListReportsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format, formatDistanceToNow } from "date-fns";
import {
  FileText, Calendar, BarChart3, Shield, ShieldAlert, Wrench,
  Play, RefreshCw, Download, ChevronDown, Trash2, CheckCircle2,
  Clock, AlertCircle, FileSpreadsheet, FileType, ExternalLink,
  Sparkles, AlarmClock,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ─── types ─── */
interface Report {
  id: string;
  type: string;
  title: string;
  period: string;
  status: "pending" | "generating" | "ready" | "failed";
  formats: string;
  errorMessage?: string | null;
  generatedAt: string | null;
  createdAt: string;
}

/* ─── meta ─── */
const REPORT_META: Record<string, { label: string; icon: typeof FileText; desc: string; color: string }> = {
  daily:                    { label: "Daily Report",              icon: Calendar,     desc: "24-hour alert, incident & AI review snapshot",          color: "text-blue-400" },
  weekly:                   { label: "Weekly Report",             icon: BarChart3,    desc: "7-day trends, top rules, MITRE breakdown",              color: "text-purple-400" },
  monthly:                  { label: "Monthly Report",            icon: FileText,     desc: "Full month summary with compliance posture",            color: "text-primary" },
  executive_summary:        { label: "Executive Summary",         icon: ShieldAlert,  desc: "High-level KPIs, risk score, critical findings",        color: "text-orange-400" },
  incident_report:          { label: "Incident Report",           icon: AlertCircle,  desc: "All incidents with timelines and resolutions",          color: "text-red-400" },
  compliance_report:        { label: "Compliance Report",         icon: Shield,       desc: "Control status, FP rate, SLA compliance checks",        color: "text-emerald-400" },
  rule_optimization_report: { label: "Rule Optimization Report",  icon: Wrench,       desc: "AI tuning suggestions with risk scores and FP rates",   color: "text-yellow-400" },
};

const STATUS_META = {
  pending:    { label: "Pending",    chip: "bg-muted/50 text-muted-foreground border-border",           icon: Clock },
  generating: { label: "Generating", chip: "bg-primary/15 text-primary border-primary/30",              icon: RefreshCw },
  ready:      { label: "Ready",      chip: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",  icon: CheckCircle2 },
  failed:     { label: "Failed",     chip: "bg-red-500/15 text-red-400 border-red-500/30",              icon: AlertCircle },
};

const FORMAT_META = {
  pdf:   { label: "PDF",   icon: FileType,        ext: "html",  mime: "text/html" },
  csv:   { label: "CSV",   icon: FileText,        ext: "csv",   mime: "text/csv" },
  excel: { label: "Excel", icon: FileSpreadsheet, ext: "xls",   mime: "application/vnd.ms-excel" },
};

const REPORT_TYPES = Object.keys(REPORT_META) as (keyof typeof REPORT_META)[];

/* ─── Generate card ─── */
function GenerateCard({ onGenerated }: { onGenerated: () => void }) {
  const [selected, setSelected] = useState<string>("daily");
  const [formats, setFormats] = useState<string[]>(["pdf"]);
  const [loading, setLoading] = useState(false);

  function toggleFormat(f: string) {
    setFormats((prev) => prev.includes(f) ? (prev.length > 1 ? prev.filter((x) => x !== f) : prev) : [...prev, f]);
  }

  async function generate() {
    setLoading(true);
    try {
      await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: selected, formats }),
      });
      onGenerated();
    } finally { setLoading(false); }
  }

  const meta = REPORT_META[selected];
  const Icon = meta.icon;

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pt-5 pb-4 px-5">
        <CardTitle className="text-sm flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />Generate Report
        </CardTitle>
      </CardHeader>
      <CardContent className="px-5 pb-5 space-y-4">
        {/* Report type grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {REPORT_TYPES.map((type) => {
            const m = REPORT_META[type];
            const Ic = m.icon;
            const active = selected === type;
            return (
              <button
                key={type}
                onClick={() => setSelected(type)}
                className={cn(
                  "flex items-start gap-3 rounded-lg border px-3 py-2.5 text-left transition-colors",
                  active ? "border-primary/50 bg-primary/10" : "border-border hover:border-border/80 hover:bg-accent/30",
                )}
              >
                <Ic className={cn("h-4 w-4 mt-0.5 flex-shrink-0", active ? "text-primary" : m.color)} />
                <div className="min-w-0">
                  <p className={cn("text-xs font-semibold", active ? "text-primary" : "text-foreground")}>{m.label}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5 leading-tight">{m.desc}</p>
                </div>
              </button>
            );
          })}
        </div>

        <Separator />

        {/* Format selector */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground">Export formats</p>
          <div className="flex gap-2">
            {(["pdf", "csv", "excel"] as const).map((f) => {
              const m = FORMAT_META[f];
              const FIcon = m.icon;
              const on = formats.includes(f);
              return (
                <button
                  key={f}
                  onClick={() => toggleFormat(f)}
                  className={cn(
                    "flex items-center gap-1.5 px-3 py-1.5 rounded-md border text-xs font-medium transition-colors",
                    on ? "border-primary/40 bg-primary/15 text-primary" : "border-border text-muted-foreground hover:text-foreground",
                  )}
                >
                  <FIcon className="h-3.5 w-3.5" />{m.label}
                </button>
              );
            })}
          </div>
        </div>

        <Button className="w-full gap-2" disabled={loading} onClick={generate}>
          {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
          Generate {meta.label}
        </Button>
      </CardContent>
    </Card>
  );
}

/* ─── Report row ─── */
function ReportRow({ report, onDelete, onRefresh }: { report: Report; onDelete: (id: string) => void; onRefresh: () => void }) {
  const meta = REPORT_META[report.type] ?? REPORT_META.daily;
  const statusMeta = STATUS_META[report.status] ?? STATUS_META.pending;
  const SIcon = statusMeta.icon;
  const RIcon = meta.icon;
  const isReady = report.status === "ready";
  const isGenerating = report.status === "generating" || report.status === "pending";
  const reportFormats = report.formats.split(",").filter(Boolean);

  function download(format: "pdf" | "csv" | "excel") {
    window.open(`/api/reports/${report.id}/export/${format}`, "_blank");
  }

  return (
    <div className="flex items-center gap-4 py-3.5 px-4 hover:bg-accent/20 transition-colors rounded-lg">
      <div className={cn("p-2 rounded-lg bg-muted/40 flex-shrink-0")}>
        <RIcon className={cn("h-4 w-4", meta.color)} />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="text-sm font-medium text-foreground">{report.title}</p>
          <Badge variant="outline" className={cn("text-[10px] gap-1 flex-shrink-0", statusMeta.chip)}>
            <SIcon className={cn("h-2.5 w-2.5", isGenerating && "animate-spin")} />
            {statusMeta.label}
          </Badge>
        </div>
        <div className="flex items-center gap-2 mt-0.5 text-[11px] text-muted-foreground">
          <span>{report.period}</span>
          <span>·</span>
          <span>{formatDistanceToNow(new Date(report.createdAt), { addSuffix: true })}</span>
          {report.generatedAt && (
            <>
              <span>·</span>
              <span>Generated {format(new Date(report.generatedAt), "MMM d, HH:mm")}</span>
            </>
          )}
          {report.errorMessage && (
            <>
              <span>·</span>
              <span className="text-red-400 truncate max-w-[200px]">{report.errorMessage}</span>
            </>
          )}
        </div>
      </div>

      {/* Format badges */}
      <div className="hidden sm:flex items-center gap-1 flex-shrink-0">
        {reportFormats.map((f) => {
          const fm = FORMAT_META[f as keyof typeof FORMAT_META];
          if (!fm) return null;
          const FIcon = fm.icon;
          return (
            <Badge key={f} variant="outline" className="text-[10px] gap-1 border-border text-muted-foreground">
              <FIcon className="h-2.5 w-2.5" />{fm.label}
            </Badge>
          );
        })}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1.5 flex-shrink-0">
        {isGenerating && (
          <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={onRefresh}>
            <RefreshCw className="h-3.5 w-3.5 animate-spin" />
          </Button>
        )}
        {isReady && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5">
                <Download className="h-3.5 w-3.5" />Export<ChevronDown className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              {reportFormats.map((f) => {
                const fm = FORMAT_META[f as keyof typeof FORMAT_META];
                if (!fm) return null;
                const FIcon = fm.icon;
                return (
                  <DropdownMenuItem key={f} onClick={() => download(f as "pdf" | "csv" | "excel")} className="gap-2">
                    <FIcon className="h-3.5 w-3.5" />{fm.label}
                    <ExternalLink className="h-3 w-3 ml-auto text-muted-foreground" />
                  </DropdownMenuItem>
                );
              })}
              {!reportFormats.includes("pdf") && (
                <DropdownMenuItem onClick={() => download("pdf")} className="gap-2 text-muted-foreground">
                  <FileType className="h-3.5 w-3.5" />PDF
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        )}
        <Button
          size="sm" variant="ghost"
          className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
          onClick={() => onDelete(report.id)}
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );
}

/* ─── Schedule info strip ─── */
function ScheduleStrip() {
  const now = new Date();
  const nextDaily = new Date(now); nextDaily.setDate(now.getDate() + 1); nextDaily.setHours(0, 0, 0, 0);
  const nextWeekly = new Date(now);
  const daysUntilMonday = (8 - now.getDay()) % 7 || 7;
  nextWeekly.setDate(now.getDate() + daysUntilMonday); nextWeekly.setHours(0, 0, 0, 0);
  const nextMonthly = new Date(now.getFullYear(), now.getMonth() + 1, 1);

  return (
    <Card className="border-border bg-card">
      <CardContent className="px-5 py-4">
        <div className="flex items-center gap-2 mb-3">
          <AlarmClock className="h-4 w-4 text-muted-foreground" />
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Automatic generation schedule</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { label: "Daily Report",   next: nextDaily,   icon: Calendar,  color: "text-blue-400" },
            { label: "Weekly Report",  next: nextWeekly,  icon: BarChart3, color: "text-purple-400" },
            { label: "Monthly Report", next: nextMonthly, icon: FileText,  color: "text-primary" },
          ].map(({ label, next, icon: Icon, color }) => (
            <div key={label} className="flex items-center gap-3 rounded-lg border border-border px-3 py-2.5">
              <Icon className={cn("h-4 w-4 flex-shrink-0", color)} />
              <div>
                <p className="text-xs font-medium text-foreground">{label}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">
                  Next: {formatDistanceToNow(next, { addSuffix: true })}
                </p>
              </div>
            </div>
          ))}
        </div>
        <p className="text-[11px] text-muted-foreground mt-3">
          Scheduled reports auto-generate at midnight UTC and are available immediately. Trigger manually anytime using the panel above.
        </p>
      </CardContent>
    </Card>
  );
}

/* ─── Page ─── */
export default function Reports() {
  const qc = useQueryClient();
  const { data: reportsRaw, isLoading, refetch } = useListReports();
  const reports: Report[] = (reportsRaw as any)?.items ?? reportsRaw ?? [];

  // Poll while any report is still generating
  useEffect(() => {
    const hasGenerating = reports.some((r) => r.status === "generating" || r.status === "pending");
    if (!hasGenerating) return;
    const t = setInterval(() => refetch(), 3000);
    return () => clearInterval(t);
  }, [reports, refetch]);

  async function handleDelete(id: string) {
    await fetch(`/api/reports/${id}`, { method: "DELETE" });
    qc.invalidateQueries({ queryKey: getListReportsQueryKey() });
  }

  const byStatus = {
    generating: reports.filter((r) => r.status === "generating" || r.status === "pending"),
    ready: reports.filter((r) => r.status === "ready"),
    failed: reports.filter((r) => r.status === "failed"),
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Reports</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Generate, schedule, and export security reports</p>
        </div>
        <Button size="sm" variant="outline" className="gap-1.5" onClick={() => refetch()}>
          <RefreshCw className="h-3.5 w-3.5" />Refresh
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: generate + schedule */}
        <div className="space-y-4">
          <GenerateCard onGenerated={() => { refetch(); }} />
          <ScheduleStrip />
        </div>

        {/* Right: report list */}
        <div className="lg:col-span-2 space-y-4">
          {/* Generating */}
          {byStatus.generating.length > 0 && (
            <Card className="border-primary/20 bg-card">
              <CardHeader className="pt-4 pb-2 px-4">
                <CardTitle className="text-xs font-medium text-primary flex items-center gap-1.5">
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />Generating ({byStatus.generating.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="px-2 pb-2">
                {byStatus.generating.map((r) => (
                  <ReportRow key={r.id} report={r} onDelete={handleDelete} onRefresh={() => refetch()} />
                ))}
              </CardContent>
            </Card>
          )}

          {/* Ready */}
          <Card className="border-border bg-card">
            <CardHeader className="pt-4 pb-2 px-4 flex-row items-center justify-between">
              <CardTitle className="text-sm font-medium">Reports ({byStatus.ready.length})</CardTitle>
            </CardHeader>
            <CardContent className="px-2 pb-2">
              {isLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="flex items-center gap-4 py-3.5 px-4">
                    <Skeleton className="h-8 w-8 rounded-lg" />
                    <div className="flex-1 space-y-1.5">
                      <Skeleton className="h-4 w-48" />
                      <Skeleton className="h-3 w-32" />
                    </div>
                    <Skeleton className="h-7 w-20" />
                  </div>
                ))
              ) : byStatus.ready.length === 0 ? (
                <div className="flex flex-col items-center gap-3 py-12 text-center">
                  <FileText className="h-10 w-10 text-muted-foreground/40" />
                  <p className="text-sm text-muted-foreground">No reports generated yet.</p>
                  <p className="text-xs text-muted-foreground">Select a report type on the left and click Generate.</p>
                </div>
              ) : (
                byStatus.ready.map((r, i) => (
                  <div key={r.id}>
                    <ReportRow report={r} onDelete={handleDelete} onRefresh={() => refetch()} />
                    {i < byStatus.ready.length - 1 && <div className="mx-4 border-b border-border/50" />}
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          {/* Failed */}
          {byStatus.failed.length > 0 && (
            <Card className="border-red-500/20 bg-card">
              <CardHeader className="pt-4 pb-2 px-4">
                <CardTitle className="text-xs font-medium text-red-400 flex items-center gap-1.5">
                  <AlertCircle className="h-3.5 w-3.5" />Failed ({byStatus.failed.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="px-2 pb-2">
                {byStatus.failed.map((r) => (
                  <ReportRow key={r.id} report={r} onDelete={handleDelete} onRefresh={() => refetch()} />
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
