import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format, formatDistanceToNow } from "date-fns";
import {
  Search, Download, RefreshCw, ChevronLeft, ChevronRight,
  Sparkles, ShieldCheck, ShieldX, AlertTriangle, FileText,
  Users, SlidersHorizontal, Activity, Clock, User,
  CheckCircle2, XCircle, Wrench, BarChart3, Shield,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ─── types ─── */
interface AuditLog {
  id: string;
  eventType: string;
  summary: string;
  actorName: string;
  actorRole?: string | null;
  resourceType?: string | null;
  resourceId?: string | null;
  resourceName?: string | null;
  details?: Record<string, unknown> | null;
  ipAddress?: string | null;
  occurredAt: string;
}

interface Stats {
  total: number;
  byDomain: Record<string, number>;
  actors: { actorId: string; actorName: string; count: number; lastSeen: string }[];
}

/* ─── Event type display ─── */
const EVENT_META: Record<string, { label: string; color: string; icon: typeof Activity }> = {
  "ai.analysis.generated":      { label: "AI Analysis",         color: "text-purple-400",  icon: Sparkles },
  "ai.analysis.rerun":          { label: "AI Re-run",           color: "text-purple-400",  icon: Sparkles },
  "ai.review.approved":         { label: "AI Approved",         color: "text-emerald-400", icon: CheckCircle2 },
  "ai.review.rejected":         { label: "AI Rejected",         color: "text-red-400",     icon: XCircle },
  "ai.recommendation.modified": { label: "Rec. Modified",       color: "text-yellow-400",  icon: Sparkles },
  "incident.created":           { label: "Incident Created",    color: "text-blue-400",    icon: AlertTriangle },
  "incident.updated":           { label: "Incident Updated",    color: "text-blue-400",    icon: AlertTriangle },
  "incident.assigned":          { label: "Assigned",            color: "text-blue-400",    icon: User },
  "incident.closed":            { label: "Incident Closed",     color: "text-emerald-400", icon: ShieldCheck },
  "incident.note.added":        { label: "Note Added",          color: "text-muted-foreground", icon: FileText },
  "incident.evidence.attached": { label: "Evidence Attached",   color: "text-muted-foreground", icon: FileText },
  "incident.alert.linked":      { label: "Alert Linked",        color: "text-blue-400",    icon: AlertTriangle },
  "alert.status.changed":       { label: "Alert Status",        color: "text-yellow-400",  icon: AlertTriangle },
  "alert.converted":            { label: "Alert → Incident",    color: "text-blue-400",    icon: AlertTriangle },
  "rule.change.approved":       { label: "Rule Approved",       color: "text-emerald-400", icon: ShieldCheck },
  "rule.change.rejected":       { label: "Rule Rejected",       color: "text-red-400",     icon: XCircle },
  "rule.tuning.run":            { label: "Tuning Run",          color: "text-yellow-400",  icon: SlidersHorizontal },
  "report.generated":           { label: "Report Generated",    color: "text-primary",     icon: BarChart3 },
  "report.exported":            { label: "Report Exported",     color: "text-primary",     icon: Download },
  "rbac.role.changed":          { label: "Role Changed",        color: "text-orange-400",  icon: Shield },
  "rbac.user.deactivated":      { label: "User Deactivated",    color: "text-red-400",     icon: Users },
  "rbac.user.reactivated":      { label: "User Reactivated",    color: "text-emerald-400", icon: Users },
};

const DOMAIN_META: Record<string, { label: string; icon: typeof Activity; color: string }> = {
  ai:       { label: "AI Analysis",      icon: Sparkles,       color: "text-purple-400" },
  incident: { label: "Incidents",        icon: AlertTriangle,  color: "text-blue-400" },
  alert:    { label: "Alerts",           icon: Activity,       color: "text-yellow-400" },
  rule:     { label: "Rule Changes",     icon: SlidersHorizontal, color: "text-orange-400" },
  report:   { label: "Reports",          icon: BarChart3,      color: "text-primary" },
  rbac:     { label: "Access Control",   icon: Shield,         color: "text-red-400" },
};

function eventMeta(eventType: string) {
  return EVENT_META[eventType] ?? { label: eventType.replace(/\./g, " → "), color: "text-muted-foreground", icon: Activity };
}

function roleBadge(role?: string | null) {
  if (!role) return null;
  const colors: Record<string, string> = {
    admin: "border-red-500/30 text-red-400", soc_manager: "border-yellow-500/30 text-yellow-400",
    l3_analyst: "border-orange-500/30 text-orange-400", l2_analyst: "border-purple-500/30 text-purple-400",
    l1_analyst: "border-blue-500/30 text-blue-400", auditor: "border-border text-muted-foreground",
  };
  const labels: Record<string, string> = {
    admin: "Admin", soc_manager: "SOC Mgr", l3_analyst: "L3", l2_analyst: "L2", l1_analyst: "L1", auditor: "Auditor",
  };
  return <Badge variant="outline" className={cn("text-[10px]", colors[role] ?? "border-border text-muted-foreground")}>{labels[role] ?? role}</Badge>;
}

/* ─── Log row ─── */
function LogRow({ log, expanded, onToggle }: { log: AuditLog; expanded: boolean; onToggle: () => void }) {
  const meta = eventMeta(log.eventType);
  const Icon = meta.icon;
  return (
    <div className={cn("border-b border-border/50 last:border-0 transition-colors", expanded && "bg-accent/10")}>
      <button className="w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-accent/20 transition-colors" onClick={onToggle}>
        <div className="flex-shrink-0 mt-0.5">
          <Icon className={cn("h-4 w-4", meta.color)} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm text-foreground/90 leading-snug">{log.summary}</p>
          <div className="flex items-center gap-2 mt-0.5 flex-wrap">
            <span className="text-[11px] text-muted-foreground">{log.actorName}</span>
            {roleBadge(log.actorRole)}
            {log.resourceType && (
              <Badge variant="outline" className="text-[10px] border-border text-muted-foreground capitalize">{log.resourceType}</Badge>
            )}
            {log.ipAddress && <span className="text-[10px] font-mono text-muted-foreground/60">{log.ipAddress}</span>}
          </div>
        </div>
        <div className="flex-shrink-0 text-right ml-2">
          <Badge variant="outline" className={cn("text-[10px] gap-1 mb-1", "border-border/60 text-muted-foreground")}>{meta.label}</Badge>
          <p className="text-[11px] text-muted-foreground whitespace-nowrap">
            {format(new Date(log.occurredAt), "MMM d, HH:mm:ss")}
          </p>
        </div>
      </button>
      {expanded && log.details && Object.keys(log.details).length > 0 && (
        <div className="px-4 pb-3 pl-11">
          <div className="rounded-md bg-muted/30 border border-border px-3 py-2">
            <p className="text-[11px] text-muted-foreground font-medium mb-1.5 uppercase tracking-wide">Event details</p>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
              {Object.entries(log.details).map(([k, v]) => (
                v != null && v !== "" && (
                  <div key={k} className="contents">
                    <dt className="text-muted-foreground truncate">{k.replace(/_/g, " ")}</dt>
                    <dd className="font-mono text-foreground/80 truncate">{typeof v === "object" ? JSON.stringify(v) : String(v)}</dd>
                  </div>
                )
              ))}
            </dl>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Stats panel ─── */
function StatsPanel({ stats }: { stats: Stats }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2">
        <Card className="border-border bg-card">
          <CardContent className="px-3 py-3">
            <p className="text-xl font-bold text-foreground">{stats.total.toLocaleString()}</p>
            <p className="text-[11px] text-muted-foreground">Total events</p>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="px-3 py-3">
            <p className="text-xl font-bold text-foreground">{stats.actors.length}</p>
            <p className="text-[11px] text-muted-foreground">Active actors</p>
          </CardContent>
        </Card>
      </div>
      <Card className="border-border bg-card">
        <CardHeader className="pt-3 pb-2 px-3">
          <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Events by domain</CardTitle>
        </CardHeader>
        <CardContent className="px-3 pb-3 space-y-2">
          {Object.entries(stats.byDomain).map(([domain, count]) => {
            const dm = DOMAIN_META[domain] ?? { label: domain, icon: Activity, color: "text-muted-foreground" };
            const DIcon = dm.icon;
            const pct = stats.total > 0 ? (count / stats.total) * 100 : 0;
            return (
              <div key={domain} className="space-y-0.5">
                <div className="flex items-center justify-between text-xs">
                  <span className={cn("flex items-center gap-1", dm.color)}><DIcon className="h-3 w-3" />{dm.label}</span>
                  <span className="font-medium text-foreground">{count}</span>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <div className="h-full rounded-full bg-primary/60" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
      <Card className="border-border bg-card">
        <CardHeader className="pt-3 pb-2 px-3">
          <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Top actors</CardTitle>
        </CardHeader>
        <CardContent className="px-3 pb-3 space-y-2">
          {stats.actors.slice(0, 6).map((actor) => (
            <div key={actor.actorId} className="flex items-center justify-between text-xs">
              <div>
                <p className="font-medium text-foreground">{actor.actorName}</p>
                <p className="text-[10px] text-muted-foreground">{formatDistanceToNow(new Date(actor.lastSeen), { addSuffix: true })}</p>
              </div>
              <Badge variant="outline" className="border-border text-muted-foreground">{actor.count}</Badge>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

/* ─── Page ─── */
const PAGE_SIZE = 50;
const EVENT_DOMAINS = ["ai", "incident", "alert", "rule", "report", "rbac"];

export default function AuditLogs() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<Stats | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const [search, setSearch] = useState("");
  const [domainFilter, setDomainFilter] = useState("all");
  const [resourceFilter, setResourceFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  async function fetchLogs(p = page, s = search, d = domainFilter, r = resourceFilter, df = dateFrom, dt = dateTo) {
    setLoading(true);
    try {
      const qs = new URLSearchParams({ limit: String(PAGE_SIZE), offset: String(p * PAGE_SIZE) });
      if (s) qs.set("search", s);
      if (d !== "all") qs.set("eventType", d);
      if (r !== "all") qs.set("resourceType", r);
      if (df) qs.set("dateFrom", df);
      if (dt) qs.set("dateTo", dt);
      const res = await fetch(`/api/audit-logs?${qs}`);
      if (res.ok) { const data = await res.json(); setLogs(data.items); setTotal(data.total); }
    } finally { setLoading(false); }
  }

  async function fetchStats() {
    const res = await fetch("/api/audit-logs/stats");
    if (res.ok) setStats(await res.json());
  }

  useEffect(() => { fetchLogs(); fetchStats(); }, []);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  function reset() {
    setPage(0); setSearch(""); setDomainFilter("all"); setResourceFilter("all"); setDateFrom(""); setDateTo("");
    fetchLogs(0, "", "all", "all", "", "");
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Audit Logs</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Immutable record of every platform action — AI, incidents, rules, reports, access</p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="gap-1.5" onClick={() => fetchLogs()}>
            <RefreshCw className="h-3.5 w-3.5" />Refresh
          </Button>
          <Button size="sm" variant="outline" className="gap-1.5" onClick={() => window.open("/api/audit-logs/export/csv", "_blank")}>
            <Download className="h-3.5 w-3.5" />Export CSV
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Stats sidebar */}
        <div>{stats ? <StatsPanel stats={stats} /> : <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-32 w-full" />)}</div>}</div>

        {/* Log feed */}
        <div className="lg:col-span-3 space-y-3">
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search events, actors, resources…"
                className="pl-8"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (setPage(0), fetchLogs(0))}
              />
            </div>
            <Select value={domainFilter} onValueChange={(v) => { setDomainFilter(v); setPage(0); fetchLogs(0, search, v, resourceFilter); }}>
              <SelectTrigger className="w-[160px]"><SelectValue placeholder="All domains" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All domains</SelectItem>
                {EVENT_DOMAINS.map((d) => (
                  <SelectItem key={d} value={d}>{DOMAIN_META[d]?.label ?? d}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={resourceFilter} onValueChange={(v) => { setResourceFilter(v); setPage(0); fetchLogs(0, search, domainFilter, v); }}>
              <SelectTrigger className="w-[140px]"><SelectValue placeholder="Resource" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All resources</SelectItem>
                {["alert", "incident", "rule", "report", "user"].map((r) => (
                  <SelectItem key={r} value={r} className="capitalize">{r}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Date range */}
          <div className="flex gap-2 items-center">
            <Clock className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
            <input type="date" className="text-xs bg-background border border-border rounded-md px-2 py-1.5 text-foreground" value={dateFrom}
              onChange={(e) => { setDateFrom(e.target.value); setPage(0); fetchLogs(0, search, domainFilter, resourceFilter, e.target.value, dateTo); }} />
            <span className="text-xs text-muted-foreground">to</span>
            <input type="date" className="text-xs bg-background border border-border rounded-md px-2 py-1.5 text-foreground" value={dateTo}
              onChange={(e) => { setDateTo(e.target.value); setPage(0); fetchLogs(0, search, domainFilter, resourceFilter, dateFrom, e.target.value); }} />
            {(dateFrom || dateTo || search || domainFilter !== "all" || resourceFilter !== "all") && (
              <Button size="sm" variant="ghost" className="h-7 text-xs text-muted-foreground" onClick={reset}>Clear</Button>
            )}
            <span className="ml-auto text-xs text-muted-foreground">
              {total === 0 ? "0 events" : `${page * PAGE_SIZE + 1}–${Math.min((page + 1) * PAGE_SIZE, total)} of ${total.toLocaleString()}`}
            </span>
          </div>

          {/* Log entries */}
          <Card className="border-border bg-card">
            <CardContent className="p-0">
              {loading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="flex gap-3 px-4 py-3 border-b border-border/50">
                    <Skeleton className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <div className="flex-1 space-y-1.5"><Skeleton className="h-4 w-3/4" /><Skeleton className="h-3 w-1/3" /></div>
                    <Skeleton className="h-4 w-20 flex-shrink-0" />
                  </div>
                ))
              ) : logs.length === 0 ? (
                <div className="flex flex-col items-center gap-3 py-16 text-center">
                  <Activity className="h-10 w-10 text-muted-foreground/40" />
                  <p className="text-sm text-muted-foreground">No audit events found.</p>
                  <p className="text-xs text-muted-foreground">Events are logged as actions are taken across the platform.</p>
                </div>
              ) : (
                logs.map((log) => (
                  <LogRow key={log.id} log={log} expanded={expandedId === log.id} onToggle={() => setExpandedId(expandedId === log.id ? null : log.id)} />
                ))
              )}
            </CardContent>
          </Card>

          {/* Pagination */}
          {total > PAGE_SIZE && (
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">Page {page + 1} of {totalPages}</span>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="h-7 text-xs gap-1" disabled={page === 0}
                  onClick={() => { const p = page - 1; setPage(p); fetchLogs(p); }}>
                  <ChevronLeft className="h-3.5 w-3.5" />Previous
                </Button>
                <Button size="sm" variant="outline" className="h-7 text-xs gap-1" disabled={page + 1 >= totalPages}
                  onClick={() => { const p = page + 1; setPage(p); fetchLogs(p); }}>
                  Next<ChevronRight className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
