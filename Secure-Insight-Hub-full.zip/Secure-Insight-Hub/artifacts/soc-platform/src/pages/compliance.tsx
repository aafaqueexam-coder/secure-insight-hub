import { useState } from "react";
import { useListComplianceFrameworks, useGetComplianceFramework, useGetComplianceGaps } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Shield, ShieldCheck, ShieldAlert, ShieldX, CheckCircle2, AlertTriangle,
  XCircle, HelpCircle, RefreshCw, ChevronRight, Lightbulb, FileText,
  Activity, Database, Clipboard, Info,
} from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

/* ─── types that extend generated ones ─── */
interface Control {
  id: string; name: string; description: string; category: string;
  requirement: string; status: string; score: number;
  evidence: string; evidenceData: Record<string, unknown>;
  recommendation: string; remediationSteps: string[];
  evidenceHints: string[]; weight: number;
}
interface Framework {
  id: string; name: string; shortName: string; version: string;
  description: string; score: number; status: string;
  controlsTotal: number; controlsPassed: number;
  controlsFailed: number; controlsPartial: number;
  controls?: Control[]; lastAssessedAt?: string | null;
}
interface Gap {
  controlId: string; controlName: string; category: string;
  status: string; score: number; evidence: string;
  evidenceData: Record<string, unknown>; recommendation: string;
  remediationSteps: string[]; evidenceHints: string[]; priority: string;
}

/* ─── visual helpers ─── */
function scoreColor(score: number) {
  return score >= 80 ? "text-emerald-400" : score >= 60 ? "text-yellow-400" : "text-red-400";
}
function scoreBg(score: number) {
  return score >= 80 ? "bg-emerald-500" : score >= 60 ? "bg-yellow-500" : "bg-red-500";
}
function statusMeta(status: string) {
  switch (status) {
    case "compliant":     return { label: "Compliant",      chip: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30", icon: ShieldCheck };
    case "partial":       return { label: "Partial",        chip: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30",   icon: Shield };
    case "non-compliant": return { label: "Non-Compliant",  chip: "bg-red-500/15 text-red-400 border-red-500/30",            icon: ShieldX };
    default:              return { label: status,           chip: "bg-muted/50 text-muted-foreground border-border",          icon: HelpCircle };
  }
}
function controlStatusMeta(status: string) {
  switch (status) {
    case "passed":         return { label: "Passed",         chip: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30", icon: CheckCircle2 };
    case "partial":        return { label: "Partial",        chip: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30",   icon: AlertTriangle };
    case "failed":         return { label: "Failed",         chip: "bg-red-500/15 text-red-400 border-red-500/30",            icon: XCircle };
    case "not_applicable": return { label: "N/A",            chip: "bg-muted/50 text-muted-foreground border-border",          icon: HelpCircle };
    default:               return { label: status,           chip: "bg-muted/50 text-muted-foreground border-border",          icon: HelpCircle };
  }
}
function priorityMeta(p: string) {
  switch (p) {
    case "critical": return "bg-red-500/15 text-red-400 border-red-500/30";
    case "high":     return "bg-orange-500/15 text-orange-400 border-orange-500/30";
    case "medium":   return "bg-yellow-500/15 text-yellow-400 border-yellow-500/30";
    default:         return "bg-blue-500/15 text-blue-400 border-blue-500/30";
  }
}

const FW_COLORS: Record<string, string> = {
  "pci-dss":  "text-blue-400",
  "iso27001": "text-purple-400",
  "cis":      "text-orange-400",
  "nist":     "text-primary",
  "hipaa":    "text-emerald-400",
};

/* ─── Framework summary card ─── */
function FrameworkCard({ fw, selected, onClick }: { fw: Framework; selected: boolean; onClick: () => void }) {
  const sm = statusMeta(fw.status);
  const SI = sm.icon;
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full text-left rounded-xl border p-4 transition-all space-y-3",
        selected ? "border-primary/50 bg-primary/10 ring-1 ring-primary/30" : "border-border bg-card hover:border-border/80 hover:bg-accent/20",
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className={cn("font-bold text-base", FW_COLORS[fw.id] ?? "text-foreground")}>{fw.shortName}</p>
          <p className="text-[11px] text-muted-foreground">{fw.version}</p>
        </div>
        <Badge variant="outline" className={cn("text-xs gap-1 flex-shrink-0", sm.chip)}>
          <SI className="h-3 w-3" />{sm.label}
        </Badge>
      </div>
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs text-muted-foreground">Compliance score</span>
          <span className={cn("text-lg font-bold", scoreColor(fw.score))}>{fw.score}%</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div className={cn("h-full rounded-full transition-all", scoreBg(fw.score))} style={{ width: `${fw.score}%` }} />
        </div>
      </div>
      <div className="flex items-center gap-3 text-[11px]">
        <span className="flex items-center gap-1 text-emerald-400"><CheckCircle2 className="h-3 w-3" />{fw.controlsPassed} passed</span>
        {fw.controlsPartial > 0 && <span className="flex items-center gap-1 text-yellow-400"><AlertTriangle className="h-3 w-3" />{fw.controlsPartial} partial</span>}
        <span className="flex items-center gap-1 text-red-400"><XCircle className="h-3 w-3" />{fw.controlsFailed} failed</span>
      </div>
    </button>
  );
}

/* ─── Control detail row ─── */
function ControlRow({ control, expanded, onToggle }: { control: Control; expanded: boolean; onToggle: () => void }) {
  const cs = controlStatusMeta(control.status);
  const CI = cs.icon;
  return (
    <div className={cn("border-b border-border last:border-0 transition-colors", expanded && "bg-accent/20")}>
      <button className="w-full flex items-center gap-3 px-4 py-3 text-left" onClick={onToggle}>
        <CI className={cn("h-4 w-4 flex-shrink-0", control.status === "passed" ? "text-emerald-400" : control.status === "partial" ? "text-yellow-400" : control.status === "failed" ? "text-red-400" : "text-muted-foreground")} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-foreground">{control.name}</span>
            <span className="text-[11px] font-mono text-muted-foreground">{control.requirement}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">{control.category}</p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="hidden sm:flex items-center gap-1.5">
            <div className="w-12 h-1.5 rounded-full bg-muted overflow-hidden">
              <div className={cn("h-full rounded-full", scoreBg(control.score))} style={{ width: `${control.score}%` }} />
            </div>
            <span className={cn("text-xs font-medium", scoreColor(control.score))}>{control.score}</span>
          </div>
          <Badge variant="outline" className={cn("text-[10px] gap-1", cs.chip)}>
            <CI className="h-2.5 w-2.5" />{cs.label}
          </Badge>
          <ChevronRight className={cn("h-3.5 w-3.5 text-muted-foreground transition-transform", expanded && "rotate-90")} />
        </div>
      </button>

      {expanded && (
        <div className="px-4 pb-4 pl-11 space-y-3">
          <p className="text-sm text-muted-foreground leading-relaxed">{control.description}</p>
          <div className="rounded-md border border-border bg-muted/20 px-3 py-2.5 space-y-1">
            <p className="text-xs font-medium text-muted-foreground flex items-center gap-1"><Activity className="h-3 w-3" />Evidence</p>
            <p className="text-sm text-foreground/90">{control.evidence}</p>
            {Object.entries(control.evidenceData).length > 0 && (
              <div className="flex flex-wrap gap-2 mt-1.5">
                {Object.entries(control.evidenceData).map(([k, v]) => (
                  <span key={k} className="text-[11px] font-mono bg-background border border-border rounded px-1.5 py-0.5">
                    {k}: <strong>{String(v)}</strong>
                  </span>
                ))}
              </div>
            )}
          </div>
          {control.status !== "passed" && (
            <div className="space-y-2">
              <p className="text-xs font-medium text-muted-foreground flex items-center gap-1"><Lightbulb className="h-3 w-3 text-yellow-400" />Remediation steps</p>
              <ul className="space-y-1">
                {control.remediationSteps.map((step, i) => (
                  <li key={i} className="text-xs text-foreground/80 flex gap-2">
                    <span className="text-primary flex-shrink-0">{i + 1}.</span>{step}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {control.evidenceHints.length > 0 && (
            <div className="flex items-start gap-1.5 text-xs text-muted-foreground">
              <Clipboard className="h-3.5 w-3.5 flex-shrink-0 mt-0.5" />
              <span>Evidence to attach: {control.evidenceHints.join(" · ")}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ─── Gaps panel ─── */
function GapsPanel({ frameworkId }: { frameworkId: string }) {
  const { data: gapsRaw, isLoading } = useGetComplianceGaps(frameworkId) as { data: Gap[] | undefined; isLoading: boolean };
  const gaps = gapsRaw ?? [];

  if (isLoading) return <div className="space-y-2 p-4">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>;
  if (!gaps.length) return (
    <div className="flex flex-col items-center gap-3 py-12 text-center">
      <ShieldCheck className="h-10 w-10 text-emerald-400" />
      <p className="text-sm font-medium text-foreground">No compliance gaps</p>
      <p className="text-xs text-muted-foreground">All controls are passing or not applicable.</p>
    </div>
  );

  return (
    <div className="divide-y divide-border">
      {gaps.map((gap) => (
        <div key={gap.controlId} className="p-4 space-y-2.5">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-sm font-semibold text-foreground">{gap.controlName}</p>
                <span className="text-[11px] font-mono text-muted-foreground">{gap.controlId}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">{gap.category}</p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <Badge variant="outline" className={cn("text-xs capitalize", priorityMeta(gap.priority))}>{gap.priority}</Badge>
              <Badge variant="outline" className={cn("text-xs", gap.status === "failed" ? "bg-red-500/15 text-red-400 border-red-500/30" : "bg-yellow-500/15 text-yellow-400 border-yellow-500/30")}>
                {gap.status}
              </Badge>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
              <div className={cn("h-full rounded-full", scoreBg(gap.score))} style={{ width: `${gap.score}%` }} />
            </div>
            <span className={cn("text-xs font-medium", scoreColor(gap.score))}>{gap.score}%</span>
          </div>
          <div className="rounded-md bg-muted/30 border border-border px-3 py-2">
            <p className="text-xs font-medium text-muted-foreground flex items-center gap-1 mb-1"><Activity className="h-3 w-3" />Evidence</p>
            <p className="text-sm text-foreground/90">{gap.evidence}</p>
          </div>
          <div>
            <p className="text-xs font-medium text-muted-foreground flex items-center gap-1 mb-1"><Lightbulb className="h-3 w-3 text-yellow-400" />Recommendation</p>
            <p className="text-sm text-foreground/90">{gap.recommendation}</p>
          </div>
          {gap.remediationSteps.length > 1 && (
            <ul className="space-y-0.5 pl-1">
              {gap.remediationSteps.slice(1).map((s, i) => (
                <li key={i} className="text-xs text-muted-foreground flex gap-1.5"><span className="text-primary">{i + 2}.</span>{s}</li>
              ))}
            </ul>
          )}
          {gap.evidenceHints.length > 0 && (
            <p className="text-[11px] text-muted-foreground flex items-center gap-1">
              <Clipboard className="h-3 w-3" />Evidence to collect: {gap.evidenceHints.join(" · ")}
            </p>
          )}
        </div>
      ))}
    </div>
  );
}

/* ─── Framework detail panel ─── */
function FrameworkDetail({ frameworkId }: { frameworkId: string }) {
  const { data: fwRaw, isLoading } = useGetComplianceFramework(frameworkId) as { data: Framework | undefined; isLoading: boolean };
  const fw = fwRaw as Framework | undefined;
  const [expandedControl, setExpandedControl] = useState<string | null>(null);
  const [categoryFilter, setCategoryFilter] = useState("all");

  if (isLoading) return <div className="p-6 space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}</div>;
  if (!fw) return null;

  const sm = statusMeta(fw.status);
  const SI = sm.icon;
  const controls = fw.controls ?? [];
  const categories = ["all", ...Array.from(new Set(controls.map((c) => c.category)))];
  const filtered = categoryFilter === "all" ? controls : controls.filter((c) => c.category === categoryFilter);

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card className="border-border bg-card">
        <CardContent className="p-5 space-y-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <p className={cn("text-xl font-bold", FW_COLORS[fw.id] ?? "text-foreground")}>{fw.name}</p>
                <span className="text-xs text-muted-foreground">{fw.version}</span>
              </div>
              <p className="text-sm text-muted-foreground mt-0.5 max-w-xl">{fw.description}</p>
            </div>
            <Badge variant="outline" className={cn("gap-1 text-sm flex-shrink-0", sm.chip)}>
              <SI className="h-3.5 w-3.5" />{sm.label}
            </Badge>
          </div>
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-sm text-muted-foreground">Overall compliance score</span>
              <span className={cn("text-3xl font-bold", scoreColor(fw.score))}>{fw.score}%</span>
            </div>
            <div className="h-3 rounded-full bg-muted overflow-hidden">
              <div className={cn("h-full rounded-full transition-all", scoreBg(fw.score))} style={{ width: `${fw.score}%` }} />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 pt-1">
            {[
              { label: "Passed",  val: fw.controlsPassed,  color: "text-emerald-400" },
              { label: "Partial", val: fw.controlsPartial, color: "text-yellow-400" },
              { label: "Failed",  val: fw.controlsFailed,  color: "text-red-400" },
            ].map(({ label, val, color }) => (
              <div key={label} className="rounded-lg border border-border bg-muted/20 px-3 py-2 text-center">
                <p className={cn("text-xl font-bold", color)}>{val}</p>
                <p className="text-[11px] text-muted-foreground">{label}</p>
              </div>
            ))}
          </div>
          {fw.lastAssessedAt && (
            <p className="text-[11px] text-muted-foreground">Last assessed: {format(new Date(fw.lastAssessedAt), "MMM d, yyyy HH:mm")}</p>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="controls">
        <TabsList className="h-9">
          <TabsTrigger value="controls" className="text-xs gap-1.5"><FileText className="h-3.5 w-3.5" />Controls ({controls.length})</TabsTrigger>
          <TabsTrigger value="gaps" className="text-xs gap-1.5"><ShieldAlert className="h-3.5 w-3.5" />Gaps &amp; Recs ({fw.controlsFailed + fw.controlsPartial})</TabsTrigger>
        </TabsList>

        <TabsContent value="controls" className="mt-3 space-y-2">
          {/* Category filter */}
          <div className="flex flex-wrap gap-1.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={cn(
                  "px-2.5 py-1 text-[11px] rounded-md border capitalize transition-colors",
                  categoryFilter === cat ? "bg-primary/15 text-primary border-primary/30" : "border-border text-muted-foreground hover:text-foreground",
                )}
              >{cat}</button>
            ))}
          </div>
          <Card className="border-border bg-card">
            <CardContent className="p-0 divide-y divide-border">
              {filtered.map((control) => (
                <ControlRow
                  key={control.id}
                  control={control}
                  expanded={expandedControl === control.id}
                  onToggle={() => setExpandedControl(expandedControl === control.id ? null : control.id)}
                />
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gaps" className="mt-3">
          <Card className="border-border bg-card">
            <CardContent className="p-0">
              <GapsPanel frameworkId={frameworkId} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ─── Page ─── */
export default function Compliance() {
  const { data: frameworksRaw, isLoading, refetch } = useListComplianceFrameworks() as { data: Framework[] | undefined; isLoading: boolean; refetch: () => void };
  const frameworks = frameworksRaw ?? [];
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const avgScore = frameworks.length
    ? Math.round(frameworks.reduce((s, f) => s + f.score, 0) / frameworks.length)
    : 0;
  const passing = frameworks.filter((f) => f.status === "compliant").length;
  const totalFailed = frameworks.reduce((s, f) => s + f.controlsFailed, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Compliance</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Real-time posture across PCI DSS, ISO 27001, CIS Controls, NIST CSF, HIPAA</p>
        </div>
        <Button size="sm" variant="outline" className="gap-1.5" onClick={() => refetch()}>
          <RefreshCw className="h-3.5 w-3.5" />Refresh
        </Button>
      </div>

      {/* Summary strip */}
      {!isLoading && frameworks.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Avg Score",      val: `${avgScore}%`, color: scoreColor(avgScore) },
            { label: "Frameworks Passing", val: `${passing}/${frameworks.length}`, color: passing === frameworks.length ? "text-emerald-400" : "text-yellow-400" },
            { label: "Failed Controls", val: String(totalFailed), color: totalFailed === 0 ? "text-emerald-400" : "text-red-400" },
          ].map(({ label, val, color }) => (
            <Card key={label} className="border-border bg-card">
              <CardContent className="px-4 py-3">
                <p className={cn("text-2xl font-bold", color)}>{val}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Framework list */}
        <div className="space-y-3">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Frameworks</p>
          {isLoading
            ? Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-36 w-full rounded-xl" />)
            : frameworks.map((fw) => (
                <FrameworkCard
                  key={fw.id}
                  fw={fw}
                  selected={selectedId === fw.id}
                  onClick={() => setSelectedId(fw.id === selectedId ? null : fw.id)}
                />
              ))
          }
        </div>

        {/* Detail panel */}
        <div className="lg:col-span-2">
          {selectedId ? (
            <FrameworkDetail frameworkId={selectedId} />
          ) : (
            <div className="h-full flex flex-col items-center justify-center gap-3 text-center py-24 rounded-xl border border-dashed border-border">
              <Shield className="h-12 w-12 text-muted-foreground/40" />
              <p className="text-muted-foreground text-sm">Select a framework to view controls, evidence, and remediation steps.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
