import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { format, formatDistanceToNow } from "date-fns";
import {
  Search, Globe, Hash, Link2, Shield, ShieldAlert, ShieldCheck,
  HelpCircle, RefreshCw, MapPin, Building2, Wifi, AlertTriangle,
  CheckCircle2, XCircle, Clock, Database, Trash2, Filter, ExternalLink,
  Fingerprint, Server, X, ChevronRight, Info,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ─── Types ─── */
type Verdict = "malicious" | "suspicious" | "clean" | "unknown";
type IndicatorType = "ip" | "domain" | "hash_md5" | "hash_sha1" | "hash_sha256" | "url";

interface ThreatFeedHit {
  feed: string; confidence: number; tags: string[];
  firstSeen?: string; lastSeen?: string; malwareFamily?: string;
}
interface EnrichmentResult {
  indicator: string; indicatorType: IndicatorType;
  verdict: Verdict; riskScore: number;
  geo?: { country?: string; countryCode?: string; city?: string; region?: string; lat?: number; lon?: number; timezone?: string };
  asn?: { asn?: string; org?: string; isp?: string };
  reputation: { isKnownBad: boolean; isPrivate?: boolean; isTor?: boolean; isProxy?: boolean; isDatacenter?: boolean; detectionRatio?: string };
  threatFeeds: ThreatFeedHit[];
  sources: string[];
  verdictReason: string;
  cachedAt?: string; expiresAt?: string;
}
interface IocRow {
  id: string; indicator: string; indicatorType: string;
  verdict: string; riskScore: number;
  enrichedAt: string; expiresAt: string;
  data: Record<string, unknown>;
}
interface IocStats {
  total: number; malicious: number; suspicious: number; clean: number; unknown: number;
  byType: Record<string, number>;
}

/* ─── Verdict meta ─── */
const VERDICT_META: Record<Verdict, { label: string; icon: typeof Shield; chip: string; ring: string }> = {
  malicious:  { label: "Malicious",  icon: ShieldAlert,   chip: "bg-red-500/15 text-red-400 border-red-500/30",       ring: "border-red-500/40" },
  suspicious: { label: "Suspicious", icon: AlertTriangle,  chip: "bg-orange-500/15 text-orange-400 border-orange-500/30", ring: "border-orange-500/40" },
  clean:      { label: "Clean",      icon: ShieldCheck,    chip: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30", ring: "border-emerald-500/30" },
  unknown:    { label: "Unknown",    icon: HelpCircle,     chip: "bg-muted/50 text-muted-foreground border-border",    ring: "border-border" },
};

const TYPE_META: Record<string, { label: string; icon: typeof Globe }> = {
  ip:         { label: "IP Address", icon: Globe },
  domain:     { label: "Domain",     icon: Server },
  hash_md5:   { label: "MD5 Hash",   icon: Hash },
  hash_sha1:  { label: "SHA-1 Hash", icon: Hash },
  hash_sha256:{ label: "SHA-256 Hash",icon: Hash },
  url:        { label: "URL",        icon: Link2 },
};

function riskColor(score: number) {
  return score >= 70 ? "text-red-400" : score >= 35 ? "text-orange-400" : score > 0 ? "text-yellow-400" : "text-emerald-400";
}
function riskBg(score: number) {
  return score >= 70 ? "bg-red-500" : score >= 35 ? "bg-orange-500" : "bg-emerald-500";
}

/* ─── Enrichment Result Card ─── */
function EnrichmentCard({ result, onRefresh, loading }: { result: EnrichmentResult; onRefresh: () => void; loading: boolean }) {
  const vm = VERDICT_META[result.verdict] ?? VERDICT_META.unknown;
  const VIcon = vm.icon;
  const tm = TYPE_META[result.indicatorType] ?? TYPE_META.ip;
  const TIcon = tm.icon;

  return (
    <Card className={cn("border bg-card", vm.ring)}>
      <CardContent className="p-5 space-y-5">
        {/* Header row */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            <div className="p-2 rounded-lg bg-muted/40 flex-shrink-0">
              <TIcon className="h-5 w-5 text-muted-foreground" />
            </div>
            <div className="min-w-0">
              <p className="font-mono font-medium text-sm text-foreground break-all">{result.indicator}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{tm.label}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Badge variant="outline" className={cn("gap-1", vm.chip)}>
              <VIcon className="h-3 w-3" />{vm.label}
            </Badge>
            <Button size="icon" variant="ghost" className="h-7 w-7" disabled={loading} onClick={onRefresh}>
              <RefreshCw className={cn("h-3.5 w-3.5", loading && "animate-spin")} />
            </Button>
          </div>
        </div>

        {/* Risk score */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Risk score</span>
            <span className={cn("font-bold text-lg", riskColor(result.riskScore))}>{result.riskScore}<span className="text-xs font-normal text-muted-foreground">/100</span></span>
          </div>
          <div className="h-2 rounded-full bg-muted overflow-hidden">
            <div className={cn("h-full rounded-full transition-all", riskBg(result.riskScore))} style={{ width: `${result.riskScore}%` }} />
          </div>
          <p className="text-xs text-muted-foreground">{result.verdictReason}</p>
        </div>

        <Separator />

        {/* Reputation flags */}
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Reputation</p>
          <div className="flex flex-wrap gap-1.5">
            {[
              { flag: result.reputation.isKnownBad, label: "Known Bad",  bad: true },
              { flag: result.reputation.isProxy,    label: "Proxy",      bad: true },
              { flag: result.reputation.isTor,      label: "Tor Exit",   bad: true },
              { flag: result.reputation.isDatacenter, label: "Datacenter", bad: false },
              { flag: result.reputation.isPrivate,  label: "Private IP", bad: false },
            ].filter((f) => f.flag).map(({ label, bad }) => (
              <Badge key={label} variant="outline" className={cn("text-xs gap-1", bad ? "border-red-500/30 text-red-400" : "border-border text-muted-foreground")}>
                {bad ? <AlertTriangle className="h-2.5 w-2.5" /> : <Info className="h-2.5 w-2.5" />}{label}
              </Badge>
            ))}
            {!result.reputation.isKnownBad && !result.reputation.isProxy && !result.reputation.isTor && (
              <Badge variant="outline" className="text-xs gap-1 border-emerald-500/30 text-emerald-400">
                <CheckCircle2 className="h-2.5 w-2.5" />No known threats
              </Badge>
            )}
          </div>
        </div>

        {/* GeoIP */}
        {result.geo && (result.geo.country || result.geo.city) && (
          <>
            <Separator />
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2.5 flex items-center gap-1">
                <MapPin className="h-3 w-3" />GeoIP
              </p>
              <dl className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
                {result.geo.country   && <><dt className="text-muted-foreground">Country</dt><dd className="font-medium text-foreground">{result.geo.countryCode && <span className="mr-1">{result.geo.countryCode}</span>}{result.geo.country}</dd></>}
                {result.geo.city      && <><dt className="text-muted-foreground">City</dt><dd className="font-medium text-foreground">{result.geo.city}</dd></>}
                {result.geo.region    && <><dt className="text-muted-foreground">Region</dt><dd className="font-medium text-foreground">{result.geo.region}</dd></>}
                {result.geo.timezone  && <><dt className="text-muted-foreground">Timezone</dt><dd className="font-mono text-foreground">{result.geo.timezone}</dd></>}
                {result.geo.lat != null && <><dt className="text-muted-foreground">Coordinates</dt><dd className="font-mono text-foreground">{result.geo.lat.toFixed(4)}, {result.geo.lon?.toFixed(4)}</dd></>}
              </dl>
            </div>
          </>
        )}

        {/* ASN */}
        {result.asn && (result.asn.org || result.asn.asn) && (
          <>
            <Separator />
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2.5 flex items-center gap-1">
                <Building2 className="h-3 w-3" />ASN / Network
              </p>
              <dl className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
                {result.asn.asn  && <><dt className="text-muted-foreground">ASN</dt><dd className="font-mono text-foreground">{result.asn.asn}</dd></>}
                {result.asn.org  && <><dt className="text-muted-foreground">Org</dt><dd className="font-medium text-foreground">{result.asn.org}</dd></>}
                {result.asn.isp  && <><dt className="text-muted-foreground">ISP</dt><dd className="font-medium text-foreground">{result.asn.isp}</dd></>}
              </dl>
            </div>
          </>
        )}

        {/* Threat feed hits */}
        {result.threatFeeds.length > 0 && (
          <>
            <Separator />
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2.5 flex items-center gap-1">
                <Fingerprint className="h-3 w-3" />Threat Feed Matches ({result.threatFeeds.length})
              </p>
              <div className="space-y-2">
                {result.threatFeeds.map((hit, i) => (
                  <div key={i} className="rounded-md border border-red-500/20 bg-red-500/5 px-3 py-2 space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-red-400">{hit.feed}</span>
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-muted-foreground">Confidence</span>
                        <span className="text-xs font-bold text-red-400">{hit.confidence}%</span>
                      </div>
                    </div>
                    {hit.malwareFamily && <p className="text-xs text-foreground/80 font-medium">{hit.malwareFamily}</p>}
                    <div className="flex flex-wrap gap-1">
                      {hit.tags.filter(Boolean).map((t) => (
                        <Badge key={t} variant="outline" className="text-[10px] border-red-500/20 text-red-400/80">{t}</Badge>
                      ))}
                    </div>
                    {(hit.firstSeen || hit.lastSeen) && (
                      <p className="text-[10px] text-muted-foreground">
                        {hit.firstSeen && `First seen: ${format(new Date(hit.firstSeen), "MMM d, yyyy")}`}
                        {hit.firstSeen && hit.lastSeen && " · "}
                        {hit.lastSeen && `Last seen: ${format(new Date(hit.lastSeen), "MMM d, yyyy")}`}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Sources + cache */}
        <Separator />
        <div className="flex items-center justify-between gap-4 text-[11px] text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Wifi className="h-3 w-3" />
            Sources: {result.sources.length > 0 ? result.sources.join(", ") : "Heuristic analysis"}
          </div>
          {result.expiresAt && (
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              Cache expires {formatDistanceToNow(new Date(result.expiresAt), { addSuffix: true })}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

/* ─── IOC Database Table ─── */
function IocDatabase() {
  const [rows, setRows] = useState<IocRow[]>([]);
  const [stats, setStats] = useState<IocStats | null>(null);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [verdictFilter, setVerdictFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 25;

  const fetchData = async (s = search, v = verdictFilter, t = typeFilter, p = page) => {
    setLoading(true);
    try {
      const qs = new URLSearchParams({ limit: String(PAGE_SIZE), offset: String(p * PAGE_SIZE) });
      if (s) qs.set("search", s);
      if (v !== "all") qs.set("verdict", v);
      if (t !== "all") qs.set("type", t);
      const [dataRes, statsRes] = await Promise.all([
        fetch(`/api/threat-intel/ioc-database?${qs}`),
        fetch("/api/threat-intel/ioc-database/stats"),
      ]);
      if (dataRes.ok) { const d = await dataRes.json(); setRows(d.items); setTotal(d.total); }
      if (statsRes.ok) setStats(await statsRes.json());
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const handleDelete = async (id: string) => {
    await fetch(`/api/threat-intel/ioc-database/${id}`, { method: "DELETE" });
    setRows((prev) => prev.filter((r) => r.id !== id));
    setTotal((n) => n - 1);
  };

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="space-y-4">
      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {([
            { label: "Total",      val: stats.total,      color: "text-foreground" },
            { label: "Malicious",  val: stats.malicious,  color: "text-red-400" },
            { label: "Suspicious", val: stats.suspicious, color: "text-orange-400" },
            { label: "Clean",      val: stats.clean,      color: "text-emerald-400" },
            { label: "Unknown",    val: stats.unknown,    color: "text-muted-foreground" },
          ] as const).map(({ label, val, color }) => (
            <Card key={label} className="border-border bg-card">
              <CardContent className="px-3 py-3">
                <p className={cn("text-xl font-bold", color)}>{val}</p>
                <p className="text-[11px] text-muted-foreground">{label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search indicator…"
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && fetchData(search)}
          />
        </div>
        <div className="flex gap-1.5">
          {(["all", "malicious", "suspicious", "clean", "unknown"] as const).map((v) => (
            <button
              key={v}
              onClick={() => { setVerdictFilter(v); setPage(0); fetchData(search, v, typeFilter, 0); }}
              className={cn(
                "px-3 py-1.5 text-xs rounded-md border capitalize transition-colors",
                verdictFilter === v ? "bg-primary/15 text-primary border-primary/30" : "border-border text-muted-foreground hover:text-foreground"
              )}
            >{v}</button>
          ))}
        </div>
        <Button size="sm" variant="outline" onClick={() => fetchData(search)}>
          <RefreshCw className="h-3.5 w-3.5" />
        </Button>
      </div>

      {/* Table */}
      <Card className="border-border bg-card">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Indicator</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Type</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Verdict</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground w-28">Risk</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Enriched</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Expires</th>
                  <th className="w-8 px-4" />
                </tr>
              </thead>
              <tbody>
                {loading ? Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-b border-border">
                    {Array.from({ length: 7 }).map((__, j) => (
                      <td key={j} className="px-4 py-3"><Skeleton className="h-4 w-full" /></td>
                    ))}
                  </tr>
                )) : rows.length === 0 ? (
                  <tr><td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">No indicators in the IOC database yet.</td></tr>
                ) : rows.map((row) => {
                  const vm = VERDICT_META[row.verdict as Verdict] ?? VERDICT_META.unknown;
                  const VIcon = vm.icon;
                  const tm = TYPE_META[row.indicatorType] ?? TYPE_META.ip;
                  const TIcon = tm.icon;
                  const expired = new Date(row.expiresAt) < new Date();
                  return (
                    <tr key={row.id} className="border-b border-border hover:bg-accent/30 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs text-foreground max-w-[200px]">
                        <span className="truncate block" title={row.indicator}>{row.indicator}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <TIcon className="h-3 w-3" />{tm.label}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className={cn("text-xs gap-1", vm.chip)}>
                          <VIcon className="h-3 w-3" />{vm.label}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          <div className="w-16 h-1.5 rounded-full bg-muted overflow-hidden">
                            <div className={cn("h-full rounded-full", riskBg(row.riskScore))} style={{ width: `${row.riskScore}%` }} />
                          </div>
                          <span className={cn("text-xs font-medium", riskColor(row.riskScore))}>{row.riskScore}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                        {format(new Date(row.enrichedAt), "MMM d, HH:mm")}
                      </td>
                      <td className="px-4 py-3 text-xs whitespace-nowrap">
                        <span className={cn(expired ? "text-orange-400" : "text-muted-foreground")}>
                          {expired ? "Expired" : formatDistanceToNow(new Date(row.expiresAt), { addSuffix: true })}
                        </span>
                      </td>
                      <td className="px-2 py-3">
                        <button onClick={() => handleDelete(row.id)} className="p-1 text-muted-foreground hover:text-destructive transition-colors rounded">
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {total > PAGE_SIZE && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <span className="text-xs text-muted-foreground">Page {page + 1} of {totalPages} · {total} total</span>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="h-7 text-xs" disabled={page === 0}
                  onClick={() => { const p = page - 1; setPage(p); fetchData(search, verdictFilter, typeFilter, p); }}>
                  Previous
                </Button>
                <Button size="sm" variant="outline" className="h-7 text-xs" disabled={page + 1 >= totalPages}
                  onClick={() => { const p = page + 1; setPage(p); fetchData(search, verdictFilter, typeFilter, p); }}>
                  Next
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/* ─── Lookup panel ─── */
function LookupPanel() {
  const [input, setInput] = useState("");
  const [result, setResult] = useState<EnrichmentResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<EnrichmentResult[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  const EXAMPLES = [
    { label: "IP", value: "8.8.8.8" },
    { label: "Domain", value: "malware.example.com" },
    { label: "Hash (SHA-256)", value: "44d88612fea8a8f36de82e1278abb02f" },
  ];

  async function lookup(indicator: string, forceFresh = false) {
    const trimmed = indicator.trim();
    if (!trimmed) return;
    setLoading(true); setError(null);
    try {
      const res = await fetch("/api/threat-intel/enrich", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ indicator: trimmed, forceFresh }),
      });
      if (!res.ok) { const d = await res.json(); setError(d.error ?? "Enrichment failed"); return; }
      const data = await res.json();
      setResult(data);
      setHistory((prev) => [data, ...prev.filter((h) => h.indicator !== data.indicator)].slice(0, 8));
    } finally { setLoading(false); }
  }

  return (
    <div className="space-y-4">
      {/* Search box */}
      <Card className="border-border bg-card">
        <CardContent className="p-5 space-y-3">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                ref={inputRef}
                placeholder="Enter IP, domain, MD5 / SHA-1 / SHA-256 hash, or URL…"
                className="pl-9 font-mono text-sm h-10"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && lookup(input)}
              />
              {input && (
                <button className="absolute right-2 top-2.5 text-muted-foreground hover:text-foreground" onClick={() => setInput("")}>
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            <Button className="h-10 px-5" disabled={loading || !input.trim()} onClick={() => lookup(input)}>
              {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              <span className="ml-2 hidden sm:inline">Enrich</span>
            </Button>
          </div>

          {/* Quick examples */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs text-muted-foreground">Try:</span>
            {EXAMPLES.map((ex) => (
              <button
                key={ex.value}
                onClick={() => { setInput(ex.value); lookup(ex.value); }}
                className="text-xs px-2.5 py-1 rounded-md border border-border text-muted-foreground hover:text-foreground hover:border-primary/40 transition-colors font-mono"
              >
                {ex.value}
              </button>
            ))}
          </div>

          {error && (
            <div className="flex items-center gap-2 text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded-md px-3 py-2">
              <XCircle className="h-3.5 w-3.5 flex-shrink-0" />{error}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Result */}
        <div className="lg:col-span-2 space-y-3">
          {loading && (
            <Card className="border-border bg-card">
              <CardContent className="p-5 space-y-3">
                {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-5 w-full" />)}
              </CardContent>
            </Card>
          )}
          {!loading && result && (
            <EnrichmentCard result={result} onRefresh={() => lookup(result.indicator, true)} loading={loading} />
          )}
          {!loading && !result && !error && (
            <Card className="border-border bg-card border-dashed">
              <CardContent className="p-12 flex flex-col items-center gap-3 text-center">
                <Shield className="h-12 w-12 text-muted-foreground/40" />
                <p className="text-muted-foreground">Enter an indicator above to enrich it against IP reputation,<br />GeoIP, ASN data, and live threat feeds.</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* History */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide px-1">Recent lookups</p>
          {history.length === 0 ? (
            <p className="text-xs text-muted-foreground px-1">No lookups yet.</p>
          ) : (
            history.map((h) => {
              const vm = VERDICT_META[h.verdict] ?? VERDICT_META.unknown;
              const VIcon = vm.icon;
              return (
                <button
                  key={h.indicator}
                  className="w-full text-left rounded-md border border-border bg-card px-3 py-2.5 hover:border-primary/40 hover:bg-accent/30 transition-colors"
                  onClick={() => { setInput(h.indicator); setResult(h); }}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs text-foreground truncate">{h.indicator}</span>
                    <Badge variant="outline" className={cn("text-[10px] gap-0.5 flex-shrink-0", vm.chip)}>
                      <VIcon className="h-2.5 w-2.5" />{h.riskScore}
                    </Badge>
                  </div>
                  <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{h.verdictReason}</p>
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

/* ─── Page ─── */
export default function ThreatIntel() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Threat Intelligence</h1>
        <p className="text-sm text-muted-foreground mt-1">Enrich indicators against live feeds — IP reputation, GeoIP, ASN, hashes, domains</p>
      </div>

      {/* Feed status chips */}
      <div className="flex flex-wrap gap-2">
        {[
          { name: "ip-api.com", desc: "GeoIP + ASN", live: true },
          { name: "ThreatFox",  desc: "IOC feed",    live: true },
          { name: "URLhaus",    desc: "Hash / URL",   live: true },
          { name: "Heuristics", desc: "Always-on",   live: true },
        ].map((f) => (
          <div key={f.name} className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-emerald-500/20 bg-emerald-500/5 text-xs">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-medium text-emerald-400">{f.name}</span>
            <span className="text-muted-foreground">· {f.desc}</span>
          </div>
        ))}
      </div>

      <Tabs defaultValue="lookup">
        <TabsList className="h-9">
          <TabsTrigger value="lookup" className="text-xs gap-1.5">
            <Search className="h-3.5 w-3.5" />Indicator Lookup
          </TabsTrigger>
          <TabsTrigger value="database" className="text-xs gap-1.5">
            <Database className="h-3.5 w-3.5" />IOC Database
          </TabsTrigger>
        </TabsList>
        <TabsContent value="lookup" className="mt-4"><LookupPanel /></TabsContent>
        <TabsContent value="database" className="mt-4"><IocDatabase /></TabsContent>
      </Tabs>
    </div>
  );
}
