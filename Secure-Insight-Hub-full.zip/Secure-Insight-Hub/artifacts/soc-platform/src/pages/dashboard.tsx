import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { format } from "date-fns";
import {
  ShieldAlert, AlertTriangle, AlertCircle, Clock, TrendingDown, TrendingUp,
  Crosshair, Lightbulb, Sparkles, CheckCircle2, XCircle, Activity,
  Users, FileBadge, BrainCircuit, SlidersHorizontal, Inbox,
  Timer, BarChart3, RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ─── tiny bar sparkline (no deps) ─── */
function MiniBar({ value, max, color }: { value: number; max: number; color: string }) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
        <div className={cn("h-full rounded-full", color)} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-[11px] font-mono text-muted-foreground w-6 text-right">{value}</span>
    </div>
  );
}

/* ─── stat card ─── */
function StatCard({
  label, value, sub, icon: Icon, color = "text-foreground", trend, loading,
}: {
  label: string; value: string | number | null; sub?: string; icon: typeof ShieldAlert;
  color?: string; trend?: { value: number; good: "up" | "down" }; loading?: boolean;
}) {
  const TrendIcon = trend && trend.value >= 0 ? TrendingUp : TrendingDown;
  const trendGood = trend && (trend.good === "up" ? trend.value >= 0 : trend.value < 0);
  return (
    <Card className="border-border bg-card">
      <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <Icon className={cn("h-4 w-4", color)} />
      </CardHeader>
      <CardContent className="px-4 pb-4">
        {loading ? (
          <Skeleton className="h-8 w-20" />
        ) : (
          <p className={cn("text-2xl font-bold tracking-tight", color)}>
            {value ?? "—"}
          </p>
        )}
        {(sub || trend) && !loading && (
          <div className="flex items-center gap-1.5 mt-1">
            {trend && (
              <span className={cn("text-[11px] flex items-center gap-0.5", trendGood ? "text-emerald-400" : "text-red-400")}>
                <TrendIcon className="h-3 w-3" />{Math.abs(trend.value)}%
              </span>
            )}
            {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* ─── MITRE heatmap cell ─── */
function HeatCell({ count, max, techniqueId, technique }: { count: number; max: number; techniqueId: string; technique: string | null }) {
  const intensity = max > 0 ? count / max : 0;
  const bg = intensity > 0.75 ? "bg-red-500" : intensity > 0.5 ? "bg-orange-500" : intensity > 0.25 ? "bg-yellow-500" : "bg-blue-500";
  return (
    <div
      title={`${techniqueId}: ${technique ?? "unknown"} — ${count} alerts`}
      className={cn("rounded px-1.5 py-1 flex flex-col items-center gap-0.5 cursor-default", bg, "bg-opacity-20 border border-current border-opacity-30")}
      style={{ opacity: 0.3 + intensity * 0.7 }}
    >
      <span className="text-[10px] font-mono font-semibold leading-none">{techniqueId}</span>
      <span className="text-[9px] text-foreground/70 leading-none">{count}</span>
    </div>
  );
}

/* ─── types ─── */
interface ExecData {
  alertsToday: number; criticalAlerts: number; activeIncidents: number;
  falsePositivePct: number; mttrHours: number | null; aiReviewsPending: number;
  complianceScore: number; avgAiConfidence: number | null;
  totalAlerts: number; highAlerts: number; incidentsResolved: number; incidentsTotal: number;
}
interface MitreRow { techniqueId: string; technique: string | null; tactic: string | null; count: number; critical: number; high: number; }
interface Suggestion { ruleId: string; ruleName: string; totalAlerts: number; fpRate: number; suggestion: string; priority: string; }
interface AnalystData {
  myAlerts: { total: number; critical: number; new: number };
  myIncidents: { total: number; open: number; investigating: number; awaitingApproval: number };
  pendingReviews: number;
  sla: { windowHours: number; breachedCount: number };
  workloadByDay: { date: string; count: number }[];
}

function useApi<T>(url: string, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [ts, setTs] = useState(0);

  useEffect(() => {
    setLoading(true);
    fetch(url).then((r) => (r.ok ? r.json() : null)).then(setData).catch(() => setData(null)).finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, ts, ...deps]);

  return { data, loading, refresh: () => setTs(Date.now()) };
}

/* ═══════════════════════════ EXECUTIVE DASHBOARD ═══════════════════════════ */
function ExecutiveDashboard() {
  const { data: exec, loading: execLoading, refresh } = useApi<ExecData>("/api/dashboard");
  const { data: mitreRaw, loading: mitreLoading } = useApi<MitreRow[]>("/api/dashboard/mitre-heatmap");
  const { data: ruleSuggestions, loading: suggestionsLoading } = useApi<{ suggestions: Suggestion[] }>("/api/dashboard/rule-suggestions");
  const { data: trends, loading: trendsLoading } = useApi<{ date: string; critical: number; high: number; medium: number; low: number }[]>("/api/dashboard/threat-trends");

  const mitre = mitreRaw ?? [];
  const maxMitreCount = mitre.reduce((m, r) => Math.max(m, r.count), 0);
  const suggestions = ruleSuggestions?.suggestions ?? [];

  // Workload trend: last 7 days total vs prior
  const trendTotal = trends?.reduce((s, r) => s + r.critical + r.high + r.medium + r.low, 0) ?? 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Executive Overview</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Live security posture across all environments</p>
        </div>
        <Button size="sm" variant="outline" className="gap-1.5" onClick={refresh}>
          <RefreshCw className="h-3.5 w-3.5" />Refresh
        </Button>
      </div>

      {/* Row 1: KPI cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard label="Alerts Today" value={exec?.alertsToday ?? null} icon={Activity} color="text-foreground" loading={execLoading} trend={{ value: 12, good: "down" }} />
        <StatCard label="Critical Alerts" value={exec?.criticalAlerts ?? null} icon={ShieldAlert} color={exec?.criticalAlerts ? "text-red-400" : "text-foreground"} loading={execLoading} />
        <StatCard label="Open Incidents" value={exec?.activeIncidents ?? null} icon={AlertTriangle} color={exec?.activeIncidents ? "text-orange-400" : "text-foreground"} loading={execLoading} />
        <StatCard label="False Positive %" value={exec ? `${exec.falsePositivePct}%` : null} icon={XCircle} color={exec && exec.falsePositivePct > 30 ? "text-red-400" : exec && exec.falsePositivePct < 15 ? "text-emerald-400" : "text-yellow-400"} loading={execLoading} />
        <StatCard label="MTTR" value={exec?.mttrHours != null ? `${exec.mttrHours}h` : "—"} icon={Clock} color="text-foreground" loading={execLoading} sub="mean time to resolve" />
        <StatCard label="AI Reviews Pending" value={exec?.aiReviewsPending ?? null} icon={Sparkles} color={exec?.aiReviewsPending ? "text-primary" : "text-foreground"} loading={execLoading} />
      </div>

      {/* Row 2: Compliance + AI Health */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="border-border bg-card col-span-1">
          <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
            <p className="text-xs font-medium text-muted-foreground">Compliance Score</p>
            <FileBadge className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent className="px-4 pb-4">
            {execLoading ? <Skeleton className="h-8 w-16" /> : (
              <>
                <p className={cn("text-2xl font-bold", exec && exec.complianceScore >= 80 ? "text-emerald-400" : exec && exec.complianceScore >= 60 ? "text-yellow-400" : "text-red-400")}>
                  {exec?.complianceScore ?? "—"}<span className="text-sm font-normal text-muted-foreground">/100</span>
                </p>
                <Progress value={exec?.complianceScore ?? 0} className="h-1.5 mt-2" />
                <p className="text-[11px] text-muted-foreground mt-1">Based on FP rate, pending reviews, critical alerts</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="border-border bg-card col-span-1">
          <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
            <p className="text-xs font-medium text-muted-foreground">AI Health</p>
            <BrainCircuit className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent className="px-4 pb-4 space-y-2">
            {execLoading ? <Skeleton className="h-16 w-full" /> : (
              <>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Avg. confidence</span>
                  <span className="font-medium">{exec?.avgAiConfidence != null ? `${exec.avgAiConfidence}%` : "—"}</span>
                </div>
                <Progress value={exec?.avgAiConfidence ?? 0} className="h-1.5" />
                <div className="grid grid-cols-3 gap-1 pt-1 text-center">
                  <div>
                    <p className="text-sm font-semibold text-foreground">{exec?.aiReviewsPending ?? "—"}</p>
                    <p className="text-[10px] text-muted-foreground">Pending</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-emerald-400">{exec ? (exec.aiReviewsPending != null ? "✓" : "—") : "—"}</p>
                    <p className="text-[10px] text-muted-foreground">Approved</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-muted-foreground">{exec?.incidentsResolved ?? "—"}/{exec?.incidentsTotal ?? "—"}</p>
                    <p className="text-[10px] text-muted-foreground">Resolved</p>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Alert severity breakdown */}
        <Card className="border-border bg-card col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
            <p className="text-xs font-medium text-muted-foreground">Alert Severity Breakdown</p>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="px-4 pb-4 space-y-2">
            {execLoading ? <Skeleton className="h-20 w-full" /> : (
              <>
                {[
                  { label: "Critical", value: exec?.criticalAlerts ?? 0, color: "bg-red-500" },
                  { label: "High", value: exec?.highAlerts ?? 0, color: "bg-orange-500" },
                  { label: "Total", value: exec?.totalAlerts ?? 0, color: "bg-primary" },
                ].map(({ label, value, color }) => (
                  <div key={label} className="space-y-0.5">
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">{label}</span>
                      <span className="font-medium text-foreground">{value}</span>
                    </div>
                    <MiniBar value={value} max={exec?.totalAlerts ?? 1} color={color} />
                  </div>
                ))}
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Row 3: MITRE Heatmap */}
      <Card className="border-border bg-card">
        <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
          <div>
            <CardTitle className="text-sm font-medium">MITRE ATT&CK Heatmap</CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">Techniques observed across all alerts — darker = higher volume</p>
          </div>
          <Crosshair className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {mitreLoading ? (
            <div className="flex flex-wrap gap-1.5">{Array.from({ length: 12 }).map((_, i) => <Skeleton key={i} className="h-10 w-16" />)}</div>
          ) : mitre.length === 0 ? (
            <p className="text-sm text-muted-foreground">No MITRE techniques mapped yet. Run AI analysis on alerts to populate this.</p>
          ) : (
            <>
              <div className="flex flex-wrap gap-1.5">
                {mitre.map((r) => (
                  <HeatCell key={r.techniqueId} count={r.count} max={maxMitreCount} techniqueId={r.techniqueId ?? ""} technique={r.technique} />
                ))}
              </div>
              {/* Tactic breakdown */}
              {(() => {
                const byTactic = mitre.reduce<Record<string, number>>((acc, r) => {
                  if (r.tactic) acc[r.tactic] = (acc[r.tactic] ?? 0) + r.count;
                  return acc;
                }, {});
                const entries = Object.entries(byTactic).sort((a, b) => b[1] - a[1]);
                return entries.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5 mt-3 pt-3 border-t border-border">
                    {entries.map(([tactic, count]) => (
                      <Badge key={tactic} variant="outline" className="text-[10px] border-border text-muted-foreground capitalize">
                        {tactic.replace(/-/g, " ")} <span className="ml-1 font-semibold text-foreground">{count}</span>
                      </Badge>
                    ))}
                  </div>
                ) : null;
              })()}
            </>
          )}
        </CardContent>
      </Card>

      {/* Row 4: Rule Optimization Suggestions */}
      <Card className="border-border bg-card">
        <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
          <div>
            <CardTitle className="text-sm font-medium">Rule Optimization Suggestions</CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">Rules with high volume or false-positive rates</p>
          </div>
          <Lightbulb className="h-4 w-4 text-yellow-400" />
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {suggestionsLoading ? (
            Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10 w-full mb-2" />)
          ) : suggestions.length === 0 ? (
            <p className="text-sm text-muted-foreground">No optimization suggestions yet — generate more alerts data to see patterns.</p>
          ) : (
            <div className="space-y-2">
              {suggestions.map((s) => (
                <div key={s.ruleId} className="flex items-start gap-3 rounded-md border border-border px-3 py-2.5">
                  <Badge variant="outline" className={cn(
                    "text-[10px] flex-shrink-0 mt-0.5",
                    s.priority === "high" ? "border-red-500/30 text-red-400" :
                    s.priority === "medium" ? "border-yellow-500/30 text-yellow-400" :
                    "border-border text-muted-foreground"
                  )}>{s.priority}</Badge>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{s.ruleName}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{s.suggestion}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-xs font-medium text-foreground">{s.totalAlerts} alerts</p>
                    <p className="text-[11px] text-muted-foreground">{s.fpRate}% FP rate</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/* ═══════════════════════════ ANALYST DASHBOARD ═══════════════════════════ */
function AnalystDashboard() {
  const { data, loading, refresh } = useApi<AnalystData>("/api/dashboard/analyst");

  const workload = data?.workloadByDay ?? [];
  const maxWorkload = workload.reduce((m, r) => Math.max(m, r.count), 0);
  const slaBreached = data?.sla.breachedCount ?? 0;
  const slaWindowHours = data?.sla.windowHours ?? 4;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">My Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Your personal queue and SLA status</p>
        </div>
        <Button size="sm" variant="outline" className="gap-1.5" onClick={refresh}>
          <RefreshCw className="h-3.5 w-3.5" />Refresh
        </Button>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <StatCard label="My Alerts" value={data?.myAlerts.total ?? null} sub={data ? `${data.myAlerts.critical} critical · ${data.myAlerts.new} new` : undefined} icon={AlertCircle} loading={loading} />
        <StatCard label="My Incidents" value={data?.myIncidents.total ?? null} icon={ShieldAlert} loading={loading} color={data?.myIncidents.total ? "text-orange-400" : "text-foreground"} />
        <StatCard label="Pending Reviews" value={data?.pendingReviews ?? null} icon={Sparkles} loading={loading} color={data?.pendingReviews ? "text-primary" : "text-foreground"} />
        <StatCard
          label={`SLA >${slaWindowHours}h`}
          value={slaBreached}
          icon={Timer}
          loading={loading}
          color={slaBreached > 0 ? "text-red-400" : "text-emerald-400"}
          sub={slaBreached > 0 ? "alerts need acknowledgment" : "all within SLA"}
        />
        <StatCard label="Awaiting Approval" value={data?.myIncidents.awaitingApproval ?? null} icon={CheckCircle2} loading={loading} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Incident breakdown */}
        <Card className="border-border bg-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
            <CardTitle className="text-sm font-medium">My Incidents by Stage</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="px-4 pb-4 space-y-3">
            {loading ? <Skeleton className="h-24 w-full" /> : (
              [
                { label: "Open / Assigned", value: data?.myIncidents.open ?? 0, color: "bg-blue-500" },
                { label: "Investigating", value: data?.myIncidents.investigating ?? 0, color: "bg-yellow-500" },
                { label: "Awaiting Approval", value: data?.myIncidents.awaitingApproval ?? 0, color: "bg-orange-500" },
              ].map(({ label, value, color }) => (
                <div key={label} className="space-y-0.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">{label}</span>
                    <span className="font-medium text-foreground">{value}</span>
                  </div>
                  <MiniBar value={value} max={data?.myIncidents.total ?? 1} color={color} />
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* SLA status */}
        <Card className={cn("border-border bg-card", slaBreached > 0 && !loading && "border-red-500/30")}>
          <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
            <CardTitle className="text-sm font-medium">SLA Status</CardTitle>
            <Timer className={cn("h-4 w-4", slaBreached > 0 && !loading ? "text-red-400" : "text-muted-foreground")} />
          </CardHeader>
          <CardContent className="px-4 pb-4">
            {loading ? <Skeleton className="h-16 w-full" /> : (
              <div className="space-y-3">
                <div className="text-center py-2">
                  <p className={cn("text-3xl font-bold", slaBreached > 0 ? "text-red-400" : "text-emerald-400")}>
                    {slaBreached}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    alert{slaBreached !== 1 ? "s" : ""} past the {slaWindowHours}h acknowledgment window
                  </p>
                </div>
                {slaBreached > 0 ? (
                  <div className="flex items-center gap-2 rounded-md bg-red-500/10 border border-red-500/20 px-3 py-2">
                    <AlertTriangle className="h-3.5 w-3.5 text-red-400 flex-shrink-0" />
                    <p className="text-xs text-red-400">Acknowledge these alerts to stay within SLA</p>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 rounded-md bg-emerald-500/10 border border-emerald-500/20 px-3 py-2">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 flex-shrink-0" />
                    <p className="text-xs text-emerald-400">All alerts acknowledged within the {slaWindowHours}h window</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Workload chart — 7 day bar chart */}
      <Card className="border-border bg-card">
        <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
          <div>
            <CardTitle className="text-sm font-medium">Alert Workload — Last 7 Days</CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">Incoming alert volume across your organisation</p>
          </div>
          <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {loading ? <Skeleton className="h-24 w-full" /> : workload.length === 0 ? (
            <p className="text-sm text-muted-foreground">No alert data for the last 7 days.</p>
          ) : (
            <div className="flex items-end gap-1.5 h-24">
              {workload.map((day) => {
                const heightPct = maxWorkload > 0 ? (day.count / maxWorkload) * 100 : 0;
                return (
                  <div key={day.date} className="flex-1 flex flex-col items-center gap-1" title={`${day.date}: ${day.count} alerts`}>
                    <span className="text-[10px] text-muted-foreground">{day.count}</span>
                    <div className="w-full rounded-t bg-primary/60 transition-all" style={{ height: `${Math.max(4, heightPct)}%`, minHeight: "4px" }} />
                    <span className="text-[9px] text-muted-foreground rotate-45 origin-left whitespace-nowrap">
                      {format(new Date(day.date + "T00:00:00"), "MMM d")}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pending review queue */}
      <Card className="border-border bg-card">
        <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
          <CardTitle className="text-sm font-medium">Quick Actions</CardTitle>
          <Inbox className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <a href="/alerts?reviewStatus=pending_review" className="flex items-center gap-3 rounded-md border border-border px-3 py-2.5 hover:border-primary/40 hover:bg-accent/30 transition-colors cursor-pointer">
              <Sparkles className="h-4 w-4 text-primary flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-foreground">Review AI analyses</p>
                <p className="text-xs text-muted-foreground">{data?.pendingReviews ?? "—"} pending approval</p>
              </div>
            </a>
            <a href="/alerts?status=new" className="flex items-center gap-3 rounded-md border border-border px-3 py-2.5 hover:border-primary/40 hover:bg-accent/30 transition-colors cursor-pointer">
              <AlertCircle className="h-4 w-4 text-blue-400 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-foreground">Triage new alerts</p>
                <p className="text-xs text-muted-foreground">{data?.myAlerts.new ?? "—"} unacknowledged</p>
              </div>
            </a>
            <a href="/incidents?status=investigating" className="flex items-center gap-3 rounded-md border border-border px-3 py-2.5 hover:border-primary/40 hover:bg-accent/30 transition-colors cursor-pointer">
              <ShieldAlert className="h-4 w-4 text-orange-400 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-foreground">Active investigations</p>
                <p className="text-xs text-muted-foreground">{data?.myIncidents.investigating ?? "—"} in progress</p>
              </div>
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

/* ═══════════════════════════ ROOT EXPORT ═══════════════════════════ */
export default function Dashboard() {
  return (
    <div className="space-y-0">
      <Tabs defaultValue="executive">
        <div className="mb-6 flex items-center gap-4">
          <TabsList className="h-9">
            <TabsTrigger value="executive" className="text-xs gap-1.5">
              <FileBadge className="h-3.5 w-3.5" />Executive
            </TabsTrigger>
            <TabsTrigger value="analyst" className="text-xs gap-1.5">
              <Users className="h-3.5 w-3.5" />Analyst
            </TabsTrigger>
          </TabsList>
        </div>
        <TabsContent value="executive" className="m-0"><ExecutiveDashboard /></TabsContent>
        <TabsContent value="analyst" className="m-0"><AnalystDashboard /></TabsContent>
      </Tabs>
    </div>
  );
}
