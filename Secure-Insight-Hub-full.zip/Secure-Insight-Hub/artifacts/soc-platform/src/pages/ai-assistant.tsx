export default function AiAssistant() {
  return <div className="p-4">AI Assistant Coming Soon</div>;
}