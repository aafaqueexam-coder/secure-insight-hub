import { useState } from "react";
import {
  useGetLatestRuleTuningJob,
  useTriggerRuleTuningJob,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import {
  AlertTriangle, Bot, CheckCircle2, Clock, Play, RefreshCw, Shield,
  TrendingDown, TrendingUp, VolumeX, Wrench, XCircle, ChevronDown,
  ChevronUp, History, Check, X, Search, SlidersHorizontal, Gauge,
  Sparkles, ArrowRight, Info,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ─── meta ─── */
const ACTION_META: Record<string, { label: string; color: string; rail: string; icon: React.ElementType }> = {
  suppress:        { label: "Suppress",          color: "bg-red-500/10 text-red-400 border-red-500/20",         rail: "bg-red-500",    icon: VolumeX },
  raise_threshold: { label: "Raise Threshold",   color: "bg-orange-500/10 text-orange-400 border-orange-500/20", rail: "bg-orange-500", icon: TrendingDown },
  tune_frequency:  { label: "Tune Frequency",    color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20", rail: "bg-yellow-500", icon: Wrench },
  investigate_fp:  { label: "Investigate FP",    color: "bg-purple-500/10 text-purple-400 border-purple-500/20", rail: "bg-purple-500", icon: AlertTriangle },
  keep:            { label: "Well Calibrated",   color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20", rail: "bg-emerald-500", icon: CheckCircle2 },
};

const PRIORITY_COLOR: Record<string, string> = {
  high:   "bg-red-500/15 text-red-400 border-red-500/30",
  medium: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30",
  low:    "bg-slate-500/15 text-slate-400 border-slate-500/30",
};

function riskColor(score: number) {
  if (score >= 70) return "text-red-400";
  if (score >= 40) return "text-yellow-400";
  return "text-emerald-400";
}

/* ─── history drawer ─── */
function VersionHistory({ ruleId, jobId }: { ruleId: string; jobId: string }) {
  const [history, setHistory] = useState<any[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);

  async function load() {
    if (history) { setOpen((v) => !v); return; }
    setLoading(true);
    try {
      const res = await fetch(`/api/rule-tuning/rules/${ruleId}/history`);
      setHistory(res.ok ? await res.json() : []);
      setOpen(true);
    } finally { setLoading(false); }
  }

  return (
    <div>
      <Button size="sm" variant="ghost" className="h-7 text-xs gap-1.5 text-muted-foreground" onClick={load} disabled={loading}>
        {loading ? <RefreshCw className="h-3 w-3 animate-spin" /> : <History className="h-3 w-3" />}
        Version history
        {open ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
      </Button>

      {open && history && (
        <div className="mt-2 rounded-md border border-border bg-muted/20 divide-y divide-border">
          {history.length === 0 ? (
            <p className="text-xs text-muted-foreground px-3 py-2">No decisions recorded for this rule yet.</p>
          ) : (
            history.map((d) => (
              <div key={d.id} className="px-3 py-2 flex items-start gap-3">
                <Badge variant="outline" className={cn("text-[10px] flex-shrink-0", d.decision === "approved" ? "border-emerald-500/30 text-emerald-400" : "border-red-500/30 text-red-400")}>
                  {d.decision === "approved" ? <Check className="h-2.5 w-2.5 mr-0.5" /> : <X className="h-2.5 w-2.5 mr-0.5" />}
                  {d.decision}
                </Badge>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-foreground/80">{d.suggestedChange}</p>
                  {d.analystNote && <p className="text-[11px] text-muted-foreground italic mt-0.5">"{d.analystNote}"</p>}
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-[11px] text-muted-foreground">{d.decidedByName}</p>
                  <p className="text-[10px] text-muted-foreground">{format(new Date(d.decidedAt), "MMM d, yyyy")}</p>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

/* ─── single recommendation card ─── */
function RecommendationCard({ rec, jobId, onDecision }: { rec: any; jobId: string; onDecision: () => void }) {
  const { toast } = useToast();
  const meta = ACTION_META[rec.action] ?? ACTION_META.keep;
  const Icon = meta.icon;
  const fpPct = ((rec.metrics?.falsePositiveRatio ?? 0) * 100).toFixed(0);
  const avgHrs = rec.metrics?.avgResolutionHours != null ? `${rec.metrics.avgResolutionHours}h` : "—";
  const riskScore = rec.riskScore ?? 0;
  const [deciding, setDeciding] = useState<"approved" | "rejected" | null>(null);
  const [note, setNote] = useState("");
  const [showNote, setShowNote] = useState(false);
  const [pendingDecision, setPendingDecision] = useState<"approved" | "rejected" | null>(null);
  const latestDecision = rec.latestDecision;

  async function submitDecision(decision: "approved" | "rejected") {
    setDeciding(decision);
    try {
      const res = await fetch(`/api/rule-tuning/${jobId}/rules/${rec.ruleId}/decision`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ decision, analystNote: note.trim() || undefined }),
      });
      if (res.ok) {
        toast({ title: decision === "approved" ? "Change approved" : "Change rejected", description: `Decision recorded for "${rec.ruleName}".` });
        setNote(""); setShowNote(false); setPendingDecision(null);
        onDecision();
      }
    } finally { setDeciding(null); }
  }

  return (
    <Card className="border-border bg-card overflow-hidden">
      {/* Severity rail */}
      <div className="flex">
        <div className={cn("w-1 flex-shrink-0", meta.rail)} />
        <div className="flex-1">
          <CardContent className="p-5 space-y-4">

            {/* Header */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 min-w-0">
                <div className={cn("mt-0.5 p-1.5 rounded-md border flex-shrink-0", meta.color)}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="font-semibold text-foreground truncate">{rec.ruleName}</p>
                  <p className="text-xs text-muted-foreground font-mono">Rule {rec.ruleId}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <Badge variant="outline" className={cn("text-xs", PRIORITY_COLOR[rec.priority])}>{rec.priority}</Badge>
                <Badge variant="outline" className={cn("text-xs", meta.color)}>{meta.label}</Badge>
                {latestDecision && (
                  <Badge variant="outline" className={cn("text-xs gap-1", latestDecision.decision === "approved" ? "border-emerald-500/30 text-emerald-400" : "border-red-500/30 text-red-400")}>
                    {latestDecision.decision === "approved" ? <Check className="h-2.5 w-2.5" /> : <X className="h-2.5 w-2.5" />}
                    {latestDecision.decision}
                  </Badge>
                )}
              </div>
            </div>

            {/* Metrics strip */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 py-3 px-4 rounded-lg bg-muted/30 border border-border/60">
              {[
                { label: "Trigger Count",   value: rec.metrics?.totalAlerts ?? 0 },
                { label: "Alerts/Day",      value: rec.metrics?.alertsPerDay?.toFixed(1) ?? "—" },
                { label: "FP Rate",         value: `${fpPct}%` },
                { label: "Avg Resolution",  value: avgHrs },
                { label: "Unique IPs",      value: rec.metrics?.uniqueSourceIps ?? 0 },
                { label: "Agents Hit",      value: rec.metrics?.uniqueAgents ?? 0 },
              ].map(({ label, value }) => (
                <div key={label} className="flex flex-col gap-0.5">
                  <span className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</span>
                  <span className="text-sm font-semibold text-foreground">{value}</span>
                </div>
              ))}
            </div>

            {/* Risk score */}
            <div className="flex items-center gap-4">
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1 text-muted-foreground"><Gauge className="h-3 w-3" />Risk score</span>
                  <span className={cn("font-bold text-sm", riskColor(riskScore))}>{riskScore}/100</span>
                </div>
                <Progress value={riskScore} className="h-1.5"
                  style={{ "--progress-color": riskScore >= 70 ? "rgb(248,113,113)" : riskScore >= 40 ? "rgb(234,179,8)" : "rgb(52,211,153)" } as any} />
              </div>
            </div>

            {/* Finding + AI suggestion */}
            <div className="space-y-2.5">
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">Finding</p>
                <p className="text-sm text-foreground/90 leading-relaxed">{rec.reason}</p>
              </div>
              <Separator />
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1 flex items-center gap-1">
                  <Sparkles className="h-3 w-3 text-primary" />AI Suggestion
                </p>
                <p className="text-sm text-primary/90 leading-relaxed">{rec.suggestedChange}</p>
              </div>
              {rec.expectedImprovement && (
                <div className="flex items-start gap-2 rounded-md bg-emerald-500/8 border border-emerald-500/15 px-3 py-2">
                  <ArrowRight className="h-3.5 w-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-emerald-400 leading-relaxed">
                    <span className="font-medium">Expected improvement: </span>{rec.expectedImprovement}
                  </p>
                </div>
              )}
            </div>

            {/* Approve / Reject */}
            <div className="space-y-2 pt-1">
              {showNote && (
                <Textarea
                  autoFocus
                  placeholder="Optional note for the audit trail…"
                  className="text-sm min-h-[56px] resize-none"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                />
              )}
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
                  disabled={!!deciding}
                  onClick={() => {
                    if (showNote) { submitDecision("approved"); }
                    else { setPendingDecision("approved"); setShowNote(true); }
                  }}
                >
                  {deciding === "approved" ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                  Approve Change
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="gap-1.5 border-red-500/40 text-red-400 hover:bg-red-500/10"
                  disabled={!!deciding}
                  onClick={() => {
                    if (showNote) { submitDecision("rejected"); }
                    else { setPendingDecision("rejected"); setShowNote(true); }
                  }}
                >
                  {deciding === "rejected" ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <X className="h-3.5 w-3.5" />}
                  Reject Change
                </Button>
                {showNote && (
                  <Button size="sm" variant="ghost" className="text-xs" onClick={() => { setShowNote(false); setNote(""); }}>
                    Cancel
                  </Button>
                )}
                {!showNote && (
                  <Button size="sm" variant="ghost" className="text-xs gap-1 text-muted-foreground ml-auto" onClick={() => setShowNote(true)}>
                    <Info className="h-3 w-3" />Add note
                  </Button>
                )}
              </div>
            </div>

            {/* Version history */}
            <VersionHistory ruleId={rec.ruleId} jobId={jobId} />
          </CardContent>
        </div>
      </div>
    </Card>
  );
}

/* ─── page ─── */
export default function RuleTuning() {
  const { toast } = useToast();
  const [isRunning, setIsRunning] = useState(false);
  const [search, setSearch] = useState("");
  const [filterAction, setFilterAction] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");
  const [sortBy, setSortBy] = useState<"priority" | "riskScore" | "triggers">("riskScore");

  const { data: job, isLoading, error, refetch } = useGetLatestRuleTuningJob();
  const { mutateAsync: triggerJob } = useTriggerRuleTuningJob();

  const handleRun = async () => {
    setIsRunning(true);
    try {
      await triggerJob();
      await refetch();
      toast({ title: "Analysis complete", description: "Rule tuning recommendations updated." });
    } catch {
      toast({ title: "Job failed", description: "Could not run analysis.", variant: "destructive" });
    } finally { setIsRunning(false); }
  };

  const rawRecs: any[] = (job as any)?.recommendations ?? [];
  const recs = rawRecs
    .filter((r) => {
      if (search && !r.ruleName.toLowerCase().includes(search.toLowerCase()) && !r.ruleId.toLowerCase().includes(search.toLowerCase())) return false;
      if (filterAction !== "all" && r.action !== filterAction) return false;
      if (filterPriority !== "all" && r.priority !== filterPriority) return false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === "priority") {
        const o = { high: 0, medium: 1, low: 2 };
        return (o[a.priority as keyof typeof o] ?? 2) - (o[b.priority as keyof typeof o] ?? 2);
      }
      if (sortBy === "riskScore") return (b.riskScore ?? 0) - (a.riskScore ?? 0);
      return (b.metrics?.totalAlerts ?? 0) - (a.metrics?.totalAlerts ?? 0);
    });

  const highCount = rawRecs.filter((r) => r.priority === "high").length;
  const needsAction = rawRecs.filter((r) => r.action !== "keep").length;
  const decided = rawRecs.filter((r) => r.latestDecision).length;
  const actionSummary = rawRecs.reduce<Record<string, number>>((acc, r) => { acc[r.action] = (acc[r.action] ?? 0) + 1; return acc; }, {});

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Rule Optimization</h1>
          <p className="text-muted-foreground mt-1">AI-powered analysis — reduce noise, protect signal</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isLoading}>
            <RefreshCw className="h-4 w-4 mr-2" />Refresh
          </Button>
          <Button size="sm" onClick={handleRun} disabled={isRunning}>
            {isRunning ? <><RefreshCw className="h-4 w-4 mr-2 animate-spin" />Analyzing…</> : <><Play className="h-4 w-4 mr-2" />Run Analysis</>}
          </Button>
        </div>
      </div>

      {/* Loading */}
      {isLoading && (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="border-border"><CardContent className="p-5"><Skeleton className="h-40 w-full" /></CardContent></Card>
          ))}
        </div>
      )}

      {/* Empty */}
      {!isLoading && error && (
        <Card className="border-border">
          <CardContent className="p-12 flex flex-col items-center gap-4 text-center">
            <div className="p-4 rounded-full bg-muted/40"><Bot className="h-10 w-10 text-muted-foreground" /></div>
            <div>
              <p className="font-semibold text-lg">No analysis yet</p>
              <p className="text-muted-foreground text-sm mt-1">Click <strong>Run Analysis</strong> to analyze the past 30 days of alert data.</p>
            </div>
            <Button onClick={handleRun} disabled={isRunning} className="mt-2">
              {isRunning ? <><RefreshCw className="h-4 w-4 mr-2 animate-spin" />Analyzing…</> : <><Play className="h-4 w-4 mr-2" />Run Analysis Now</>}
            </Button>
          </CardContent>
        </Card>
      )}

      {!isLoading && job && (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {[
              { label: "Alerts Analyzed", value: (job as any).totalAlertsAnalyzed, icon: Shield, color: "text-foreground", sub: `past ${(job as any).aggregationWindowDays}d` },
              { label: "Rules Evaluated", value: rawRecs.length, icon: TrendingUp, color: "text-foreground", sub: `${needsAction} need attention` },
              { label: "High Priority", value: highCount, icon: AlertTriangle, color: highCount > 0 ? "text-red-400" : "text-foreground", sub: "immediate action" },
              { label: "Decisions Made", value: decided, icon: CheckCircle2, color: "text-emerald-400", sub: `of ${rawRecs.length} rules` },
              { label: "AI Model", value: (job as any).aiModelUsed ?? "Rule-based", icon: Bot, color: "text-primary", sub: format(new Date((job as any).jobRunAt), "MMM d, HH:mm") },
            ].map(({ label, value, icon: Icon, color, sub }) => (
              <Card key={label} className="border-border bg-card">
                <CardHeader className="flex flex-row items-center justify-between pb-1 pt-4 px-4">
                  <p className="text-xs font-medium text-muted-foreground">{label}</p>
                  <Icon className={cn("h-4 w-4", color)} />
                </CardHeader>
                <CardContent className="px-4 pb-4">
                  <p className={cn("text-2xl font-bold", color)}>{value}</p>
                  {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Action summary chips */}
          {Object.keys(actionSummary).length > 0 && (
            <Card className="border-border bg-card">
              <CardHeader className="py-3 px-4">
                <CardTitle className="text-sm">Action Summary</CardTitle>
                <CardDescription className="text-xs">Distribution of recommendations across all rules</CardDescription>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <div className="flex flex-wrap gap-2">
                  {Object.entries(actionSummary).map(([action, count]) => {
                    const m = ACTION_META[action] ?? ACTION_META.keep;
                    const Ic = m.icon;
                    return (
                      <button
                        key={action}
                        onClick={() => setFilterAction(filterAction === action ? "all" : action)}
                        className={cn("flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm font-medium transition-colors", m.color, filterAction === action && "ring-2 ring-primary/40")}
                      >
                        <Ic className="h-3.5 w-3.5" />{count}× {m.label}
                      </button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Filter + sort bar */}
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search rule name or ID…" className="pl-8" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <div className="flex gap-2">
              {(["all", "high", "medium", "low"] as const).map((p) => (
                <button key={p} onClick={() => setFilterPriority(p)} className={cn(
                  "px-3 py-1.5 text-xs rounded-md border transition-colors capitalize",
                  filterPriority === p ? "bg-primary/15 text-primary border-primary/30" : "border-border text-muted-foreground hover:text-foreground"
                )}>{p}</button>
              ))}
              <div className="flex items-center gap-1 border border-border rounded-md px-2">
                <SlidersHorizontal className="h-3.5 w-3.5 text-muted-foreground" />
                <select className="text-xs bg-transparent text-foreground py-1.5 pr-1 outline-none" value={sortBy} onChange={(e) => setSortBy(e.target.value as any)}>
                  <option value="riskScore">Sort: Risk</option>
                  <option value="priority">Sort: Priority</option>
                  <option value="triggers">Sort: Triggers</option>
                </select>
              </div>
            </div>
          </div>

          {/* Cards */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Recommendations <span className="text-sm font-normal text-muted-foreground ml-1">{recs.length} of {rawRecs.length} rules</span></h2>
            </div>
            {recs.length === 0 ? (
              <Card className="border-border">
                <CardContent className="p-8 text-center">
                  <XCircle className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No rules match your filters.</p>
                </CardContent>
              </Card>
            ) : (
              recs.map((rec, i) => (
                <RecommendationCard key={`${rec.ruleId}-${i}`} rec={rec} jobId={(job as any).id} onDecision={() => refetch()} />
              ))
            )}
          </div>
        </>
      )}
    </div>
  );
}
