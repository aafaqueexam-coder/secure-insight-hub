import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Search, SlidersHorizontal, Bookmark, BookmarkPlus, X, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export interface AlertFilters {
  severities: string[];
  statuses: string[];
  reviewStatuses: string[];
  agentId?: string;
  search: string;
  dateFrom?: string;
  dateTo?: string;
}

export const EMPTY_FILTERS: AlertFilters = {
  severities: [],
  statuses: [],
  reviewStatuses: [],
  agentId: undefined,
  search: "",
  dateFrom: undefined,
  dateTo: undefined,
};

interface SavedFilter {
  id: string;
  name: string;
  filters: AlertFilters;
}

const SEVERITY_OPTIONS = ["CRITICAL", "HIGH", "MEDIUM", "LOW"];
const STATUS_OPTIONS = ["new", "acknowledged", "resolved"];
const REVIEW_OPTIONS = [
  { value: "pending_review", label: "Awaiting approval" },
  { value: "approved", label: "Approved" },
  { value: "rejected", label: "Rejected" },
];

function activeFilterCount(f: AlertFilters): number {
  return (
    f.severities.length +
    f.statuses.length +
    f.reviewStatuses.length +
    (f.agentId ? 1 : 0) +
    (f.dateFrom || f.dateTo ? 1 : 0)
  );
}

interface AlertFiltersBarProps {
  filters: AlertFilters;
  onChange: (filters: AlertFilters) => void;
  agents: { id: string; name: string }[];
}

export function AlertFiltersBar({ filters, onChange, agents }: AlertFiltersBarProps) {
  const [searchDraft, setSearchDraft] = useState(filters.search);
  const [savedFilters, setSavedFilters] = useState<SavedFilter[]>([]);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveName, setSaveName] = useState("");

  // Debounce search -> filters.search
  useEffect(() => {
    const t = setTimeout(() => {
      if (searchDraft !== filters.search) onChange({ ...filters, search: searchDraft });
    }, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchDraft]);

  useEffect(() => {
    fetch("/api/alerts/saved-filters")
      .then((r) => (r.ok ? r.json() : []))
      .then(setSavedFilters)
      .catch(() => setSavedFilters([]));
  }, []);

  function toggle(list: string[], value: string): string[] {
    return list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
  }

  async function handleSaveFilter() {
    if (!saveName.trim()) return;
    const res = await fetch("/api/alerts/saved-filters", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: saveName.trim(), filters }),
    });
    if (res.ok) {
      const created = await res.json();
      setSavedFilters((prev) => [created, ...prev]);
      setSaveName("");
      setSaveOpen(false);
    }
  }

  async function handleDeleteSavedFilter(id: string, e: React.MouseEvent) {
    e.stopPropagation();
    setSavedFilters((prev) => prev.filter((f) => f.id !== id));
    await fetch(`/api/alerts/saved-filters/${id}`, { method: "DELETE" });
  }

  const count = activeFilterCount(filters);

  return (
    <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
      {/* Search */}
      <div className="relative flex-1 min-w-[200px]">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search rule, agent, IP, MITRE…"
          className="pl-8"
          value={searchDraft}
          onChange={(e) => setSearchDraft(e.target.value)}
        />
        {searchDraft && (
          <button
            className="absolute right-2 top-2.5 text-muted-foreground hover:text-foreground"
            onClick={() => setSearchDraft("")}
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Advanced filters popover */}
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" className="gap-1.5">
            <SlidersHorizontal className="h-4 w-4" />
            Filters
            {count > 0 && (
              <Badge variant="outline" className="ml-1 h-5 px-1.5 bg-primary/15 text-primary border-primary/30">
                {count}
              </Badge>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent align="end" className="w-80 space-y-4">
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2">Severity</p>
            <div className="flex flex-wrap gap-1.5">
              {SEVERITY_OPTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => onChange({ ...filters, severities: toggle(filters.severities, s) })}
                  className={cn(
                    "text-xs px-2.5 py-1 rounded-md border transition-colors",
                    filters.severities.includes(s)
                      ? "bg-primary/15 text-primary border-primary/30"
                      : "border-border text-muted-foreground hover:text-foreground",
                  )}
                >
                  {s.charAt(0) + s.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2">Status</p>
            <div className="flex flex-wrap gap-1.5">
              {STATUS_OPTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => onChange({ ...filters, statuses: toggle(filters.statuses, s) })}
                  className={cn(
                    "text-xs px-2.5 py-1 rounded-md border capitalize transition-colors",
                    filters.statuses.includes(s)
                      ? "bg-primary/15 text-primary border-primary/30"
                      : "border-border text-muted-foreground hover:text-foreground",
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2">AI review status</p>
            <div className="flex flex-wrap gap-1.5">
              {REVIEW_OPTIONS.map((r) => (
                <button
                  key={r.value}
                  onClick={() => onChange({ ...filters, reviewStatuses: toggle(filters.reviewStatuses, r.value) })}
                  className={cn(
                    "text-xs px-2.5 py-1 rounded-md border transition-colors",
                    filters.reviewStatuses.includes(r.value)
                      ? "bg-primary/15 text-primary border-primary/30"
                      : "border-border text-muted-foreground hover:text-foreground",
                  )}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          {agents.length > 0 && (
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-2">Agent</p>
              <select
                className="w-full text-sm bg-background border border-border rounded-md px-2 py-1.5"
                value={filters.agentId ?? ""}
                onChange={(e) => onChange({ ...filters, agentId: e.target.value || undefined })}
              >
                <option value="">All agents</option>
                {agents.map((a) => (
                  <option key={a.id} value={a.id}>{a.name}</option>
                ))}
              </select>
            </div>
          )}

          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2">Date range</p>
            <Calendar
              mode="range"
              selected={{
                from: filters.dateFrom ? new Date(filters.dateFrom) : undefined,
                to: filters.dateTo ? new Date(filters.dateTo) : undefined,
              }}
              onSelect={(range: any) =>
                onChange({
                  ...filters,
                  dateFrom: range?.from ? range.from.toISOString() : undefined,
                  dateTo: range?.to ? range.to.toISOString() : undefined,
                })
              }
              className="rounded-md border border-border p-2"
            />
          </div>

          {count > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="w-full text-muted-foreground"
              onClick={() => onChange({ ...EMPTY_FILTERS, search: filters.search })}
            >
              Clear all filters
            </Button>
          )}
        </PopoverContent>
      </Popover>

      {/* Saved filters */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="gap-1.5">
            <Bookmark className="h-4 w-4" />
            Saved
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-64">
          {savedFilters.length === 0 ? (
            <div className="px-2 py-3 text-xs text-muted-foreground text-center">No saved filters yet.</div>
          ) : (
            savedFilters.map((sf) => (
              <DropdownMenuItem
                key={sf.id}
                className="flex items-center justify-between gap-2"
                onClick={() => onChange({ ...EMPTY_FILTERS, ...sf.filters })}
              >
                <span className="truncate">{sf.name}</span>
                <Trash2
                  className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive flex-shrink-0"
                  onClick={(e) => handleDeleteSavedFilter(sf.id, e)}
                />
              </DropdownMenuItem>
            ))
          )}
          <DropdownMenuSeparator />
          {saveOpen ? (
            <div className="p-2 flex gap-1.5">
              <Input
                autoFocus
                placeholder="Filter name…"
                value={saveName}
                onChange={(e) => setSaveName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSaveFilter()}
                className="h-8 text-sm"
              />
              <Button size="sm" className="h-8" onClick={handleSaveFilter}>Save</Button>
            </div>
          ) : (
            <DropdownMenuItem onClick={(e) => { e.preventDefault(); setSaveOpen(true); }} className="gap-2">
              <BookmarkPlus className="h-3.5 w-3.5" />
              Save current filters
            </DropdownMenuItem>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
