import { useEffect, useState } from "react";
import {
  useGetAlert,
  useGetAlertAnalysis,
  useGenerateAlertAnalysis,
  getGetAlertAnalysisQueryKey,
  getListAlertsQueryKey,
} from "@workspace/api-client-react";
import type { AlertAnalysis } from "@workspace/api-zod";
import { useQueryClient } from "@tanstack/react-query";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { format } from "date-fns";
import {
  ShieldAlert, AlertTriangle, AlertCircle, Info, Crosshair, ScrollText, Sparkles,
  RefreshCw, ListChecks, ShieldCheck, Check, X, MessageSquare, Send, Loader2,
  Fingerprint, History, Link2, FileSearch, BrainCircuit, Gauge, Cpu, Tag,
  Clock, Pencil, Save, UserCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";

// Fields added by the review/redaction/explainability workflow that the
// generated AlertAnalysis type doesn't know about yet (regenerate the OpenAPI
// client against the updated route to remove this patch type).
type ChecklistItem = { id: string; label: string; completed: boolean };
type Ioc = { type: string; value: string };
type ReviewableAnalysis = AlertAnalysis & {
  reasoning?: string;
  rootCause?: string;
  mitreExplanation?: string;
  falsePositiveProbability?: number;
  evidence?: string[];
  iocs?: Ioc[];
  investigationChecklist?: ChecklistItem[];
  aiModelUsed?: string | null;
  promptVersion?: string | null;
  redactedFields?: string[];
  reviewStatus?: "pending_review" | "approved" | "rejected";
  reviewedBy?: string | null;
  reviewedAt?: string | null;
  reviewNote?: string | null;
  recommendationModified?: boolean;
};

interface AlertComment { id: string; content: string; authorName: string; createdAt: string; }
interface RelatedAlert { ruleName: string; severity: string; timestamp: string; sameAgent: boolean; sameSourceIp: boolean; }
interface AuditEntry { id: string; action: string; actorName: string; createdAt: string; details?: Record<string, unknown> | null; }

const SEVERITY_META: Record<string, { label: string; icon: typeof ShieldAlert; rail: string; chip: string }> = {
  CRITICAL: { label: "Critical", icon: ShieldAlert, rail: "bg-red-500", chip: "bg-red-500/15 text-red-400 border-red-500/30" },
  HIGH: { label: "High", icon: AlertTriangle, rail: "bg-orange-500", chip: "bg-orange-500/15 text-orange-400 border-orange-500/30" },
  MEDIUM: { label: "Medium", icon: AlertCircle, rail: "bg-yellow-500", chip: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30" },
  LOW: { label: "Low", icon: Info, rail: "bg-blue-500", chip: "bg-blue-500/15 text-blue-400 border-blue-500/30" },
};
function severityMeta(severity: string) {
  return SEVERITY_META[severity?.toUpperCase()] ?? SEVERITY_META.LOW;
}

const AUDIT_LABEL: Record<string, string> = {
  analysis_generated: "AI analysis generated",
  approved: "Recommendation approved",
  rejected: "Recommendation rejected",
  recommendation_modified: "Recommendation modified",
  comment_added: "Comment added",
};

interface AlertDetailSheetProps {
  alertId: string | null;
  onOpenChange: (open: boolean) => void;
}

export function AlertDetailSheet({ alertId, onOpenChange }: AlertDetailSheetProps) {
  const open = !!alertId;
  const qc = useQueryClient();

  const { data: alert, isLoading: alertLoading } = useGetAlert(alertId ?? "", { query: { enabled: open } });
  const { data: analysisRaw, isLoading: analysisLoading, error: analysisError } = useGetAlertAnalysis(alertId ?? "", {
    query: { enabled: open, retry: false },
  });
  const analysis = analysisRaw as ReviewableAnalysis | undefined;
  const generate = useGenerateAlertAnalysis();

  const [reviewing, setReviewing] = useState<"approve" | "reject" | null>(null);
  const [comments, setComments] = useState<AlertComment[]>([]);
  const [commentsLoading, setCommentsLoading] = useState(false);
  const [draftComment, setDraftComment] = useState("");
  const [postingComment, setPostingComment] = useState(false);
  const [related, setRelated] = useState<{ relatedAlerts: RelatedAlert[]; previousOccurrences: number } | null>(null);
  const [auditLog, setAuditLog] = useState<AuditEntry[]>([]);
  const [checklist, setChecklist] = useState<ChecklistItem[]>([]);
  const [editingRec, setEditingRec] = useState(false);
  const [recDraft, setRecDraft] = useState("");
  const [savingRec, setSavingRec] = useState(false);

  useEffect(() => {
    if (!alertId) return;
    setCommentsLoading(true);
    fetch(`/api/alerts/${alertId}/comments`).then((r) => (r.ok ? r.json() : [])).then(setComments).catch(() => setComments([])).finally(() => setCommentsLoading(false));
    fetch(`/api/alerts/${alertId}/related`).then((r) => (r.ok ? r.json() : null)).then(setRelated).catch(() => setRelated(null));
    fetch(`/api/alerts/${alertId}/audit-log`).then((r) => (r.ok ? r.json() : [])).then(setAuditLog).catch(() => setAuditLog([]));
  }, [alertId]);

  useEffect(() => {
    setChecklist(analysis?.investigationChecklist ?? []);
  }, [analysis?.investigationChecklist]);

  if (!alertId) return null;

  const sev = severityMeta(alert?.severity ?? "low");
  const SevIcon = sev.icon;

  async function refreshAuditLog() {
    const r = await fetch(`/api/alerts/${alertId}/audit-log`);
    if (r.ok) setAuditLog(await r.json());
  }

  async function handleReview(decision: "approve" | "reject") {
    if (!alertId) return;
    setReviewing(decision);
    try {
      await fetch(`/api/alerts/${alertId}/analysis/review`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ decision }),
      });
      await qc.invalidateQueries({ queryKey: getGetAlertAnalysisQueryKey(alertId) });
      await qc.invalidateQueries({ queryKey: getListAlertsQueryKey() });
      await refreshAuditLog();
    } finally {
      setReviewing(null);
    }
  }

  async function handlePostComment() {
    if (!alertId || !draftComment.trim()) return;
    setPostingComment(true);
    try {
      const res = await fetch(`/api/alerts/${alertId}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: draftComment.trim() }),
      });
      if (res.ok) {
        const created = await res.json();
        setComments((prev) => [...prev, created]);
        setDraftComment("");
        await refreshAuditLog();
      }
    } finally {
      setPostingComment(false);
    }
  }

  async function handleToggleChecklist(itemId: string, completed: boolean) {
    setChecklist((prev) => prev.map((i) => (i.id === itemId ? { ...i, completed } : i)));
    if (!alertId) return;
    await fetch(`/api/alerts/${alertId}/analysis/checklist`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ itemId, completed }),
    });
  }

  function startEditRec() {
    setRecDraft((analysis?.recommendedActions ?? []).join("\n"));
    setEditingRec(true);
  }

  async function handleSaveRec() {
    if (!alertId) return;
    setSavingRec(true);
    try {
      const recommendedActions = recDraft.split("\n").map((l) => l.trim()).filter(Boolean);
      await fetch(`/api/alerts/${alertId}/analysis`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ recommendedActions }),
      });
      await qc.invalidateQueries({ queryKey: getGetAlertAnalysisQueryKey(alertId) });
      await refreshAuditLog();
      setEditingRec(false);
    } finally {
      setSavingRec(false);
    }
  }

  const reviewStatus = analysis?.reviewStatus ?? (analysis ? "pending_review" : undefined);
  const checklistDone = checklist.filter((c) => c.completed).length;
  const [converting, setConverting] = useState(false);
  const [incidentLink, setIncidentLink] = useState<{ id: string; number: string } | null>(null);

  async function handleConvertToIncident() {
    if (!alertId) return;
    setConverting(true);
    try {
      const res = await fetch(`/api/alerts/${alertId}/convert-to-incident`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      if (res.ok) {
        const incident = await res.json();
        setIncidentLink({ id: incident.id, number: incident.incidentNumber });
        await qc.invalidateQueries({ queryKey: getListAlertsQueryKey() });
      } else if (res.status === 409) {
        const data = await res.json();
        setIncidentLink({ id: data.incidentId, number: "existing" });
      }
    } finally {
      setConverting(false);
    }
  }

  return (
    <Sheet open={open} onOpenChange={(v) => !v && onOpenChange(false)}>
      <SheetContent side="right" className="w-full sm:max-w-2xl p-0 flex flex-col gap-0 overflow-hidden">
        <div className={cn("absolute left-0 top-0 h-full w-1.5", sev.rail)} />

        <SheetHeader className="px-6 pt-6 pb-3 pl-7 border-b border-border space-y-2 text-left">
          {alertLoading || !alert ? (
            <>
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </>
          ) : (
            <>
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="outline" className={cn("gap-1", sev.chip)}><SevIcon className="h-3 w-3" />{sev.label}</Badge>
                  <Badge variant="outline" className="text-muted-foreground border-border">{alert.status}</Badge>
                  {reviewStatus && (
                    <Badge variant="outline" className={cn(
                      "gap-1",
                      reviewStatus === "approved" && "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
                      reviewStatus === "rejected" && "bg-red-500/15 text-red-400 border-red-500/30",
                      reviewStatus === "pending_review" && "bg-primary/15 text-primary border-primary/30",
                    )}>
                      {reviewStatus === "pending_review" ? "Awaiting approval" : reviewStatus === "approved" ? "Approved" : "Rejected"}
                    </Badge>
                  )}
                </div>
                {incidentLink ? (
                  <Badge variant="outline" className="bg-emerald-500/15 text-emerald-400 border-emerald-500/30 gap-1 flex-shrink-0">
                    <ShieldCheck className="h-3 w-3" />{incidentLink.number === "existing" ? "In incident" : incidentLink.number}
                  </Badge>
                ) : (
                  <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5 flex-shrink-0" disabled={converting} onClick={handleConvertToIncident}>
                    {converting ? <Loader2 className="h-3 w-3 animate-spin" /> : <Fingerprint className="h-3 w-3" />}
                    Create Incident
                  </Button>
                )}
              </div>
              <SheetTitle className="text-lg leading-snug pr-6">{alert.ruleName}</SheetTitle>
              <SheetDescription className="font-mono text-xs">
                {format(new Date(alert.timestamp), "MMM d, yyyy · HH:mm:ss")} · {alert.agentName}{alert.agentIp ? ` (${alert.agentIp})` : ""}
              </SheetDescription>
            </>
          )}
        </SheetHeader>

        <Tabs defaultValue="details" className="flex-1 flex flex-col min-h-0">
          <div className="px-6 pl-7 pt-2 border-b border-border">
            <TabsList className="h-9">
              <TabsTrigger value="details" className="text-xs">Alert Details</TabsTrigger>
              <TabsTrigger value="ai" className="text-xs">AI Investigation</TabsTrigger>
              <TabsTrigger value="review" className="text-xs">Human Review</TabsTrigger>
            </TabsList>
          </div>

          {/* ============== ALERT DETAILS TAB ============== */}
          <TabsContent value="details" className="flex-1 min-h-0 m-0">
            <ScrollArea className="h-full">
              <div className="px-6 py-5 pl-7 space-y-6">
                <section className="space-y-3">
                  <div className="flex items-center gap-2 text-sm font-medium text-foreground"><Crosshair className="h-4 w-4 text-primary" />MITRE ATT&CK</div>
                  {alert?.mitreTechniqueId ? (
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge className="bg-primary/15 text-primary border-primary/30 font-mono" variant="outline">{alert.mitreTechniqueId}</Badge>
                      <span className="text-sm text-foreground/90">{alert.mitreTechnique}</span>
                      {alert.mitreTactic && <span className="text-xs text-muted-foreground">· {alert.mitreTactic}</span>}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No MITRE technique mapped to this rule.</p>
                  )}
                </section>

                <Separator />

                <section className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-medium text-foreground"><ScrollText className="h-4 w-4 text-primary" />Rule description</div>
                  <p className="text-sm text-foreground/90 leading-relaxed">{alert?.description}</p>
                  {alert && (
                    <dl className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs pt-2">
                      <dt className="text-muted-foreground">Rule ID</dt><dd className="font-mono text-foreground/80">{alert.ruleId}</dd>
                      <dt className="text-muted-foreground">Rule level</dt><dd className="font-mono text-foreground/80">{alert.ruleLevel}</dd>
                      <dt className="text-muted-foreground">Agent ID</dt><dd className="font-mono text-foreground/80">{alert.agentId}</dd>
                      <dt className="text-muted-foreground">Source IP</dt><dd className="font-mono text-foreground/80">{alert.sourceIp ?? "—"}</dd>
                    </dl>
                  )}
                </section>

                <Separator />

                <section className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-medium text-foreground"><ListChecks className="h-4 w-4 text-primary" />Event logs</div>
                  <pre className="text-xs font-mono bg-muted/40 border border-border rounded-md p-3 max-h-48 overflow-auto whitespace-pre-wrap break-all text-foreground/80">
                    {alert?.rawLog ?? "No raw log captured for this alert."}
                  </pre>
                </section>

                {analysis && (
                  <>
                    <Separator />
                    <section className="space-y-2">
                      <div className="flex items-center gap-2 text-sm font-medium text-foreground"><FileSearch className="h-4 w-4 text-primary" />Evidence</div>
                      {analysis.evidence?.length ? (
                        <ul className="space-y-1">
                          {analysis.evidence.map((e, i) => (
                            <li key={i} className="text-xs text-foreground/80 flex gap-2"><span className="text-primary">•</span>{e}</li>
                          ))}
                        </ul>
                      ) : <p className="text-xs text-muted-foreground">No evidence captured yet.</p>}
                    </section>

                    <Separator />
                    <section className="space-y-2">
                      <div className="flex items-center gap-2 text-sm font-medium text-foreground"><Fingerprint className="h-4 w-4 text-primary" />Indicators of compromise</div>
                      {analysis.iocs?.length ? (
                        <div className="flex flex-wrap gap-1.5">
                          {analysis.iocs.map((ioc, i) => (
                            <Badge key={i} variant="outline" className="font-mono text-[11px] gap-1">
                              <Tag className="h-2.5 w-2.5" />{ioc.type}: {ioc.value}
                            </Badge>
                          ))}
                        </div>
                      ) : <p className="text-xs text-muted-foreground">No indicators of compromise detected.</p>}
                    </section>

                    <Separator />
                    <section className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm font-medium text-foreground"><ListChecks className="h-4 w-4 text-primary" />Investigation checklist</div>
                        {checklist.length > 0 && <span className="text-[11px] text-muted-foreground">{checklistDone}/{checklist.length}</span>}
                      </div>
                      {checklist.length > 0 && <Progress value={(checklistDone / checklist.length) * 100} className="h-1.5" />}
                      {checklist.length ? (
                        <div className="space-y-1.5 pt-1">
                          {checklist.map((item) => (
                            <label key={item.id} className="flex items-start gap-2 text-sm cursor-pointer">
                              <Checkbox
                                className="mt-0.5"
                                checked={item.completed}
                                onCheckedChange={(v) => handleToggleChecklist(item.id, !!v)}
                              />
                              <span className={cn("text-foreground/90", item.completed && "line-through text-muted-foreground")}>{item.label}</span>
                            </label>
                          ))}
                        </div>
                      ) : <p className="text-xs text-muted-foreground">No checklist generated yet.</p>}
                    </section>
                  </>
                )}

                <Separator />
                <section className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-medium text-foreground"><Link2 className="h-4 w-4 text-primary" />Related alerts</div>
                  {related === null ? (
                    <Skeleton className="h-10 w-full" />
                  ) : related.relatedAlerts.length ? (
                    <ul className="space-y-1.5">
                      {related.relatedAlerts.map((r, i) => (
                        <li key={i} className="text-xs flex items-center justify-between gap-2 text-foreground/80">
                          <span className="truncate">{r.ruleName}</span>
                          <span className="flex items-center gap-1.5 flex-shrink-0 text-muted-foreground">
                            {r.sameAgent && <Badge variant="outline" className="text-[10px] py-0">same agent</Badge>}
                            {r.sameSourceIp && <Badge variant="outline" className="text-[10px] py-0">same IP</Badge>}
                            {format(new Date(r.timestamp), "MMM d, HH:mm")}
                          </span>
                        </li>
                      ))}
                    </ul>
                  ) : <p className="text-xs text-muted-foreground">No related alerts found in the recent window.</p>}
                </section>

                <Separator />
                <section className="space-y-1.5">
                  <div className="flex items-center gap-2 text-sm font-medium text-foreground"><History className="h-4 w-4 text-primary" />Previous occurrences</div>
                  {related === null ? (
                    <Skeleton className="h-5 w-32" />
                  ) : (
                    <p className="text-sm text-foreground/80">
                      This exact rule has fired <span className="font-semibold text-foreground">{related.previousOccurrences}</span> time{related.previousOccurrences === 1 ? "" : "s"} before on this agent.
                    </p>
                  )}
                </section>
              </div>
            </ScrollArea>
          </TabsContent>

          {/* ============== AI INVESTIGATION TAB ============== */}
          <TabsContent value="ai" className="flex-1 min-h-0 m-0">
            <ScrollArea className="h-full">
              <div className="px-6 py-5 pl-7 space-y-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-medium text-foreground"><Sparkles className="h-4 w-4 text-primary" />AI analysis</div>
                  <Button size="sm" variant={analysis ? "outline" : "default"} className="h-7 text-xs" disabled={generate.isPending} onClick={() => generate.mutate({ id: alertId })}>
                    {generate.isPending ? (<><RefreshCw className="h-3 w-3 mr-1.5 animate-spin" />Analyzing…</>) : analysis ? (<><RefreshCw className="h-3 w-3 mr-1.5" />Re-run</>) : (<><Sparkles className="h-3 w-3 mr-1.5" />Run AI analysis</>)}
                  </Button>
                </div>

                {analysisLoading && !analysisError && (
                  <div className="space-y-2"><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-5/6" /><Skeleton className="h-4 w-4/6" /></div>
                )}
                {!analysisLoading && !analysis && (
                  <p className="text-sm text-muted-foreground">No analysis yet. Run AI analysis to investigate this alert.</p>
                )}

                {analysis && (
                  <>
                    <section className="space-y-1.5">
                      <p className="text-xs font-semibold uppercase tracking-wide text-primary">Why was this triggered?</p>
                      <p className="text-sm text-foreground/90 leading-relaxed">{analysis.summary}</p>
                      {analysis.threatDescription && <p className="text-sm text-muted-foreground leading-relaxed">{analysis.threatDescription}</p>}
                    </section>

                    {analysis.reasoning && (
                      <section className="space-y-1.5">
                        <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-primary"><BrainCircuit className="h-3.5 w-3.5" />AI reasoning</div>
                        <p className="text-sm text-foreground/90 leading-relaxed">{analysis.reasoning}</p>
                      </section>
                    )}

                    {analysis.rootCause && (
                      <section className="space-y-1.5">
                        <p className="text-xs font-semibold uppercase tracking-wide text-primary">Root cause</p>
                        <p className="text-sm text-foreground/90 leading-relaxed">{analysis.rootCause}</p>
                      </section>
                    )}

                    {analysis.mitreExplanation && (
                      <section className="space-y-1.5">
                        <p className="text-xs font-semibold uppercase tracking-wide text-primary">MITRE explanation</p>
                        <p className="text-sm text-foreground/90 leading-relaxed">{analysis.mitreExplanation}</p>
                      </section>
                    )}

                    {!!analysis.investigationSteps?.length && (
                      <section className="space-y-1.5">
                        <p className="text-xs font-semibold uppercase tracking-wide text-primary">Recommended investigation</p>
                        <ul className="space-y-1">
                          {analysis.investigationSteps.map((step, i) => (
                            <li key={i} className="text-xs text-foreground/80 flex gap-2"><span className="text-primary">{i + 1}.</span>{step}</li>
                          ))}
                        </ul>
                      </section>
                    )}

                    {!!analysis.containmentActions?.length && (
                      <section className="space-y-1.5">
                        <p className="text-xs font-semibold uppercase tracking-wide text-emerald-400">Recommended containment</p>
                        <ul className="space-y-1">
                          {analysis.containmentActions.map((c, i) => (
                            <li key={i} className="text-sm text-foreground/90 flex gap-2"><ShieldCheck className="h-3.5 w-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />{c}</li>
                          ))}
                        </ul>
                      </section>
                    )}

                    <Separator />

                    <section className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground"><Gauge className="h-3 w-3" />AI confidence</div>
                        <div className="flex items-center gap-2">
                          <Progress value={(analysis.confidenceScore ?? 0) * 100} className="h-1.5 flex-1" />
                          <span className="text-xs font-medium text-foreground">{Math.round((analysis.confidenceScore ?? 0) * 100)}%</span>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground"><AlertCircle className="h-3 w-3" />False positive probability</div>
                        <div className="flex items-center gap-2">
                          <Progress value={(analysis.falsePositiveProbability ?? 0) * 100} className="h-1.5 flex-1" />
                          <span className="text-xs font-medium text-foreground">{Math.round((analysis.falsePositiveProbability ?? 0) * 100)}%</span>
                        </div>
                      </div>
                    </section>

                    <section className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs pt-1">
                      <dt className="text-muted-foreground flex items-center gap-1.5"><Cpu className="h-3 w-3" />AI version</dt>
                      <dd className="font-mono text-foreground/80">{analysis.aiModelUsed ?? "—"}</dd>
                      <dt className="text-muted-foreground flex items-center gap-1.5"><Tag className="h-3 w-3" />Prompt version</dt>
                      <dd className="font-mono text-foreground/80">{analysis.promptVersion ?? "—"}</dd>
                      <dt className="text-muted-foreground flex items-center gap-1.5"><Clock className="h-3 w-3" />Analysis timestamp</dt>
                      <dd className="font-mono text-foreground/80">{format(new Date(analysis.generatedAt), "MMM d, yyyy HH:mm:ss")}</dd>
                      {analysis.redactedFields && analysis.redactedFields.length > 0 && (
                        <>
                          <dt className="text-muted-foreground">Redacted fields</dt>
                          <dd className="text-foreground/80">{analysis.redactedFields.join(", ")}</dd>
                        </>
                      )}
                    </section>
                  </>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* ============== HUMAN REVIEW TAB ============== */}
          <TabsContent value="review" className="flex-1 min-h-0 m-0">
            <ScrollArea className="h-full">
              <div className="px-6 py-5 pl-7 space-y-6">
                {!analysis ? (
                  <p className="text-sm text-muted-foreground">Run AI analysis first — there's nothing to review yet.</p>
                ) : (
                  <>
                    <section className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm font-medium text-foreground">
                          Recommended action
                          {analysis.recommendationModified && <Badge variant="outline" className="text-[10px] border-amber-500/30 text-amber-400">edited by analyst</Badge>}
                        </div>
                        {!editingRec && (
                          <Button size="sm" variant="ghost" className="h-6 text-xs gap-1" onClick={startEditRec}>
                            <Pencil className="h-3 w-3" />Modify
                          </Button>
                        )}
                      </div>

                      {editingRec ? (
                        <div className="space-y-2">
                          <Textarea
                            className="text-sm min-h-[100px]"
                            value={recDraft}
                            onChange={(e) => setRecDraft(e.target.value)}
                            placeholder="One recommended action per line…"
                          />
                          <div className="flex gap-2">
                            <Button size="sm" className="h-7 text-xs gap-1" disabled={savingRec} onClick={handleSaveRec}>
                              {savingRec ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />} Save changes
                            </Button>
                            <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => setEditingRec(false)}>Cancel</Button>
                          </div>
                        </div>
                      ) : (
                        <ul className="space-y-1.5">
                          {analysis.recommendedActions?.map((action, i) => (
                            <li key={i} className="text-sm text-foreground/90 flex gap-2"><ShieldCheck className="h-3.5 w-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />{action}</li>
                          ))}
                        </ul>
                      )}
                    </section>

                    <Separator />

                    <section className="space-y-2">
                      <div className="text-sm font-medium text-foreground">Decision</div>
                      {reviewStatus === "pending_review" || !reviewStatus ? (
                        <div className="flex gap-2">
                          <Button className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white" disabled={!!reviewing} onClick={() => handleReview("approve")}>
                            {reviewing === "approve" ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : <Check className="h-4 w-4 mr-1.5" />}Approve
                          </Button>
                          <Button variant="outline" className="flex-1 border-red-500/40 text-red-400 hover:bg-red-500/10" disabled={!!reviewing} onClick={() => handleReview("reject")}>
                            {reviewing === "reject" ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : <X className="h-4 w-4 mr-1.5" />}Reject &amp; ignore
                          </Button>
                        </div>
                      ) : (
                        <div className="rounded-md border border-border bg-muted/30 p-3 space-y-1">
                          <div className="flex items-center gap-1.5 text-sm text-foreground">
                            <UserCheck className="h-4 w-4 text-muted-foreground" />
                            {reviewStatus === "approved" ? "Approved" : "Rejected — marked as false positive"} by {analysis.reviewedBy ?? "—"}
                          </div>
                          {analysis.reviewedAt && (
                            <p className="text-xs text-muted-foreground pl-5">{format(new Date(analysis.reviewedAt), "MMM d, yyyy · HH:mm:ss")}</p>
                          )}
                        </div>
                      )}
                    </section>

                    <Separator />

                    {/* Review comments */}
                    <section className="space-y-3">
                      <div className="flex items-center gap-2 text-sm font-medium text-foreground"><MessageSquare className="h-4 w-4 text-primary" />Review comments</div>
                      {commentsLoading ? (
                        <Skeleton className="h-10 w-full" />
                      ) : comments.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No comments yet.</p>
                      ) : (
                        <div className="space-y-3">
                          {comments.map((c) => (
                            <div key={c.id} className="text-sm">
                              <div className="flex items-center gap-2 text-xs text-muted-foreground mb-0.5">
                                <span className="font-medium text-foreground/90">{c.authorName}</span>
                                <span>{format(new Date(c.createdAt), "MMM d, HH:mm")}</span>
                              </div>
                              <p className="text-foreground/90 leading-relaxed">{c.content}</p>
                            </div>
                          ))}
                        </div>
                      )}
                      <div className="flex gap-2 pt-1">
                        <Textarea
                          placeholder="Add a comment for the team…"
                          className="text-sm min-h-[44px] resize-none"
                          value={draftComment}
                          onChange={(e) => setDraftComment(e.target.value)}
                          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handlePostComment(); } }}
                        />
                        <Button size="icon" disabled={postingComment || !draftComment.trim()} onClick={handlePostComment}>
                          {postingComment ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                        </Button>
                      </div>
                    </section>

                    <Separator />

                    {/* Audit history */}
                    <section className="space-y-2 pb-2">
                      <div className="flex items-center gap-2 text-sm font-medium text-foreground"><History className="h-4 w-4 text-primary" />Audit history</div>
                      {auditLog.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No actions recorded yet.</p>
                      ) : (
                        <div className="relative pl-4">
                          <div className="absolute left-[3px] top-1 bottom-1 w-px bg-border" />
                          <div className="space-y-3">
                            {auditLog.map((entry) => (
                              <div key={entry.id} className="relative">
                                <div className="absolute -left-4 top-1 h-1.5 w-1.5 rounded-full bg-primary" />
                                <p className="text-xs text-foreground/90">
                                  <span className="font-medium">{AUDIT_LABEL[entry.action] ?? entry.action}</span>
                                  {" "}by {entry.actorName}
                                </p>
                                <p className="text-[11px] text-muted-foreground">{format(new Date(entry.createdAt), "MMM d, yyyy · HH:mm:ss")}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </section>
                  </>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}
