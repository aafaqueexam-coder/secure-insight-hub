import { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, Sparkles } from "lucide-react";

interface CreateIncidentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  prefill?: {
    title?: string;
    description?: string;
    priority?: string;
    alertIds?: string[];
    tags?: string[];
  };
  onCreated: (incident: { id: string; incidentNumber: string; title: string }) => void;
}

const PRIORITIES = ["critical", "high", "medium", "low"] as const;

export function CreateIncidentDialog({ open, onOpenChange, prefill, onCreated }: CreateIncidentDialogProps) {
  const [title, setTitle] = useState(prefill?.title ?? "");
  const [description, setDescription] = useState(prefill?.description ?? "");
  const [priority, setPriority] = useState(prefill?.priority ?? "medium");
  const [assigneeName, setAssigneeName] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const hasPrefill = !!prefill?.alertIds?.length;

  async function handleCreate() {
    if (!title.trim()) { setError("Title is required"); return; }
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/incidents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim() || undefined,
          priority,
          assigneeName: assigneeName.trim() || undefined,
          alertIds: prefill?.alertIds,
          tags: prefill?.tags,
        }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error ?? "Failed to create incident");
        return;
      }
      const incident = await res.json();
      onCreated({ id: incident.id, incidentNumber: incident.incidentNumber, title: incident.title });
      onOpenChange(false);
      setTitle(""); setDescription(""); setPriority("medium"); setAssigneeName("");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Create Incident</DialogTitle>
          <DialogDescription>
            {hasPrefill
              ? `Auto-filled from ${prefill!.alertIds!.length} alert${prefill!.alertIds!.length > 1 ? "s" : ""}. Edit before saving.`
              : "Fill in the details to open a new incident."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {hasPrefill && (
            <div className="flex items-center gap-1.5 text-xs text-primary bg-primary/10 border border-primary/20 rounded-md px-3 py-2">
              <Sparkles className="h-3.5 w-3.5 flex-shrink-0" />
              Fields auto-filled from linked alert data
            </div>
          )}

          <div className="space-y-1.5">
            <Label htmlFor="inc-title">Title <span className="text-destructive">*</span></Label>
            <Input
              id="inc-title"
              placeholder="Brief description of the incident…"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="inc-desc">Description</Label>
            <Textarea
              id="inc-desc"
              placeholder="What happened? What is the potential impact?"
              className="min-h-[80px] resize-none"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Priority</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRIORITIES.map((p) => (
                    <SelectItem key={p} value={p} className="capitalize">{p.charAt(0).toUpperCase() + p.slice(1)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="inc-assignee">Assign to</Label>
              <Input
                id="inc-assignee"
                placeholder="Analyst name (optional)"
                value={assigneeName}
                onChange={(e) => setAssigneeName(e.target.value)}
              />
            </div>
          </div>

          {prefill?.tags?.length ? (
            <div className="space-y-1.5">
              <Label>Tags</Label>
              <div className="flex flex-wrap gap-1.5">
                {prefill.tags.map((t) => (
                  <Badge key={t} variant="outline" className="font-mono text-xs">{t}</Badge>
                ))}
              </div>
            </div>
          ) : null}

          {error && <p className="text-xs text-destructive">{error}</p>}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button disabled={saving || !title.trim()} onClick={handleCreate}>
            {saving && <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />}
            Create Incident
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
