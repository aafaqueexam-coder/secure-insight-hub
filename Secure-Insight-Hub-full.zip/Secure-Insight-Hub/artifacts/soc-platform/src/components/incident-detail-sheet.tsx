import { useCallback, useEffect, useRef, useState } from "react";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { format, formatDistanceToNow } from "date-fns";
import {
  ShieldAlert, AlertTriangle, AlertCircle, Info, Clock, User, Send,
  Loader2, Paperclip, Link2, FileText, X, ChevronRight, CheckCircle2,
  Circle, AlertOctagon, Eye, Lock, BookOpen, StickyNote,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface Incident {
  id: string;
  incidentSeq: number;
  incidentNumber: string;
  title: string;
  description?: string | null;
  status: string;
  priority: string;
  assigneeName?: string | null;
  alertCount: number;
  tags: string[];
  resolutionSummary?: string | null;
  resolvedAt?: string | null;
  closedAt?: string | null;
  createdAt: string;
  updatedAt: string;
}

interface TimelineEvent {
  id: string;
  type: string;
  message: string;
  actorName: string;
  occurredAt: string;
}

interface Note {
  id: string;
  content: string;
  internal: boolean;
  authorName: string;
  createdAt: string;
  evidence: Evidence[];
}

interface Evidence {
  id: string;
  name: string;
  type: "file" | "link";
  url: string;
  mimeType?: string | null;
  sizeBytes?: number | null;
  uploadedBy: string;
  uploadedAt: string;
}

const WORKFLOW_STEPS = [
  { value: "open", label: "Open" },
  { value: "assigned", label: "Assigned" },
  { value: "investigating", label: "Investigating" },
  { value: "awaiting_approval", label: "Awaiting Approval" },
  { value: "resolved", label: "Resolved" },
  { value: "closed", label: "Closed" },
];

const PRIORITY_META: Record<string, { chip: string; icon: typeof ShieldAlert }> = {
  critical: { chip: "bg-red-500/15 text-red-400 border-red-500/30", icon: ShieldAlert },
  high: { chip: "bg-orange-500/15 text-orange-400 border-orange-500/30", icon: AlertTriangle },
  medium: { chip: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30", icon: AlertCircle },
  low: { chip: "bg-blue-500/15 text-blue-400 border-blue-500/30", icon: Info },
};

const TIMELINE_ICONS: Record<string, { icon: typeof Clock; color: string }> = {
  incident_created: { icon: AlertOctagon, color: "text-primary" },
  alert_linked: { icon: Link2, color: "text-blue-400" },
  ai_analysis: { icon: AlertCircle, color: "text-purple-400" },
  human_review: { icon: Eye, color: "text-yellow-400" },
  comment_added: { icon: StickyNote, color: "text-muted-foreground" },
  assignment: { icon: User, color: "text-emerald-400" },
  status_change: { icon: ChevronRight, color: "text-muted-foreground" },
  resolution: { icon: CheckCircle2, color: "text-emerald-400" },
};

function priorityMeta(p: string) { return PRIORITY_META[p] ?? PRIORITY_META.medium; }

function workflowIndex(status: string) { return WORKFLOW_STEPS.findIndex((s) => s.value === status); }

interface IncidentDetailSheetProps {
  incidentId: string | null;
  onOpenChange: (open: boolean) => void;
  onUpdated?: (incident: Incident) => void;
}

export function IncidentDetailSheet({ incidentId, onOpenChange, onUpdated }: IncidentDetailSheetProps) {
  const open = !!incidentId;
  const [incident, setIncident] = useState<Incident | null>(null);
  const [loading, setLoading] = useState(false);
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [evidence, setEvidence] = useState<Evidence[]>([]);

  // Note composer state
  const [noteDraft, setNoteDraft] = useState("");
  const [noteInternal, setNoteInternal] = useState(true);
  const [postingNote, setPostingNote] = useState(false);

  // Evidence attacher state
  const [evidenceName, setEvidenceName] = useState("");
  const [evidenceUrl, setEvidenceUrl] = useState("");
  const [evidenceMode, setEvidenceMode] = useState<"link" | "file">("link");
  const [attachingEvidence, setAttachingEvidence] = useState(false);
  const [showEvidenceForm, setShowEvidenceForm] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Workflow
  const [statusUpdating, setStatusUpdating] = useState(false);
  const [resolutionDraft, setResolutionDraft] = useState("");
  const [showResolutionBox, setShowResolutionBox] = useState(false);

  const fetchAll = useCallback(async (id: string) => {
    setLoading(true);
    try {
      const [inc, tl, ns, ev] = await Promise.all([
        fetch(`/api/incidents/${id}`).then((r) => r.ok ? r.json() : null),
        fetch(`/api/incidents/${id}/timeline`).then((r) => r.ok ? r.json() : []),
        fetch(`/api/incidents/${id}/notes`).then((r) => r.ok ? r.json() : []),
        fetch(`/api/incidents/${id}/evidence`).then((r) => r.ok ? r.json() : []),
      ]);
      setIncident(inc);
      setTimeline(tl);
      setNotes(ns);
      setEvidence(ev);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (incidentId) fetchAll(incidentId);
    else { setIncident(null); setTimeline([]); setNotes([]); setEvidence([]); }
  }, [incidentId, fetchAll]);

  async function updateStatus(newStatus: string) {
    if (!incidentId || !incident) return;
    if ((newStatus === "resolved" || newStatus === "closed") && !incident.resolutionSummary && !resolutionDraft) {
      setShowResolutionBox(true);
      return;
    }
    setStatusUpdating(true);
    try {
      const res = await fetch(`/api/incidents/${incidentId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status: newStatus,
          ...(resolutionDraft ? { resolutionSummary: resolutionDraft } : {}),
        }),
      });
      if (res.ok) {
        const updated = await res.json();
        setIncident(updated);
        setShowResolutionBox(false);
        setResolutionDraft("");
        onUpdated?.(updated);
        await fetchAll(incidentId);
      }
    } finally {
      setStatusUpdating(false);
    }
  }

  async function postNote() {
    if (!incidentId || !noteDraft.trim()) return;
    setPostingNote(true);
    try {
      const res = await fetch(`/api/incidents/${incidentId}/notes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: noteDraft.trim(), internal: noteInternal }),
      });
      if (res.ok) {
        const note = await res.json();
        setNotes((prev) => [...prev, note]);
        setNoteDraft("");
        const tl = await fetch(`/api/incidents/${incidentId}/timeline`).then((r) => r.ok ? r.json() : timeline);
        setTimeline(tl);
      }
    } finally {
      setPostingNote(false);
    }
  }

  async function attachLink() {
    if (!incidentId || !evidenceName.trim() || !evidenceUrl.trim()) return;
    setAttachingEvidence(true);
    try {
      const res = await fetch(`/api/incidents/${incidentId}/evidence`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: evidenceName.trim(), type: "link", url: evidenceUrl.trim() }),
      });
      if (res.ok) {
        const item = await res.json();
        setEvidence((prev) => [item, ...prev]);
        setEvidenceName(""); setEvidenceUrl(""); setShowEvidenceForm(false);
      }
    } finally {
      setAttachingEvidence(false);
    }
  }

  async function attachFile(file: File) {
    if (!incidentId || !file) return;
    setAttachingEvidence(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const res = await fetch(`/api/incidents/${incidentId}/evidence`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: file.name, type: "file", url: dataUrl, mimeType: file.type, sizeBytes: file.size }),
      });
      if (res.ok) {
        const item = await res.json();
        setEvidence((prev) => [item, ...prev]);
        setShowEvidenceForm(false);
      }
    } finally {
      setAttachingEvidence(false);
    }
  }

  if (!incidentId) return null;
  const pm = incident ? priorityMeta(incident.priority) : PRIORITY_META.medium;
  const PIcon = pm.icon;
  const currentStepIdx = incident ? workflowIndex(incident.status) : 0;
  const nextStep = WORKFLOW_STEPS[currentStepIdx + 1];

  return (
    <Sheet open={open} onOpenChange={(v) => !v && onOpenChange(false)}>
      <SheetContent side="right" className="w-full sm:max-w-2xl p-0 flex flex-col gap-0 overflow-hidden">

        {/* Header */}
        <SheetHeader className="px-6 pt-6 pb-3 border-b border-border space-y-2 text-left">
          {loading || !incident ? (
            <><Skeleton className="h-6 w-2/3" /><Skeleton className="h-4 w-1/3" /></>
          ) : (
            <>
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="outline" className="font-mono text-xs border-border text-muted-foreground">{incident.incidentNumber}</Badge>
                <Badge variant="outline" className={cn("gap-1", pm.chip)}>
                  <PIcon className="h-3 w-3" />{incident.priority}
                </Badge>
                <Badge variant="outline" className="capitalize border-border text-foreground/70">{incident.status.replace("_", " ")}</Badge>
                {incident.assigneeName && (
                  <Badge variant="outline" className="gap-1 border-border text-muted-foreground">
                    <User className="h-3 w-3" />{incident.assigneeName}
                  </Badge>
                )}
              </div>
              <SheetTitle className="text-lg leading-snug pr-6">{incident.title}</SheetTitle>
              {incident.description && (
                <SheetDescription className="text-sm line-clamp-2">{incident.description}</SheetDescription>
              )}
              <p className="text-[11px] font-mono text-muted-foreground">
                Opened {format(new Date(incident.createdAt), "MMM d, yyyy · HH:mm")}
                {incident.alertCount > 0 && ` · ${incident.alertCount} alert${incident.alertCount > 1 ? "s" : ""}`}
                {incident.tags.length > 0 && ` · ${incident.tags.join(", ")}`}
              </p>
            </>
          )}
        </SheetHeader>

        {/* Workflow stepper */}
        {incident && (
          <div className="px-6 py-3 border-b border-border bg-muted/20">
            <div className="flex items-center gap-0 overflow-x-auto">
              {WORKFLOW_STEPS.map((step, idx) => {
                const done = idx < currentStepIdx;
                const active = idx === currentStepIdx;
                return (
                  <div key={step.value} className="flex items-center gap-0 flex-shrink-0">
                    <button
                      className={cn(
                        "text-[10px] px-2.5 py-1 rounded-full font-medium transition-colors whitespace-nowrap",
                        active && "bg-primary text-primary-foreground",
                        done && "text-emerald-400",
                        !active && !done && "text-muted-foreground",
                      )}
                      onClick={() => !active && updateStatus(step.value)}
                      disabled={statusUpdating}
                    >
                      {done ? <CheckCircle2 className="h-3 w-3 inline mr-1" /> : active ? <Circle className="h-3 w-3 inline mr-1" /> : null}
                      {step.label}
                    </button>
                    {idx < WORKFLOW_STEPS.length - 1 && (
                      <ChevronRight className={cn("h-3 w-3 flex-shrink-0", idx < currentStepIdx ? "text-emerald-400" : "text-muted-foreground/40")} />
                    )}
                  </div>
                );
              })}
            </div>
            {nextStep && !showResolutionBox && (
              <div className="mt-2 flex items-center gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 text-xs"
                  disabled={statusUpdating}
                  onClick={() => updateStatus(nextStep.value)}
                >
                  {statusUpdating ? <Loader2 className="h-3 w-3 mr-1.5 animate-spin" /> : <ChevronRight className="h-3 w-3 mr-1.5" />}
                  Advance to {nextStep.label}
                </Button>
              </div>
            )}
            {showResolutionBox && (
              <div className="mt-2 space-y-2">
                <Textarea
                  autoFocus
                  placeholder="Write a resolution summary before closing…"
                  className="text-sm min-h-[64px] resize-none"
                  value={resolutionDraft}
                  onChange={(e) => setResolutionDraft(e.target.value)}
                />
                <div className="flex gap-2">
                  <Button size="sm" className="h-7 text-xs" disabled={!resolutionDraft.trim() || statusUpdating} onClick={() => updateStatus(nextStep!.value)}>
                    {statusUpdating ? <Loader2 className="h-3 w-3 mr-1.5 animate-spin" /> : null}Save & {nextStep!.label}
                  </Button>
                  <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => setShowResolutionBox(false)}>Cancel</Button>
                </div>
              </div>
            )}
            {incident.resolutionSummary && (
              <p className="mt-2 text-xs text-muted-foreground italic">
                <span className="font-medium text-foreground/70">Resolution:</span> {incident.resolutionSummary}
              </p>
            )}
          </div>
        )}

        <Tabs defaultValue="timeline" className="flex-1 flex flex-col min-h-0">
          <div className="px-6 pt-2 border-b border-border">
            <TabsList className="h-9">
              <TabsTrigger value="timeline" className="text-xs">Timeline</TabsTrigger>
              <TabsTrigger value="notes" className="text-xs">Analyst Notes</TabsTrigger>
              <TabsTrigger value="evidence" className="text-xs">
                Evidence {evidence.length > 0 && <span className="ml-1 text-[10px] text-muted-foreground">({evidence.length})</span>}
              </TabsTrigger>
            </TabsList>
          </div>

          {/* ─── TIMELINE ─── */}
          <TabsContent value="timeline" className="flex-1 min-h-0 m-0">
            <ScrollArea className="h-full">
              <div className="px-6 py-5 space-y-0">
                {loading ? (
                  Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-12 w-full mb-3" />)
                ) : timeline.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No timeline events yet.</p>
                ) : (
                  <div className="relative">
                    <div className="absolute left-[11px] top-3 bottom-3 w-px bg-border" />
                    <div className="space-y-0">
                      {timeline.map((event, idx) => {
                        const meta = TIMELINE_ICONS[event.type] ?? { icon: Clock, color: "text-muted-foreground" };
                        const IconComp = meta.icon;
                        const isLast = idx === timeline.length - 1;
                        return (
                          <div key={event.id} className={cn("relative flex gap-3", !isLast && "pb-4")}>
                            <div className={cn("relative z-10 flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-background border border-border mt-0.5", meta.color)}>
                              <IconComp className="h-3 w-3" />
                            </div>
                            <div className="flex-1 pt-0.5 min-w-0">
                              <p className="text-sm text-foreground/90 leading-snug">{event.message}</p>
                              <p className="text-[11px] text-muted-foreground mt-0.5">
                                {event.actorName} · {format(new Date(event.occurredAt), "MMM d, yyyy · HH:mm")}
                                <span className="ml-1">({formatDistanceToNow(new Date(event.occurredAt), { addSuffix: true })})</span>
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* ─── ANALYST NOTES ─── */}
          <TabsContent value="notes" className="flex-1 min-h-0 m-0 flex flex-col">
            <ScrollArea className="flex-1">
              <div className="px-6 py-5 space-y-4">
                {loading ? (
                  Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)
                ) : notes.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No notes yet. Add the first one below.</p>
                ) : (
                  notes.map((note) => (
                    <div key={note.id} className={cn("rounded-md border p-3 space-y-1.5", note.internal ? "border-border bg-muted/30" : "border-primary/20 bg-primary/5")}>
                      <div className="flex items-center gap-2">
                        {note.internal ? (
                          <Badge variant="outline" className="text-[10px] gap-1 border-border text-muted-foreground">
                            <Lock className="h-2.5 w-2.5" />Internal
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-[10px] gap-1 border-primary/30 text-primary">
                            <Eye className="h-2.5 w-2.5" />Stakeholder note
                          </Badge>
                        )}
                        <span className="text-xs text-muted-foreground">{note.authorName} · {format(new Date(note.createdAt), "MMM d, HH:mm")}</span>
                      </div>
                      <p className="text-sm text-foreground/90 whitespace-pre-wrap leading-relaxed">{note.content}</p>
                      {note.evidence.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {note.evidence.map((e) => (
                            <a key={e.id} href={e.url} target="_blank" rel="noreferrer"
                              className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded border border-border hover:border-primary/40 text-muted-foreground hover:text-foreground transition-colors">
                              {e.type === "link" ? <Link2 className="h-3 w-3" /> : <FileText className="h-3 w-3" />}{e.name}
                            </a>
                          ))}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>

            {/* Note composer — pinned to bottom */}
            <div className="border-t border-border px-4 py-3 space-y-2 bg-background">
              <Textarea
                placeholder="Write a note… (shift+enter for new line, enter to post)"
                className="text-sm min-h-[72px] resize-none"
                value={noteDraft}
                onChange={(e) => setNoteDraft(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); postNote(); } }}
              />
              <div className="flex items-center justify-between gap-2">
                <label className="flex items-center gap-1.5 text-xs text-muted-foreground cursor-pointer select-none">
                  <Checkbox
                    checked={noteInternal}
                    onCheckedChange={(v) => setNoteInternal(!!v)}
                    className="h-3.5 w-3.5"
                  />
                  <Lock className="h-3 w-3" /> Internal only
                </label>
                <div className="flex gap-2">
                  {noteInternal === false && (
                    <span className="text-[10px] text-primary bg-primary/10 px-2 py-0.5 rounded">Stakeholder-visible</span>
                  )}
                  <Button size="sm" className="h-7 text-xs gap-1.5" disabled={postingNote || !noteDraft.trim()} onClick={postNote}>
                    {postingNote ? <Loader2 className="h-3 w-3 animate-spin" /> : <Send className="h-3 w-3" />}Add note
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* ─── EVIDENCE ─── */}
          <TabsContent value="evidence" className="flex-1 min-h-0 m-0 flex flex-col">
            <ScrollArea className="flex-1">
              <div className="px-6 py-5 space-y-3">
                {evidence.length === 0 && !loading && (
                  <p className="text-sm text-muted-foreground">No evidence attached yet.</p>
                )}
                {loading ? (
                  Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)
                ) : (
                  evidence.map((item) => (
                    <div key={item.id} className="flex items-start gap-3 rounded-md border border-border p-3">
                      <div className="flex-shrink-0 mt-0.5 text-muted-foreground">
                        {item.type === "link" ? <Link2 className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <a href={item.url} target="_blank" rel="noreferrer"
                          className="text-sm font-medium text-foreground hover:text-primary hover:underline truncate block">{item.name}</a>
                        <p className="text-[11px] text-muted-foreground">
                          {item.uploadedBy} · {format(new Date(item.uploadedAt), "MMM d, HH:mm")}
                          {item.sizeBytes ? ` · ${(item.sizeBytes / 1024).toFixed(1)} KB` : ""}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>

            {/* Evidence attacher */}
            <div className="border-t border-border px-4 py-3 bg-background">
              {!showEvidenceForm ? (
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5" onClick={() => { setEvidenceMode("link"); setShowEvidenceForm(true); }}>
                    <Link2 className="h-3 w-3" />Attach link
                  </Button>
                  <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5" onClick={() => { setEvidenceMode("file"); setShowEvidenceForm(true); fileInputRef.current?.click(); }}>
                    <Paperclip className="h-3 w-3" />Attach file
                  </Button>
                  <input ref={fileInputRef} type="file" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) attachFile(f); }} />
                </div>
              ) : evidenceMode === "link" ? (
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <Label className="text-xs">Label</Label>
                      <Input placeholder="e.g. VirusTotal report" className="h-8 text-sm" value={evidenceName} onChange={(e) => setEvidenceName(e.target.value)} />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">URL</Label>
                      <Input placeholder="https://…" className="h-8 text-sm" value={evidenceUrl} onChange={(e) => setEvidenceUrl(e.target.value)} />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" className="h-7 text-xs gap-1.5" disabled={attachingEvidence || !evidenceName.trim() || !evidenceUrl.trim()} onClick={attachLink}>
                      {attachingEvidence ? <Loader2 className="h-3 w-3 animate-spin" /> : <Link2 className="h-3 w-3" />}Attach
                    </Button>
                    <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => { setShowEvidenceForm(false); setEvidenceName(""); setEvidenceUrl(""); }}>
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ) : null}
              {attachingEvidence && evidenceMode === "file" && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Loader2 className="h-3 w-3 animate-spin" />Uploading…
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}
