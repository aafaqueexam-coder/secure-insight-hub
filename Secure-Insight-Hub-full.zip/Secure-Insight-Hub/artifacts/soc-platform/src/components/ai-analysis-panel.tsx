import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Bot, RefreshCw, ChevronRight, Sparkles } from "lucide-react";

interface AiAnalysisPanelProps {
  analysis: any;
  isLoading: boolean;
  error: boolean;
  onGenerate: () => void;
  isGenerating: boolean;
  children: (details: any) => React.ReactNode;
  label?: string;
}

export function AiAnalysisPanel({
  analysis,
  isLoading,
  error,
  onGenerate,
  isGenerating,
  children,
  label = "AI Analysis",
}: AiAnalysisPanelProps) {
  return (
    <Card className="bg-card/50 border-border">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Bot className="h-4 w-4 text-primary" />
            {label}
            {analysis?.aiModelUsed && (
              <Badge variant="outline" className="text-[10px] text-primary border-primary/30 ml-1">
                {analysis.aiModelUsed}
              </Badge>
            )}
            {analysis && !analysis.aiModelUsed && (
              <Badge variant="outline" className="text-[10px] text-muted-foreground border-border ml-1">
                rule-based
              </Badge>
            )}
          </CardTitle>
          <Button
            size="sm"
            variant={analysis ? "outline" : "default"}
            onClick={onGenerate}
            disabled={isGenerating}
            className="h-7 text-xs"
          >
            {isGenerating ? (
              <><RefreshCw className="h-3 w-3 mr-1.5 animate-spin" />Analyzing…</>
            ) : analysis ? (
              <><RefreshCw className="h-3 w-3 mr-1.5" />Refresh</>
            ) : (
              <><Sparkles className="h-3 w-3 mr-1.5" />Generate</>
            )}
          </Button>
        </div>
        {analysis && (
          <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{analysis.summary}</p>
        )}
      </CardHeader>

      {(isLoading || isGenerating) && (
        <CardContent className="space-y-2 pt-0">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="h-4 w-4/6" />
        </CardContent>
      )}

      {!isLoading && !isGenerating && !analysis && (
        <CardContent className="pt-0">
          <div className="flex items-center gap-2 text-xs text-muted-foreground py-2">
            <Bot className="h-4 w-4" />
            <span>Click <strong>Generate</strong> to run AI analysis on this item.</span>
          </div>
        </CardContent>
      )}

      {!isLoading && !isGenerating && analysis?.details && (
        <CardContent className="pt-0">
          {children(analysis.details)}
        </CardContent>
      )}
    </Card>
  );
}

export function AiList({ label, items }: { label: string; items?: string[] }) {
  if (!items?.length) return null;
  return (
    <div>
      <p className="text-xs font-medium text-muted-foreground mb-1.5">{label}</p>
      <ul className="space-y-1">
        {items.map((item, i) => (
          <li key={i} className="flex gap-2 text-xs text-foreground/90">
            <ChevronRight className="h-3.5 w-3.5 text-primary flex-shrink-0 mt-0.5" />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function AiBadge({ label, value, colorMap }: { label: string; value: string; colorMap?: Record<string, string> }) {
  const color = colorMap?.[value] ?? "bg-muted text-muted-foreground border-border";
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-muted-foreground">{label}:</span>
      <Badge variant="outline" className={`text-xs ${color}`}>{value}</Badge>
    </div>
  );
}
