import { Link, useLocation } from "wouter";
import { UserButton } from "@clerk/react";
import { 
  LayoutDashboard, 
  AlertTriangle, 
  ShieldAlert, 
  Bug, 
  Server, 
  Crosshair, 
  CheckSquare, 
  FileText, 
  Bot,
  Settings,
  SlidersHorizontal,
  Radar,
  Users,
  ScrollText,
  BellRing,
  ShieldCheck as WazuhIcon
} from "lucide-react";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/alerts", label: "Alerts", icon: AlertTriangle },
    { href: "/incidents", label: "Incidents", icon: ShieldAlert },
    { href: "/vulnerabilities", label: "Vulnerabilities", icon: Bug },
    { href: "/agents", label: "Agents", icon: Server },
    { href: "/mitre", label: "MITRE ATT&CK", icon: Crosshair },
    { href: "/compliance", label: "Compliance", icon: CheckSquare },
    { href: "/reports", label: "Reports", icon: FileText },
    { href: "/ai-assistant", label: "AI Assistant", icon: Bot },
    { href: "/rule-tuning", label: "Rule Tuning", icon: SlidersHorizontal },
    { href: "/threat-intel", label: "Threat Intel", icon: Radar },
    { href: "/rbac", label: "Access Control", icon: Users },
    { href: "/wazuh", label: "Wazuh", icon: WazuhIcon },
    { href: "/notifications", label: "Notifications", icon: BellRing },
    { href: "/audit-logs", label: "Audit Logs", icon: ScrollText },
  ];

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden font-sans">
      <aside className="w-64 flex-shrink-0 border-r border-border bg-card flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-border">
          <div className="flex items-center gap-2">
            <ShieldAlert className="h-6 w-6 text-primary" />
            <span className="font-bold text-lg tracking-tight">SentinelIQ</span>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1">
          {navItems.map((item) => {
            const isActive = location === item.href || location.startsWith(`${item.href}/`);
            return (
              <Link key={item.href} href={item.href} className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${isActive ? 'bg-primary/10 text-primary font-medium' : 'text-muted-foreground hover:bg-accent hover:text-foreground'}`}>
                <item.icon className="h-4 w-4" />
                <span className="text-sm">{item.label}</span>
              </Link>
            );
          })}
        </div>
        <div className="p-4 border-t border-border">
          <Link href="/settings/connections" className="flex items-center gap-3 px-3 py-2 rounded-md transition-colors text-muted-foreground hover:bg-accent hover:text-foreground">
            <Settings className="h-4 w-4" />
            <span className="text-sm">Settings</span>
          </Link>
        </div>
      </aside>
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 flex-shrink-0 border-b border-border bg-background/95 backdrop-blur flex items-center justify-between px-6 z-10">
          <div className="flex-1"></div>
          <div className="flex items-center gap-4">
            <UserButton 
              appearance={{
                elements: {
                  userButtonAvatarBox: "h-8 w-8",
                  userButtonPopoverCard: "bg-card border-border",
                }
              }}
            />
          </div>
        </header>
        
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
