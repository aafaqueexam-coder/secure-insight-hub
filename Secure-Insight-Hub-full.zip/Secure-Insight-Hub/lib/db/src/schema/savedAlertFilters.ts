import { pgTable, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const savedAlertFiltersTable = pgTable("saved_alert_filters", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  // Serialized query params: severity[], status[], mitreTechniqueId[], agentId,
  // search, dateFrom, dateTo, reviewStatus[]
  filters: jsonb("filters").notNull().$type<Record<string, unknown>>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertSavedAlertFilterSchema = createInsertSchema(savedAlertFiltersTable).omit({ id: true, createdAt: true });
export type InsertSavedAlertFilter = z.infer<typeof insertSavedAlertFilterSchema>;
export type SavedAlertFilter = typeof savedAlertFiltersTable.$inferSelect;
