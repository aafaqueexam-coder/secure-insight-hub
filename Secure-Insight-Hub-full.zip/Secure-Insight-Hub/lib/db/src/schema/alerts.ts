import { pgTable, text, timestamp, integer, real, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const alertsTable = pgTable("alerts", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  connectionId: text("connection_id").notNull(),
  ruleId: text("rule_id").notNull(),
  ruleName: text("rule_name").notNull(),
  ruleLevel: integer("rule_level").notNull().default(0),
  severity: text("severity").notNull().default("low"),
  description: text("description").notNull(),
  agentId: text("agent_id").notNull(),
  agentName: text("agent_name").notNull(),
  agentIp: text("agent_ip"),
  sourceIp: text("source_ip"),
  status: text("status").notNull().default("new"),
  mitreTactic: text("mitre_tactic"),
  mitreTechnique: text("mitre_technique"),
  mitreTechniqueId: text("mitre_technique_id"),
  falsePositive: boolean("false_positive").notNull().default(false),
  rawLog: text("raw_log"),
  incidentId: text("incident_id"),
  timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertAlertSchema = createInsertSchema(alertsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alertsTable.$inferSelect;
