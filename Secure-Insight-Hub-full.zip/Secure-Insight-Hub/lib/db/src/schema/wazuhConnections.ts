import { pgTable, text, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const wazuhConnectionsTable = pgTable("wazuh_connections", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  name: text("name").notNull(),
  apiUrl: text("api_url").notNull(),
  username: text("username").notNull(),
  passwordHash: text("password_hash").notNull(),
  status: text("status").notNull().default("pending"),
  syncInterval: integer("sync_interval").notNull().default(300),
  lastSyncAt: timestamp("last_sync_at", { withTimezone: true }),
  lastSyncStatus: text("last_sync_status"),
  lastErrorAt: timestamp("last_error_at", { withTimezone: true }),
  lastErrorMessage: text("last_error_message"),
  agentCount: integer("agent_count"),
  // Feature flags — which data streams are enabled for this connection
  syncAlerts: boolean("sync_alerts").notNull().default(true),
  syncAgents: boolean("sync_agents").notNull().default(true),
  syncVulnerabilities: boolean("sync_vulnerabilities").notNull().default(true),
  syncFim: boolean("sync_fim").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertWazuhConnectionSchema = createInsertSchema(wazuhConnectionsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertWazuhConnection = z.infer<typeof insertWazuhConnectionSchema>;
export type WazuhConnection = typeof wazuhConnectionsTable.$inferSelect;

