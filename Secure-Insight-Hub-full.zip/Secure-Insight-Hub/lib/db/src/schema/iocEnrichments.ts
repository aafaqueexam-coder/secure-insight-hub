import { pgTable, text, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

/**
 * Cached enrichment result for a single indicator (IP, domain, hash, URL).
 * Re-used across alerts for the same IOC until expiresAt passes.
 *
 * The `data` column stores the full enrichment payload:
 *   { reputation, geo, asn, threatFeeds, sources, verdicts }
 */
export const iocEnrichmentsTable = pgTable("ioc_enrichments", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  // Canonical lowercase form of the indicator
  indicator: text("indicator").notNull(),
  // "ip" | "domain" | "hash_md5" | "hash_sha1" | "hash_sha256" | "url"
  indicatorType: text("indicator_type").notNull(),
  // Aggregate verdict: "malicious" | "suspicious" | "clean" | "unknown"
  verdict: text("verdict").notNull().default("unknown"),
  // 0–100 composite risk score
  riskScore: real("risk_score").notNull().default(0),
  // Full structured payload
  data: jsonb("data").notNull().$type<Record<string, unknown>>(),
  enrichedAt: timestamp("enriched_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertIocEnrichmentSchema = createInsertSchema(iocEnrichmentsTable).omit({ id: true, createdAt: true });
export type InsertIocEnrichment = z.infer<typeof insertIocEnrichmentSchema>;
export type IocEnrichment = typeof iocEnrichmentsTable.$inferSelect;
