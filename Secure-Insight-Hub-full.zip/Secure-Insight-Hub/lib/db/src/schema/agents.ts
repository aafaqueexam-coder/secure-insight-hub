import { pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const wazuhAgentsTable = pgTable("wazuh_agents", {
  id: text("id").primaryKey(),
  organizationId: text("organization_id").notNull(),
  connectionId: text("connection_id").notNull(),
  name: text("name").notNull(),
  status: text("status").notNull().default("disconnected"),
  os: text("os").notNull().default("Unknown"),
  ip: text("ip").notNull().default("0.0.0.0"),
  version: text("version").notNull().default("unknown"),
  groups: text("groups").array().notNull().default([]),
  lastKeepAlive: timestamp("last_keep_alive", { withTimezone: true }).notNull().defaultNow(),
  vulnerabilityCount: integer("vulnerability_count").default(0),
  alertCount: integer("alert_count").default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertWazuhAgentSchema = createInsertSchema(wazuhAgentsTable).omit({ createdAt: true, updatedAt: true });
export type InsertWazuhAgent = z.infer<typeof insertWazuhAgentSchema>;
export type WazuhAgent = typeof wazuhAgentsTable.$inferSelect;
