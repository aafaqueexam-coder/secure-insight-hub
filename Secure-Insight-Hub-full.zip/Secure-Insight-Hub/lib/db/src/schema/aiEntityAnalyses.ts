import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const aiEntityAnalysesTable = pgTable("ai_entity_analyses", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  summary: text("summary").notNull().default(""),
  details: text("details").notNull().default("{}"),
  aiModelUsed: text("ai_model_used"),
  generatedAt: timestamp("generated_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAiEntityAnalysisSchema = createInsertSchema(aiEntityAnalysesTable).omit({ id: true, createdAt: true });
export type InsertAiEntityAnalysis = z.infer<typeof insertAiEntityAnalysisSchema>;
export type AiEntityAnalysis = typeof aiEntityAnalysesTable.$inferSelect;
