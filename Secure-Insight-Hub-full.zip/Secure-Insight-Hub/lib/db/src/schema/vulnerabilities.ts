import { pgTable, text, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const vulnerabilitiesTable = pgTable("vulnerabilities", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  connectionId: text("connection_id").notNull(),
  cveId: text("cve_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  severity: text("severity").notNull().default("medium"),
  cvssScore: real("cvss_score").notNull().default(0),
  status: text("status").notNull().default("open"),
  agentId: text("agent_id").notNull(),
  agentName: text("agent_name").notNull(),
  packageName: text("package_name"),
  packageVersion: text("package_version"),
  fixedVersion: text("fixed_version"),
  remediationNote: text("remediation_note"),
  detectedAt: timestamp("detected_at", { withTimezone: true }).notNull().defaultNow(),
  patchedAt: timestamp("patched_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertVulnerabilitySchema = createInsertSchema(vulnerabilitiesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertVulnerability = z.infer<typeof insertVulnerabilitySchema>;
export type Vulnerability = typeof vulnerabilitiesTable.$inferSelect;
