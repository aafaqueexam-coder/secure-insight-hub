import { pgTable, text, timestamp, real, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// One row per analyst decision on a specific rule recommendation. Querying all
// rows for a ruleId gives the full version history of decisions for that rule.
export const ruleTuningDecisionsTable = pgTable("rule_tuning_decisions", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  jobId: text("job_id").notNull(), // FK to ruleTuningRecommendationsTable.id
  ruleId: text("rule_id").notNull(),
  ruleName: text("rule_name").notNull(),
  // Snapshot of the recommendation at decision time
  action: text("action").notNull(),
  suggestedChange: text("suggested_change").notNull(),
  riskScore: real("risk_score"),
  expectedImprovement: text("expected_improvement"),
  // Analyst decision
  decision: text("decision").notNull(), // "approved" | "rejected"
  analystNote: text("analyst_note"),
  decidedBy: text("decided_by").notNull(),
  decidedByName: text("decided_by_name").notNull(),
  decidedAt: timestamp("decided_at", { withTimezone: true }).notNull().defaultNow(),
  // Full recommendation payload snapshot for history replay
  snapshot: jsonb("snapshot").notNull().$type<Record<string, unknown>>(),
});

export const insertRuleTuningDecisionSchema = createInsertSchema(ruleTuningDecisionsTable).omit({ id: true, decidedAt: true });
export type InsertRuleTuningDecision = z.infer<typeof insertRuleTuningDecisionSchema>;
export type RuleTuningDecision = typeof ruleTuningDecisionsTable.$inferSelect;
