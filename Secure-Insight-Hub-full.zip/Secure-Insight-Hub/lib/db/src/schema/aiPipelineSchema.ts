import { pgTable, text, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

/**
 * AI response cache.
 *
 * Cache key: SHA-256 hash of (model + promptVersion + prompt content hash).
 * Identical alerts on the same prompt version get the cached result, saving
 * tokens and latency while full pipeline stats (retries, tokens) are still
 * recorded against the analysis row.
 *
 * TTL: cache entries expire after 6 hours by default.
 */
export const aiResponseCacheTable = pgTable("ai_response_cache", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  cacheKey: text("cache_key").notNull().unique(),
  model: text("model").notNull(),
  promptVersion: text("prompt_version").notNull(),
  // Cached structured response payload
  response: jsonb("response").notNull().$type<Record<string, unknown>>(),
  promptTokens: integer("prompt_tokens"),
  completionTokens: integer("completion_tokens"),
  hitCount: integer("hit_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

/**
 * Prompt version registry.
 *
 * One row per prompt version + stage combination. Used to:
 *   - Track which prompt text was in use at any given time
 *   - Pin analyses to the exact prompt that produced them
 *   - Roll back to a prior prompt version without code changes
 */
export const promptVersionsTable = pgTable("prompt_versions", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  // e.g. "v2" — must match PROMPT_VERSION constant in aiPipeline.ts
  version: text("version").notNull(),
  // "investigation" | "recommendation"
  stage: text("stage").notNull(),
  promptTemplate: text("prompt_template").notNull(),
  model: text("model").notNull().default("gpt-4o-mini"),
  isActive: text("is_active").notNull().default("true"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAiResponseCacheSchema = createInsertSchema(aiResponseCacheTable).omit({ id: true, createdAt: true });
export type InsertAiResponseCache = z.infer<typeof insertAiResponseCacheSchema>;
export type AiResponseCache = typeof aiResponseCacheTable.$inferSelect;

export const insertPromptVersionSchema = createInsertSchema(promptVersionsTable).omit({ id: true, createdAt: true });
export type InsertPromptVersion = z.infer<typeof insertPromptVersionSchema>;
export type PromptVersion = typeof promptVersionsTable.$inferSelect;
