import { pgTable, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

/**
 * Platform-wide immutable audit log.
 *
 * Every significant action — AI, human review, incident lifecycle, rule
 * changes, report generation, RBAC changes — writes one row here.
 *
 * Event type catalogue (extend as needed):
 *   AI analysis
 *     ai.analysis.generated       — AI ran investigation+recommendation
 *     ai.analysis.rerun           — analyst triggered re-run
 *     ai.review.approved          — human approved AI recommendation
 *     ai.review.rejected          — human rejected (false positive)
 *     ai.recommendation.modified  — analyst edited the recommended actions
 *
 *   Incidents
 *     incident.created            — new incident opened
 *     incident.updated            — status/priority/title changed
 *     incident.assigned           — assigned (or reassigned) to analyst
 *     incident.closed             — resolved or closed
 *     incident.note.added         — analyst note added
 *     incident.evidence.attached  — evidence file/link attached
 *     incident.alert.linked       — alert linked to incident
 *
 *   Alerts
 *     alert.status.changed        — bulk or individual status change
 *     alert.converted             — alert converted to incident
 *
 *   Rules
 *     rule.change.approved        — rule optimisation change approved
 *     rule.change.rejected        — rule optimisation change rejected
 *     rule.tuning.run             — tuning job triggered
 *
 *   Reports
 *     report.generated            — report generation triggered
 *     report.exported             — report exported (pdf/csv/excel)
 *
 *   RBAC
 *     rbac.role.changed           — user's role updated
 *     rbac.user.deactivated       — user deactivated
 *     rbac.user.reactivated       — user reactivated
 */
export const auditLogsTable = pgTable("audit_logs", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),

  // Structured event type: "domain.noun.verb"
  eventType: text("event_type").notNull(),

  // Human-readable one-liner shown in the log viewer
  summary: text("summary").notNull(),

  // Who triggered it
  actorId: text("actor_id").notNull(),
  actorName: text("actor_name").notNull(),
  actorRole: text("actor_role"),

  // What resource was affected
  resourceType: text("resource_type"), // "alert" | "incident" | "rule" | "report" | "user"
  resourceId: text("resource_id"),
  resourceName: text("resource_name"),

  // Structured payload — varies by event type:
  //   ai.analysis.generated  → { aiModel, promptVersion, confidenceScore, falsePositiveProbability, alertId, ruleId }
  //   ai.review.*            → { decision, note, alertId, analysisId }
  //   incident.*             → { incidentId, incidentNumber, status, priority, assigneeId }
  //   rule.change.*          → { ruleId, ruleName, action, suggestedChange, jobId }
  //   report.*               → { reportId, reportType, format }
  //   rbac.*                 → { targetUserId, oldRole, newRole }
  details: jsonb("details").$type<Record<string, unknown>>(),

  // IP address of the actor (best-effort, from X-Forwarded-For or req.ip)
  ipAddress: text("ip_address"),

  occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAuditLogSchema = createInsertSchema(auditLogsTable).omit({ id: true, occurredAt: true });
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogsTable.$inferSelect;
