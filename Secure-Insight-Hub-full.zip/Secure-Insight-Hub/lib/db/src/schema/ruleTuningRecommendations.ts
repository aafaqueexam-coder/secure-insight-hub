import { pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const ruleTuningRecommendationsTable = pgTable("rule_tuning_recommendations", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  status: text("status").notNull().default("completed"),
  jobRunAt: timestamp("job_run_at", { withTimezone: true }).notNull().defaultNow(),
  aggregationWindowDays: integer("aggregation_window_days").notNull().default(30),
  totalAlertsAnalyzed: integer("total_alerts_analyzed").notNull().default(0),
  recommendations: text("recommendations").notNull().default("[]"),
  rawMetrics: text("raw_metrics").notNull().default("{}"),
  aiModelUsed: text("ai_model_used"),
  errorMessage: text("error_message"),
  triggeredBy: text("triggered_by").notNull().default("scheduler"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertRuleTuningSchema = createInsertSchema(ruleTuningRecommendationsTable).omit({ id: true, createdAt: true });
export type InsertRuleTuning = z.infer<typeof insertRuleTuningSchema>;
export type RuleTuningRecommendation = typeof ruleTuningRecommendationsTable.$inferSelect;
