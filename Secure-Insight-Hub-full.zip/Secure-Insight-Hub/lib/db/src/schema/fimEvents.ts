import { pgTable, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const fimEventsTable = pgTable("fim_events", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  connectionId: text("connection_id").notNull(),
  agentId: text("agent_id").notNull(),
  agentName: text("agent_name").notNull(),
  // "added" | "modified" | "deleted"
  type: text("type").notNull(),
  path: text("path").notNull(),
  mode: text("mode"),
  md5Before: text("md5_before"),
  md5After: text("md5_after"),
  sha256Before: text("sha256_before"),
  sha256After: text("sha256_after"),
  permissionsBefore: text("permissions_before"),
  permissionsAfter: text("permissions_after"),
  ownerBefore: text("owner_before"),
  ownerAfter: text("owner_after"),
  sizeBefore: text("size_before"),
  sizeAfter: text("size_after"),
  extra: jsonb("extra").$type<Record<string, unknown>>(),
  eventTimestamp: timestamp("event_timestamp", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertFimEventSchema = createInsertSchema(fimEventsTable).omit({ id: true, createdAt: true });
export type InsertFimEvent = z.infer<typeof insertFimEventSchema>;
export type FimEvent = typeof fimEventsTable.$inferSelect;
