import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const alertCommentsTable = pgTable("alert_comments", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  alertId: text("alert_id").notNull(),
  organizationId: text("organization_id").notNull(),
  content: text("content").notNull(),
  authorId: text("author_id").notNull(),
  authorName: text("author_name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAlertCommentSchema = createInsertSchema(alertCommentsTable).omit({ id: true, createdAt: true });
export type InsertAlertComment = z.infer<typeof insertAlertCommentSchema>;
export type AlertComment = typeof alertCommentsTable.$inferSelect;
