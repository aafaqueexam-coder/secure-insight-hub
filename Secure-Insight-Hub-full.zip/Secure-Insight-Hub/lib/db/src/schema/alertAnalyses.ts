import { pgTable, text, timestamp, real, jsonb, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const alertAnalysesTable = pgTable("alert_analyses", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  alertId: text("alert_id").notNull().unique(),
  organizationId: text("organization_id").notNull(),
  summary: text("summary").notNull(),
  threatDescription: text("threat_description").notNull(),
  businessImpact: text("business_impact").notNull(),
  investigationSteps: text("investigation_steps").array().notNull().default([]),
  remediationPlan: text("remediation_plan").array().notNull().default([]),
  recommendedActions: text("recommended_actions").array().notNull().default([]),
  containmentActions: text("containment_actions").array().notNull().default([]),
  affectedAssets: text("affected_assets").array().notNull().default([]),
  analystNotes: text("analyst_notes").notNull().default(""),
  executiveSummary: text("executive_summary").notNull().default(""),
  confidenceScore: real("confidence_score").notNull().default(0),
  severity: text("severity").notNull().default("medium"),
  // AI reasoning / explainability
  reasoning: text("reasoning").notNull().default(""),
  rootCause: text("root_cause").notNull().default(""),
  mitreExplanation: text("mitre_explanation").notNull().default(""),
  falsePositiveProbability: real("false_positive_probability").notNull().default(0),
  // Evidence, IOCs, checklist
  evidence: text("evidence").array().notNull().default([]),
  iocs: jsonb("iocs").notNull().default([]).$type<Array<{ type: string; value: string }>>(),
  investigationChecklist: jsonb("investigation_checklist").notNull().default([]).$type<Array<{ id: string; label: string; completed: boolean }>>(),
  // Model/prompt provenance
  aiModelUsed: text("ai_model_used"),
  promptVersion: text("prompt_version"),
  // Token usage
  promptTokens: integer("prompt_tokens"),
  completionTokens: integer("completion_tokens"),
  totalTokens: integer("total_tokens"),
  // Execution metadata
  retryCount: integer("retry_count").notNull().default(0),
  pipelineDurationMs: integer("pipeline_duration_ms"),
  fromCache: boolean("from_cache").notNull().default(false),
  // Sensitive-field redaction (Context Builder step): names of fields stripped/masked
  // before the alert context was sent to the AI, e.g. ["agentIp", "sourceIp", "rawLog"].
  redactedFields: text("redacted_fields").array().notNull().default([]),
  // Human-in-the-loop approval workflow: pending_review -> approved | rejected
  reviewStatus: text("review_status").notNull().default("pending_review"),
  reviewedBy: text("reviewed_by"),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  reviewNote: text("review_note"),
  recommendationModified: boolean("recommendation_modified").notNull().default(false),
  generatedAt: timestamp("generated_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAlertAnalysisSchema = createInsertSchema(alertAnalysesTable).omit({ id: true, createdAt: true });
export type InsertAlertAnalysis = z.infer<typeof insertAlertAnalysisSchema>;
export type AlertAnalysis = typeof alertAnalysesTable.$inferSelect;
