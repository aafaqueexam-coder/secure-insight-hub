import { pgTable, text, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

/**
 * Roles (least → most privileged):
 *   auditor      — read-only: alerts, reports, compliance
 *   l1_analyst   — view alerts, acknowledge, run AI analysis
 *   l2_analyst   — l1 + review AI, create incidents, enrich IOCs
 *   l3_analyst   — l2 + close incidents, modify rules, rule tuning
 *   soc_manager  — l3 + manage team, assign roles below manager
 *   admin        — full access including user/role management
 */
export type UserRole = "l1_analyst" | "l2_analyst" | "l3_analyst" | "soc_manager" | "admin" | "auditor";

export const usersTable = pgTable("users", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name"),
  role: text("role").notNull().default("l1_analyst"),
  organizationId: text("organization_id"),
  avatarUrl: text("avatar_url"),
  isActive: boolean("is_active").notNull().default(true),
  lastActiveAt: timestamp("last_active_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ createdAt: true, updatedAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
