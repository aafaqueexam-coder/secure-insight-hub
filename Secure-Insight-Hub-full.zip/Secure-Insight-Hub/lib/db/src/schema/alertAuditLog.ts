import { pgTable, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const alertAuditLogTable = pgTable("alert_audit_log", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  alertId: text("alert_id").notNull(),
  organizationId: text("organization_id").notNull(),
  // e.g. "analysis_generated", "approved", "rejected", "recommendation_modified", "comment_added"
  action: text("action").notNull(),
  actorId: text("actor_id").notNull(),
  actorName: text("actor_name").notNull(),
  details: jsonb("details").$type<Record<string, unknown> | null>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAlertAuditLogSchema = createInsertSchema(alertAuditLogTable).omit({ id: true, createdAt: true });
export type InsertAlertAuditLog = z.infer<typeof insertAlertAuditLogSchema>;
export type AlertAuditLog = typeof alertAuditLogTable.$inferSelect;
