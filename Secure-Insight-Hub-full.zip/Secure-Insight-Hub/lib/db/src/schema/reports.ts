import { pgTable, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const reportsTable = pgTable("reports", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  // daily | weekly | monthly | executive_summary | incident_report | compliance_report | rule_optimization_report
  type: text("type").notNull(),
  title: text("title").notNull().default(""),
  period: text("period").notNull(),
  status: text("status").notNull().default("pending"), // pending | generating | ready | failed
  // Structured report data used for all exports
  content: jsonb("content").$type<Record<string, unknown>>(),
  // Comma-separated list of requested formats: pdf,csv,excel
  formats: text("formats").notNull().default("pdf"),
  errorMessage: text("error_message"),
  generatedAt: timestamp("generated_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertReportSchema = createInsertSchema(reportsTable).omit({ id: true, createdAt: true });
export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reportsTable.$inferSelect;
