import { pgTable, text, timestamp, integer, boolean, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const incidentsTable = pgTable("incidents", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  // Auto-incrementing human-readable identifier, displayed as "INC-1001".
  incidentSeq: serial("incident_seq"),
  organizationId: text("organization_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  // Workflow: open -> assigned -> investigating -> awaiting_approval -> resolved -> closed
  status: text("status").notNull().default("open"),
  priority: text("priority").notNull().default("medium"),
  assigneeId: text("assignee_id"),
  assigneeName: text("assignee_name"),
  alertCount: integer("alert_count").notNull().default(0),
  tags: text("tags").array().notNull().default([]),
  resolutionSummary: text("resolution_summary"),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  closedAt: timestamp("closed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const incidentNotesTable = pgTable("incident_notes", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  incidentId: text("incident_id").notNull(),
  organizationId: text("organization_id").notNull(),
  content: text("content").notNull(),
  // Internal notes are analyst-only working notes; non-internal are intended
  // for stakeholder-facing summaries (e.g. resolution write-ups).
  internal: boolean("internal").notNull().default(true),
  authorId: text("author_id").notNull(),
  authorName: text("author_name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertIncidentSchema = createInsertSchema(incidentsTable).omit({ id: true, incidentSeq: true, createdAt: true, updatedAt: true });
export type InsertIncident = z.infer<typeof insertIncidentSchema>;
export type Incident = typeof incidentsTable.$inferSelect;

export const insertIncidentNoteSchema = createInsertSchema(incidentNotesTable).omit({ id: true, createdAt: true });
export type InsertIncidentNote = z.infer<typeof insertIncidentNoteSchema>;
export type IncidentNote = typeof incidentNotesTable.$inferSelect;
