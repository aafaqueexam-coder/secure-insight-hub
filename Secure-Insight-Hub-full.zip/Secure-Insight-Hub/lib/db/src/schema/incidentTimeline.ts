import { pgTable, text, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// Structured event log shown on the incident's Timeline tab. One row per
// notable event: incident_created, alert_linked, ai_analysis, human_review,
// comment_added, assignment, status_change, resolution.
export const incidentTimelineTable = pgTable("incident_timeline", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  incidentId: text("incident_id").notNull(),
  organizationId: text("organization_id").notNull(),
  type: text("type").notNull(),
  message: text("message").notNull(),
  actorName: text("actor_name").notNull().default("System"),
  metadata: jsonb("metadata").$type<Record<string, unknown> | null>(),
  occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertIncidentTimelineSchema = createInsertSchema(incidentTimelineTable).omit({ id: true, createdAt: true });
export type InsertIncidentTimelineEvent = z.infer<typeof insertIncidentTimelineSchema>;
export type IncidentTimelineEvent = typeof incidentTimelineTable.$inferSelect;
