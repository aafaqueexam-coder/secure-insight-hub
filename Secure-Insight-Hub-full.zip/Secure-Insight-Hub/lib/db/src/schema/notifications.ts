import { pgTable, text, timestamp, boolean, jsonb, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

/**
 * Configured delivery channels.
 * type: "email" | "slack" | "teams" | "browser" | "digest"
 * config keys per type:
 *   email   → { to: string[], smtpHost?, smtpPort?, smtpUser?, smtpPass?, fromAddress? }
 *   slack   → { webhookUrl: string }
 *   teams   → { webhookUrl: string }
 *   browser → (no config — push subscriptions stored separately)
 *   digest  → { scheduleHour: number (0-23 UTC), recipients: string[] }
 */
export const notificationChannelsTable = pgTable("notification_channels", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  config: jsonb("config").notNull().default({}).$type<Record<string, unknown>>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

/**
 * Notification rules: what events trigger which channels.
 * eventPattern: glob-style, e.g. "alert.critical", "incident.*", "*" (all events)
 * minSeverity: "low" | "medium" | "high" | "critical" (ignored for non-alert events)
 */
export const notificationRulesTable = pgTable("notification_rules", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  channelId: text("channel_id").notNull(),
  eventPattern: text("event_pattern").notNull().default("*"),
  minSeverity: text("min_severity").notNull().default("high"),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * Delivery log: one row per attempted notification dispatch.
 * status: "sent" | "failed" | "skipped"
 */
export const notificationLogsTable = pgTable("notification_logs", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  channelId: text("channel_id").notNull(),
  eventType: text("event_type").notNull(),
  summary: text("summary").notNull(),
  status: text("status").notNull().default("sent"),
  errorMessage: text("error_message"),
  latencyMs: integer("latency_ms"),
  sentAt: timestamp("sent_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * Browser push subscriptions (Web Push API).
 * One row per browser/device that has granted push permission.
 */
export const pushSubscriptionsTable = pgTable("push_subscriptions", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  organizationId: text("organization_id").notNull(),
  userId: text("user_id").notNull(),
  endpoint: text("endpoint").notNull().unique(),
  p256dhKey: text("p256dh_key").notNull(),
  authKey: text("auth_key").notNull(),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertNotificationChannelSchema = createInsertSchema(notificationChannelsTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertNotificationRuleSchema = createInsertSchema(notificationRulesTable).omit({ id: true, createdAt: true });
export const insertNotificationLogSchema = createInsertSchema(notificationLogsTable).omit({ id: true, sentAt: true });
export const insertPushSubscriptionSchema = createInsertSchema(pushSubscriptionsTable).omit({ id: true, createdAt: true });

export type InsertNotificationChannel = z.infer<typeof insertNotificationChannelSchema>;
export type NotificationChannel = typeof notificationChannelsTable.$inferSelect;
export type NotificationRule = typeof notificationRulesTable.$inferSelect;
export type NotificationLog = typeof notificationLogsTable.$inferSelect;
export type PushSubscription = typeof pushSubscriptionsTable.$inferSelect;
