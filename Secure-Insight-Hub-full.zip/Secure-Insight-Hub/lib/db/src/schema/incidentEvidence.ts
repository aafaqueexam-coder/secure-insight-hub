import { pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// Evidence attached to an incident (optionally to a specific note). Files are
// stored as data URLs for small attachments (screenshots, short logs); links
// just store a URL. There is no object storage in this environment, so this
// intentionally stays lightweight rather than handling large binary uploads.
export const incidentEvidenceTable = pgTable("incident_evidence", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  incidentId: text("incident_id").notNull(),
  organizationId: text("organization_id").notNull(),
  noteId: text("note_id"),
  name: text("name").notNull(),
  type: text("type").notNull(), // "file" | "link"
  url: text("url").notNull(), // data: URL for files, plain URL for links
  mimeType: text("mime_type"),
  sizeBytes: integer("size_bytes"),
  uploadedBy: text("uploaded_by").notNull(),
  uploadedAt: timestamp("uploaded_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertIncidentEvidenceSchema = createInsertSchema(incidentEvidenceTable).omit({ id: true, uploadedAt: true });
export type InsertIncidentEvidence = z.infer<typeof insertIncidentEvidenceSchema>;
export type IncidentEvidence = typeof incidentEvidenceTable.$inferSelect;
