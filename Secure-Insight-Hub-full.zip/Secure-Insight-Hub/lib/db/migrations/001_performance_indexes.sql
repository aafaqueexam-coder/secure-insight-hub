/**
 * Performance indexes migration.
 *
 * Run once against the live DB:
 *   psql $DATABASE_URL -f db-indexes.sql
 *
 * All indexes are CREATE INDEX IF NOT EXISTS so they are safe to re-run.
 * CONCURRENTLY means they build without locking the table (requires running
 * outside a transaction — do not wrap in BEGIN/COMMIT).
 */

-- alerts: the single most-queried table
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alerts_org_timestamp
  ON alerts (organization_id, timestamp DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alerts_org_severity
  ON alerts (organization_id, severity);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alerts_org_status
  ON alerts (organization_id, status);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alerts_incident
  ON alerts (incident_id)
  WHERE incident_id IS NOT NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alerts_rule
  ON alerts (organization_id, rule_id);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alerts_agent
  ON alerts (organization_id, agent_id);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alerts_mitre
  ON alerts (organization_id, mitre_technique_id)
  WHERE mitre_technique_id IS NOT NULL;

-- Full-text search on rule_name, description, agent_name
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alerts_text_search
  ON alerts USING gin(
    to_tsvector('english',
      coalesce(rule_name, '') || ' ' ||
      coalesce(description, '') || ' ' ||
      coalesce(agent_name, '')
    )
  );

-- alert_analyses
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alert_analyses_alert
  ON alert_analyses (alert_id);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alert_analyses_org_review
  ON alert_analyses (organization_id, review_status);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alert_analyses_org_generated
  ON alert_analyses (organization_id, generated_at DESC);

-- incidents
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_incidents_org_status
  ON incidents (organization_id, status);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_incidents_org_created
  ON incidents (organization_id, created_at DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_incidents_assignee
  ON incidents (assignee_id)
  WHERE assignee_id IS NOT NULL;

-- audit_logs: high-write, high-read
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_audit_logs_org_occurred
  ON audit_logs (organization_id, occurred_at DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_audit_logs_event_type
  ON audit_logs (organization_id, event_type);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_audit_logs_resource
  ON audit_logs (resource_type, resource_id)
  WHERE resource_id IS NOT NULL;

-- ioc_enrichments: cache lookups by indicator
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_ioc_indicator
  ON ioc_enrichments (organization_id, indicator, expires_at);

-- ai_response_cache: cache key lookups
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_ai_cache_key
  ON ai_response_cache (cache_key, expires_at);

-- fim_events
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_fim_events_agent
  ON fim_events (connection_id, agent_id, event_timestamp DESC);

-- vulnerabilities
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_vulns_org_status
  ON vulnerabilities (organization_id, status, severity);

-- notification_logs
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_notif_logs_org
  ON notification_logs (organization_id, sent_at DESC);
