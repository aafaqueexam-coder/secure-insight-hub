---
name: SentinelIQ Architecture
description: Key decisions and quirks for the SentinelIQ MDR/SOC platform (Express + React + Drizzle + Clerk).
---

# SentinelIQ Architecture Decisions

## Tenant isolation
Routes use `req.query.orgId || "demo-org"` as org scoping — Clerk userId is not yet wired to org membership. Demo org ID is `"demo-org"`.

## DB schema raw SQL caveat
Drizzle `$defaultFn(() => crypto.randomUUID())` only fires through the ORM, NOT in raw psql. When seeding with psql, always add `gen_random_uuid()` explicitly for `id` columns.

## OpenAI integration
`OPENAI_API_KEY` is deferred by user. All AI routes (`/api/alerts/:id/analysis`, `/api/ai/chat`) have graceful fallback responses when key is absent. Model is `gpt-4o-mini`.

## Alert pipeline (Wazuh → AI → human approval → incident)
Full flow as of this change:
1. **Receive Alert**: `POST /api/wazuh-connections/:id/ingest` accepts raw Wazuh alert JSON (single object, array, or `{ alerts: [...] }`) and normalizes into `alertsTable` with `status: "new"`. (The old `/sync` endpoint is still a no-op stub pending a real Wazuh API client.)
2. **Context Builder**: `artifacts/api-server/src/lib/contextBuilder.ts#buildAlertContext` pulls the last 5 related alerts (same agent or source IP) for situational context.
3. **Remove Sensitive Fields**: `contextBuilder.ts#redactSensitiveFields` strips `agentIp`, `sourceIp`, `rawLog` from the context before it's used in any prompt, returns the field names removed.
4. **AI Investigation**: first OpenAI call → summary/threatDescription/businessImpact/investigationSteps/affectedAssets/executiveSummary/confidenceScore.
5. **AI Recommendation**: second OpenAI call, given the investigation output → remediationPlan/recommendedActions/containmentActions/analystNotes.
6. Both are saved together into `alertAnalysesTable` with `reviewStatus: "pending_review"` and `redactedFields` recorded.
7. **Human Approval Needed**: `POST /api/alerts/:id/analysis/review` with `{ decision: "approve" | "reject" }`. Approve just flips `reviewStatus`; an analyst still separately calls `POST /api/incidents` to create one. Reject sets `reviewStatus: "rejected"` and marks the alert `falsePositive: true, status: "resolved"` (the "Ignore" path).
8. **Store Everything**: alerts, analyses (with redaction + review audit trail), incidents, and notes all persist in Postgres via Drizzle as before.

Schema additions: `alertAnalysesTable` now has `redactedFields` (text[]), `reviewStatus`, `reviewedBy`, `reviewedAt`, `reviewNote`. Also added explainability fields: `reasoning`, `rootCause`, `mitreExplanation`, `falsePositiveProbability`, `evidence` (text[]), `iocs` (jsonb), `investigationChecklist` (jsonb), `aiModelUsed`, `promptVersion`, `recommendationModified`. New table `alert_audit_log` records every analysis lifecycle event (generated/approved/rejected/recommendation_modified/comment_added) with actor + timestamp. New table `alert_comments` for the per-alert discussion thread, and `saved_alert_filters` for per-analyst filter presets. Run `pnpm --filter @workspace/db run push` after pulling this change.

## Alert Details page (frontend)
`artifacts/soc-platform/src/pages/alerts.tsx` is the only page with active development focus right now — full Core Alert Workflow: search, advanced filter popover (severity/status/review-status/agent/date range), saved filters, bulk actions (`POST /alerts/bulk`), pagination. Clicking a row opens `components/alert-detail-sheet.tsx`, a 3-tab sheet: "Alert Details" (MITRE, rule description, raw log, evidence, IOCs, investigation checklist, related alerts, previous occurrences), "AI Investigation" (reasoning, root cause, MITRE explanation, confidence + false-positive probability, AI model/prompt version, analysis timestamp), "Human Review" (modify recommendation, approve/reject, review comments, audit history timeline).

## Clerk proxy
Server uses `@clerk/express` with `clerkMiddleware` and the custom `clerkProxyMiddleware`. Frontend uses `publishableKeyFromHost` from `@clerk/react/internal` to resolve the key at runtime. `@clerk/themes` must be installed separately (it is a peer dep, not bundled).

## API codegen
Source of truth: `lib/api-spec/openapi.yaml`. Run `pnpm --filter @workspace/api-spec run codegen` after any spec change. Generated hooks in `@workspace/api-client-react`, Zod schemas in `@workspace/api-zod`.

## Demo data
Seeded via psql into `demo-org` / `demo-conn-1`. 150 alerts, 42 vulnerabilities, 6 agents, 5 incidents. Re-seed by re-running the psql seed commands.

**Why:** Async design subagent built UI while backend was constructed in parallel — both completed in the same session pass.
